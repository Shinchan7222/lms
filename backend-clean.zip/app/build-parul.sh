#!/bin/bash
# make sur to install jq , for mac( brew install jq ) ,  for debian ( sudo apt-get install jq ) 
# first attempt we need to push an image and tag it with a n > 54 without using the script
#npm i --only=dev
#npm run full-build
#npm run bprod
#rm -rdf node_modules
#pnpm i
#npm run build
# tar -czf dist.tar.gz dist
# tar -czf node_modules.tar.gz node_modules
# aws ecr get-login-password --region ap-south-1 --profile parul| docker login --username AWS --password-stdin 939984136438.dkr.ecr.ap-south-1.amazonaws.com/lms
#docker build -t lms -f ./docker/parul/edorer/Dockerfile . --no-cache
# REGION=ap-south-1
# TASK_FAMILY=lms
#LAST_TAG=$(aws ecr describe-images --output json --repository-name lms --query 'sort_by(imageDetails,& imagePushedAt)[-1].imageTags[0]' | jq . --raw-output)
#NEW_TAG=$(( LAST_TAG + 1 ))
# IMAGE_URI=939984136438.dkr.ecr.ap-south-1.amazonaws.com/lms:12
# docker tag lms:latest $IMAGE_URI
# docker push $IMAGE_URI
# TASK_DEFINITION=$(aws ecs describe-task-definition --task-definition "$TASK_FAMILY" --region "$REGION")
# NEW_TASK_DEFINITION=$(echo $TASK_DEFINITION | jq --arg IMAGE $IMAGE_URI '.taskDefinition | .containerDefinitions[0].image = $IMAGE | del(.taskDefinitionArn) | del(.revision) | del(.status) | del(.requiresAttributes) | del(.compatibilities) | del(.registeredAt) | del(.registeredBy) ')
# NEW_TASK=$(aws ecs register-task-definition --region "$REGION" --cli-input-json "$NEW_TASK_DEFINITION")
# NEW_REVISION=$(echo $NEW_TASK | jq '.taskDefinition.revision')
# aws ecs update-service --cluster edorer-lms-parul --service lms --task-definition ${TASK_FAMILY}:${NEW_REVISION}

docker build -t lms-parul -f ./docker/parul/edorer/Dockerfile .
VERSION=$(date +%Y%m%d)
docker tag lms-parul asia-south1-docker.pkg.dev/edorer-3e799/edorer/parul-lms:$VERSION
docker push asia-south1-docker.pkg.dev/edorer-3e799/edorer/parul-lms:$VERSION