import { Nems } from '@edorer/nems';
import { OpenBook, OpenBookIndexer } from '@edorer/open-book-data';
import { OpenBookCrudController } from '@edorer/open-book-api';

export class OpenBookApp {

    controllers = [
        OpenBookCrudController
    ];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'OpenBook', model: OpenBook }]);
        await OpenBookIndexer.index();
    }
}
