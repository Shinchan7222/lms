import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { ListFacade, UpdateFacade } from '@edorer/generic-facades';
import { Validate } from '@edorer/validator';
import { openBookRepository } from '@edorer/open-book-data';

@JsonController()
export class OpenBookCrudController {

    @Post('/open-books')
    @Validate([
        {
            field: 'title',
            validation: [{ value: 'notEmpty', message: 'Title is required' }]
        },
        {
            field: 'url',
            validation: [{ value: 'notEmpty', message: 'Open Book URL is required' }]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async create(@Req() req: any, @Res() res: any) {
        try {
            const { title, url } = req.body;

            await openBookRepository.create({
                title, url,
                owner: req.user._id,
                university: req.university._id
            });

            return res.status(201).send({ message: 'Open Book created successfully.' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/open-books')
    @Validate([
        {
            field: 'limit', validation: [
                { value: 'notEmpty', message: 'limit is required' }
            ]
        },
        {
            field: 'skip', validation: [
                { value: 'notEmpty', message: 'skip is required' }
            ]
        },
        'keyword'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async find(@Req() req: any, @Res() res: any) {
        try {
            const { keyword, limit, skip } = req.query;

            const facade = new ListFacade(req.user, req.university, +skip, +limit, keyword, ['title', 'url'], openBookRepository);
            const result = await facade.create();

            return res.status(200).send(result);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/open-books/:openBookId([0-9a-f]{24})')
    @Validate([
        {
            field: 'openBookId',
            validation: [{ value: 'notEmpty', message: 'Open Book ID is required' }]
        }
    ])
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async findOne(@Req() req: any, @Res() res: any, @Param('openBookId') openBookId: string) {
        try {
            const openBook = await openBookRepository.findOne({ _id: openBookId }).lean();

            return res.status(200).send(openBook);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Put('/open-books/:openBookId([0-9a-f]{24})')
    @Validate([
        {
            field: 'openBookId',
            validation: [{ value: 'notEmpty', message: 'Open Book ID is required' }]
        },
        {
            field: 'title',
            validation: [{ value: 'notEmpty', message: 'Open Book Title is required' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async update(@Req() req: any, @Res() res: any, @Param('openBookId') openBookId: string) {
        try {
            const facade = new UpdateFacade(openBookId, req.body, ['title', 'url'], openBookRepository);
            await facade.create();

            return res.status(201).send({ message: 'Open Book updated successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Put('/open-books/delete')
    @Validate([
        {
            field: 'ids',
            validation: [{ value: 'notEmpty', message: 'Please select open books to delete' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async delete(@Req() req: any, @Res() res: any) {
        try {
            const { ids } = req.body;
            await openBookRepository.destroy({ _id: { $in: ids } }, req.user);

            return res.status(201).send({ message: 'Open Book(s) deleted successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
