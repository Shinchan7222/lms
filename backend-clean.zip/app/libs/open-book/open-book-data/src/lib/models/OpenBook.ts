import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('OpenBook')
export class OpenBook extends MongooseModel {

    @field({
        ref: 'User',
        required: true,
        type: Types.ObjectId
    })
    owner: any;

    @field({
        required: true,
        trim: true,
        type: String
    })
    title: string;

    @field({
        required: true,
        trim: true,
        type: String
    })
    url: string;

    @field({
        ref: 'University',
        required: true,
        type: Types.ObjectId
    })
    university: any;

    @field({
        default: new Date(),
        type: Date
    })
    createdAt: Date;

    @field({
        type: Date,
        default: new Date()
    })
    updatedAt: Date;

    @post('save')
    async notifyCreate() {
        dbOperationsNotifier.notify('subject',
            {
                id: this._id,
                name: this.title,
                university: this.university,
                createdAt: this.createdAt
            },
            'create');
    }
}
