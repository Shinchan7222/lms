import { openBookRepository } from '@edorer/open-book-data';

export class OpenBookIndexer {

    static async index() {
        await openBookRepository.ensureIndex({ _id: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, title: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, title: 1, university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, title: 1, university: 1, url: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, title: 1, university: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, title: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, title: 1, url: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, title: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, university: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, university: 1, url: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, university: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1, url: 1 });
        await openBookRepository.ensureIndex({ _id: 1, owner: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1, university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1, university: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1, university: 1, url: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1, university: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1, url: 1 });
        await openBookRepository.ensureIndex({ _id: 1, title: 1 });
        await openBookRepository.ensureIndex({ _id: 1, university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, university: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, university: 1, url: 1 });
        await openBookRepository.ensureIndex({ _id: 1, university: 1 });
        await openBookRepository.ensureIndex({ _id: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ _id: 1, url: 1 });
        await openBookRepository.ensureIndex({ owner: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1, university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1, university: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1, university: 1, url: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1, university: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1, url: 1 });
        await openBookRepository.ensureIndex({ owner: 1, title: 1 });
        await openBookRepository.ensureIndex({ owner: 1, university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, university: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, university: 1, url: 1 });
        await openBookRepository.ensureIndex({ owner: 1, university: 1 });
        await openBookRepository.ensureIndex({ owner: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ owner: 1, url: 1 });
        await openBookRepository.ensureIndex({ owner: 1 });
        await openBookRepository.ensureIndex({ title: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ title: 1, university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ title: 1, university: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ title: 1, university: 1, url: 1 });
        await openBookRepository.ensureIndex({ title: 1, university: 1 });
        await openBookRepository.ensureIndex({ title: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ title: 1, url: 1 });
        await openBookRepository.ensureIndex({ title: 1 });
        await openBookRepository.ensureIndex({ university: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ university: 1, url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ university: 1, url: 1 });
        await openBookRepository.ensureIndex({ university: 1 });
        await openBookRepository.ensureIndex({ url: 1, deleted: 1 });
        await openBookRepository.ensureIndex({ url: 1 });
    }
}
