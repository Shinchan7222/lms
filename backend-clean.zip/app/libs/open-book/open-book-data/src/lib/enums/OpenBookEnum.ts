export enum OpenBookActionTypes {
    SELECT_ALL = 'SELECT_ALL',
    UNSELECT_ALL = 'UNSELECT_ALL'
}
