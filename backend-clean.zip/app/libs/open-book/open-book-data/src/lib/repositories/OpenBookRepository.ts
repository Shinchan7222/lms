import { MongooseRepository } from '@edorer/nems';

class OpenBookRepository extends MongooseRepository {
}

export let openBookRepository = new OpenBookRepository();
