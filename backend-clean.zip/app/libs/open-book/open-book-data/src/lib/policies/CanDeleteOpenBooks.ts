import { openBookRepository } from '../repositories/OpenBookRepository';
import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanDeleteOpenBooks implements ExpressMiddlewareInterface {
	async use(req: any, res: any, next?: (err?: any) => any) {
		const { ids, user } = req;
		if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
		if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

		const { type } = user;
		switch (type) {
			case UserTypes.APPLICANT:
			case UserTypes.APPLICANT_V2:
			case UserTypes.STUDENT: {
				return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
			}

			case UserTypes.UNIVERSITY_MEMBER: {
				const { role } = user;

				if (role === null) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
				if (role === undefined) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
				if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });

				const { openBooks } = role;
				if (openBooks === null) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
				if (openBooks === undefined) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
				if (Object.keys(openBooks).length === 0)
					return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });

				if (openBooks.delete === null) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
				if (openBooks.delete === undefined) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
				if (openBooks.delete === false) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });

				break;
			}

			case UserTypes.TEACHER: {
				const count = await openBookRepository.count({
					_id: { $in: ids },
					$or: [{ owner: user._id }, { editors: { $in: user._id } }],
				});

				if (count !== ids.length) return res.status(401).send({ message: 'You do not have permission to delete openBook(s).' });
				break;
			}

			default:
				break;
		}

		next();
	}
}
