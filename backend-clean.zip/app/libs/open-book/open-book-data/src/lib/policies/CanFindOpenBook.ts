import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanFindOpenBook implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to view openBook.' });

    const { openBookId } = params;
    if (openBookId === null) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
    if (openBookId === undefined) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
    if (Types.ObjectId.isValid(openBookId) === false) return res.status(401).send({ message: 'You do not have permission to view openBook.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        if (String(openBookId) !== String(user._id)) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
        break;
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view openBook.' });

        const { openBooks } = role;
        if (openBooks === null) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
        if (openBooks === undefined) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
        if (Object.keys(openBooks).length === 0) return res.status(401).send({ message: 'You do not have permission to view openBook.' });

        const { read } = openBooks;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view openBook.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view openBook.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
