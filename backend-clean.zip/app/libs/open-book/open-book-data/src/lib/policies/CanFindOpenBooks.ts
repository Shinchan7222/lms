import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanFindOpenBooks implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to view openBooks.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });

        const { openBooks } = role;
        if (openBooks === null) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });
        if (openBooks === undefined) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });
        if (Object.keys(openBooks).length === 0) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });

        const { read } = openBooks;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view openBooks.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
