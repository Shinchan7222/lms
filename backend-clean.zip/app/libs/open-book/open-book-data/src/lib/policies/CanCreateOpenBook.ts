import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanCreateOpenBook implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to create openBook.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to create openBook.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to create openBook.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to create openBook.' });

        const { openBooks } = role;
        if (openBooks === null) return res.status(401).send({ message: 'You do not have permission to create openBook.' });
        if (openBooks === undefined) return res.status(401).send({ message: 'You do not have permission to create openBook.' });
        if (Object.keys(openBooks).length === 0) return res.status(401).send({ message: 'You do not have permission to create openBook.' });

        const { write } = openBooks;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to create openBook.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to create openBook.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to create openBook.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
