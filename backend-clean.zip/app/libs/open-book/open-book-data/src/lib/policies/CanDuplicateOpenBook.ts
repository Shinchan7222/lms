import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';
import { Types } from 'mongoose';
import { openBookRepository } from '../repositories/OpenBookRepository';

export class CanDuplicateOpenBook implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { body, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (body === null) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
    if (body === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
    if (Object.keys(body).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });

    const { openBookId } = body;
    if (openBookId === null) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
    if (openBookId === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
    if (Types.ObjectId.isValid(openBookId) === false) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });

        const { openBooks } = role;
        if (openBooks === null) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
        if (openBooks === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
        if (Object.keys(openBooks).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });

        const { write } = openBooks;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await openBookRepository.count({
          _id: openBookId,
          $or: [{ owner: user._id }, { editors: { $in: user._id } }]
        });

        if (count === 0) return res.status(401).send({ message: 'You do not have permission to duplicate openBook.' });
        break;
      }

      default:
        break;
    }

    next();
  }
}
