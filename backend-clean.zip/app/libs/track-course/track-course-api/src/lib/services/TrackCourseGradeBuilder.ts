const binarysearch = require('binarysearch');
import { CourseGrade } from '@edorer/course-data';

export class TrackCourseGradeBuilder {

    static grade(courseGrade: CourseGrade, score: number): string {
        const courseScores = Object.values(courseGrade);
        const sortedScores = [...courseScores].sort((a, b) => a - b);

        const closestScore = binarysearch.closest(sortedScores, score);

        if (closestScore !== -1) {
            const grade = Object.keys(courseGrade).find(key => courseGrade[key] === sortedScores[closestScore]);

            if (score < courseGrade[grade]) {
                return 'f';
            }

            return grade;
        } else {
            return 'f';
        }
    }
}
