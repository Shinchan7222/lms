import { CoursePageContentTypes } from '@edorer/course-data';
import { CourseRubricUpdater } from '@edorer/track-course-api';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { TrackCourse, trackCourseRepository } from '@edorer/track-course-data';
import { TrackProgramProgressUpdater } from '@edorer/track-program-api';
import { User } from '@edorer/user-data';

export class TrackCourseLectureUpdater {
  private lecture: Lecture;

  private trackCourse: TrackCourse;

  private readonly courseId: string;

  private readonly currentUser: User;

  private readonly lectureCondition: Record<string, string> = {};

  private readonly pageContentType: CoursePageContentTypes;

  constructor(courseId: string, lectureCondition: Record<string, string>, pageContentType: CoursePageContentTypes, currentUser: User) {
    this.courseId = courseId;
    this.currentUser = currentUser;
    this.lectureCondition = lectureCondition;
    this.pageContentType = pageContentType;
  }

  public async update() {
    try {
      await Promise.all([this.fetchTrackCourse(), this.fetchLecture()]);
      await this.updateCourseProgress();
    } catch (error) {
      throw new Error((error as Error).message);
    }
  }

  private async fetchLecture() {
    if (!this.courseId) return;
    this.lecture = await lectureRepository.findOne({ ...this.lectureCondition, course: this.courseId }).lean();
  }

  private async fetchTrackCourse() {
    if (!this.courseId) return;
    this.trackCourse = await trackCourseRepository.findOne({ course: this.courseId, user: this.currentUser._id }).lean();
  }

  private async updateCourseProgress() {
    if (!this.courseId) return;
    if (!this.lecture) return;
    if (!this.lecture._id) return;
    if (!this.trackCourse) return;
    if (!this.trackCourse._id) return;

    const { completedLectures } = this.trackCourse;
    const completedLectureIds = completedLectures.map((o) => o.toString());

    if (completedLectureIds.includes(this.lecture._id.toString())) return;

    const { pages = [] } = this.lecture;
    if (pages.length === 0) return;

    const [page] = this.lecture.pages;
    if (!page) return;

    const { contentType } = page;
    if (contentType !== this.pageContentType) return;

    const updater = new TrackProgramProgressUpdater(this.courseId, this.lecture._id, this.currentUser);
    await updater.update();

    const updateCourse = new CourseRubricUpdater(this.courseId, this.currentUser);
    await updateCourse.update();
  }
}
