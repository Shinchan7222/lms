import { QuestionTypes } from '@edorer/question-data';
import { User } from '@edorer/user-data';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { trackCourseRepository, TrackCourse } from '@edorer/track-course-data';

export class TrackCourseAddAnswer {

    private lecture: Lecture;

    private page: any;

    private trackCourse: TrackCourse;

    private readonly answer: any;

    private readonly answerInput: any;

    private readonly compiledResult: any;

    private readonly courseId: string;

    private readonly currentUser: User;

    private readonly lectureId: string;

    private readonly pageId: string;

    private readonly questionId?: string;

    constructor(
        courseId: string, lectureId: string, pageId: string,
        questionId: string, answerInput: any, currentUser: User, compiledResult?: any
    ) {
        this.answerInput = answerInput;
        this.compiledResult = compiledResult;
        this.courseId = courseId;
        this.currentUser = currentUser;
        this.lectureId = lectureId;
        this.pageId = pageId;
        this.questionId = questionId;

        this.answer = { questionId, lectureId, answer: [...answerInput] };

        if (this.compiledResult) {
            const { isCorrect, ...result } = this.compiledResult;
            this.answer = { ...this.answer, compiledResult: { ...result } };
        }
    }

    async add(): Promise<TrackCourse> {
        await this.fetchLecture();
        this.currentPage();
        this.checkCorrect();
        await this.fetchTrackCourse();
        this.checkAnswerExistence();
        this.addAnswer();

        return await this.trackCourse.save();
    }

    private async fetchLecture(): Promise<void> {
        this.lecture = await lectureRepository
            .findOne({ _id: this.lectureId })
            .populate('pages.question')
            .lean();

        if (!this.lecture) {
            throw new Error('Lecture not found!');
        }
    }

    private currentPage() {
        this.page = this.lecture.pages.find(page => page._id.toString() === this.pageId.toString());

        if (!this.page) {
            throw new Error('Page not found');
        }
    }

    private checkCorrect() {
        if (this.page.question.type === QuestionTypes.SINGLE_SELECT
            || this.page.question.type === QuestionTypes.LIKERT_SCALE) {
            const selectedOption = this.page.question.options.find(option => option.content === this.answerInput[0]);

            if (!selectedOption) {
                throw new Error('Option not found');
            }
            this.answer.isCorrect = selectedOption.isCorrect;
        } else if (this.page.question.type === QuestionTypes.MULTIPLE_SELECT) {
            this.answer.isCorrect = this.page.question.options.every(option => {
                if (this.answerInput.includes(option.content)) {
                    return option.isCorrect;
                }

                return true;
            });
        } else if (this.page.question.type === QuestionTypes.ORDERING || this.page.question.type === QuestionTypes.MATCHING) {
            this.answer.isCorrect = this.answer.answer.every((value: string, index, array) => !index || (value > array[index - 1]));
        } else if (this.page.question.type === QuestionTypes.PROGRAMMING) {
            this.answer.isCorrect = this.compiledResult.verdictDetails.isAccepted;
        }
    }

    private async fetchTrackCourse() {
        this.trackCourse = await trackCourseRepository.findOne({ course: this.courseId, user: this.currentUser._id });

        if (!this.trackCourse) {
            this.trackCourse = await trackCourseRepository.create({ course: this.courseId, user: this.currentUser._id });
        }
    }

    private checkAnswerExistence() {
        const existingIndex = this.trackCourse.questionsAnswers.findIndex((o) => o.questionId.toString() === this.questionId.toString());

        if (existingIndex !== -1) {
            throw new Error('Question already answered');
        }
    }

    private addAnswer() {
        this.trackCourse.questionsAnswers.push(this.answer);
    }
}
