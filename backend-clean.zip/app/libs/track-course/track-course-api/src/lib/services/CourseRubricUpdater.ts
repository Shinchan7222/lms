import { Course, courseCertificateRepository, CoursePageContentTypes, courseRepository, CourseRubricData } from '@edorer/course-data';
import { CustomMail } from '@edorer/custom-mailer';
import { lectureRepository } from '@edorer/lecture-data';
import { TrackAssignment, trackAssignmentRepository } from '@edorer/track-assignment-data';
import { TrackCourse, trackCourseRepository } from '@edorer/track-course-data';
import { TrackCourseGradeBuilder } from './TrackCourseGradeBuilder';
import { TrackExam, trackExamRepository } from '@edorer/track-exam-data';
import { universityRepository } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import * as moment from 'moment';

export class CourseRubricUpdater {
  private assignments: string[] = [];

  private course: Course;

  private exams: string[] = [];

  private lectures: any[] = [];

  private readonly courseId: string;

  private readonly owner: User;

  private score = 0;

  private trackCourse: TrackCourse;

  constructor(courseId: string, owner: User) {
    this.courseId = courseId;
    this.owner = owner;
  }

  async update() {
    await this.fetchCourse();
    await this.fetchTrackCourse();

    if (!this.trackCourse.enableProgress && this.trackCourse.isFreezed) {
      return;
    }

    this.separateContents();

    await this.calculateExamsScore();
    await this.calculateAssignmentsScore();
    await this.calculateLecturesScore();

    this.calculateProgressScore();

    await this.updateTrackScore();
    await this.manageCertificate();
  }

  private async fetchCourse() {
    this.course = await courseRepository.findOne({ _id: this.courseId }).lean();

    if (!this.course) {
      throw new Error('Course not found');
    }
  }

  private async fetchTrackCourse() {
    this.trackCourse = await trackCourseRepository
      .findOne({ course: this.courseId, user: this.owner._id })
      .populate({ path: 'completedLectures', populate: 'pages.question' })
      .populate({ path: 'course' })
      .lean();

    if (!this.trackCourse) {
      throw new Error('Track not found');
    }
  }

  private separateContents() {
    for (let completedLecture of this.trackCourse.completedLectures) {
      const hasAssignment = completedLecture.pages.some((page) => page.contentType === CoursePageContentTypes.ASSIGNMENT);
      const hasExam = completedLecture.pages.some((page) => page.contentType === CoursePageContentTypes.EXAM);

      if (hasExam) {
        const exams = completedLecture.pages.filter((page) => page.contentType === CoursePageContentTypes.EXAM);
        this.exams.push(...exams.map((page) => page.exam));
      }

      if (hasAssignment) {
        const assignments = completedLecture.pages.filter((page) => page.contentType === CoursePageContentTypes.ASSIGNMENT);
        this.assignments.push(...assignments.map((page) => page.assignment));
      }

      if (!hasExam && !hasAssignment) {
        this.lectures.push(completedLecture._id);
      }
    }
  }

  private async calculateLecturesScore() {
    const options = this.course.rubric.lecture.options;
    const lectures = await lectureRepository.count({ course: this.courseId });
    for (let lecture of this.lectures) {
      if (this.course.rubric.lecture.globalWeightageEnabled) {
        this.score += Math.floor(this.course.rubric.lecture.globalWeightage / lectures);
      } else if (this.course.rubric.lecture.weightageEnabled) {
        if (options.length > 0) {
          const option = options.find((op) => op.id.toString() === lecture.toString());
          if (option) {
            this.score += option.weightage;
          } else {
            this.score += 0;
          }
        }
      }
    }
  }

  private async calculateAssignmentsScore() {
    const percentages = [];

    for (let assignment of this.assignments) {
      const trackAssignment: TrackAssignment = await trackAssignmentRepository
        .findOne({ assignment, user: this.owner._id })
        .sort({ startedAt: -1 })
        .lean();

      if (!trackAssignment) {
        percentages.push(0);
      } else {
        percentages.push(trackAssignment.percentage);
      }
    }

    if (this.course.rubric && this.course.rubric.assignment) {
      this.calculateScoreFromRubric(percentages, this.assignments, this.course.rubric.assignment);
    }
  }

  private async calculateExamsScore() {
    const percentages = [];

    for (let exam of this.exams) {
      const trackExam: TrackExam = await trackExamRepository.findOne({ user: this.owner._id, exam }).sort({ startedAt: -1 }).lean();

      if (!trackExam) {
        percentages.push(0);
      } else {
        percentages.push(trackExam.percentage);
      }
    }

    if (this.course.rubric && this.course.rubric.exam) {
      this.calculateScoreFromRubric(percentages, this.exams, this.course.rubric.exam);
    }
  }

  private calculateScoreFromRubric(percentages: number[], ids: string[], rubricValue: CourseRubricData) {
    for (let index = 0; index < ids.length; index++) {
      const id = ids[index];
      const percentage = percentages[index];
      const globalPercentage = (Math.floor(rubricValue.globalWeightage / ids.length) / 100) * percentage;

      if (rubricValue.globalWeightageEnabled) {
        this.score += globalPercentage;
      } else if (rubricValue.weightageEnabled) {
        const option = rubricValue.options.find((rubricOption) => rubricOption.id.toString() === id.toString());
        if (option) {
          this.score += ((option.weightage || 0) / 100) * percentage;
        }
      }
    }
  }

  private async updateTrackScore() {
    const grade = TrackCourseGradeBuilder.grade(this.trackCourse.course.grade, this.score);

    await trackCourseRepository.update({ _id: this.trackCourse._id }, { score: this.score, grade }, { multi: false });
  }

  private async manageCertificate(): Promise<void> {
    const university = await universityRepository.findOne({ _id: this.owner.university }).lean();
    if (this.trackCourse.progress === 100 && this.course.haveCertificate && this.score >= this.course.minPoint) {
      const mail = new CustomMail(this.owner.email, 'Certificate for ' + this.course.title, this.course.certificate, {
        student: {
          name: this.owner.name,
          email: this.owner.email
        },
        course: this.course,
        generatedAt: moment().format('MMMM Do YYYY')
      });
      mail.init(university);
      await mail.send();
      await courseCertificateRepository.create({
        course: this.courseId,
        user: this.owner._id,
        university: university._id
      });
    }
  }

  private calculateProgressScore() {
    const { progress } = this.course.rubric;
    if (!progress) {
      return;
    }

    const { globalWeightage, globalWeightageEnabled, weightage = 0, weightageCondition = 0, weightageEnabled = false } = progress;

    if (globalWeightageEnabled) {
      this.score += globalWeightage;
      return;
    }

    if (!weightageEnabled) {
      return;
    }

    if (this.trackCourse.progress >= weightageCondition) {
      this.score += weightage;
    }
  }
}
