import { CodeCompiler } from '@edorer/compiler';
import { CourseRubricUpdater } from '../services/CourseRubricUpdater';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { IsAuthenticated } from '@edorer/user-data';
import { TrackCourseAddAnswer } from '../services/TrackCourseAddAnswer';
import { trackCourseRepository } from '@edorer/track-course-data';
import { TrackProgramProgressUpdater } from '@edorer/track-program-api';
import { Validate } from '@edorer/validator';

/**
 * @description Crud Operation Controller For Track Course
 */
@JsonController()
export class TrackCourseController {
  /**
   * @description Get One track course by ID
   */
  @Get('/track-courses/course/:course([0-9a-f]{24})')
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async get(@Req() req: any, @Res() res: any, @Param('course') course: string) {
    try {
      let trackCourse = await trackCourseRepository.findOne({ course, user: req.user._id }).lean();

      if (!trackCourse) {
        trackCourse = await trackCourseRepository.create({ course, user: req.user._id });
      }

      return res.status(200).send(trackCourse);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Update track course on program
   */
  @Put('/track-courses/course/:course([0-9a-f]{24})')
  @Validate([
    {
      field: 'lecture',
      validation: [{ value: 'notEmpty', message: 'lecture is required' }]
    },
    {
      field: 'course',
      validation: [{ value: 'notEmpty', message: 'course is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async updateLectureStatus(@Req() req: any, @Res() res: any, @Param('course') courseId: string) {
    const { lecture } = req.body;

    try {
      const updater = new TrackProgramProgressUpdater(courseId, lecture, req.user);
      const trackCourse = await updater.update();

      const updateCourse = new CourseRubricUpdater(courseId, req.user);
      await updateCourse.update();

      return res.status(201).send(trackCourse);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Create track course
   */
  @Post('/track-courses/quiz')
  @Validate([
    {
      field: 'answer',
      validation: [{ value: 'notEmpty', message: 'answer is required' }]
    },
    {
      field: 'lecture',
      validation: [{ value: 'notEmpty', message: 'lecture is required' }]
    },
    {
      field: 'course',
      validation: [{ value: 'notEmpty', message: 'course is required' }]
    },
    {
      field: 'page',
      validation: [{ value: 'notEmpty', message: 'page is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async answerQuiz(@Req() req: any, @Res() res: any) {
    try {
      const { answer, lecture, course, page } = req.body;

      const trackCourseAddAnswer = new TrackCourseAddAnswer(course, lecture, page, page, answer, req.user);
      const trackCourse = trackCourseAddAnswer.add();

      return res.status(201).send(trackCourse);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Update track course question content programming
   */
  @Post('/track-courses/compile/:trackCourseId([0-9a-f]{24})')
  @Validate([
    {
      field: 'trackCourseId',
      validation: [{ value: 'notEmpty', message: 'trackExamId is required' }]
    },
    {
      field: 'lecture',
      validation: [{ value: 'notEmpty', message: 'lecture is required' }]
    },
    {
      field: 'course',
      validation: [{ value: 'notEmpty', message: 'course is required' }]
    },
    {
      field: 'page',
      validation: [{ value: 'notEmpty', message: 'page is required' }]
    },
    {
      field: 'answer',
      validation: [{ value: 'notEmpty', message: 'answer is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async compile(@Req() req: any, @Res() res: any, @Param('trackCourseId') trackCourseId: string) {
    const { answer, lecture, course, page } = req.body;

    let query: any = {};

    const compiler = new CodeCompiler(answer, answer.question);

    if (answer.isSubmission) {
      query = compiler.judgeSubmission(false);
    } else {
      query = compiler.judge();
    }

    try {
      const result = await query;
      if (answer.isSubmission) {
        const trackCourseAddAnswer = new TrackCourseAddAnswer(course, lecture, page, page, [answer.files[0].content], req.user, {
          isCorrect: result.verdictDetails.isAccepted,
          ...result
        });
        await trackCourseAddAnswer.add();
      }

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Update track course question content programming
   */
  @Put('/track-courses/update-progress-ability/:trackCourseId([0-9a-f]{24})')
  @Validate([
    {
      field: 'trackCourseId',
      validation: [{ value: 'notEmpty', message: 'trackExamId is required' }]
    },
    {
      field: 'enableProgress',
      validation: [{ value: 'notEmpty', message: 'Status is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async changeProgressAbility(@Req() req: any, @Res() res: any, @Param('trackCourseId') trackCourseId: string) {
    try {
      const { enableProgress } = req.body;
      await trackCourseRepository.update({ _id: trackCourseId }, { $set: { enableProgress } }, { multi: false });

      return res.status(200).send({ message: 'Changed successfully.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
