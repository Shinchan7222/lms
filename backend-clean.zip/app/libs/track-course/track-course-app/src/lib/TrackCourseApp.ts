import { Nems } from '@edorer/nems';
import { TrackCourse, TrackCourseIndexer } from '@edorer/track-course-data';
import { TrackCourseController } from '@edorer/track-course-api';

export class TrackCourseApp {

    controllers = [TrackCourseController];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'TrackCourse', model: TrackCourse }]);
        await TrackCourseIndexer.index();
    }
}
