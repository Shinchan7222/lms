export enum TrackCourseStatus {
  ENDED = 'ended',
  IN_PROGRESS = 'inProgress',
  NOT_STARTED = 'notStarted'
}
