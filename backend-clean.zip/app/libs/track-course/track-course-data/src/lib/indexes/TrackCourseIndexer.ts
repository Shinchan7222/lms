import { trackCourseRepository } from '@edorer/track-course-data';

export class TrackCourseIndexer {
  static async index() {
    await trackCourseRepository.ensureIndex({ _id: 1, deleted: 1 });
    await trackCourseRepository.ensureIndex({ completedLectures: 1, course: 1, user: 1, deleted: 1 });
    await trackCourseRepository.ensureIndex({ course: 1, deleted: 1 });
    await trackCourseRepository.ensureIndex({ course: 1, progress: 1, deleted: 1 });
    await trackCourseRepository.ensureIndex({ course: 1, user: 1, deleted: 1 });
    await trackCourseRepository.ensureIndex({ user: 1, deleted: 1 });
  }
}
