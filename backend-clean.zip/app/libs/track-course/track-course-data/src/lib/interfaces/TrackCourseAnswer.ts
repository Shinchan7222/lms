import { CompiledResult } from '@edorer/compiler';

export interface TrackCourseAnswer {

    _id: string;

    answer: string[];

    compiledResult?: CompiledResult;

    createdAt: Date;

    isCorrect: boolean;

    lectureId: string;

    questionId: string;
}
