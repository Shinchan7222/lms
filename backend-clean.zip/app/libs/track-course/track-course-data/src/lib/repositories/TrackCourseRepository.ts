import { MongooseRepository } from '@edorer/nems';

class TrackCourseRepository extends MongooseRepository { }

export const trackCourseRepository = new TrackCourseRepository();
