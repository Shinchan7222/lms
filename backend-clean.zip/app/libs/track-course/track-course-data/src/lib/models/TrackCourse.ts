import { Lecture } from '@edorer/lecture-data';
import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Schema, Types } from 'mongoose';
import { TrackCourseAnswer } from '../interfaces/TrackCourseAnswer';

@Model('TrackCourse')
export class TrackCourse extends MongooseModel {
  @field([
    {
      ref: 'Lecture',
      required: true,
      type: Types.ObjectId
    }
  ])
  completedLectures: any[];

  @field([
    {
      completedAt: {
        default: new Date(),
        type: Date
      },
      lecture: {
        ref: 'Lecture',
        required: true,
        type: Types.ObjectId
      }
    }
  ])
  lectureCompletionTimelines: Array<{ completedAt: Date; lecture: string | Lecture }>;

  @field({
    default: false,
    type: Boolean
  })
  enableProgress: boolean;

  @field({
    default: false,
    type: Boolean
  })
  isFreezed: boolean;

  @field([
    {
      answer: [
        {
          type: String
        }
      ],
      compiledResult: {
        editorLanguage: {
          type: String
        },
        editorMode: {
          type: String
        },
        editorTheme: {
          type: String
        },
        hiddenEvaluations: [
          {
            elapsedTime: {
              type: Number
            },
            expectedOutput: {
              type: String
            },
            input: {
              type: String
            },
            memory: {
              type: Number
            },
            output: {
              type: String
            }
          }
        ],
        verdicts: [{ type: Boolean }],
        verdictDetails: {
          content: {
            type: String
          },
          isAccepted: {
            type: Boolean
          },
          stderr: {
            type: String
          },
          stdout: {
            type: String
          },
          type: {
            enum: [],
            type: String
          }
        },
        visibleEvaluations: [
          {
            elapsedTime: {
              type: Number
            },
            expectedOutput: {
              type: String
            },
            input: {
              type: String
            },
            memory: {
              type: Number
            },
            output: {
              type: String
            }
          }
        ]
      },
      createdAt: {
        default: new Date(),
        type: Date
      },
      isCorrect: {
        type: Boolean
      },
      lectureId: {
        ref: 'Lecture',
        type: Types.ObjectId
      },
      questionId: {
        type: Types.ObjectId
      }
    }
  ])
  questionsAnswers: TrackCourseAnswer[];

  @field({
    ref: 'User',
    required: true,
    type: Types.ObjectId
  })
  user: any;

  @field({
    ref: 'Course',
    type: Types.ObjectId
  })
  course: any;

  @field({
    type: Schema.Types.Mixed
  })
  activityByDate: any[];

  @field([
    {
      createdAt: {
        default: new Date(),
        type: Date
      },
      activity: {
        type: String
      }
    }
  ])
  activityLogs: any[];

  @field({
    type: String
  })
  grade: string;

  @field({
    type: Number
  })
  score: number;

  @field({
    type: Number
  })
  progress: number;

  @field([
    {
      chapter: { ref: 'Chapter', type: Types.ObjectId },
      restrictDate: { type: Date }
    }
  ])
  chapterRestrictions: Array<{ chapter: string; restrictDate: Date }>;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  @post('save')
  async notifyCreate() {
    dbOperationsNotifier.notify(
      'trackCourse',
      {
        id: this._id,
        course: this.course,
        createdAt: this.createdAt,
        user: this.user
      },
      'create'
    );
  }
}
