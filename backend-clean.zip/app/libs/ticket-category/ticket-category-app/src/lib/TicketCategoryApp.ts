import { TicketCategory, TicketCategoryIndexer } from '@edorer/ticket-category-data';
import { TicketCategoryCrudController, TicketSubCategoryController } from '@edorer/ticket-category-api';
import { Nems } from '@edorer/nems';

export class TicketCategoryApp {
  controllers = [TicketCategoryCrudController, TicketSubCategoryController];

  constructor() {
    this.initDB();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'TicketCategory', model: TicketCategory }]);
    await TicketCategoryIndexer.index();
  }
}
