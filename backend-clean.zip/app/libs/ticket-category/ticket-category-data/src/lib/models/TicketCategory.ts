import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('TicketCategory')
export class TicketCategory extends MongooseModel {
  @field({
    type: Types.ObjectId,
    ref: 'User'
  })
  creator: any;

  @field({
    trim: true,
    type: String
  })
  name: string;

  @field([
    {
      type: Types.ObjectId
    }
  ])
  ticketSubCategories: string[];

  @field({
    type: Types.ObjectId,
    ref: 'University',
    required: true
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  @post('save')
  async notifyCreate() {
    dbOperationsNotifier.notify(
      'ticketCategory',
      {
        id: this._id,
        name: this.name,
        university: this.university,
        creator: this.creator
      },
      'create'
    );
  }
}
