import { ticketCategoryRepository } from '@edorer/ticket-category-data';

export class TicketCategoryIndexer {
  static async index() {
    await ticketCategoryRepository.ensureIndex({ _id: 1, deleted: 1 });
    await ticketCategoryRepository.ensureIndex({ department: 1, university: 1, deleted: 1 });
    await ticketCategoryRepository.ensureIndex({ name: 1, deleted: 1 });
    await ticketCategoryRepository.ensureIndex({ name: 1, university: 1, deleted: 1 });
    await ticketCategoryRepository.ensureIndex({ university: 1, deleted: 1 });
  }
}
