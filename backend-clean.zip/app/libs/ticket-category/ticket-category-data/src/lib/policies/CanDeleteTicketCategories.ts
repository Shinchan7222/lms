import { ticketCategoryRepository } from '../repositories/TicketCategoryRepository';
import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanDeleteTicketCategories implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { body, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (body === null) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
    if (body === undefined) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
    if (Object.keys(body).length === 0) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });

    const { ids } = body;
    if (Array.isArray(ids) === false) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
    if (ids.length === 0) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });

    const role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });

        const { ticketCategories } = role;
        if (ticketCategories === null) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
        if (ticketCategories === undefined) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
        if (Object.keys(ticketCategories).length === 0)
          return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });

        if (ticketCategories.delete === null) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
        if (ticketCategories.delete === undefined)
          return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });
        if (ticketCategories.delete === false) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await ticketCategoryRepository.count({ _id: { $in: ids }, owner: user._id });
        if (count !== ids.length) return res.status(401).send({ message: 'You do not have permission to delete ticketCategory(s).' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
