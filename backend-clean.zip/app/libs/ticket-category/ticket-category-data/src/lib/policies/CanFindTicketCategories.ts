import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanFindTicketCategories implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });

        const { ticketCategories } = role;
        if (ticketCategories === null) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });
        if (ticketCategories === undefined) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });
        if (Object.keys(ticketCategories).length === 0) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });

        const { read } = ticketCategories;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view ticket categories.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
