import { ticketCategoryRepository } from '../repositories/TicketCategoryRepository';
import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanUpdateTicketCategory implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });

    const { ticketCategoryId } = params;
    if (ticketCategoryId === null) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
    if (ticketCategoryId === undefined) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
    if (Types.ObjectId.isValid(ticketCategoryId) === false) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });

    const role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });

        const { ticketCategories } = role;
        if (ticketCategories === null) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
        if (ticketCategories === undefined) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
        if (Object.keys(ticketCategories).length === 0) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });

        const { write } = ticketCategories;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await ticketCategoryRepository.count({ _id: ticketCategoryId, owner: user._id });
        if (count === 0) return res.status(401).send({ message: 'You do not have permission to update ticket-category.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
