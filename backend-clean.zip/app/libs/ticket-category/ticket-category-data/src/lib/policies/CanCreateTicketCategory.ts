import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanCreateTicketCategory implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });

        const { ticketCategories } = role;
        if (ticketCategories === null) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });
        if (ticketCategories === undefined) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });
        if (Object.keys(ticketCategories).length === 0)
          return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });

        const { write } = ticketCategories;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to create ticket-category.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
