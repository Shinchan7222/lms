import { MongooseRepository } from '@edorer/nems';

class TicketCategoryRepository extends MongooseRepository {}

export let ticketCategoryRepository = new TicketCategoryRepository();
