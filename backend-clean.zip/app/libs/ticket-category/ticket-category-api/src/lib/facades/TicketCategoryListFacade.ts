import { ticketCategoryRepository } from '@edorer/ticket-category-data';
import { ListFacade } from '@edorer/generic-facades';
import { Role } from '@edorer/role-data';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';

export class TicketCategoryListFacade {
  private readonly action: string;

  private readonly currentUser: User;

  private readonly facade: ListFacade;

  private readonly keyword: string;

  private readonly limit: number;

  private readonly skip: number;

  private readonly university: University;

  constructor(action: string, keyword: string, limit: number, skip: number, currentUser: User, university: University) {
    this.action = action;
    this.currentUser = currentUser;
    this.keyword = keyword;
    this.limit = limit;
    this.skip = skip;
    this.university = university;

    this.facade = new ListFacade(null, this.university, +this.skip, +this.limit, this.keyword, ['name'], ticketCategoryRepository, false);
  }

  async create() {
    await this.addConditions();
    return this.result();
  }

  private async addConditions() {
    await this.checkAction();
    await this.checkUserRole();
  }

  private async checkAction() {
    if (this.action && this.action === 'DELETE') {
      this.facade.query = ticketCategoryRepository.destroy(this.facade.condition, this.currentUser._id);
      await this.facade.create();
    }
  }

  private async checkUserRole() {
    if (this.currentUser.type === UserTypes.UNIVERSITY_MEMBER) {
      const conditions: any = [{ creator: this.currentUser._id }];
      const { role } = this.currentUser;
      const userRole = new Role(role);

      if (userRole && userRole.ticketCategories && userRole.ticketCategories.read) {
        const ticketCategoryCondition = await userRole.createCondition(this.currentUser.university);

        if (Object.keys(ticketCategoryCondition).length > 0) {
          conditions.push({ _id: ticketCategoryCondition });
        }
      }

      this.facade.addConditions({ $and: [{ $or: conditions }] });
    }
  }

  private async result() {
    this.facade.prepareQuery();

    return await this.facade.create();
  }
}
