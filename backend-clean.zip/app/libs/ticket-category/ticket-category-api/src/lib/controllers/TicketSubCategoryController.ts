import { CanUpdateTicketCategory, ticketCategoryRepository } from '@edorer/ticket-category-data';
import { Delete, JsonController, Param, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

/* this class responsible for Update and Delete SubTicketCategory on TicketCategory */

@JsonController()
export class TicketSubCategoryController {
	/* Update SubTicketCategory */
	@Put('/ticketCategories/:ticketCategoryId([0-9a-f]{24})/sub-ticketCategory/:subTicketCategory([0-9a-f]{24})')
	@Validate([
		{
			field: 'ticketCategoryId',
			validation: [{ value: 'notEmpty', message: 'TicketCategory ID is required' }],
		},
		{
			field: 'subTicketCategory',
			validation: [{ value: 'notEmpty', message: 'subTicketCategory is required' }],
		},
	])
	@UseBefore(IsAuthenticated, CanUpdateTicketCategory)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async addSubTicketCategory(@Req() req: any, @Res() res: any, @Param('ticketCategoryId') ticketCategoryId: string, @Param('subTicketCategory') subTicketCategory: string) {
		try {
			const cat = await ticketCategoryRepository.findOneAndUpdate({ _id: ticketCategoryId }, { $addToSet: { ticketSubCategories: subTicketCategory } });
			return res.send(cat);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}

	/* Delete SubTicketCategory*/
	@Delete('/ticketCategories/:ticketCategory([0-9a-f]{24})/sub-ticketCategory/:subTicketCategory([0-9a-f]{24})')
	@Validate([
		{
			field: 'ticketCategory',
			validation: [{ value: 'notEmpty', message: 'ticketCategory is required' }],
		},
		{
			field: 'subTicketCategory',
			validation: [{ value: 'notEmpty', message: 'subTicketCategory is required' }],
		},
	])
	@UseBefore(IsAuthenticated)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async deleteSubTicketCategory(@Req() req: any, @Res() res: any, @Param('ticketCategory') ticketCategory: string, @Param('subTicketCategory') subTicketCategory: string) {
		try {
			const cat = await ticketCategoryRepository.findOneAndUpdate({ _id: ticketCategory }, { $pullAll: { ticketSubCategories: [subTicketCategory] } });
			return res.send(cat);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}
}
