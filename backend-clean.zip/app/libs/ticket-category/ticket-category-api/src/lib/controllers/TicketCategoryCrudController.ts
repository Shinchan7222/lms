import {
  CanCreateTicketCategory,
  CanDeleteTicketCategories,
  CanFindTicketCategories,
  CanUpdateTicketCategory,
  ticketCategoryRepository
} from '@edorer/ticket-category-data';
import { TicketCategoryListFacade } from '../facades/TicketCategoryListFacade';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { HasUser, IsAuthenticated } from '@edorer/user-data';
import { UpdateFacade } from '@edorer/generic-facades';
import { Validate } from '@edorer/validator';

/**
 * @description CRUD controller for TicketCategory
 */
@JsonController()
export class TicketCategoryCrudController {
  /**
   * @param req
   * @param res
   * @description Creates a ticketCategory
   */
  @Post('/ticket-categories')
  @Validate([
    {
      field: 'name',
      validation: [{ value: 'notEmpty', message: 'Name is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanCreateTicketCategory)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async create(@Req() req: any, @Res() res: any) {
    try {
      const { name } = req.body;
      const condition: { [key: string]: string } = { name, university: req.university._id };

      const ticketCategory = await ticketCategoryRepository.findOneAndUpdate(
        condition,
        {
          $set: {
            ...condition,
            creator: req.user._id,
            university: req.university._id
          }
        },
        { multi: false, new: true, upsert: true }
      );

      return res.status(201).send(ticketCategory);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Finds ticketCategories based on the given queries
   */
  @Get('/ticket-categories')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    'action',
    'keyword'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(HasUser)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { action, keyword, limit, skip } = req.query;

      const ticketCategoryListFacade = new TicketCategoryListFacade(action, keyword, limit, skip, req.user, req.university);
      const result = await ticketCategoryListFacade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/ticket-categories/:ticketCategoryId([0-9a-f]{24})')
  @Validate([
    {
      field: 'ticketCategoryId',
      validation: [{ value: 'notEmpty', message: 'TicketCategory ID is required' }]
    }
  ])
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('ticketCategoryId') ticketCategoryId: string) {
    try {
      const ticketCategory = await ticketCategoryRepository.findOne({ _id: ticketCategoryId }).lean();

      return res.status(200).send(ticketCategory);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param ticketCategoryId
   * @description Updates a ticketCategory
   */
  @Put('/ticket-categories/:ticketCategoryId([0-9a-f]{24})')
  @Validate([
    'department',
    {
      field: 'ticketCategoryId',
      validation: [{ value: 'notEmpty', message: 'TicketCategory ID is required' }]
    },
    {
      field: 'name',
      validation: [{ value: 'notEmpty', message: 'TicketCategory Name is required' }]
    }
  ])
  @UseBefore(IsAuthenticated, CanUpdateTicketCategory)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async update(@Req() req: any, @Res() res: any, @Param('ticketCategoryId') ticketCategoryId: string) {
    try {
      const facade = new UpdateFacade(ticketCategoryId, req.body, ['department', 'name'], ticketCategoryRepository);
      await facade.create();

      return res.send({ message: 'TicketCategory updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Deletes ticketCategories based on the given IDs
   */
  @Put('/ticket-categories/delete')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'ids is required' }]
    }
  ])
  @UseBefore(IsAuthenticated, CanDeleteTicketCategories)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async delete(@Req() req: any, @Res() res: any) {
    try {
      const { ids } = req.body;
      const index = ids.findIndex((o) => o.toString() === req.user._id.toString());
      if (index !== -1) {
        ids.splice(index, 1);
      }
      await ticketCategoryRepository.destroy({ _id: { $in: ids } }, req.user._id);
      return res.send({ message: 'deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
