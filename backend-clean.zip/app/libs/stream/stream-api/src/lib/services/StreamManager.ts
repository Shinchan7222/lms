import axios from 'axios';
import { Stream, streamRepository } from '@edorer/stream-data';

export class StreamManager {

    private readonly id: string;

    private readonly prefixUserId: string;

    private readonly type: string;

    private readonly userId: string;

    private stream: Stream;

    constructor(id: string, type: string, prefixUserId?: string, userId?: string) {
        this.id = id;
        this.type = type;
        this.prefixUserId = prefixUserId;
        this.userId = userId;
    }

    async build() {
        await this.fetchStream();
        if (this.stream) {
            let sessionDoesExist = await this.isSessionExist();
            if (!sessionDoesExist) {
                this.stream.sessionId = await this.createSession();
            }
        } else {
            this.stream = new Stream({
                id: this.id,
                type: this.type
            });
            this.stream.sessionId = await this.createSession();
        }
        let tokens = { ...this.stream.tokens };
        tokens[this.prefixUserId + this.userId] = await this.createToken();
        this.stream.tokens = tokens;
        await this.stream.save();
        return this.stream;
    }

    private async fetchStream() {
        this.stream = await streamRepository.findOne({
            id: this.id,
            type: this.type
        });
    }

    private async isSessionExist() {
        try {
            let sessionResult = await axios({
                method: 'GET',
                headers: {
                    'content-type': 'application/json',
                    'Authorization': 'Basic ' + Buffer.from('OPENVIDUAPP:amine96295751').toString('base64')
                },
                url: 'https://openvidu.talent.social/api/sessions/' + this.stream.sessionId
            });
            return sessionResult.status === 200;
        } catch (error: any) {
            return false;
        }

    }

    private async createSession() {
        let session = await axios({
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'Authorization': 'Basic ' + Buffer.from('OPENVIDUAPP:amine96295751').toString('base64')
            },
            data: {},
            url: 'https://openvidu.talent.social/api/sessions'
        });
        return session.data.id;
    }

    private async createToken() {
        let tokenResult = await axios({
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'Authorization': 'Basic ' + Buffer.from('OPENVIDUAPP:amine96295751').toString('base64')
            },
            data: { session: this.stream.sessionId, role: 'PUBLISHER' },
            url: 'https://openvidu.talent.social/api/tokens'
        });
        return tokenResult.data.token;
    }

    async startRecord() {
        await this.fetchStream();
        let recordResult = await axios({
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'Authorization': 'Basic ' + Buffer.from('OPENVIDUAPP:amine96295751').toString('base64')
            },
            data: { session: this.stream.sessionId, name: this.stream._id, hasAudio: true, hasVideo: true, outputMode: 'INDIVIDUAL' },
            url: 'https://openvidu.talent.social/api/recordings/start'
        });
        await streamRepository.update({ _id: this.stream._id }, { $set: { recordId: recordResult.data.id } }, { multi: false });
        return this.stream;
    }

    async stopRecord() {
        await this.fetchStream();
        let recordResult = await axios({
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'Authorization': 'Basic ' + Buffer.from('OPENVIDUAPP:amine96295751').toString('base64')
            },
            data: {},
            url: 'https://openvidu.talent.social/api/recordings/stop/' + this.stream.recordId
        });
        await streamRepository.update({ _id: this.stream._id }, { $set: { recordId: recordResult.data.id } }, { multi: false });
        await streamRepository.update(
            { _id: this.stream._id },
            {
                $set: { recordUrl: 'https://openvidu.talent.social/recordings/' + recordResult.data.id + '/' + recordResult.data.name + '.mp4' }
            }, { multi: false });
        return this.stream;
    }
}
