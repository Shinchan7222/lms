import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { StreamManager } from '../services/StreamManager';
import { Validate } from '@edorer/validator';

@JsonController()
export class StreamCrudController {

    @Post('/streams')
    @Validate(['type', 'id', 'prefixUserId', 'userId'])
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async create(@Req() req: any, @Res() res: any) {
        try {
            let { id, type, prefixUserId, userId } = req.body;
            let manager = new StreamManager(id, type, prefixUserId, userId);
            let stream = await manager.build();
            return res.send(stream);

        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
