import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { StreamManager } from '../services/StreamManager';
import { Validate } from '@edorer/validator';

@JsonController()
export class StreamController {

    @Get('/streams/record')
    @Validate(['type', 'id'])
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async record(@Req() req: any, @Res() res: any) {
        try {
            let {id, type} = req.body;
            let manager = new StreamManager(id, type);
            let stream = await manager.startRecord();
            return res.send(stream);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({error: error.message});
        }
    }

    @Get('/streams/stop-record')
    @Validate(['type', 'id'])
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async stopRecord(@Req() req: any, @Res() res: any) {
        try {
            let {id, type} = req.body;
            let manager = new StreamManager(id, type);
            let stream = await manager.startRecord();
            return res.send(stream);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({error: error.message});
        }
    }
}
