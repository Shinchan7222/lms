import { Nems } from '@edorer/nems';
import { Stream, StreamIndexer } from '@edorer/stream-data';
import { StreamController, StreamCrudController } from '@edorer/stream-api';

export class StreamApp {

    controllers = [
        StreamController,
        StreamCrudController
    ];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'Stream', model: Stream }]);
        await StreamIndexer.index();
    }
}
