import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Schema } from 'mongoose';

@Model('Stream')
export class Stream extends MongooseModel {

    @field({
        type: String
    })
    id: any;

    @field({
        type: String
    })
    type: any;

    @field({
        type: String
    })
    sessionId: string;

    @field({
        type: String
    })
    recordId: string;

    @field({
        type: String
    })
    recordUrl: string;

    @field({
        type: Schema.Types.Mixed
    })
    tokens: any;

    @field({
        default: new Date(),
        type: Date
    })
    createdAt: Date;

    @field({
        type: Date
    })
    updatedAt: Date;

    @post('save')
    async notifyCreate() {
        dbOperationsNotifier.notify('stream',
            {
                id: this.id,
                type: this.type,
                recordId: this.recordId,
                recordUrl: this.recordUrl
            },
            'create');
    }
}
