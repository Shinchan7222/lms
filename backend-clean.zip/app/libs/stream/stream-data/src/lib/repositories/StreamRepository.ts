import { MongooseRepository } from '@edorer/nems';

class StreamRepository extends MongooseRepository {
}

export let streamRepository = new StreamRepository();
