import { streamRepository } from '@edorer/stream-data';

export class StreamIndexer {

    static async index() {
        await streamRepository.ensureIndex({ id: 1, type: 1, deleted: 1 });
    }
}
