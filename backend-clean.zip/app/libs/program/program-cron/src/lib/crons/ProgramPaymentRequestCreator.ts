import axios from 'axios';
import { PaymentRequest, paymentRequestRepository } from '@edorer/payment-request-data';
import { Program, ProgramFeeModes, programRepository } from '@edorer/program-data';
import { TrackProgram, trackProgramRepository } from '@edorer/track-program-data';
import { UserDynamicData, userDynamicDataRepository } from '@edorer/user-dynamic-data';

class ProgramPaymentRequestCreator {
  private paymentRequests: PaymentRequest[] = [];

  private programs: Program[] = [];

  private programIds: string[] = [];

  private studentIds: string[] = [];

  private trackPrograms: TrackProgram[] = [];

  private userDynamicDatas: UserDynamicData[] = [];

  async init() {
    try {
      await this.fetchPrograms();
      await this.fetchTrackPrograms();
      await this.fetchUserDynamicDatas();
      await this.fetchPaymentRequests();

      await this.work();
    } catch (e) {
      console.error(e);
    }
  }

  private async fetchPrograms() {
    this.programs = await programRepository
      .find({
        'payment.plugin': { $exists: true },
        feesMode: ProgramFeeModes.CUSTOM,
        payment: { $exists: true },
        paymentGateway: { $exists: true }
      })
      .populate('payment.plugin')
      .lean();

    this.programIds = this.programs.map((program) => program._id);
    this.studentIds = [...new Set(this.programs.flatMap((program) => program.students))];
  }

  private async fetchTrackPrograms() {
    this.trackPrograms = await trackProgramRepository
      .find({ program: { $in: this.programIds }, user: { $in: this.studentIds } })
      .select('currentStep program user')
      .lean();
  }

  private async fetchUserDynamicDatas() {
    this.userDynamicDatas = await userDynamicDataRepository
      .find({ user: { $in: this.studentIds } })
      .select('data user')
      .lean();
  }

  private async fetchPaymentRequests() {
    this.paymentRequests = await paymentRequestRepository
      .find({ program: { $in: this.programIds }, user: { $in: this.studentIds } })
      .select('program user')
      .lean();
  }

  private async work() {
    for (let program of this.programs) {
      const programId = program._id.toString();
      const programStudents = program.students.map((student) => student.toString());

      const userIncludes = (studentId) => programStudents.includes(studentId.toString());
      const idMatches = (id) => id.toString() === programId;

      const trackPrograms = this.trackPrograms.filter((track) => idMatches(track.program));
      const userDynamicDatas = this.userDynamicDatas.filter((dynamicData) => userIncludes(dynamicData.user));
      const paymentRequests = this.paymentRequests.filter((paymentRequest) => {
        return userIncludes(paymentRequest.user) && idMatches(paymentRequest.program);
      });

      try {
        const { data: requests, status } = await axios({
          data: { paymentRequests, trackPrograms, userDynamicDatas },
          method: program.payment.plugin.method,
          url: program.payment.plugin.endPoint
        });

        if (status === 200 && requests && requests.length > 0) {
          const { paymentGateway, university } = program;

          const requestsToCreate = requests.map((request) => ({ ...request, paymentGateway, university }));
          await paymentRequestRepository.insertMany(requestsToCreate);
        }
      } catch (error: any) {
        console.error(error.message);
      }
    }
  }
}

export const programPaymentRequestCreator = new ProgramPaymentRequestCreator();
