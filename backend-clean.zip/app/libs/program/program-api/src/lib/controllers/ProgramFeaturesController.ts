import { CanDuplicateProgram } from '@edorer/program-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { ProgramDuplicator } from '../services/ProgramDuplicator';
import { Validate } from '@edorer/validator';

@JsonController()
export class ProgramFeaturesController {
  /**
   * @duplicate
   * implements Authentication middleware for User is required.
   * @param: { programId:string }  required field
   * duplicate a program and does not copy all the details
   */
  @Post('/programs/duplicate/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'programId is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanDuplicateProgram)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async duplicate(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const programDuplicator = new ProgramDuplicator(programId, req.university, req.user);
      await programDuplicator.run();

      return res.status(201).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
