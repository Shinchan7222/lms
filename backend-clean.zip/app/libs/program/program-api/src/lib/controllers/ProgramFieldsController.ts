import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { ProgramMajorSubjects } from '../services/ProgramMajorSubjects';
import { ProgramMajorSubjectsUpdater } from '../services/ProgramMajorSubjectsUpdater';
import { ProgramMinorSubjectsUpdater } from '../services/ProgramMinorSubjectsUpdater';
import { programRepository } from '@edorer/program-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ProgramFieldsController {
  @Get('/programs/fields/batches')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async batches(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const batches = await programRepository.distinct('batch', {
        batch: new RegExp(keyword, 'i'),
        university: req.university._id
      });
      const result = batches.map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/programs/fields/years')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async years(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const years = await programRepository.distinct('year', {
        year: new RegExp(keyword, 'i'),
        university: req.university._id
      });
      const result = years.map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/programs/major-subjects/:programId')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program ID is required' }]
    },
    'isMajor'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async majorSubjects(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const { isMajor } = req.query;

      const fetcher = new ProgramMajorSubjects(isMajor === 'true', programId);
      const items = await fetcher.fetch();

      return res.status(200).send({ items });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/programs/upload-major-subjects/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'document',
      validation: [{ value: 'notEmpty', message: 'Document is required' }]
    },
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async uploadMajorSubjects(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const { document } = req.body;

      const uploader = new ProgramMajorSubjectsUpdater(document, programId, req.university);
      await uploader.upload();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/programs/upload-minor-subjects/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'document',
      validation: [{ value: 'notEmpty', message: 'Document is required' }]
    },
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async uploadMinorSubjects(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const { document } = req.body;

      const uploader = new ProgramMinorSubjectsUpdater(document, programId, req.university);
      await uploader.upload();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
