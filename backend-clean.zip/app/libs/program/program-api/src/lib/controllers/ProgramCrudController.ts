import { CanCreateProgram, CanDeletePrograms, CanFindPrograms, CanUpdateProgram, programRepository } from '@edorer/program-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { LogActions, LogTargetTypes, logRepository } from '@edorer/log-data';
import { ProgramBuilder } from '../services/ProgramBuilder';
import { ProgramListFacade } from '../services/ProgramListFacade';
import { ProgramListFromFlowFacade } from '../services/ProgramListFromFlowFacade';
import { ProgramUpdater } from '../services/ProgramUpdater';
import { Types } from 'mongoose';
import { Validate } from '@edorer/validator';

@JsonController()
export class ProgramCrudController {
  /**
   * @param req
   * @param res
   * @description Creates one Program with the given properties
   */
  @Post('/programs')
  @Validate([
    {
      field: 'title',
      validation: [{ value: 'notEmpty', message: 'title is required' }]
    },
    'backgroundImage',
    'batch',
    'breakUp',
    'brochure',
    'captureDeadline',
    'contentBuilder',
    'curriculum',
    'description',
    'domain',
    'duration',
    'editors',
    'examCenter',
    'facts',
    'feesMode',
    'initialPrice',
    'intro',
    'isApproved',
    'language',
    'learnings',
    'logo',
    'meta',
    'name',
    'objective',
    'owner',
    'payment',
    'paymentDueDay',
    'paymentGateway',
    'price',
    'programCode',
    'requirements',
    'restricted',
    'allowChooseMajorSubjects',
    'secure',
    'serial',
    'skills',
    'slug',
    'splitPayment',
    'subDomain',
    'summary',
    'university',
    'updatedAt',
    'year'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanCreateProgram)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async create(@Req() req: any, @Res() res: any) {
    try {
      const programBuilder = new ProgramBuilder(req.user, req.university, req.body);
      const program = await programBuilder.build();

      return res.status(201).send(program);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Finds Programs with the given queries
   */
  @Get('/programs')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    'action',
    'batch',
    'domainId',
    'keyword',
    'priceEnabled',
    'year'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { action, batch, domainId, keyword, limit, priceEnabled, skip, year } = req.query;

      const facade = new ProgramListFacade(
        action,
        batch,
        keyword,
        limit,
        domainId,
        priceEnabled && priceEnabled === 'true',
        skip,
        year,
        req.user,
        req.university
      );
      const response = await facade.create();

      return res.status(200).send(response);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Finds Programs with the given queries
   */
  @Get('/programs/from-flows')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    'keyword'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanFindPrograms)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async findForFlow(@Req() req: any, @Res() res: any) {
    try {
      const { keyword, limit, skip } = req.query;

      const facade = new ProgramListFromFlowFacade(keyword, limit, skip, req.user, req.university);
      const response = await facade.create();

      return res.status(200).send(response);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param programId
   * @description Finds one Program with the given ID
   */
  @Get('/programs/:programId')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const condition = {};
      if (Types.ObjectId.isValid(programId)) {
        condition['_id'] = programId;
      } else {
        condition['slug'] = programId;
      }

      const program = await programRepository
        .findOne(condition)
        .populate({
          path: 'curriculum',
          populate: {
            path: 'yearData.data.course',
            populate: { path: 'chapters' }
          },
          select: 'yearData'
        })
        .populate('contentBuilder')
        .lean();

      return res.status(200).send(program);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param programId
   * @description Updates one Program with the given changes
   */
  @Put('/programs/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program ID is required' }]
    },
    'backgroundImage',
    'batch',
    'breakUp',
    'brochure',
    'captureDeadline',
    'contentBuilder',
    'curriculum',
    'description',
    'domain',
    'duration',
    'editors',
    'examCenter',
    'facts',
    'feesMode',
    'initialPrice',
    'intro',
    'isApproved',
    'language',
    'learnings',
    'logo',
    'meta',
    'name',
    'objective',
    'owner',
    'payment',
    'paymentDueDay',
    'paymentGateway',
    'price',
    'programCode',
    'requirements',
    'restricted',
    'allowChooseMajorSubjects',
    'secure',
    'serial',
    'skills',
    'slug',
    'splitPayment',
    'subDomain',
    'summary',
    'title',
    'updatedAt',
    'year'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanUpdateProgram)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async update(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const updater = new ProgramUpdater(req.body, programId, req.user, req.university);
      const updatedProgram = await updater.update();

      return res.status(201).send(updatedProgram);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Deletes Programs with the given IDs
   */
  @Put('/programs/delete')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'Please select Programs to delete' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanDeletePrograms)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async delete(@Req() req: any, @Res() res: any) {
    try {
      const { ids } = req.body;
      await programRepository.destroy({ _id: { $in: ids } }, req.user._id);

      const logs = [];
      for (let id of ids) {
        logs.push({
          action: LogActions.DELETE,
          program: id,
          targetType: LogTargetTypes.PROGRAM,
          university: req.university._id,
          user: req.user._id
        });

        await logRepository.insertMany(logs);
      }
      return res.send({ message: 'deleted successful' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
