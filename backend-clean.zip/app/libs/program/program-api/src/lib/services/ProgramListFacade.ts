import { ListFacade, QueryActions } from '@edorer/generic-facades';
import { LogActions, logRepository, LogTargetTypes } from '@edorer/log-data';
import { programRepository } from '@edorer/program-data';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';

export class ProgramListFacade {
  private facade: ListFacade;

  private readonly action: string;

  private readonly batch: string;

  private readonly currentUser: User;

  private readonly domainId: string;

  private readonly keyword: string = null;

  private readonly limit: number;

  private readonly priceEnabled: boolean;

  private readonly skip: number;

  private readonly year: string;

  private readonly university: University;

  constructor(
    action: string = null,
    batch: string = null,
    keyword: string = null,
    limit: number = 10,
    domainId: string,
    priceEnabled: boolean = false,
    skip: number,
    year: string = null,
    currentUser: User,
    university: University
  ) {
    this.action = action;
    this.batch = batch;
    this.currentUser = currentUser;
    this.domainId = domainId;
    this.keyword = keyword;
    this.limit = +limit;
    this.priceEnabled = priceEnabled;
    this.skip = +skip;
    this.university = university;
    this.year = year;
  }

  async create() {
    this.facade = new ListFacade(this.currentUser, this.university, this.skip, this.limit, this.keyword, ['id', 'title'], programRepository);

    await this.addConditions();
    await this.runAction();

    this.facade.prepareQuery();

    return await this.processResults();
  }

  private async addConditions() {
    this.checkPrice();
    this.checkTeacher();
    this.checkDomain();

    if (this.batch) {
      this.facade.addConditions({ batch: this.batch });
    }

    if (this.year) {
      this.facade.addConditions({ year: this.year });
    }
  }

  private checkTeacher() {
    if (this.currentUser && this.currentUser.type === UserTypes.TEACHER) {
      this.facade.deleteCondition('owner');

      this.facade.addConditions({
        $or: [{ editors: { $in: this.currentUser._id } }, { owner: this.currentUser._id }]
      });
    }

    if (this.currentUser && this.currentUser.type === UserTypes.STUDENT) {
      this.facade.addConditions({ _id: { $in: this.currentUser.programs } });
    }
  }

  private checkDomain() {
    if (this.domainId) {
      this.facade.addConditions({ domain: this.domainId });
    }
  }

  private checkPrice() {
    if (this.priceEnabled) {
      this.facade.addConditions({ price: { $exists: true, $gt: 0 } });
    }
  }

  private async runAction() {
    if (this.action && this.action === QueryActions.DELETE) {
      const programs = await programRepository.find(this.facade.condition).select('_id').lean();
      this.facade.query = programRepository.delete(this.facade.condition);
      await this.facade.create();

      const logs = [];

      for (let program of programs) {
        logs.push({
          action: LogActions.DELETE,
          program: program._id,
          targetType: LogTargetTypes.PROGRAM,
          university: this.university._id,
          user: this.currentUser._id
        });
      }

      await logRepository.insertMany(logs);
    }
  }

  private async processResults() {
    try {
      const response = await this.facade.create();

      for (let item of response.items) {
        item.name = item.title;

        if (item.programCode) {
          item.title = `${item.title} - (${item.programCode})`;
        }

        if (item.year) {
          item.title = `${item.title} - (${item.year})`;
        }

        if (item.batch) {
          item.title = `${item.title} - (${item.batch})`;
        }
      }

      return response;
    } catch (error) {
      console.error(error);
      throw new Error('Error processing results');
    }
  }
}
