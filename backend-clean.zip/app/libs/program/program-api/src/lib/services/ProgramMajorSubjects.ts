import { courseRepository } from '@edorer/course-data';
import { Program, programRepository } from '@edorer/program-data';

export class ProgramMajorSubjects {
  private readonly programId: string = '';

  private courseIds: string[] = [];
  private isMajor: boolean;
  private program: Program;

  constructor(isMajor: boolean, programId: string) {
    this.isMajor = isMajor;
    this.programId = programId;
  }

  public async fetch() {
    await this.fetchProgram();
    this.getCourseIds();

    return await this.fetchCourses();
  }

  private async fetchProgram() {
    this.program = await programRepository.findOne({ _id: this.programId }).lean();
  }

  public getCourseIds() {
    let yearData = [];

    const { curriculum = [] } = this.program;
    if (curriculum === null) return;
    if (curriculum === undefined) return;
    if (curriculum.length === 0) return;

    let curriculumData = [];
    for (let c of curriculum) {
      curriculumData = curriculumData.concat(c.yearData);
    }

    let curriculumYearData = [];
    for (let c of curriculumData) {
      curriculumYearData = curriculumYearData.concat(c.data);
    }

    yearData = yearData.concat(curriculumYearData);

    yearData = yearData
      .filter((item) => {
        if (this.isMajor) {
          return item.isMajor;
        }

        return item.isMinor;
      })
      .filter(Boolean);

    const courseIds = [];
    for (let item of yearData) {
      courseIds.push(item.course);
    }

    this.courseIds = [...new Set(courseIds.filter(Boolean))];
  }

  private async fetchCourses() {
    if (!this.courseIds.length) return;

    return await courseRepository
      .find({ _id: { $in: this.courseIds } })
      .select('_id title name')
      .lean();
  }
}
