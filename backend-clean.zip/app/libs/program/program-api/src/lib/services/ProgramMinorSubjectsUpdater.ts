import { courseRepository } from '@edorer/course-data';
import { Downloader } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { ListFacade } from '@edorer/generic-facades';
import { Program, programRepository } from '@edorer/program-data';
import { TrackProgram, trackProgramRepository } from '@edorer/track-program-data';
import { University } from '@edorer/university-data';
import { userRepository, UserTypes } from '@edorer/user-data';
import * as excelToJson from 'convert-excel-to-json';

export class ProgramMinorSubjectsUpdater {
  private courses: Record<string, string> = {};

  private emailCourseMap: Record<string, string[]> = {};

  private excelFile: Buffer;

  private program: Program;

  private results: Array<Record<string, string>> = [];

  private students: Record<string, string> = {};

  private trackPrograms: Record<string, TrackProgram> = {};

  private readonly document: string;

  private readonly programId: string;

  private readonly university: University;

  constructor(document: string, programId: string, university: University) {
    this.programId = programId;
    this.document = document;
    this.university = university;
  }

  async upload() {
    await this.downloadFile();

    this.readExcelFile();

    await this.fetchProgram();

    await Promise.all([this.fetchStudents(), this.fetchCourses()]);

    await this.fetchTrackPrograms();
    await this.updateTrackPrograms();
  }

  private async downloadFile() {
    try {
      const downloader = new Downloader(this.document);
      const downloadedFile = await downloader.download();

      if (downloadedFile) {
        this.excelFile = FileUtils.readFile(downloadedFile);
      }

      if (!this.excelFile) {
        throw new Error('Could not download file. Please try again.');
      }
    } catch (error) {
      console.error(error);
      throw new Error('Could not download file. Please try again.');
    }
  }

  private readExcelFile() {
    const result = excelToJson({
      source: this.excelFile,
      header: {
        rows: 1
      },
      columnToKey: {
        A: 'Email',
        B: 'Subjects'
      }
    });

    if (result['Students']) {
      this.results = result['Students'];
    } else {
      throw new Error('Could not upload results. Please try again.');
    }

    for (let result of this.results) {
      const { Email, Subjects } = result;

      this.emailCourseMap[Email] = Subjects.split(',');
    }
  }

  private async fetchProgram() {
    try {
      this.program = await programRepository.findOne({ _id: this.programId }).lean();
      if (!this.program) throw new Error('Program not found');
    } catch (error) {
      throw new Error('Program not found');
    }
  }

  private async fetchStudents() {
    const students = this.results
      .map((student) => {
        const { Email } = student;
        return Email;
      })
      .filter(Boolean);

    const facade = new ListFacade(null, this.university, 0, 0, null, [], userRepository);
    facade.addConditions({ email: { $in: students }, type: { $in: [UserTypes.APPLICANT, UserTypes.STUDENT] } });

    const { items } = await facade.addSelect('_id email').createOnlyItems();

    for (let item of items) {
      this.students[item.email] = item._id;
    }
  }

  private async fetchTrackPrograms() {
    const users = Object.values(this.students);

    try {
      const facade = new ListFacade(null, null, 0, 0, null, [], trackProgramRepository);
      const { items } = await facade.addConditions({ program: this.programId, user: { $in: users } }).createOnlyItems();

      for (let item of items) {
        this.trackPrograms[item.user] = item;
      }
    } catch (error) {
      throw new Error('Track programs not found');
    }
  }

  private async fetchCourses() {
    const courseIds = [];

    this.results
      .map((entry) => entry['Subjects'])
      .filter(Boolean)
      .forEach((course) => {
        String(course)
          .split(',')
          .forEach((courseId) => {
            const trimmedId = String(courseId).trim();
            if (trimmedId) courseIds.push(trimmedId);
          });
      });

    const facade = new ListFacade(null, this.university, 0, 0, null, [], courseRepository);
    const { items } = await facade
      .addConditions({ id: { $in: courseIds } })
      .addSelect('_id id')
      .createOnlyItems();

    for (let item of items) {
      this.courses[item.id] = item._id;
    }
  }

  private async updateTrackPrograms() {
    const { curriculum } = this.program;

    try {
      const bulkOperations = [];

      for (const [email, courseIds] of Object.entries(this.emailCourseMap)) {
        const student = this.students[email];
        if (!student || !Array.isArray(courseIds) || courseIds.length === 0) continue;

        const trackProgram = this.trackPrograms[student];
        if (!trackProgram) continue;

        const validCourses = courseIds
          .map((id) => this.courses[id])
          .filter(Boolean)
          .map((o) => String(o));

        if (validCourses.length === 0) continue;

        const validCourseSet = new Set(validCourses);

        const { currentYear, currentStep } = trackProgram;
        const { yearData = [] } = curriculum[currentYear - 1];
        const { data = [] } = yearData[currentStep - 1];

        const availableCourses: string[] = [];
        const minorSubjects: Record<string, string> = {};

        const coursesWithoutElectives = data
          .filter(({ isElective, isMajor, isMinor }) => !isMajor && !isElective && !isMinor)
          .filter(Boolean)
          .map(({ course }) => String(course));

        availableCourses.push(...coursesWithoutElectives);

        const coursesWithElectives = data
          .filter(({ isElective, isMajor, isMinor }) => !isMajor && !isElective && isMinor)
          .filter(Boolean)
          .map(({ course }) => String(course));

        for (let course of coursesWithElectives) {
          if (validCourseSet.has(course)) {
            availableCourses.push(course);
            minorSubjects[course] = course;
          }
        }

        const availableCoursesMap = new Set(availableCourses);
        const newAvailableCourses = Array.from(availableCoursesMap);

        bulkOperations.push({
          updateOne: {
            filter: { _id: trackProgram._id },
            update: {
              $set: { availableCourses: newAvailableCourses, minorSubjects: Object.keys(minorSubjects) }
            }
          }
        });
      }

      if (bulkOperations.length === 0) return;

      const BATCH_SIZE = 100;
      for (let i = 0; i < bulkOperations.length; i += BATCH_SIZE) {
        const batch = bulkOperations.slice(i, i + BATCH_SIZE);
        await trackProgramRepository.bulkWrite(batch);
      }
    } catch (error) {
      console.error('Error updating track programs:', error);
      throw new Error('Could not update track programs');
    }
  }
}
