import { contentBuilderRepository } from '@edorer/content-builder-data';
import { Program, programRepository } from '@edorer/program-data';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class ProgramDuplicator {
  private readonly programId: string;
  private readonly currentUniversity: University;
  private readonly currentUser: User;
  private currentProgram: Program;
  private newTitle: string;

  constructor(programId: string, currentUniversity: University, currentUser: User) {
    this.currentUniversity = currentUniversity;
    this.currentUser = currentUser;
    this.programId = programId;
  }

  public async run() {
    await this.fetchProgram();
    await this.generateName();
    await this.createContentBuilder();
  }

  private async fetchProgram() {
    this.currentProgram = await programRepository.findOne({ _id: this.programId, university: this.currentUniversity._id }).lean();
  }

  private async generateName() {
    let programs: Program[];
    let copy = ' copy';
    if (this.currentProgram.title.indexOf('copy') > -1) {
      programs = await programRepository.find({
        university: this.currentUniversity._id,
        title: { $regex: `.*${this.currentProgram.title.slice(0, this.currentProgram.title.indexOf('copy')).trim()}.*` },
        deleted: false
      });
      if (programs && programs.length) {
        copy = copy + ` (${programs.length})`;
      }
    } else {
      programs = await programRepository.find({
        university: this.currentUniversity._id,
        title: { $regex: `.*${this.currentProgram.title}.*` },
        deleted: false
      });
      if (programs && programs.length) {
        copy = copy + ` (${programs.length})`;
      }
    }
    let findCopy = this.currentProgram.title.indexOf('copy');
    if (findCopy !== -1) {
      this.newTitle = this.currentProgram.title.slice(0, this.currentProgram.title.indexOf('copy')) + copy;
    } else {
      this.newTitle = this.currentProgram.title + copy;
    }
  }

  private async createCopyCourse() {
    const copyProgram = JSON.parse(JSON.stringify(this.currentProgram));
    copyProgram.title = this.newTitle;

    delete copyProgram._id;
    copyProgram.owner = this.currentUser._id;

    return await programRepository.create(copyProgram);
  }

  private async createContentBuilder() {
    const program = await this.createCopyCourse();
    let contentBuilder = {
      sections: [
        {
          innerCounter: 1,
          type: 'Sections',
          rows: [
            {
              innerCounter: 4,
              type: 'Row',
              properties: {
                'Number of columns': 1
              },
              inputs: [
                {
                  type: 'Text Description',
                  placeholder: '',
                  name: 'title',
                  values: null,
                  icon: '',
                  properties: {
                    'Input type': 'text-description',
                    Values: {
                      title: 'This is the best program ever',
                      key: 'text-description'
                    },
                    'Is Required': true
                  },
                  id: '114'
                }
              ],
              id: '11'
            }
          ],
          id: '1',
          title: 'Best program ever',
          description: 'this is the best'
        }
      ],
      name: program.title + 'Content Builder',
      program: program._id,
      university: this.currentUniversity._id
    };

    const createdContentBuilder = await contentBuilderRepository.create(contentBuilder);
    await programRepository.update({ _id: program._id }, { $set: { contentBuilder: createdContentBuilder._id } }, { multi: false });
  }
}
