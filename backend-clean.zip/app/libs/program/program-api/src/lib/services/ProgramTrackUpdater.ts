import { Program, programRepository } from '@edorer/program-data';
import { TrackProgram, trackProgramRepository } from '@edorer/track-program-data';
import { Types } from 'mongoose';
import { University } from '@edorer/university-data';
import { User, userRepository, UserTypes } from '@edorer/user-data';

export class ProgramTrackUpdater {
  private programMap: Map<string, Program> = new Map();
  private readonly university: University;

  constructor(university: University) {
    this.university = university;
  }

  async run(): Promise<void> {
    try {
      const [users, programs] = await Promise.all([this.fetchUsers(), this.fetchPrograms()]);

      await this.updateProgramTracks(users, programs);
    } catch (error) {
      console.error('Error in ProgramTrackUpdater:', error);
      throw error;
    }
  }

  private async fetchUsers(): Promise<User[]> {
    return userRepository
      .find({
        $or: [{ type: UserTypes.APPLICANT }, { type: UserTypes.APPLICANT_V2 }, { type: UserTypes.STUDENT }],
        university: this.university._id
      })
      .sort({ createdAt: 1 })
      .lean();
  }

  private async fetchPrograms(): Promise<Program[]> {
    const programs = await programRepository.find({ university: this.university._id }).lean();

    // Create program map for efficient lookups
    programs.forEach((program) => {
      this.programMap.set(program._id.toString(), program);
    });

    return programs;
  }

  private extractCoursesFromProgram(program: Program): { courses: Types.ObjectId[]; electiveSubjects: Types.ObjectId[] } {
    const courses: Types.ObjectId[] = [];
    const electiveSubjects: Types.ObjectId[] = [];

    try {
      const curriculum = program.curriculum?.[0]?.yearData?.[0]?.data || [];

      for (const part of curriculum) {
        if (part.isElective) {
          electiveSubjects.push(part.course);
        } else {
          courses.push(part.course);
        }
      }
    } catch (error) {
      console.error(`Error extracting courses for program ${program._id}:`, error);
    }

    return { courses, electiveSubjects };
  }

  private async updateProgramTracks(users: User[], programs: Program[]): Promise<void> {
    try {
      // Get all existing tracks for these users and programs
      const existingTracks = await trackProgramRepository
        .find({
          user: { $in: users.map((u) => u._id) },
          program: { $in: programs.map((p) => p._id) }
        })
        .lean();

      // Create lookup map for existing tracks
      const trackLookup = new Map<string, TrackProgram>(
        existingTracks.map((track) => [`${track.user.toString()}-${track.program.toString()}`, track])
      );

      // Prepare bulk operations
      const bulkOperations = [];

      for (const user of users) {
        for (const programId of user.programs) {
          const program = this.programMap.get(programId.toString());
          if (!program) continue;

          const { courses, electiveSubjects } = this.extractCoursesFromProgram(program);
          const trackKey = `${user._id.toString()}-${programId.toString()}`;
          const existingTrack = trackLookup.get(trackKey);

          if (existingTrack) {
            // Update existing track
            bulkOperations.push({
              updateOne: {
                filter: { _id: existingTrack._id },
                update: {
                  $set: {
                    availableCourses: courses,
                    electiveSubjects: electiveSubjects
                  }
                }
              }
            });
          } else {
            // Create new track
            bulkOperations.push({
              insertOne: {
                document: {
                  availableCourses: courses,
                  breakUp: program.breakUp,
                  currentStep: 1,
                  currentYear: 1,
                  duration: program.duration,
                  electiveSubjects: electiveSubjects,
                  period: program.breakUp,
                  program: program._id,
                  user: user._id
                }
              }
            });
          }
        }
      }

      // Execute bulk operations in chunks to avoid memory issues
      const CHUNK_SIZE = 500;
      for (let i = 0; i < bulkOperations.length; i += CHUNK_SIZE) {
        const chunk = bulkOperations.slice(i, i + CHUNK_SIZE);

        if (chunk.length > 0) {
          await trackProgramRepository.bulkWrite(chunk);
        }
      }
    } catch (error) {
      console.error('Error in updateProgramTracks:', error);
      throw error;
    }
  }
}
