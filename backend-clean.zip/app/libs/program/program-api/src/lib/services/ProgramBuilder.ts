import { contentBuilderRepository } from '@edorer/content-builder-data';
import { LogActions, LogTargetTypes, logRepository } from '@edorer/log-data';
import { Program, programRepository } from '@edorer/program-data';
import { StringUtils } from '@edorer/utils';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class ProgramBuilder {
  private programFields = [
    'backgroundImage',
    'breakUp',
    'brochure',
    'curriculum',
    'description',
    'domain',
    'duration',
    'editors',
    'facts',
    'feesMode',
    'initialPrice',
    'intro',
    'language',
    'learnings',
    'logo',
    'objective',
    'paymentDueDay',
    'paymentGateway',
    'price',
    'programCode',
    'requirements',
    'allowChooseMajorSubjects',
    'restricted',
    'secure',
    'skills',
    'splitPayment',
    'subDomain',
    'summary',
    'title',
    'updatedAt'
  ];

  private readonly requestPayload: Partial<Program>;

  private readonly currentUser: User;

  private readonly currentUniversity: University;

  private readonly owner: User;

  private programPayload: any = {};

  private program: Program;

  constructor(currentUser: User, currentUniversity: University, requestPayload: Partial<Program>) {
    this.currentUniversity = currentUniversity;
    this.currentUser = currentUser;
    this.owner = requestPayload.owner || currentUser._id;
    this.requestPayload = requestPayload;
  }

  async build() {
    this.setProgramPayload();
    this.setOwnershipFields();

    await this.createProgram();
    await this.attachContentBuilder();

    this.createLog();

    return this.program;
  }

  private setProgramPayload() {
    for (let field of this.programFields) {
      this.programPayload[field] = this.requestPayload[field];
    }
  }

  private setOwnershipFields() {
    this.programPayload.owner = this.owner;
    this.programPayload.university = this.currentUniversity._id;
  }

  private async createProgram() {
    try {
      const slug = this.requestPayload.slug || StringUtils.slug(this.programPayload.title);
      const slugExists = await programRepository.count({ slug, university: this.currentUniversity._id });
      if (slugExists > 0) {
        throw new Error('Please choose different name to create program.');
      }

      this.program = await programRepository.create(this.programPayload);
    } catch (error: any) {
      throw new Error(error.message);
    }
  }

  private async attachContentBuilder() {
    const defaultContentBuilder = await contentBuilderRepository
      .findOne({
        name: 'Default Content Builder',
        university: this.currentUniversity._id
      })
      .lean();

    this.program.contentBuilder = await contentBuilderRepository.create({
      name: this.program.title + ' Content Builder',
      program: this.program._id,
      university: this.currentUniversity._id,
      sections: defaultContentBuilder ? defaultContentBuilder.sections : []
    });

    await programRepository.update({ _id: this.program._id }, { $set: { contentBuilder: this.program.contentBuilder } }, { multi: false });
  }

  private createLog() {
    logRepository
      .create({
        user: this.owner,
        university: this.currentUniversity,
        targetType: LogTargetTypes.PROGRAM,
        program: this.program._id,
        action: LogActions.CREATE
      })
      .then();
  }
}
