import { Flow, FlowStatus, FlowStep, FlowStepData, FlowStepTypes, flowRepository } from '@edorer/flow-data';
import { ListFacade } from '@edorer/generic-facades';
import { programRepository } from '@edorer/program-data';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';

export class ProgramListFromFlowFacade {
  private facade: ListFacade;

  private flows: Flow[] = [];

  private readonly currentUser: User;

  private readonly keyword: string = null;

  private readonly limit: number;

  private readonly skip: number;

  private readonly university: University;

  constructor(keyword: string = null, limit: number = 10, skip: number, currentUser: User, university: University) {
    this.currentUser = currentUser;
    this.keyword = keyword;
    this.limit = +limit;
    this.skip = +skip;
    this.university = university;
  }

  async create() {
    this.facade = new ListFacade(this.currentUser, this.university, this.skip, this.limit, this.keyword, ['title', 'id'], programRepository);

    await this.fetchFlows();
    this.fetchProgramNames();

    await this.addConditions();

    this.facade.prepareQuery();

    return await this.facade.create();
  }

  private async addConditions() {
    this.checkTeacher();
  }

  private async fetchFlows() {
    try {
      const facade = new ListFacade(this.currentUser, this.university, null, null, null, [], flowRepository);
      facade.addConditions({ status: FlowStatus.PUBLISHED });

      const { items } = await facade.createOnlyItems();
      this.flows = items;
    } catch (error) {
      console.error(error);
    }
  }

  private fetchProgramNames() {
    let steps: FlowStep[] = [];

    for (const flow of this.flows) {
      steps = steps.concat(flow.steps.filter((o) => o.type === FlowStepTypes.CARD));
    }

    let data: FlowStepData[] = [];
    for (let step of steps) {
      data = data.concat(step.data);
    }

    let cards = [];
    for (let item of data) {
      cards = cards.concat(item.card);
    }

    const values: Array<{ key: string; value: string }> = [];
    for (let card of cards) {
      if (card.data === null) continue;
      if (card.data === undefined) continue;

      const { key = '' } = card.data;
      if (key === null) continue;
      if (key === undefined) continue;
      if (String(key).toLowerCase() !== 'program') continue;

      values.push(card.data);
    }

    const names = values
      .filter((o) => o.value)
      .map((o) => o.value)
      .filter(Boolean);

    this.facade.addConditions({ title: { $in: names } });
  }

  private checkTeacher() {
    if (this.currentUser && this.currentUser.type === UserTypes.TEACHER) {
      this.facade.deleteCondition('owner');

      this.facade.addConditions({
        $or: [{ editors: { $in: this.currentUser._id } }, { owner: this.currentUser._id }]
      });
    }
  }
}
