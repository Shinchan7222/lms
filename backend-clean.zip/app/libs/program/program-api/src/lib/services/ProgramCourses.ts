import { Program } from '@edorer/program-data';
import { TrackProgram } from '@edorer/track-program-data';

export class ProgramCourses {
  private readonly programs: Program[] = [];

  private readonly trackPrograms: TrackProgram[] = [];

  constructor(programs: Program[], trackPrograms: TrackProgram[]) {
    this.programs = programs;
    this.trackPrograms = trackPrograms;
  }

  public getAll() {
    let yearData = [];

    for (let program of this.programs) {
      const { curriculum = [] } = program;
      if (curriculum === null) continue;
      if (curriculum === undefined) continue;
      if (curriculum.length === 0) continue;

      let curriculumData = [];
      for (let c of curriculum) {
        curriculumData = curriculumData.concat(c.yearData);
      }

      let curriculumYearData = [];
      for (let c of curriculumData) {
        curriculumYearData = curriculumYearData.concat(c.data);
      }

      yearData = yearData.concat(curriculumYearData);
    }

    yearData = yearData.filter(Boolean);

    const courseIds = [];
    for (let item of yearData) {
      courseIds.push(item.course);
    }

    return [...new Set(courseIds.filter(Boolean))];
  }

  public getBySemester() {
    let yearData = [];

    for (let program of this.programs) {
      const trackProgram = this.trackPrograms.find((o) => o.program.toString() === program._id.toString());

      if (trackProgram === null) continue;
      if (trackProgram === undefined) continue;

      const { currentStep, currentYear } = trackProgram;
      if (currentStep === null) continue;
      if (currentStep === undefined) continue;

      if (currentYear === null) continue;
      if (currentYear === undefined) continue;

      const { curriculum = [] } = program;
      if (curriculum === null) continue;
      if (curriculum === undefined) continue;
      if (curriculum.length === 0) continue;

      const curriculumData = curriculum[currentYear - 1];
      if (curriculumData === null) continue;
      if (curriculumData === undefined) continue;

      if (curriculumData.yearData === null) continue;
      if (curriculumData.yearData === undefined) continue;

      const curriculumYearData = curriculumData.yearData[currentStep - 1];
      if (curriculumYearData === null) continue;
      if (curriculumYearData === undefined) continue;

      if (curriculumYearData.data === null) continue;
      if (curriculumYearData.data === undefined) continue;

      yearData.push(curriculumYearData);
    }

    yearData = yearData.filter(Boolean);

    let data = [];
    for (let year of yearData) {
      data.push(...year.data);
    }

    data = data.filter(Boolean);

    const courseIds = [];
    for (let item of data) {
      courseIds.push(item.course);
    }

    return [...new Set(courseIds.filter(Boolean))];
  }
}
