import { LogActions, LogBuilder, LogTargetTypes } from '@edorer/log-data';
import { Program, programRepository } from '@edorer/program-data';
import { StringUtils } from '@edorer/utils';
import { TrackProgram, trackProgramRepository } from '@edorer/track-program-data';
import { University } from '@edorer/university-data';
import { UpdateFacade } from '@edorer/generic-facades';
import { User } from '@edorer/user-data';

export class ProgramUpdater {
  private readonly currentUser: User;
  private readonly program: Partial<Program>;
  private readonly programId: string;
  private readonly university: University;

  private updatedProgram: Partial<Program>;

  constructor(program: Partial<Program>, programId: string, currentUser: User, university: University) {
    this.currentUser = currentUser;
    this.program = program;
    this.programId = programId;
    this.university = university;
  }

  public async update() {
    await this.validateSlug();
    await this.updateProgram();

    await Promise.all([this.updateTracks(), this.buildLog()]);

    return this.updatedProgram;
  }

  private async validateSlug() {
    try {
      let { title, slug } = this.program;

      if (!slug) {
        slug = StringUtils.slug(title);
      }
      const slugExists = await programRepository.count({ _id: { $ne: this.programId }, slug, university: this.university._id });
      if (slugExists > 0) {
        throw new Error('Please choose different name to create program');
      }

      this.program.slug = slug;
    } catch (error) {
      console.error(error);
      throw new Error('Error validating slug');
    }
  }

  private async updateProgram() {
    try {
      const facade = new UpdateFacade(
        this.programId,
        this.program,
        [
          'backgroundImage',
          'batch',
          'breakUp',
          'brochure',
          'captureDeadline',
          'contentBuilder',
          'curriculum',
          'description',
          'domain',
          'duration',
          'editors',
          'examCenter',
          'facts',
          'feesMode',
          'initialPrice',
          'intro',
          'isApproved',
          'language',
          'learnings',
          'logo',
          'meta',
          'name',
          'objective',
          'owner',
          'payment',
          'paymentDueDay',
          'paymentGateway',
          'price',
          'programCode',
          'requirements',
          'allowChooseMajorSubjects',
          'restricted',
          'secure',
          'serial',
          'skills',
          'slug',
          'splitPayment',
          'subDomain',
          'summary',
          'title',
          'updatedAt',
          'year'
        ],
        programRepository
      );

      this.updatedProgram = await facade.create();
    } catch (error) {
      console.error(error);
      throw new Error('Error updating program');
    }
  }

  private async updateTracks() {
    try {
      const program = await programRepository.findOne({ _id: this.programId }).lean();
      if (!program) throw new Error("Program doesn't exist");

      const trackPrograms: TrackProgram[] = await trackProgramRepository.find({ program: this.programId }).lean();

      const bulkOperations = [];

      for (let trackProgram of trackPrograms) {
        const { curriculum } = program;
        const { currentYear, currentStep } = trackProgram;

        const { yearData } = curriculum[currentYear - 1];
        const semester = yearData[currentStep - 1];

        const availableCourses = semester?.data
          ?.filter(({ isElective, isMajor, isMinor }) => !isElective && !isMajor && !isMinor)
          .map((entry) => entry.course);

        bulkOperations.push({
          updateOne: {
            filter: { _id: trackProgram._id },
            update: { $set: { availableCourses } }
          }
        });
      }

      if (bulkOperations.length !== 0) {
        await trackProgramRepository.bulkWrite(bulkOperations);
      }
    } catch (error: any) {
      console.error(error);
      throw new Error('Error updating tracks');
    }
  }

  private async buildLog() {
    try {
      const builder = new LogBuilder({
        action: LogActions.UPDATE,
        targetId: this.programId,
        targetType: LogTargetTypes.PROGRAM,
        university: this.university,
        user: this.currentUser
      });

      await builder.build();
    } catch (error) {
      console.error(error);
      throw new Error('Error building log');
    }
  }
}
