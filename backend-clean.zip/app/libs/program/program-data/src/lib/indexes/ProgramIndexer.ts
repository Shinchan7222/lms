import { programRepository } from '@edorer/program-data';

export class ProgramIndexer {

    static async index() {
        await programRepository.ensureIndex({ _id: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1, title: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1, title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1, title: 1, university: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1, title: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1, university: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, owner: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, title: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, title: 1, university: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, title: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1, university: 1 });
        await programRepository.ensureIndex({ _id: 1, id: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1, title: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1, title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1, title: 1, university: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1, title: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1, university: 1 });
        await programRepository.ensureIndex({ _id: 1, owner: 1 });
        await programRepository.ensureIndex({ _id: 1, title: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, title: 1, university: 1 });
        await programRepository.ensureIndex({ _id: 1, title: 1 });
        await programRepository.ensureIndex({ _id: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ _id: 1, university: 1 });
        await programRepository.ensureIndex({ id: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1, title: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1, title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1, title: 1, university: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1, title: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1, university: 1 });
        await programRepository.ensureIndex({ id: 1, owner: 1 });
        await programRepository.ensureIndex({ id: 1, title: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, title: 1, university: 1 });
        await programRepository.ensureIndex({ id: 1, title: 1 });
        await programRepository.ensureIndex({ id: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ id: 1, university: 1 });
        await programRepository.ensureIndex({ id: 1 });
        await programRepository.ensureIndex({ owner: 1, deleted: 1 });
        await programRepository.ensureIndex({ owner: 1, title: 1, deleted: 1 });
        await programRepository.ensureIndex({ owner: 1, title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ owner: 1, title: 1, university: 1 });
        await programRepository.ensureIndex({ owner: 1, title: 1 });
        await programRepository.ensureIndex({ owner: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ owner: 1, university: 1 });
        await programRepository.ensureIndex({ owner: 1 });
        await programRepository.ensureIndex({ title: 1, deleted: 1 });
        await programRepository.ensureIndex({ title: 1, university: 1, deleted: 1 });
        await programRepository.ensureIndex({ title: 1, university: 1 });
        await programRepository.ensureIndex({ title: 1 });
        await programRepository.ensureIndex({ university: 1, deleted: 1 });
        await programRepository.ensureIndex({ university: 1 });
    }
}
