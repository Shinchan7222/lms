export enum ProgramFeeModes {
  CUSTOM = 'custom',
  ONE_TIME = 'one time',
  SPLIT = 'split'
}
