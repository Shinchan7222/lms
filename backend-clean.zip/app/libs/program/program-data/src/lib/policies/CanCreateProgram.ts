import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanCreateProgram implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to create program.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to create program.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to create program.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to create program.' });

        const { programs } = role;
        if (programs === null) return res.status(401).send({ message: 'You do not have permission to create program.' });
        if (programs === undefined) return res.status(401).send({ message: 'You do not have permission to create program.' });
        if (Object.keys(programs).length === 0) return res.status(401).send({ message: 'You do not have permission to create program.' });

        const { write } = programs;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to create program.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to create program.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to create program.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
