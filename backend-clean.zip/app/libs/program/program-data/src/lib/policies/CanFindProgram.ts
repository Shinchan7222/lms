import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanFindProgram implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to view program.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to view program.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to view program.' });

    const { programId } = params;
    if (programId === null) return res.status(401).send({ message: 'You do not have permission to view program.' });
    if (programId === undefined) return res.status(401).send({ message: 'You do not have permission to view program.' });
    if (Types.ObjectId.isValid(programId) === false) return res.status(401).send({ message: 'You do not have permission to view program.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        if (String(programId) !== String(user._id)) return res.status(401).send({ message: 'You do not have permission to view program.' });
        break;
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to view program.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view program.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view program.' });

        const { programs } = role;
        if (programs === null) return res.status(401).send({ message: 'You do not have permission to view program.' });
        if (programs === undefined) return res.status(401).send({ message: 'You do not have permission to view program.' });
        if (Object.keys(programs).length === 0) return res.status(401).send({ message: 'You do not have permission to view program.' });

        const { read } = programs;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view program.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view program.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view program.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
