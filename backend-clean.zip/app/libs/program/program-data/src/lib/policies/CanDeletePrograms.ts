import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanDeletePrograms implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT:
      case UserTypes.TEACHER: {
        return res.status(401).send({ message: 'You do not have permission to delete program(s).' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });

        const { programs } = role;
        if (programs === null) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });
        if (programs === undefined) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });
        if (Object.keys(programs).length === 0) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });

        if (programs.delete === null) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });
        if (programs.delete === undefined) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });
        if (programs.delete === false) return res.status(401).send({ message: 'You do not have permission to delete program(s).' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
