import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';
import { Types } from 'mongoose';
import { programRepository } from '../repositories/ProgramRepository';

export class CanDuplicateProgram implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });

    const { programId } = params;
    if (programId === null) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
    if (programId === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
    if (Types.ObjectId.isValid(programId) === false) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });

        const { programs } = role;
        if (programs === null) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
        if (programs === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
        if (Object.keys(programs).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });

        const { write } = programs;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await programRepository.count({
          _id: programId,
          $or: [{ owner: user._id }, { editors: { $in: user._id } }]
        });

        if (count === 0) return res.status(401).send({ message: 'You do not have permission to duplicate program.' });
        break;
      }

      default:
        break;
    }

    next();
  }
}
