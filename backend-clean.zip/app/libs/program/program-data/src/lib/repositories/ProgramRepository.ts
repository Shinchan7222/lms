import { PermissionRepository } from '@edorer/permission';

class ProgramRepository extends PermissionRepository {
    override addSubdomain = true;

    override featureFields = ['programs'];
}

export let programRepository = new ProgramRepository();
