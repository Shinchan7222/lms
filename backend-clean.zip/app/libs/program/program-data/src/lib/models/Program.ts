import { CourseDurationUnits, CredXCourseTypes } from '@edorer/course-data';
import { Model, MongooseModel, dbOperationsNotifier, field, post, pre } from '@edorer/nems';
import { programRepository } from '../repositories/ProgramRepository';
import { Types } from 'mongoose';
import { ProgramFeeModes } from '../enums/ProgramEnum';

@Model('Program')
export class Program extends MongooseModel {
  @field({
    trim: true,
    type: String
  })
  id: string;

  @field({
    trim: true,
    type: String
  })
  batch: string;

  @field({
    trim: true,
    type: String
  })
  year: string;

  @field({
    default: '',
    trim: true,
    type: String
  })
  examCenter: string;

  @field({
    trim: true,
    type: String
  })
  slug: string;

  @field({
    title: {
      type: String
    },
    description: {
      type: String
    },
    h1Tag: {
      type: String
    },
    h2Tag: {
      type: String
    }
  })
  meta: { title: string; description: string; h1Tag: string; h2Tag: string };

  @field({
    trim: true,
    type: String
  })
  serial: string;

  @field({
    trim: true,
    type: String
  })
  programCode: string;

  @field({
    required: false,
    trim: true,
    type: String
  })
  name: string;

  @field({
    required: true,
    trim: true,
    type: String
  })
  title: string;

  @field({
    required: true,
    trim: true,
    type: String
  })
  description: string;

  @field({
    required: true,
    trim: true,
    type: String
  })
  language: string;

  @field({
    required: true,
    trim: true,
    type: String
  })
  summary: string;

  @field({
    default: 0,
    required: false,
    type: Number
  })
  price: number;

  @field({
    type: String
  })
  feesMode: string;

  @field({
    trim: true,
    type: String
  })
  breakUp: string;

  @field({
    trim: true,
    type: String
  })
  duration: string;

  @field({
    ref: 'User',
    required: true,
    type: Types.ObjectId
  })
  owner: any;

  @field([
    {
      ref: 'User',
      type: Types.ObjectId
    }
  ])
  students: any[];

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @field([
    {
      trim: true,
      type: String
    }
  ])
  objective: any[];

  @field([
    {
      trim: true,
      type: String
    }
  ])
  learnings: any[];

  @field([
    {
      trim: true,
      type: String
    }
  ])
  requirements: any[];

  @field([
    {
      trim: true,
      type: String
    }
  ])
  skills: any[];

  @field({
    default: false,
    type: Boolean
  })
  isActive: boolean;

  @field({
    default: new Date(),
    type: Date
  })
  captureDeadline: Date;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    type: Date
  })
  updatedAt: Date;

  @field({
    type: String
  })
  intro: string;

  @field({
    type: String
  })
  previousIntro: string;

  @field({
    type: String
  })
  backgroundImage: string;

  @field({
    type: String
  })
  previousBackgroundImage: string;

  @field({
    type: String
  })
  logo: string;

  @field({
    type: String
  })
  previousLogo: string;

  @field({
    type: String
  })
  previewIntro: string;

  @field({
    type: String
  })
  brochure: string;

  @field({
    type: Boolean,
    default: false
  })
  secure: boolean;

  @field({
    type: Boolean,
    default: false
  })
  allowChooseMajorSubjects: boolean;

  @field({
    type: Boolean,
    default: false
  })
  restricted: boolean;

  @field({
    type: Types.ObjectId,
    ref: 'Domain',
    required: true
  })
  domain: any;

  @field({
    type: Types.ObjectId,
    ref: 'ContentBuilder'
  })
  contentBuilder: any;

  @field([
    {
      number: String,
      title: String
    }
  ])
  facts: any[];

  @field([
    {
      yearName: String,
      yearData: [
        {
          data: [
            {
              course: {
                type: Types.ObjectId,
                ref: 'Course'
              },
              credits: { type: Number },
              credX: {
                enabled: { default: false, type: Boolean },
                credits: { default: 0, type: Number },
                duration: { default: 0, type: Number },
                durationUnit: {
                  default: CourseDurationUnits.DAYS,
                  enum: [CourseDurationUnits.DAYS, CourseDurationUnits.MONTHS, CourseDurationUnits.WEEKS],
                  type: CourseDurationUnits
                },
                title: { type: String },
                courseType: {
                  default: CredXCourseTypes.MASTERS,
                  enum: [CredXCourseTypes.BACHELORS, CredXCourseTypes.BOTH, CredXCourseTypes.MASTERS],
                  type: CredXCourseTypes
                }
              },
              subjectCode: { type: String },
              isElective: { type: Boolean },
              isMajor: { type: Boolean },
              isMinor: { type: Boolean },
              exams: [
                {
                  datetime: { type: Date },
                  type: { type: String }
                }
              ]
            }
          ],
          endDate: String,
          semesterName: String,
          startDate: String
        }
      ]
    }
  ])
  curriculum: any[];

  @field({
    type: Types.ObjectId,
    ref: 'SubDomain'
  })
  subDomain: any;

  @field({
    totalRatings: {
      type: Number,
      default: 0
    },
    averageRatings: {
      type: Number,
      default: 0
    },
    zeroPointFiveStar: {
      type: Number,
      default: 0
    },
    oneStar: {
      type: Number,
      default: 0
    },
    onePointFiveStar: {
      type: Number,
      default: 0
    },
    twoStar: {
      type: Number,
      default: 0
    },
    twoPointFiveStar: {
      type: Number,
      default: 0
    },
    threeStar: {
      type: Number,
      default: 0
    },
    threePointFiveStar: {
      type: Number,
      default: 0
    },
    fourStar: {
      type: Number,
      default: 0
    },
    fourPointFiveStar: {
      type: Number,
      default: 0
    },
    fiveStar: {
      type: Number,
      default: 0
    }
  })
  reviews: any;

  @field({
    type: Boolean,
    default: false
  })
  isApproved: boolean;

  @field([
    {
      ref: 'User',
      type: Types.ObjectId
    }
  ])
  editors: any[];

  @field({
    type: Boolean,
    default: false
  })
  splitPayment: boolean;

  @field({
    type: Number
  })
  initialPrice: number;

  @field({
    ref: 'PaymentGateway',
    type: Types.ObjectId
  })
  paymentGateway: any;

  @field({
    default: 30,
    type: Number
  })
  paymentDueDay: number;

  @field({
    plugin: { ref: 'Plugin', type: Types.ObjectId },
    visiblePrice: { default: 0, type: Number }
  })
  payment: any;

  @field({
    default: false,
    type: Boolean
  })
  isAssetsShifted: boolean;

  @pre('save')
  async generateId(next: Function) {
    if (this.isNew) {
      try {
        await this.generateNewId();
      } catch (e) {
        console.error(e);
      }
      next();
    } else {
      next();
    }
  }

  @post('save')
  async notifyCreate() {
    dbOperationsNotifier.notify(
      'program',
      {
        id: this._id,
        title: this.title,
        university: this.university,
        owner: this.owner
      },
      'create'
    );
  }

  // generate id
  async generateNewId(): Promise<void> {
    const latestCourse = await programRepository
      .findOne({ id: { $exists: true }, _id: { $ne: this._id } })
      .sort({ id: -1 })
      .select('id')
      .lean();

    if (!latestCourse) {
      this.id = '000000';
      return;
    }

    let codeOne = Number(latestCourse.id);
    codeOne++;
    this.id = new Array(6 - (codeOne + '').length).fill('0').join('') + (codeOne + '');
  }
}
