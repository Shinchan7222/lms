import { CronRegistry } from '@edorer/cron-data';
import { Nems } from '@edorer/nems';
import { Program, ProgramIndexer } from '@edorer/program-data';
import { ProgramCrudController, ProgramFeaturesController, ProgramFieldsController } from '@edorer/program-api';

export class ProgramApp {
  controllers = [ProgramCrudController, ProgramFeaturesController, ProgramFieldsController];

  constructor() {
    this.initDB();
    this.initCrons();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'Program', model: Program }]);
    await ProgramIndexer.index();
  }

  async initCrons() {
    // CronRegistry.getInstance().register(
    //     'programPaymentRequestCreator', programPaymentRequestCreator.init, programPaymentRequestCreator
    // );
  }
}
