import { MeetingCrudController } from '@edorer/meeting-api';
import { Meeting, MeetingIndexer } from '@edorer/meeting-data';
import { Nems } from '@edorer/nems';

export class MeetingApp {

    controllers = [
        MeetingCrudController
    ];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'Meeting', model: Meeting }]);
        await MeetingIndexer.index();
    }
}
