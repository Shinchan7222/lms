import { Applicant, applicantRepository } from '@edorer/applicant-data';
import { GenerateMeetingJitsi } from './GenerateMeetingJitsi';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class CreateMeeting {

    private applicant: Applicant;

    private readonly applicantId: string;

    private readonly currentUser: User;

    private readonly scheduleId: string;

    private readonly university: University;

    constructor(applicantId: string, university: University, currentUser: User, scheduleId: string) {
        this.applicantId = applicantId;
        this.currentUser = currentUser;
        this.scheduleId = scheduleId;
        this.university = university;
    }

    public async create() {
        try {
            await this.fetchApplicant();
            return await this.createMeeting();
        } catch (e) {
            return new Error(e instanceof Error ? e.message : String(e));
        }
    }

    private async fetchApplicant() {
        try {
            this.applicant = await applicantRepository.find({ _id: this.applicantId }).populate('owner').lean();
        } catch (e) {
            throw new Error(e instanceof Error ? e.message : String(e));
        }
    }

    private async createMeeting() {
        const generateMeeting = new GenerateMeetingJitsi(this.currentUser, this.applicant, this.scheduleId, this.university);
        return await generateMeeting.create();
    }
}
