import * as moment from 'moment';
import { Applicant } from '@edorer/applicant-data';
import { Meeting, meetingRepository } from '@edorer/meeting-data';
import { Meetings } from '../mail/Meetings';
import { Schedule, scheduleRepository } from '@edorer/schedule-data';
import { TokenUtils } from '@edorer/utils';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import { scheduleTrackRepository } from '@edorer/schedule-track-data';

export class GenerateMeetingJitsi {
  private applicant: Applicant;

  private currentSchedule: Schedule;

  private meeting: Meeting;

  private readonly scheduleId: any;

  private readonly university: University;

  private readonly user: User;

  constructor(currentUser: User, applicant: Applicant, scheduleId: string, university: University) {
    this.user = currentUser;
    this.applicant = applicant;
    this.scheduleId = scheduleId;
    this.university = university;
  }

  async create() {
    await this.fetchSchedule();
    await this.createMeeting();
    await this.fetchMeeting();
    return this.generate();
  }

  private async createMeeting() {
    const scheduleTrack = await scheduleTrackRepository.findOne({ schedule: this.scheduleId });
    this.meeting = await meetingRepository.create({
      applicant: this.applicant._id,
      owner: this.user._id,
      status: 'pending',
      date: scheduleTrack.date
    });
  }

  private async fetchMeeting() {
    this.meeting = await meetingRepository
      .findOne({ owner: this.user._id })
      .populate({
        path: 'university',
        select:
          '-advanced.googleClientId -advanced.googleClientSecret -emailSender -smsSender -defaultPassword -driveAccessToken -driveRefreshToken -logRocket -logRocketEmail -logRocketPassword -plagiarism'
      })
      .populate('owner')
      .lean();
  }

  private async fetchSchedule() {
    this.currentSchedule = await scheduleRepository.findOne({ _id: this.scheduleId });
  }

  private async generate() {
    let meetingTime = moment(this.meeting.date);
    let today = moment(new Date());
    let todayTime = moment({
      h: today.hours(),
      s: today.second()
    });

    let meetingDateTime = moment({
      h: meetingTime.hours(),
      s: meetingTime.second()
    });

    if (!todayTime.isBefore(meetingDateTime)) {
      let user = {};

      user = {
        name: this.meeting.applicant.user.name,
        email: this.meeting.applicant.user.email,
        id: this.meeting.applicant.user._id
      };

      const data = {
        context: {
          user
        },
        room: this.currentSchedule.name,
        aud: 'BAIRDHUNT',
        iss: 'BAIRDHUNT',
        sub: 'meet.ubqfit.net',
        exp: moment(this.currentSchedule.duration)
      };
      const token = new TokenUtils(data, this.currentSchedule.duration).generateWithSecret();
      await this.sendMail(this.user);
      await this.sendMail(this.applicant.owner);
      return {
        jwt: token,
        roomName: this.currentSchedule.name
      };
    } else {
      return {
        error: new Error('INVALID DATE'),
        token: false
      };
    }
  }

  private async sendMail(user: User) {
    const mail = new Meetings(this.university, user, this.scheduleId);
    await mail.send();
  }
}
