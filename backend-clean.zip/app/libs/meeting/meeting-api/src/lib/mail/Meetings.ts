import { Mail } from '@edorer/mailer';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class Meetings extends Mail {

    private readonly user: User;

    private readonly meetingId: string;

    constructor(university: University, user: User, meetingId: string) {
        super();

        this.user = user;
        this.meetingId = meetingId;

        this.init(university);
    }

    build() {
        let currentApi = '/event/interview/';

        return {
            template: __dirname + '/meetings.ejs',
            subject: 'Join Interview',
            data: {
                user: this.user,
                host: this.university ? 'https://' + this.university.url : process.env.LMS_URL,
                api: currentApi + this.meetingId,
                universityName: this.university ? this.university.name : 'Edorer'
            }
        };
    }

    async send() {
        await super.sendEmail(this.user.email);
    }
}
