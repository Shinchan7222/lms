import { CreateMeeting } from '../services/CreateMeeting';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';

@JsonController()
export class MeetingCrudController {

    @Post('/meetings')
    @Validate([
        {
            field: 'applicant',
            validation: [{ value: 'notEmpty', message: 'Applicant ID is required' }]
        },
        {
            field: 'scheduleId',
            validation: [{ value: 'notEmpty', message: 'Schedule ID is required' }]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async create(@Req() req: any, @Res() res: any) {
        try {
            const { applicant, scheduleId } = req.body;

            const meetingCreator = new CreateMeeting(applicant, req.user, req.university, scheduleId);
            const result = await meetingCreator.create();

            return res.status(201).send(result);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send(error);
        }
    }
}

