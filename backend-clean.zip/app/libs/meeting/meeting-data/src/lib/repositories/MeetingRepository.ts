import { MongooseRepository } from '@edorer/nems';

class MeetingRepository extends MongooseRepository {
}

export let meetingRepository = new MeetingRepository();
