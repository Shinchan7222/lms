import { meetingRepository } from '@edorer/meeting-data';

export class MeetingIndexer {

    static async index() {
        await meetingRepository.ensureIndex({ owner: 1, deleted: 1 });
    }
}
