import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('Meeting')
export class Meeting extends MongooseModel {

    @field({
        type: String,
        default: null
    })
    acceptToken: string;

    @field({
        type: Types.ObjectId,
        ref: 'Applicant'
    })
    applicant: any;

    @field({
        type: Date
    })
    date: Date;

    @field({
        ref: 'User',
        type: Types.ObjectId
    })
    owner: any;

    @field({
        trim: true,
        type: String
    })
    stage: string;

    @field({
        type: String,
        default: 'pending'
    })
    status: 'pending' | 'accepted' | 'declined';

    @field({
        default: new Date(),
        type: Date
    })
    createdAt: Date;

    @field({
        type: Date
    })
    updatedAt: Date;
}
