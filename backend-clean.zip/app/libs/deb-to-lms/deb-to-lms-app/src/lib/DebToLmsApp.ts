import { DebToLms, DebToLmsIndexer } from '@edorer/deb-to-lms-data';
import {
  DebStudentController,
  DebToLmsApproveController,
  DebToLmsApprovedCrudController,
  DebToLmsCrudController,
  DebToLmsEmailController,
  DebToLmsExportController,
  DebToLmsFieldsController,
  DebToLmsImportController,
  DebToLmsRestrictionController,
  DebToLmsCourseController,
  DebToLmsPlanController,
  DebToLmsTransferController
} from '@edorer/deb-to-lms-api';
import { Nems } from '@edorer/nems';

export class DebToLmsApp {
  controllers = [
    DebStudentController,
    DebToLmsApproveController,
    DebToLmsApprovedCrudController,
    DebToLmsCrudController,
    DebToLmsEmailController,
    DebToLmsExportController,
    DebToLmsFieldsController,
    DebToLmsImportController,
    DebToLmsRestrictionController,
    DebToLmsCourseController,
    DebToLmsPlanController,
    DebToLmsTransferController
  ];

  constructor() {
    this.initDB();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'DebToLms', model: DebToLms }]);
    await DebToLmsIndexer.index();
  }
}
