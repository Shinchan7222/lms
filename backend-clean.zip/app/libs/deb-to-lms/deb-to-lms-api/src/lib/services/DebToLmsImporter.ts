import { debToLmsRepository } from '@edorer/deb-to-lms-data';
import { University, UniversityConfiguration } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import * as excelToJson from 'convert-excel-to-json';

export class DebToLmsImporter {
  public results: Record<string, string>[] = [];

  private readonly currentUser: User;

  private readonly university: University;

  private readonly uploadedFile: any;

  constructor(uploadedFile: any, currentUser: User, university: University, universityConfig: UniversityConfiguration) {
    this.currentUser = currentUser;
    this.university = university;
    this.uploadedFile = uploadedFile;
  }

  async import() {
    this.extractData();

    await this.createOrUpdateData();
  }

  private extractData() {
    try {
      const result = excelToJson({
        columnToKey: { '*': '{{columnHeader}}' },
        header: { rows: 1 },
        source: this.uploadedFile.buffer
      });

      this.results = result['Results'] || result['Report'];
    } catch (error) {
      console.error(error);
      throw new Error('We could not store data.');
    }
  }

  private async createOrUpdateData() {
    try {
      const bulkOperations = [];

      const records = await debToLmsRepository
        .find({ permanentEnrollmentNumber: { $in: this.results.map((o) => o['Permanent Enrollment Number']) } })
        .select('_id isFresh permanentEnrollmentNumber')
        .lean();

      for (let item of this.results) {
        const permanentEnrollmentNumber = item['Permanent Enrollment Number'];

        if (!permanentEnrollmentNumber) {
          console.warn('Skipping record due to missing "Permanent Enrollment Number":', item);
          continue;
        }

        let isFresh = true;
        const record = records.find((o) => o?.permanentEnrollmentNumber === permanentEnrollmentNumber);
        if (record) isFresh = false;

        const updatedData = {
          aadharNumber: item['Aadhar Number'],
          abcId: item['ABC ID'],
          additionalContacts: String(item['Additional Contacts'] || '')
            .split(',')
            .filter(Boolean),
          additionalEmails: (item['Personal Emails'] || '')
            .split(',')
            .filter(Boolean)
            .map((email) => email.toLowerCase().trim()),
          admissionDate: item['Admission Date'],
          admissionSession: item['Admission Session'],
          applicationGeneratedDatetime: item['Application Generated DateTime'],
          applicationId: item['Application Id'],
          applicationNumber: item['Application #'],
          applicationSource: item['Application Source'],
          birthDate: item['Date of Birth'],
          bloodGroup: item['Blood Group'],
          city: item['City'],
          classes: (item['Classes'] || '').split(',').filter(Boolean),
          country: item['Country'],
          course: item['Course'],
          courses: (item['Courses'] || '')
            .split(',')
            .filter(Boolean)
            .map((o) => String(o).padStart(6, '0')),
          debUniqueId: item['DEB ID'],
          email: (item['LMS Email'] || `${permanentEnrollmentNumber}@paruluniversity.ac.in`).toLowerCase().trim(),
          fatherName: item["Father's Name"],
          feeCollected: item['Collected Academic Fee'],
          feeStatus: item['Academic Fee Status'],
          gender: item['Gender'],
          id: item['ID'],
          isFresh,
          leadGeneratedDatetime: item['Lead Generated DateTime'],
          leadId: item['Lead Id'],
          leadIntake: item['Lead Intake'],
          leadSource: item['Lead Source'],
          locality: item['Locality'],
          name: item['Name'],
          nationality: item['Nationality'],
          outstandingFee: item['Outstanding Academic Fee'],
          owner: this.currentUser._id,
          passportNumber: item['Passport Number'],
          password: item['Password'] || this.generateRandomPassword(),
          paymentType: item['Payment Type'],
          permanentEnrollmentNumber,
          phoneNumber: item['Primary Contact'],
          profilePicture: item['Profile Picture'],
          program: (item['Program Name As Per Edorer'] || '').split('-')[0].trim(),
          programId: item['Program ID'],
          programName: item['Program'],
          programType: item['Program Type'],
          provisionalAdmissionDate: item['Provisional Admission Date'],
          registrationDate: item['Registration Date'],
          remarks: item['Remarks'],
          scholarshipAmount: item['Scholarship Amount'],
          scholarshipAppliedDate: item['Scholarship Applied Date'],
          scholarshipType: item['Scholarship Type'],
          sendToDeb: item['Send To DEB'],
          state: item['State'],
          status: item['Status'],
          totalFee: item['Total Academic Fee'],
          university: this.university._id
        };

        bulkOperations.push({
          updateOne: {
            filter: { deleted: false, permanentEnrollmentNumber },
            update: { $set: updatedData },
            upsert: true
          }
        });
      }

      if (bulkOperations.length === 0) return;

      await debToLmsRepository.bulkWrite(bulkOperations);
    } catch (error) {
      console.error(error);
      throw new Error('We could not store data.');
    }
  }

  private generateRandomPassword(): string {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    let password = '';

    for (let i = 0; i < 8; i++) {
      const randomIndex = Math.floor(Math.random() * chars.length);
      password += chars[randomIndex];
    }

    return password;
  }
}
