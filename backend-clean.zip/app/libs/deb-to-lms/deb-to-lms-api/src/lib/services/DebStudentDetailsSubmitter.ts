import { User, userRepository } from '@edorer/user-data';
import { UserDynamicData, userDynamicDataRepository } from '@edorer/user-dynamic-data';
import axios from 'axios';
import moment = require('moment');

export class DebStudentDetailsSubmitter {
  private dynamicData: UserDynamicData;
  private readonly ABCID: string;
  private readonly AdmissionDate: string;
  private readonly AdmissionDetails: string;
  private readonly DEBUniqueID: string;
  private readonly student: string;
  private user: User;

  constructor(ABCID: string, AdmissionDate: string, AdmissionDetails: string, DEBUniqueID: string, student: string) {
    this.ABCID = ABCID;
    this.AdmissionDate = AdmissionDate;
    this.AdmissionDetails = AdmissionDetails;
    this.DEBUniqueID = DEBUniqueID;
    this.student = student;
  }

  async submit() {
    await Promise.all([this.fetchUser(), this.fetchDynamicData()]);

    await this.submitDetails();
  }

  private async fetchUser() {
    try {
      this.user = await userRepository.findOne({ _id: this.student }).populate('programs').lean();
      if (!this.user) throw new Error('User not found');
    } catch (error) {
      throw new Error('User not found');
    }
  }

  private async fetchDynamicData() {
    try {
      this.dynamicData = await userDynamicDataRepository.findOne({ user: this.student }).lean();
    } catch (error) {
      throw new Error('Dynamic data not found');
    }
  }

  private async submitDetails() {
    let Category = this.dynamicData?.data?.find((data) => data && data.key === 'Category')?.value;
    const Country = this.dynamicData?.data?.find((data) => data && data.key?.trim() === 'Country')?.value || 'India';
    const CourseName = this.user?.programs?.[0]?.programCode;
    const Locality = this.dynamicData?.data?.find((data) => data && data.key === 'Locality')?.value === 'Urban' ? 'Urban' : 'Rural';
    const Nationality = this.dynamicData?.data?.find((data) => data && data.key === 'Nationality')?.value;
    if (Category === '--') {
      Category = 'General';
    }
    const { GovernmentIdentifier, GovernmentIdentifierNumber } = this.prepareGovtId();

    const CountryResidence = Country && Country !== '--' ? String(Country).split('(')[0].trim() : this.user.location;

    if (!CourseName) throw new Error('Please check the Program Code');

    const user = new User(this.user);

    try {
      const payload = {
        ABCID: this.ABCID,
        AdmissionDate: this.AdmissionDate || moment(user.createdAt).format('DD-MM-YYYY'),
        // AdmissionDate: '10-10-2025',
        AdmissionDetails: this.AdmissionDetails || 'NA',
        Category: (Category === 'BCA' || Category === 'BCB' ? 'OBC' : Category) || 'General',
        CountryResidence,
        CourseName,
        DEBuniqueID: this.DEBUniqueID,
        EnrollmentNumber: user.getExtraField('Roll Number').trim(),
        GovernmentIdentifier,
        GovernmentIdentifierNumber,
        Locality,
        ModeEducation: 'Online(OL)',
        Nationality: Nationality === 'Indian' ? 'Indian' : 'Others',
        UniversityName: 'U-0168'
      };
      console.log('Payload Sent to Deb API:', payload);


      const { data } = await axios.post(
        'https://deb.ugc.ac.in/api/DebUniqueID/GetAdmissionDetails',
        { ...payload },
        {
          headers: {
            APIKey: 'zLaIxcWACMe29JvpsyE5cUzet5eJyldr',
            ClientID: 'MM0168_GetAdmissionDetails'
          },
          params: { ...payload }
        }
      );

      console.log('Payload Sent to Deb API:', payload);
      console.log('Response from Deb API:', data);

      if (data.Status === 'Process Unsuccess') {
        throw new Error(data.Message);
      }
    } catch (error: any) {
      console.log(error);
      throw new Error(error?.message || 'Failed to submit details');
    }
  }

  private prepareGovtId() {
    const nationality = this.dynamicData?.data?.find((data) => data && data.key === 'Nationality')?.value;

    const hasAadharCard = this.dynamicData?.data?.find((data) => data && data.key === 'Do you have Adhar card ?')?.value;
    const aadharNumber = this.dynamicData?.data?.find((data) => data && data.key === 'Adhar number')?.value;

    const validationMode = this.dynamicData?.data?.find((data) => data && data.key === 'Validation mode')?.value;
    const voterId = this.dynamicData?.data?.find((data) => data && data.key === 'Voter ID No.')?.value;
    const drivingLicense = this.dynamicData?.data?.find((data) => data && data.key === 'DL No.')?.value;
    const panCard = this.dynamicData?.data?.find((data) => data && data.key === 'PAN No.')?.value;
    const otherGovtId = this.dynamicData?.data?.find((data) => data && data.key === 'ID No')?.value;

    const issuedGovtId = this.dynamicData?.data?.find((data) => data && data.key === 'Issued Govt. ID')?.value;
    const foreignGovtId = this.dynamicData?.data?.find((data) => data && data.key === 'Name of Govt. ID')?.value;

    let passportNumber = '';
    if (this.dynamicData?.data?.find((data) => data && data.key.trim() === 'Passport')) {
      passportNumber = this.dynamicData?.data?.find((data) => data && data.key.trim() === 'Passport')?.value as string;
    } else if (this.dynamicData?.data?.find((data) => data && data.key.trim() === 'Passport Number')) {
      passportNumber = this.dynamicData?.data?.find((data) => data && data.key.trim() === 'Passport Number')?.value as string;
    }

    if (nationality === 'Indian') {
      if (hasAadharCard === 'Yes') {
        return {
          GovernmentIdentifier: 'AADHAR Card',
          GovernmentIdentifierNumber: aadharNumber
        };
      }

      if (hasAadharCard === 'No') {
        switch (validationMode) {
          case 'Voter ID information': {
            return {
              GovernmentIdentifier: 'Voter id Card',
              GovernmentIdentifierNumber: voterId
            };
          }

          case 'PAN CARD Information': {
            return {
              GovernmentIdentifier: 'PAN Card',
              GovernmentIdentifierNumber: panCard
            };
          }

          case 'Other Govt. ID': {
            return {
              GovernmentIdentifier: 'Other Govt. ID',
              GovernmentIdentifierNumber: otherGovtId
            };
          }

          default: {
            return {
              GovernmentIdentifier: 'Driving License',
              GovernmentIdentifierNumber: drivingLicense
            };
          }
        }
      }
    }

    switch (issuedGovtId) {
      case 'Passport': {
        return {
          GovernmentIdentifier: 'Passport',
          GovernmentIdentifierNumber: passportNumber
        };
      }

      case 'Name of Govt. ID': {
        return {
          GovernmentIdentifier: 'Foreign Govt. ID',
          GovernmentIdentifierNumber: foreignGovtId
        };
      }
    }

    return {
      GovernmentIdentifier: '',
      GovernmentIdentifierNumber: ''
    };
  }
}
