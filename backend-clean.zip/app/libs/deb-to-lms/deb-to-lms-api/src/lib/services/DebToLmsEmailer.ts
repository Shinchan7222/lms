import { CustomMail } from '@edorer/custom-mailer';
import { DebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { User, userRepository } from '@edorer/user-data';

export class DebToLmsEmailer {
  public users: User[] = [];

  public items: DebToLms[] = [];

  public records: DebToLms[] = [];

  public readonly attachments: string[] = [];

  public readonly recordIds: string[] = [];

  private readonly template: string;

  private readonly university: University;

  constructor(attachments: string[] = [], recordIds: string[] = [], template: string, university: University) {
    this.attachments = attachments;
    this.recordIds = recordIds;
    this.template = template;
    this.university = university;
  }

  async email() {
    await this.fetchRecords();
    await this.fetchUsers();
    await this.mailUsers();
  }

  private async fetchRecords() {
    try {
      const facade = new ListFacade(null, this.university, 0, 0, null, [], debToLmsRepository);
      const { items } = await facade.addConditions({ _id: { $in: this.recordIds } }).createOnlyItems();

      this.records = JSON.parse(JSON.stringify(items));
    } catch (error: any) {
      console.error(error);
      throw new Error(error);
    }
  }

  private async fetchUsers() {
    try {
      const emails = this.records.map((record) => record.email).map((o) => String(o).toLowerCase());

      const facade = new ListFacade(null, this.university, 0, 0, null, [], userRepository);
      const { items } = await facade
        .addConditions({ email: { $in: emails } })
        .addSelect('email name plainPassword registrationNumbers')
        .createOnlyItems();

      this.users = JSON.parse(JSON.stringify(items));
    } catch (error: any) {
      console.error(error);
      throw new Error(error);
    }
  }

  private async mailUsers() {
    if (this.users.length === 0) return;

    const recordsMap: Record<string, DebToLms> = this.records.reduce(
      (map, record) => {
        map[String(record.email).toLowerCase()] = record;
        return map;
      },
      {} as Record<string, DebToLms>
    );

    try {
      const mailPromises = this.users.map(async ({ email, name, plainPassword, registrationNumbers = [] }) => {
        const record = recordsMap[String(email).toLowerCase()];
        if (!record) return;

        const { additionalEmails = [], permanentEnrollmentNumber, program, programName } = record;
        const emails = new Set(additionalEmails.concat(email).filter(Boolean));
        if (emails.size === 0) return;

        try {
          const mail = new CustomMail(
            Array.from(emails).concat('info.onlinelearning@paruluniversity.ac.in').concat('infoictcell@gmail.com'),
            'Account approval',
            this.template,
            {
              email,
              name,
              password: plainPassword || record['password'],
              permanentEnrollmentNumber,
              program,
              programName,
              registration: registrationNumbers.map((o) => o.registration).join(', ')
            },
            this.attachments.map((o) => ({ fileName: o.split('/').pop(), path: o }))
          );

          mail.init(this.university);

          await mail.send();
        } catch (error) {
          console.error(`Failed to send email to ${email}:`, error);
        }
      });

      await Promise.all(mailPromises);
    } catch (error: any) {
      console.error('Error in mailUsers:', error);
      throw new Error(error);
    }
  }
}
