import { DebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { University } from '@edorer/university-data';
import { FeePlan, feePlanRepository } from '@edorer/fee-plan-data';

export class DebToLmsTransferApprover {
  private readonly id: string;
  private readonly university: University;

  private feePlan: FeePlan;
  public record: DebToLms;

  constructor(id: string, university: University) {
    this.id = id;
    this.university = university;
  }

  async approve(): Promise<void> {
    await this.fetchRecord();
    await this.fetchFeePlan();
    await this.approveRecords();
  }

  private async fetchRecord() {
    this.record = await debToLmsRepository
      .findOne({
        _id: this.id,
        university: this.university._id
      })
      .lean();
  }

  private async fetchFeePlan() {
    this.feePlan = await feePlanRepository
      .findOne({
        feeCategory: this.record.transferDetails.feeCategory,
        university: this.university._id
      })
      .populate('feeHeads')
      .lean();

    if (!this.feePlan) {
      throw new Error('Fee plan not found');
    }
  }

  private async approveRecords(): Promise<void> {
    try {
      const { feeHeads } = this.feePlan;
      const totalFee = feeHeads.reduce((acc, feeHead) => acc + feeHead.amount, 0);
      const outstandingFee = Math.max(0, totalFee - (this.record.feeCollected || 0));

      await debToLmsRepository.update({ _id: this.id }, {
        $set: {
          status: 'Transfer Approved',
          paymentType: this.feePlan.feeCategory, totalFee, outstandingFee,
          ...this.record.transferDetails
        }
      }, { multi: false });
    } catch (error: any) {
      console.error('Error updating records:', error);
      throw new Error(error.message || 'Failed to update records');
    }
  }
}
