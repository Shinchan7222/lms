import { debToLmsRepository } from '@edorer/deb-to-lms-data';
import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class DebToLmsListFacade {
  private static readonly ENROLLMENT_KEYS = ['permanentEnrollmentNumber', 'enrollmentNumber', 'rollNumber', 'registrationNumber'];

  private readonly admissionSession: string;

  private readonly applicationSource: string;

  private readonly city: string;

  private readonly country: string;

  private readonly course: string;

  private readonly currentUser: User;

  private readonly endDate: Date;

  private readonly facade: ListFacade;

  private readonly feeStatus: string;

  private readonly keyword: string;

  private readonly leadSource: string;

  private readonly limit: number;

  private readonly locality: string;

  private readonly nationality: string;

  private readonly paymentMode: string;

  private readonly paymentType: string;

  private readonly program: string;

  private readonly programName: string;

  private readonly programType: string;

  private readonly scholarshipType: string;

  private readonly skip: number;

  private readonly startDate: Date;

  private readonly state: string;

  private readonly status: string;

  private readonly university: University;

  private readonly sendToDeb: string;

  private andConditions: any = [{ $or: [{ isApproved: { $eq: false } }, { isApproved: { $exists: false } }] }];

  constructor(
    admissionSession: string,
    applicationSource: string,
    city: string,
    country: string,
    course: string,
    endDate: Date,
    feeStatus: string,
    keyword: string,
    leadSource: string,
    limit: number,
    locality: string,
    nationality: string,
    paymentMode: string,
    paymentType: string,
    program: string,
    programName: string,
    programType: string,
    scholarshipType: string,
    sendToDeb: string,
    skip: number,
    startDate: Date,
    state: string,
    status: string,
    currentUser: User,
    university: University
  ) {
    this.admissionSession = admissionSession;
    this.applicationSource = applicationSource;
    this.city = city;
    this.country = country;
    this.course = course;
    this.currentUser = currentUser;
    this.endDate = endDate;
    this.feeStatus = feeStatus;
    this.keyword = keyword;
    this.leadSource = leadSource;
    this.limit = +limit;
    this.locality = locality;
    this.nationality = nationality;
    this.paymentMode = paymentMode;
    this.paymentType = paymentType;
    this.program = program;
    this.programName = programName;
    this.programType = programType;
    this.scholarshipType = scholarshipType;
    this.sendToDeb = sendToDeb;
    this.skip = +skip;
    this.startDate = startDate;
    this.state = state;
    this.status = status;
    this.university = university;

    this.facade = new ListFacade(
      this.currentUser,
      this.university,
      0,
      0,
      this.keyword,
      ['abcId', 'applicationId', 'applicationNumber', 'debUniqueId', 'easepayId', 'email', 'fatherName', 'leadId', 'name', 'programId', 'utrNo'],
      debToLmsRepository
    );
  }

  async create() {
    this.addConditions();
    this.facade.prepareQuery();

    this.facade.addConditions({ isFresh: true });
    const result = await this.facade.create();
    const sortedItems = [...result.items].sort((a, b) => this.compareByEnrollmentNumber(a, b));
    const paginatedItems = this.limit > 0 ? sortedItems.slice(this.skip, this.skip + this.limit) : sortedItems.slice(this.skip);

    return { items: paginatedItems, total: result.total };
  }

  private addConditions() {
    this.checkAdmissionSession();
    this.checkApplicationSource();
    this.checkCity();
    this.checkCountry();
    this.checkCourse();
    this.checkDates();
    this.checkFeeStatus();
    this.checkLeadSource();
    this.checkLocality();
    this.checkNationality();
    this.checkState();
    this.checkPaymentMode();
    this.checkPaymentType();
    this.checkProgramType();
    this.checkStatus();
    this.checkProgram();
    this.checkProgramName();
    this.checkScholarshipType();
    this.checkSendToDeb();

    this.facade.addConditions({ $and: this.andConditions });
  }

  private checkAdmissionSession() {
    if (this.admissionSession) {
      this.facade.addConditions({ admissionSession: this.admissionSession });
    }
  }

  private checkApplicationSource() {
    if (this.applicationSource) {
      this.facade.addConditions({ applicationSource: this.applicationSource });
    }
  }

  private checkCity() {
    if (this.city) {
      this.facade.addConditions({ city: this.city });
    }
  }

  private checkCountry() {
    if (this.country) {
      this.facade.addConditions({ country: this.country });
    }
  }

  private checkDates() {
    if (this.endDate && this.startDate) {
      this.andConditions.push({
        $or: [
          { admissionDate: { $gte: this.startDate, $lte: this.endDate } },
          { applicationGenerationDate: { $gte: this.startDate, $lte: this.endDate } },
          { leadGenerationDate: { $gte: this.startDate, $lte: this.endDate } },
          { provisionalAdmissionDate: { $gte: this.startDate, $lte: this.endDate } },
          { registrationDate: { $gte: this.startDate, $lte: this.endDate } },
          { scholarshipAppliedDate: { $gte: this.startDate, $lte: this.endDate } }
        ]
      });
    }
  }

  private checkFeeStatus() {
    if (this.feeStatus) {
      this.facade.addConditions({ feeStatus: this.feeStatus });
    }
  }

  private checkLeadSource() {
    if (this.leadSource) {
      this.facade.addConditions({ leadSource: this.leadSource });
    }
  }

  private checkLocality() {
    if (this.locality) {
      this.facade.addConditions({ locality: this.locality });
    }
  }

  private checkNationality() {
    if (this.nationality) {
      this.facade.addConditions({ nationality: this.nationality });
    }
  }

  private checkState() {
    if (this.state) {
      this.facade.addConditions({ state: this.state });
    }
  }

  private checkPaymentMode() {
    if (this.paymentMode) {
      this.facade.addConditions({ paymentMode: this.paymentMode });
    }
  }

  private checkPaymentType() {
    if (this.paymentType) {
      this.facade.addConditions({ paymentType: this.paymentType });
    }
  }

  private checkProgramType() {
    if (this.programType) {
      this.facade.addConditions({ programType: this.programType });
    }
  }

  private checkStatus() {
    if (this.status) {
      this.facade.addConditions({ status: this.status });
    }
  }

  private checkCourse() {
    if (this.course) {
      this.facade.addConditions({ course: this.course });
    }
  }
  private checkProgram() {
    if (this.program) {
      this.facade.addConditions({ programId: this.program });
    }
  }

  private checkProgramName() {
    if (this.programName) {
      this.facade.addConditions({ programName: this.programName });
    }
  }

  private checkScholarshipType() {
    if (this.scholarshipType) {
      this.facade.addConditions({ scholarshipType: this.scholarshipType });
    }
  }

  private checkSendToDeb() {
    if (this.sendToDeb) {
      this.facade.addConditions({ sendToDeb: this.sendToDeb });
    }
  }

  private compareByEnrollmentNumber(first: any, second: any) {
    const firstEnrollment = this.getEnrollmentNumber(first);
    const secondEnrollment = this.getEnrollmentNumber(second);

    if (!firstEnrollment && !secondEnrollment) return 0;
    if (!firstEnrollment) return 1;
    if (!secondEnrollment) return -1;

    return firstEnrollment.localeCompare(secondEnrollment, undefined, { numeric: true, sensitivity: 'base' });
  }

  private getEnrollmentNumber(item: any) {
    for (const key of DebToLmsListFacade.ENROLLMENT_KEYS) {
      const value = item?.[key];
      if (value) {
        return String(value).trim();
      }
    }

    return '';
  }
}
