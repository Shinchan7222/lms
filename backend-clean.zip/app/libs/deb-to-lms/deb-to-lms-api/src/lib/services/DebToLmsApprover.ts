import { DebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { University } from '@edorer/university-data';
import { UpdateMultipleFacade } from '@edorer/generic-facades';
import { User } from '@edorer/user-data';

export class DebToLmsApprover {
  public items: DebToLms[] = [];

  public users: User[] = [];

  public records: DebToLms[] = [];

  private readonly approvedByAdmin: boolean;

  private readonly currentUser: User;

  public readonly recordIds: string[] = [];

  private readonly university: University;

  constructor(approvedByAdmin: boolean, currentUser: User, recordIds: string[] = [], university: University) {
    this.approvedByAdmin = approvedByAdmin;
    this.currentUser = currentUser;
    this.recordIds = recordIds;
    this.university = university;
  }

  async approve() {
    await this.updateRecords();
  }

  private async updateRecords() {
    if (this.recordIds.length === 0) return;

    try {
      if (this.approvedByAdmin) {
        const facade = new UpdateMultipleFacade({ approvedByAdmin: true }, { _id: { $in: this.recordIds } }, ['approvedByAdmin'], debToLmsRepository);
        await facade.create();

        return;
      }

      const facade = new UpdateMultipleFacade({ isApproved: true }, { _id: { $in: this.recordIds } }, ['isApproved'], debToLmsRepository);
      await facade.create();
    } catch (error: any) {
      console.error(error);
      throw new Error(error);
    }
  }
}
