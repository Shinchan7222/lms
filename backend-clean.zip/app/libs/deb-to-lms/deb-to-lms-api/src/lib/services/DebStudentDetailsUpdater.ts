import { Applicant, applicantRepository } from '@edorer/applicant-data';
import { hash } from 'bcryptjs';
import { University } from '@edorer/university-data';
import { User, userRepository, UserTypes } from '@edorer/user-data';
import { UserDynamicData, userDynamicDataRepository } from '@edorer/user-dynamic-data';
import { v4 as uuidV4 } from 'uuid';
import { VerifyEmail } from '@edorer/user-api';

export class DebStudentDetailsUpdater {
  private dynamicData: UserDynamicData;

  private readonly 'ABC ID': string;
  private readonly 'DEB-Student-Id': string;
  private readonly ABCID: string;
  private readonly AdmissionDate: string;
  private readonly AdmissionDetails: string;
  private readonly cdate: string;
  private readonly CourseName: string;
  private readonly DEBUniqueID: string;
  private readonly DOB: string;
  private readonly email: string;
  private readonly EnrollmentNumber: string;
  private readonly fathername: string;
  private readonly Gender: string;
  private readonly InstituteID: string;
  private readonly institutename: string;
  private readonly mobile: string;
  private readonly mode: string;
  private readonly Program: string;
  private readonly programcode: string;
  private readonly stdname: string;
  private readonly StudentID: string;
  private readonly UniqueNumber: string;
  private readonly university: University;
  private readonly UniversityName: string;

  private applicant: Applicant;
  private createdUser: User;
  private password: string;
  private user: User;

  constructor(
    ABCID: string,
    AdmissionDate: string,
    AdmissionDetails: string,
    cdate: string,
    CourseName: string,
    DEBUniqueID: string,
    DOB: string,
    email: string,
    EnrollmentNumber: string,
    fathername: string,
    Gender: string,
    InstituteID: string,
    institutename: string,
    mobile: string,
    mode: string,
    Program: string,
    programcode: string,
    stdname: string,
    StudentID: string,
    UniqueNumber: string,
    UniversityName: string,
    university: University
  ) {
    this.ABCID = ABCID;
    this.AdmissionDate = AdmissionDate;
    this.AdmissionDetails = AdmissionDetails;
    this.cdate = cdate;
    this.CourseName = CourseName;
    this.DEBUniqueID = DEBUniqueID;
    this.DOB = DOB;
    this.email = email;
    this.EnrollmentNumber = EnrollmentNumber;
    this.fathername = fathername;
    this.Gender = Gender;
    this.InstituteID = InstituteID;
    this.institutename = institutename;
    this.mobile = mobile;
    this.mode = mode;
    this.Program = Program;
    this.programcode = programcode;
    this.stdname = stdname;
    this.StudentID = StudentID;
    this.UniqueNumber = UniqueNumber;
    this.UniversityName = UniversityName;
    this.university = university;

    this.password = this.email;
    this['ABC ID'] = ABCID;
    this['DEB-Student-Id'] = DEBUniqueID;
  }

  private prepareExtraFields(extraFields = []) {
    const extraFieldsMap: Record<string, string> = {};

    extraFields.forEach((field) => {
      extraFieldsMap[field.key] = field.value;
    });

    for (const field of [
      'ABC ID',
      'ABCID',
      'AdmissionDate',
      'AdmissionDetails',
      'cdate',
      'CourseName',
      'DEB-Student-Id',
      'DEBUniqueID',
      'DOB',
      'EnrollmentNumber',
      'fathername',
      'Gender',
      'InstituteID',
      'institutename',
      'mobile',
      'mode',
      'Program',
      'programcode',
      'stdname',
      'StudentID',
      'UniqueNumber',
      'UniversityName'
    ]) {
      extraFieldsMap[field] = this[field];
    }

    const fields = [];
    for (const key in extraFieldsMap) {
      if (!extraFieldsMap[key]) continue;

      fields.push({ key, value: extraFieldsMap[key] });
    }

    return fields;
  }

  async update() {
    try {
      await this.fetchUser();

      if (this.user) {
        await this.fetchDynamicData();
        await Promise.all([this.updateExtraFields(), this.updateDynamicData()]);

        throw new Error('Registered already.');
      }

      await this.createApplicant();
      await this.createUser();

      await this.updateApplicant();
      await this.createUserDynamicData();
      await this.updateDynamicData();
      await this.generateEmail();

      return this.createdUser;
    } catch (error: any) {
      console.error(error);
      throw new Error(error?.message);
    }
  }

  private async fetchUser() {
    try {
      this.user = await userRepository.findOne({ email: this.email }).lean();
    } catch (error) {
      throw new Error('User not found');
    }
  }

  private async fetchDynamicData() {
    try {
      this.dynamicData = await userDynamicDataRepository.findOne({ user: this.user._id }).lean();
    } catch (error) {
      throw new Error('Dynamic data not found');
    }
  }

  private async updateExtraFields() {
    if (!this.user) throw new Error('User not found');

    try {
      const { extraFields = [] } = this.user;

      const fields = this.prepareExtraFields(extraFields);

      await userRepository.update({ _id: this.user._id }, { $set: { extraFields: fields } });
    } catch (error) {
      console.error(error);
      throw new Error('Failed to update extra fields');
    }
  }

  private async updateDynamicData() {
    try {
      const { data = [] } = this.dynamicData || {};

      const fields = this.prepareExtraFields(data);

      await userDynamicDataRepository.findOneAndUpdate({ user: this.user?._id || this.createdUser._id }, { data: fields }, { upsert: true });
    } catch (error) {
      console.error(error);
      throw new Error('Failed to update dynamic data');
    }
  }

  private async createApplicant() {
    try {
      this.applicant = await applicantRepository.create({ university: this.university._id });
    } catch (error) {
      console.error(error);
      throw new Error('Failed to create applicant');
    }
  }

  private async createUser() {
    try {
      const extraFields = this.prepareExtraFields();

      this.createdUser = await userRepository.create({
        applicant: this.applicant._id,
        email: this.email,
        extraFields,
        isEmailVerified: !this.university.verifyEmail,
        isPhoneVerified: !this.university.verifyPhone,
        name: this.stdname,
        password: await hash(this.password, 10),
        phone: this.mobile,
        type: UserTypes.APPLICANT,
        university: this.university._id,
        verifyToken: uuidV4()
      });
    } catch (error) {
      console.error(error);
      throw new Error('Failed to create user');
    }
  }

  private async updateApplicant() {
    try {
      await applicantRepository.update({ _id: this.applicant._id }, { $set: { owner: this.createdUser._id } }, { multi: false });
    } catch (error) {
      console.error(error);
      throw new Error('Failed to update applicant');
    }
  }

  private async createUserDynamicData() {
    try {
      const fields = this.prepareExtraFields();

      await userDynamicDataRepository.create({ data: fields, user: this.createdUser._id });
    } catch (error) {
      console.error(error);
      throw new Error('Failed to create user dynamic');
    }
  }

  private async generateEmail() {
    try {
      this.createdUser.password = this.password;
      const mailer = new VerifyEmail(this.university, this.createdUser);
      await mailer.send();
    } catch (e) {
      console.error(e);
    }
  }
}
