import { DateUtils, Json2Excel } from '@edorer/utils';
import { DebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';
import * as moment from 'moment';

export class DebToLmsExporter {
  private static readonly ENROLLMENT_KEYS = ['permanentEnrollmentNumber', 'enrollmentNumber', 'rollNumber', 'registrationNumber'];

  private readonly admissionSession: string;
  private readonly applicationSource: string;
  private readonly city: string;
  private readonly country: string;
  private readonly course: string;
  private readonly currentUser: User;
  private readonly endDate: Date;
  private readonly facade: ListFacade;
  private readonly feeStatus: string;
  private readonly isApproved: boolean;
  private readonly isConverted: string;
  private readonly keyword: string;
  private readonly leadSource: string;
  private readonly locality: string;
  private readonly nationality: string;
  private readonly paymentMode: string;
  private readonly paymentType: string;
  private readonly program: string;
  private readonly programName: string;
  private readonly programType: string;
  private readonly remittance: string;
  private readonly scholarshipType: string;
  private readonly sendToDeb: string;
  private readonly startDate: Date;
  private readonly state: string;
  private readonly status: string;
  private readonly university: University;

  public items: DebToLms[] = [];
  public results: Array<{ [key: string]: string | number }> = [];

  constructor(
    admissionSession: string,
    applicationSource: string,
    city: string,
    country: string,
    course: string,
    endDate: Date,
    feeStatus: string,
    isApproved: boolean,
    isConverted: string,
    keyword: string,
    leadSource: string,
    locality: string,
    nationality: string,
    paymentMode: string,
    paymentType: string,
    program: string,
    programName: string,
    programType: string,
    remittance: string,
    scholarshipType: string,
    sendToDeb: string,
    startDate: Date,
    state: string,
    status: string,
    currentUser: User,
    university: University
  ) {
    this.admissionSession = admissionSession;
    this.applicationSource = applicationSource;
    this.city = city;
    this.country = country;
    this.course = course;
    this.currentUser = currentUser;
    this.endDate = endDate;
    this.feeStatus = feeStatus;
    this.isApproved = isApproved;
    this.isConverted = isConverted;
    this.keyword = keyword;
    this.leadSource = leadSource;
    this.locality = locality;
    this.nationality = nationality;
    this.paymentMode = paymentMode;
    this.paymentType = paymentType;
    this.program = program;
    this.programName = programName;
    this.programType = programType;
    this.remittance = remittance;
    this.scholarshipType = scholarshipType;
    this.sendToDeb = sendToDeb;
    this.startDate = startDate;
    this.state = state;
    this.status = status;
    this.university = university;

    this.facade = new ListFacade(
      this.currentUser,
      this.university,
      0,
      0,
      this.keyword,
      ['abcId', 'applicationId', 'applicationNumber', 'debUniqueId', 'easepayId', 'email', 'fatherName', 'leadId', 'name', 'programId', 'utrNo'],
      debToLmsRepository
    );
  }

  async export() {
    this.addConditions();

    this.facade.addConditions({ isFresh: true });

    const { items } = await this.facade.createOnlyItems();
    this.items = [...items].sort((a, b) => this.compareByEnrollmentNumber(a, b));

    this.prepareData();

    const converter = new Json2Excel(this.results);
    converter.sheet = 'Results';

    return await converter.convert();
  }

  private addConditions() {
    this.facade.addConditions({ isApproved: this.isApproved });
    if (this.isConverted && this.isConverted === 'converted') {
      this.facade.addConditions({ isConverted: true });
    }

    if (this.isConverted && this.isConverted === 'notConverted') {
      this.facade.addConditions({ $and: [{ $or: [{ isConverted: { $exists: false } }, { isConverted: false }] }] });
    }

    this.checkAdmissionSession();
    this.checkApplicationSource();
    this.checkCity();
    this.checkCountry();
    this.checkCourse();
    this.checkDates();
    this.checkFeeStatus();
    this.checkLeadSource();
    this.checkLocality();
    this.checkNationality();
    this.checkState();
    this.checkPaymentMode();
    this.checkPaymentType();
    this.checkProgram();
    this.checkProgramName();
    this.checkProgramType();
    this.checkRemittance();
    this.checkStatus();
    this.checkProgram();
    this.checkScholarshipType();
    this.checkSendToDeb();
  }

  private checkAdmissionSession() {
    if (this.admissionSession) {
      this.facade.addConditions({ admissionSession: this.admissionSession });
    }
  }

  private checkApplicationSource() {
    if (this.applicationSource) {
      this.facade.addConditions({ applicationSource: this.applicationSource });
    }
  }

  private checkCity() {
    if (this.city) {
      this.facade.addConditions({ city: this.city });
    }
  }

  private checkCountry() {
    if (this.country) {
      this.facade.addConditions({ country: this.country });
    }
  }

  private checkDates() {
    if (this.endDate && this.startDate) {
      this.facade.addConditions({
        $and: [
          {
            $or: [
              { admissionDate: { $gte: this.startDate, $lte: this.endDate } },
              { applicationGenerationDate: { $gte: this.startDate, $lte: this.endDate } },
              { leadGenerationDate: { $gte: this.startDate, $lte: this.endDate } },
              { provisionalAdmissionDate: { $gte: this.startDate, $lte: this.endDate } },
              { registrationDate: { $gte: this.startDate, $lte: this.endDate } },
              { scholarshipAppliedDate: { $gte: this.startDate, $lte: this.endDate } }
            ]
          }
        ]
      });
    }
  }

  private checkFeeStatus() {
    if (this.feeStatus) {
      this.facade.addConditions({ feeStatus: this.feeStatus });
    }
  }

  private checkLeadSource() {
    if (this.leadSource) {
      this.facade.addConditions({ leadSource: this.leadSource });
    }
  }

  private checkLocality() {
    if (this.locality) {
      this.facade.addConditions({ locality: this.locality });
    }
  }

  private checkNationality() {
    if (this.nationality) {
      this.facade.addConditions({ nationality: this.nationality });
    }
  }

  private checkState() {
    if (this.state) {
      this.facade.addConditions({ state: this.state });
    }
  }

  private checkPaymentMode() {
    if (this.paymentMode) {
      this.facade.addConditions({ paymentMode: this.paymentMode });
    }
  }

  private checkRemittance() {
    if (this.remittance && this.remittance === 'Fresh') {
      this.facade.addConditions({ isFresh: true });
    } else if (this.remittance && this.remittance === 'Recurring') {
      this.facade.addConditions({ isFresh: false });
    }
  }

  private checkPaymentType() {
    if (this.paymentType) {
      this.facade.addConditions({ paymentType: this.paymentType });
    }
  }

  private checkProgramType() {
    if (this.programType) {
      this.facade.addConditions({ programType: this.programType });
    }
  }

  private checkStatus() {
    if (this.status) {
      this.facade.addConditions({ status: this.status });
    }
  }

  private checkProgram() {
    if (this.program) {
      this.facade.addConditions({ programId: this.program });
    }
  }

  private checkCourse() {
    if (this.course) {
      this.facade.addConditions({ course: this.course });
    }
  }

  private checkProgramName() {
    if (this.programName) {
      this.facade.addConditions({ programName: this.programName });
    }
  }

  private checkScholarshipType() {
    if (this.scholarshipType) {
      this.facade.addConditions({ scholarshipType: this.scholarshipType });
    }
  }

  private checkSendToDeb() {
    if (this.sendToDeb) {
      this.facade.addConditions({ sendToDeb: this.sendToDeb });
    }
  }

  private prepareData() {
    for (let index = 0; index < this.items.length; index++) {
      const report = this.items[index];
      const item: { [key: string]: number | string } = { 'S. No': index + 1 };

      item['Name'] = report.name || '--';
      item['First Name'] = report.firstName || '--';
      item['Last Name'] = report.lastName || '--';
      item['Aadhar Number'] = report.aadharNumber || '--';
      item['ABC ID'] = report.abcId || '--';
      item['Additional Contacts'] = report.additionalContacts.join(', ') || '--';
      item['Personal Emails'] = report.additionalEmails.join(', ') || '--';
      item['Admission Date'] = moment(report.admissionDate).format(DateUtils.DATE_FORMATS.FULL_DATE) || '--';
      item['Admission Session'] = report.admissionSession || '--';
      item['Application Generated DateTime'] = moment(report.applicationGeneratedDatetime).format(DateUtils.DATE_FORMATS.FULL_DATE) || '--';
      item['Application Id'] = report.applicationId || '--';
      item['Application #'] = report.applicationNumber || '--';
      item['Application Source'] = report.applicationSource || '--';
      item['Date of Birth'] = report.birthDate || '--';
      item['Blood Group'] = report.bloodGroup || '--';
      item['City'] = report.city || '--';
      item['Country'] = report.country || '--';
      item['Course'] = report.course || '--';
      item['DEB ID'] = report.debUniqueId || '--';
      item["Father's Name"] = report.fatherName || '--';
      item['Collected Academic Fee'] = report.feeCollected || '--';
      item['Academic Fee Status'] = report.feeStatus || '--';
      item['Gender'] = report.gender || '--';
      item['ID'] = report.id || '--';
      item['Lead Generated DateTime'] = moment(report.leadGeneratedDatetime).format(DateUtils.DATE_FORMATS.FULL_DATE) || '--';
      item['Lead Id'] = report.leadId || '--';
      item['Lead Intake'] = report.leadIntake || '--';
      item['Lead Source'] = report.leadSource || '--';
      item['Locality'] = report.locality || '--';
      item['Nationality'] = report.nationality || '--';
      item['Outstanding Academic Fee'] = report.outstandingFee || '--';
      item['Passport Number'] = report.passportNumber || '--';
      item['Payment Mode'] = report.paymentMode || '--';
      item['Payment Type'] = report.paymentType || '--';
      item['Payment Nature'] = report.paymentNature || '--';
      item['Permanent Enrollment Number'] = report.permanentEnrollmentNumber || '--';
      item['LMS Email'] = report.email || '--';
      item['Primary Contact'] = report.phoneNumber || '--';
      item['Profile Picture'] = report.profilePicture || '--';
      item['Program'] = report.program || '--';
      item['Program Name As Per Edorer'] = report.programName || '--';
      item['Program Type'] = report.programType || '--';
      item['Provisional Admission Date'] = moment(report.provisionalAdmissionDate).format(DateUtils.DATE_FORMATS.FULL_DATE) || '--';
      item['Registration Date'] = moment(report.registrationDate).format(DateUtils.DATE_FORMATS.FULL_DATE) || '--';
      item['Remarks'] = report.remarks || '--';
      item['Scholarship Amount'] = report.scholarshipAmount || '--';
      item['Scholarship Applied Date'] = moment(report.scholarshipAppliedDate).format(DateUtils.DATE_FORMATS.FULL_DATE) || '--';
      item['Scholarship Type'] = report.scholarshipType || '--';
      item['Send To DEB'] = report.sendToDeb || '--';
      item['State'] = report.state || '--';
      item['Approval Status'] = report.isApproved ? 'Approved' : 'Pending';
      item['Status'] = report.status || '--';
      item['Session Intake'] = report.sessionIntake || '--';
      item['Total Academic Fee'] = report.totalFee || '--';
      item['Settlement UTR'] = report.utrNo || '--';
      item['Settlement Date'] = report.utrDate || '--';
      item['Transaction IDs'] = report.transactionIds.join(', ') || '--';
      item['Remittance Type'] = report.isFresh ? 'Fresh' : 'Recurring';

      if (this.currentUser.type === UserTypes.UNIVERSITY_OWNER) {
        item['Password'] = report.password || '--';
      }

      this.results.push(item);
    }
  }

  private compareByEnrollmentNumber(first: any, second: any) {
    const firstEnrollment = this.getEnrollmentNumber(first);
    const secondEnrollment = this.getEnrollmentNumber(second);

    if (!firstEnrollment && !secondEnrollment) return 0;
    if (!firstEnrollment) return 1;
    if (!secondEnrollment) return -1;

    return firstEnrollment.localeCompare(secondEnrollment, undefined, { numeric: true, sensitivity: 'base' });
  }

  private getEnrollmentNumber(item: any) {
    for (const key of DebToLmsExporter.ENROLLMENT_KEYS) {
      const value = item?.[key];
      if (value) {
        return String(value).trim();
      }
    }

    return '';
  }
}
