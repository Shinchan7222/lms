import { DebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { University } from '@edorer/university-data';
import { User, userRepository } from '@edorer/user-data';

export class DebToLmsCoursesUpdater {
  private readonly courseIds: string[] = [];
  private readonly recordIds: string[] = [];
  private readonly university: University;

  private records: DebToLms[] = [];
  private users: User[] = [];

  constructor(courseIds: string[], recordIds: string[], university: University) {
    this.courseIds = courseIds;
    this.recordIds = recordIds;
    this.university = university;
  }

  async update() {
    await this.fetchRecords();
    await this.fetchUsers();

    await this.updateCourses();
  }

  private async fetchRecords() {
    this.records = await debToLmsRepository
      .find({ _id: { $in: this.recordIds }, isApproved: true, isConverted: true, university: this.university._id })
      .lean();
  }

  private async fetchUsers() {
    await this.fetchRecords();

    const emails = this.records.map((record) => record.email).filter(Boolean);

    this.users = await userRepository
      .find({
        email: { $regex: new RegExp(`^(${emails.map((email) => email.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})$`, 'i') },
        university: this.university._id
      })
      .lean();
  }

  private async updateCourses() {
    try {
      await userRepository.update(
        { _id: { $in: this.users.map((user) => user._id) }, university: this.university._id },
        { $addToSet: { courses: { $each: this.courseIds } } }
      );
    } catch (error) {
      console.error(error);
    }
  }
}
