import { CanUpdateDebToLmsDetails } from '@edorer/deb-to-lms-data';
import { DebToLmsTransferUpdater } from '../services/DebToLmsTransferUpdater';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';
import { DebToLmsTransferApprover } from '../services/DebToLmsTransferApprover';
import { DebToLmsTransferRejecter } from '../services/DebToLmsTransferRejecter';

@JsonController()
export class DebToLmsTransferController {
  @Put('/deb-to-lms/transfer')
  @Validate([
    {
      field: 'attachments',
      validation: [{ value: 'notEmpty', message: 'attachments are required' }]
    },
    {
      field: 'classes',
      validation: [{ value: 'notEmpty', message: 'classes are required' }]
    },
    {
      field: 'course',
      validation: [{ value: 'notEmpty', message: 'course is required' }]
    },
    {
      field: 'feeCategory',
      validation: [{ value: 'notEmpty', message: 'feeCategory is required' }]
    },
    {
      field: 'program',
      validation: [{ value: 'notEmpty', message: 'program is required' }]
    },
    {
      field: 'remarks',
      validation: [{ value: 'notEmpty', message: 'remarks is required' }]
    },
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'records are required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanUpdateDebToLmsDetails)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async transfer(@Req() req: any, @Res() res: any) {
    try {
      const { attachments, classes, course, feeCategory, program, ids: records, remarks } = req.body;

      const facade = new DebToLmsTransferUpdater(
        attachments,
        classes,
        course,
        feeCategory,
        program,
        records,
        remarks,
        req.user,
        req.university
      );
      await facade.transfer();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/deb-to-lms/approve-transfer')
  @Validate([
    {
      field: 'id',
      validation: [{ value: 'notEmpty', message: 'ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanUpdateDebToLmsDetails)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async approve(@Req() req: any, @Res() res: any) {
    try {
      const { id } = req.body;

      const facade = new DebToLmsTransferApprover(
        id,
        req.university
      );
      await facade.approve();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/deb-to-lms/reject-transfer')
  @Validate([
    {
      field: 'id',
      validation: [{ value: 'notEmpty', message: 'ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanUpdateDebToLmsDetails)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async reject(@Req() req: any, @Res() res: any) {
    try {
      const { id } = req.body;

      const facade = new DebToLmsTransferRejecter(
        id,
        req.university
      );
      await facade.reject();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
