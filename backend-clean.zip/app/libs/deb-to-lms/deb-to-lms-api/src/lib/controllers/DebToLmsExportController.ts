import { DebToLmsExporter } from '../services/DebToLmsExporter';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { readFileSync } from 'fs';
import { CanExportDebToLms } from '@edorer/deb-to-lms-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class DebToLmsExportController {
  @Get('/deb-to-lms/export')
  @Validate([
    'admissionSession',
    'applicationSource',
    'city',
    'country',
    'course',
    'endDate',
    'feeStatus',
    'isConverted',
    'keyword',
    'leadSource',
    'locality',
    'nationality',
    'paymentMode',
    'paymentType',
    'program',
    'programName',
    'programType',
    'remittance',
    'scholarshipType',
    'sendToDeb',
    'startDate',
    'state',
    'status'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanExportDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async export(@Req() req: any, @Res() res: any) {
    try {
      const {
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        isConverted,
        keyword,
        leadSource,
        locality,
        nationality,
        paymentType,
        program,
        programName,
        programType,
        scholarshipType,
        sendToDeb,
        startDate,
        remittance,
        paymentMode,
        state,
        status
      } = req.query;

      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=ExamReports.xlsx');

      const excel = new DebToLmsExporter(
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        false,
        isConverted,
        keyword,
        leadSource,
        locality,
        nationality,
        paymentMode,
        paymentType,
        program,
        programName,
        programType,
        remittance,
        scholarshipType,
        sendToDeb,
        startDate,
        state,
        status,
        req.user,
        req.university
      );
      const path = await excel.export();
      const buffer = readFileSync(path);

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; ExamReports.xlsx`,
        'Content-Length': buffer.length
      });
      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/export-approved')
  @Validate([
    'admissionSession',
    'applicationSource',
    'city',
    'country',
    'course',
    'endDate',
    'feeStatus',
    'isConverted',
    'keyword',
    'leadSource',
    'locality',
    'nationality',
    'paymentType',
    'program',
    'programName',
    'programType',
    'remittance',
    'scholarshipType',
    'sendToDeb',
    'startDate',
    'paymentMode',
    'state',
    'status'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanExportDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async exportApproved(@Req() req: any, @Res() res: any) {
    try {
      const {
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        isConverted,
        keyword,
        leadSource,
        locality,
        nationality,
        paymentType,
        program,
        programName,
        programType,
        scholarshipType,
        sendToDeb,
        startDate,
        remittance,
        paymentMode,
        state,
        status
      } = req.query;

      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=ExamReports.xlsx');

      const excel = new DebToLmsExporter(
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        true,
        isConverted,
        keyword,
        leadSource,
        locality,
        nationality,
        paymentMode,
        paymentType,
        program,
        programName,
        programType,
        remittance,
        scholarshipType,
        sendToDeb,
        startDate,
        state,
        status,
        req.user,
        req.university
      );
      const path = await excel.export();
      const buffer = readFileSync(path);

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; ExamReports.xlsx`,
        'Content-Length': buffer.length
      });
      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
