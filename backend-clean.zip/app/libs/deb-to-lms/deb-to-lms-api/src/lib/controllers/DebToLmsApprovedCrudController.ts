import { DebToLmsApprovedListFacade } from '../services/DebToLmsApprovedListFacade';
import { CanDeleteDebToLms, CanUpdateDebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { UpdateFacade } from '@edorer/generic-facades';
import { Validate } from '@edorer/validator';

@JsonController()
export class DebToLmsApprovedCrudController {
  @Get('/approved-deb-to-lms')
  @Validate([
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    'admissionSession',
    'applicationSource',
    'city',
    'country',
    'course',
    'endDate',
    'feeStatus',
    'isConverted',
    'keyword',
    'leadSource',
    'locality',
    'nationality',
    'paymentMode',
    'paymentType',
    'program',
    'programName',
    'programType',
    'remittance',
    'scholarshipType',
    'sendToDeb',
    'startDate',
    'state',
    'status'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const {
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        isConverted,
        keyword,
        leadSource,
        limit,
        locality,
        nationality,
        paymentMode,
        paymentType,
        program,
        programName,
        programType,
        remittance,
        scholarshipType,
        sendToDeb,
        skip,
        startDate,
        state,
        status
      } = req.query;

      const facade = new DebToLmsApprovedListFacade(
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        isConverted,
        keyword,
        leadSource,
        limit,
        locality,
        nationality,
        paymentMode,
        paymentType,
        program,
        programName,
        programType,
        remittance,
        scholarshipType,
        sendToDeb,
        skip,
        startDate,
        state,
        status,
        req.user,
        req.university
      );
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/approved-deb-to-lms/:debToLmsId([0-9a-f]{24})')
  @Validate([
    {
      field: 'debToLmsId',
      validation: [{ value: 'notEmpty', message: 'ID is required' }]
    },
    'aadharNumber',
    'abcId',
    'additionalContacts',
    'additionalEmails',
    'admissionDate',
    'admissionSession',
    'applicationGeneratedDatetime',
    'applicationId',
    'applicationNumber',
    'applicationSource',
    'birthDate',
    'city',
    'country',
    'course',
    'debUniqueId',
    'email',
    'fatherName',
    'feeCollected',
    'feeStatus',
    'gender',
    'id',
    'leadGeneratedDatetime',
    'leadId',
    'leadIntake',
    'leadSource',
    'locality',
    'name',
    'nationality',
    'outstandingFee',
    'passportNumber',
    'paymentType',
    'permanentEnrollmentNumber',
    'phoneNumber',
    'program',
    'programName',
    'programType',
    'provisionalAdmissionDate',
    'registrationDate',
    'remarks',
    'scholarshipAmount',
    'scholarshipAppliedDate',
    'scholarshipType',
    'sendToDeb',
    'state',
    'status',
    'totalFee'
  ])
  @UseBefore(IsAuthenticated, CanUpdateDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async update(@Req() req: any, @Res() res: any, @Param('debToLmsId') debToLmsId: string) {
    try {
      const facade = new UpdateFacade(
        debToLmsId,
        req.body,
        [
          'aadharNumber',
          'abcId',
          'additionalContacts',
          'additionalEmails',
          'admissionDate',
          'admissionSession',
          'applicationGeneratedDatetime',
          'applicationId',
          'applicationNumber',
          'applicationSource',
          'birthDate',
          'city',
          'country',
          'course',
          'debUniqueId',
          'email',
          'fatherName',
          'feeCollected',
          'feeStatus',
          'gender',
          'id',
          'leadGeneratedDatetime',
          'leadId',
          'leadIntake',
          'leadSource',
          'locality',
          'name',
          'nationality',
          'outstandingFee',
          'passportNumber',
          'paymentType',
          'permanentEnrollmentNumber',
          'phoneNumber',
          'program',
          'programName',
          'programType',
          'provisionalAdmissionDate',
          'registrationDate',
          'remarks',
          'scholarshipAmount',
          'scholarshipAppliedDate',
          'scholarshipType',
          'sendToDeb',
          'state',
          'status',
          'totalFee'
        ],
        debToLmsRepository
      );
      await facade.create();

      return res.status(201).send({ message: 'Updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/approved-deb-to-lms/delete')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'IDs are required' }]
    }
  ])
  @UseBefore(IsAuthenticated, CanDeleteDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async delete(@Req() req: any, @Res() res: any) {
    try {
      const { ids } = req.body;

      await debToLmsRepository.destroy({ _id: { $in: ids } }, req.user._id);

      return res.send({ message: 'Record(s) deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
