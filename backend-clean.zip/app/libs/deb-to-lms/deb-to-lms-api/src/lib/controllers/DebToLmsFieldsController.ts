import { debToLmsRepository } from '@edorer/deb-to-lms-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';

@JsonController()
export class DebToLmsFieldsController {
  @Get('/deb-to-lms/admission-sessions')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async admissionSessions(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const admissionSessions = await debToLmsRepository.distinct('admissionSession', {
        admissionSession: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = admissionSessions.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/application-sources')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async applicationSources(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const applicationSources = await debToLmsRepository.distinct('applicationSource', {
        applicationSource: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = applicationSources.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/cities')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async cities(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const cities = await debToLmsRepository.distinct('city', {
        city: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = cities.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/countries')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async countries(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const countries = await debToLmsRepository.distinct('country', {
        country: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = countries.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/nationalities')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async nationalities(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const nationalities = await debToLmsRepository.distinct('nationality', {
        nationality: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = nationalities.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/states')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async states(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const states = await debToLmsRepository.distinct('state', {
        state: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = states.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/lead-sources')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async leadSources(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const leadSources = await debToLmsRepository.distinct('leadSource', {
        leadSource: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = leadSources.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/programs')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async programs(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const programs = await debToLmsRepository.distinct('programName', {
        deleted: false,
        programName: new RegExp(keyword, 'i'),
        university: req.university._id
      });

      const result = programs.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/courses')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async courses(@Req() req: any, @Res() res: any) {
    try {
      const { keyword } = req.query;

      const courses = await debToLmsRepository.distinct('course', {
        course: new RegExp(keyword, 'i'),
        university: req.university._id
      });
      const result = courses.filter(Boolean).map((o) => ({ name: o, value: o }));

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
