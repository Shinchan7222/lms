const jwt = require('jsonwebtoken');
import { DebStudentDetailsSubmitter } from '../services/DebStudentDetailsSubmitter';
import { DebStudentDetailsUpdater } from '../services/DebStudentDetailsUpdater';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';
import axios from 'axios';

@JsonController()
export class DebStudentController {
  @Post('/deb-to-lms/students/get-details')
  @Validate([
    {
      field: 'debId',
      validation: [{ value: 'notEmpty', message: 'Deb ID is required' }]
    }
  ])
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async getStudentDetails(@Req() req: any, @Res() res: any) {
    try {
      const { debId } = req.body;

      const { data } = await axios.post(
        'https://deb.ugc.ac.in/api/DebUniqueID/GetStudentDetails',
        { PROGRAMCODE: debId },
        {
          headers: {
            APIKey: 'zXtniIlfhWTlPlxxxCrId71eagiZmxfD',
            ClientID: 'MM0168_GetStudentDetails'
          },
          params: { PROGRAMCODE: debId }
        }
      );

      console.log(data);

      return res.status(200).send(data);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/deb-to-lms/students/update-details')
  @Validate([
    {
      field: 'DEBUniqueID',
      validation: [{ value: 'notEmpty', message: 'DEB Id is required' }]
    },
    {
      field: 'email',
      validation: [{ value: 'notEmpty', message: 'Email is required' }]
    },
    {
      field: 'stdname',
      validation: [{ value: 'notEmpty', message: 'Student name is required' }]
    },
    'ABCID',
    'AdmissionDate',
    'AdmissionDetails',
    'cdate',
    'CourseName',
    'DEBUniqueID',
    'DOB',
    'EnrollmentNumber',
    'fathername',
    'Gender',
    'InstituteID',
    'institutename',
    'mobile',
    'mode',
    'Program',
    'programcode',
    'StudentID',
    'UniqueNumber',
    'UniversityName'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async updateStudentDetails(@Req() req: any, @Res() res: any) {
    try {
      const {
        ABCID,
        AdmissionDate,
        AdmissionDetails,
        cdate,
        CourseName,
        DEBUniqueID,
        DOB,
        email,
        EnrollmentNumber,
        fathername,
        Gender,
        InstituteID,
        institutename,
        mobile,
        mode,
        Program,
        programcode,
        stdname,
        StudentID,
        UniqueNumber,
        UniversityName
      } = req.body;

      const updater = new DebStudentDetailsUpdater(
        ABCID,
        AdmissionDate,
        AdmissionDetails,
        cdate,
        CourseName,
        DEBUniqueID,
        DOB,
        email,
        EnrollmentNumber,
        fathername,
        Gender,
        InstituteID,
        institutename,
        mobile,
        mode,
        Program,
        programcode,
        stdname,
        StudentID,
        UniqueNumber,
        UniversityName,
        req.university
      );

      const applicant = await updater.update();

      const token = jwt.sign(
        {
          email: applicant.email,
          _id: applicant._id
        },
        `-----BEGIN RSA PRIVATE KEY-----
MIICXgIBAAKBgQDYSA1pbh5egaUQe7MbJUbUhbN6yxArBIjk4Y2drD7p6uBchayq
fWzN53vcbUQC7rkjqANKiLJdA+5GeUV7tcB753h4prFWe4yGZ0gO8LsoG9qAmCQV
3KRN95YJflwekfU3Hdf0vziZar38kddEBs8rG8MMLEHPuA4PaB9rtrNW0QIDAQAB
AoGBANOza1VYkWdmNUD2I/GdQkCCApVeMJw62xhWYz0Dva1P138Y5VMYZCkDvayc
U2cfbp8lNNt/BD+huljHGakm1ZllYp2xHvLjBP0gL/QVsip/+AbUcb59RZy/EHM6
HLXxq199AgTnBjA8fJ6aBlt5evH16hNj5/NPG2hkk980lZM1AkEA9toWLHtEthE9
XI1yLdxQz9P2qKHVp0xWgElskx2ah4byr+MwxnnmZ2bQV0+v1dtxz3DdFuhLKkNT
bTQ5+7mF1wJBAOBL8Lgi8Bwi5wqWxlJlNBKLlftNk+S7G5dZDgmNy4ROQ+KgX9Um
w5JhTQODi9fivt6l8ZYuLYY18VT98YevI5cCQQCIwBRcnAVan35Q0YMZaN3T5GbW
0KCdx6p78zEU5ud+gQHc8o1IxqsfSVPNqrWMUb9g3fN9Bz7ssNN8wdwFWaeNAkEA
vkfuaWhKZrQ9aUBL8y6kJG+Cx3Ui2FLbr2P/gp9mXlG/SY1gf4WpOI+PNEHu6zET
V/NTpmJ6gHdWyxG8S62K9QJATw1J1GVOdx6BoFZxRr8m4FVOc7iDf1F55Ouv8zGI
n4peScen8hUFmnvo0EAaiRrCIOZO3rb/0pDX8E9sncwNyg==
-----END RSA PRIVATE KEY-----`,
        { algorithm: 'RS256', expiresIn: '24h' }
      );

      return res.status(201).send({ ...JSON.parse(JSON.stringify(applicant)), token });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/deb-to-lms/students/submit-details')
  @Validate([
    // {
    //   field: 'ABCID',
    //   validation: [{ value: 'notEmpty', message: 'ABC ID is required' }]
    // },
    {
      field: 'DEBUniqueID',
      validation: [{ value: 'notEmpty', message: 'DEB ID is required' }]
    },
    {
      field: 'student',
      validation: [{ value: 'notEmpty', message: 'Student ID is required' }]
    },
    'ABCID',
    'AdmissionDate',
    'AdmissionDetails'
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async submitStudentDetails(@Req() req: any, @Res() res: any) {
    const { ABCID, AdmissionDate, AdmissionDetails, DEBUniqueID, student } = req.body;

    try {
      const submitter = new DebStudentDetailsSubmitter(ABCID, AdmissionDate, AdmissionDetails, DEBUniqueID, student);
      await submitter.submit();

      return res.status(200).send({ message: 'Details submitted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
