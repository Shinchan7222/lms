import { DebToLmsUpdater } from '../services/DebToLmsUpdater';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { IsAuthenticated, userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import { GetUniversity } from '@edorer/university-data';
import { CanUpdateDebToLmsDetails } from '@edorer/deb-to-lms-data';

@JsonController()
export class DebToLmsRestrictionController {
  @Put('/deb-to-lms/update-restriction')
  @Validate([
    {
      field: 'profile',
      validation: [{ value: 'notEmpty', message: 'profile is required' }]
    },
    'isRestricted'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanUpdateDebToLmsDetails)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async updateRestriction(@Req() req: any, @Res() res: any) {
    try {
      const updater = new DebToLmsUpdater(req.body.profile, req.body);
      const result = await updater.update();

      await userRepository.update(
        { email: { $regex: result.email, $options: 'i' }, university: req.university._id },
        { $set: { isRestricted: req.body.isRestricted } },
        { multi: false }
      );

      return res.status(201).send({ message: 'Updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
