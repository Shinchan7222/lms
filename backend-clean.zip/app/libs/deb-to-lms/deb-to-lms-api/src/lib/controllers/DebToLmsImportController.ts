import { CanImportDebToLms } from '@edorer/deb-to-lms-data';
import { DebToLmsImporter } from '../services/DebToLmsImporter';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity, GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';

/**
 * @description Controller for working with Exam Questions
 */
@JsonController()
export class DebToLmsImportController {
  @Post('/deb-to-lms/import')
  @UseBefore(GetUniversityConfig)
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanImportDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async import(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      const debToLmsImporter = new DebToLmsImporter(file, req.user, req.university, req.universityConfig);
      await debToLmsImporter.import();

      return res.send({ message: 'Imported successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
