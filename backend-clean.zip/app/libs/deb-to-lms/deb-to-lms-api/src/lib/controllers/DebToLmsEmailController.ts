import { DebToLmsEmailer } from '../services/DebToLmsEmailer';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';
import { CanEmailDebToLms } from '@edorer/deb-to-lms-data';

/**
 * @description Controller for working with Exam Questions
 */
@JsonController()
export class DebToLmsEmailController {
  @Post('/deb-to-lms/email')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'IDs are required' }]
    },
    {
      field: 'template',
      validation: [{ value: 'notEmpty', message: 'Template is required' }]
    },
    'attachments'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanEmailDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async email(@Req() req: any, @Res() res: any) {
    const { attachments, ids, template } = req.body;

    try {
      const debToLmsImporter = new DebToLmsEmailer(attachments, ids, template, req.university);
      await debToLmsImporter.email();

      return res.send({ message: 'Emailed successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
