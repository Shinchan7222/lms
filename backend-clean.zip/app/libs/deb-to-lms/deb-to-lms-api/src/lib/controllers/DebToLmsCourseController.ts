import { DebToLmsCoursesUpdater } from '../services/DebToLmsCoursesUpdater';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import { CanUpdateDebToLmsDetails } from '@edorer/deb-to-lms-data';

@JsonController()
export class DebToLmsCourseController {
  @Put('/deb-to-lms/update-courses')
  @Validate([
    {
      field: 'courses',
      validation: [{ value: 'notEmpty', message: 'courses are required' }]
    },
    {
      field: 'records',
      validation: [{ value: 'notEmpty', message: 'records are required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanUpdateDebToLmsDetails)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async update(@Req() req: any, @Res() res: any) {
    try {
      const { courses, records } = req.body;

      const facade = new DebToLmsCoursesUpdater(courses, records, req.university);
      await facade.update();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
