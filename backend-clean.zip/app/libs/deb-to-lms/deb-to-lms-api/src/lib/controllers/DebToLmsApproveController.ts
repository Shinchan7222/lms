import { DebToLmsApprover } from '../services/DebToLmsApprover';
import { DebToLmsDisApprover } from '../services/DebToLmsDisApprover';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';
import { DebToLmsConverter } from '../services/DebToLmsConverter';
import { CanApproveDebToLms } from '@edorer/deb-to-lms-data';
import { DebToLmsInitialApprover } from '../services/DebToLmsInitialApprover';

@JsonController()
export class DebToLmsApproveController {
  @Put('/deb-to-lms/approve')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'IDs are required' }]
    },
    'approvedByAdmin'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanApproveDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async approve(@Req() req: any, @Res() res: any) {
    try {
      const { approvedByAdmin = false, ids } = req.body;

      const approver = new DebToLmsApprover(approvedByAdmin, req.user, ids, req.university);
      await approver.approve();

      return res.send({ message: 'Record(s) approved successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/deb-to-lms/dis-approve')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'IDs are required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanApproveDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async disApprove(@Req() req: any, @Res() res: any) {
    try {
      const { ids } = req.body;

      const approver = new DebToLmsDisApprover(req.user, ids, req.university);
      await approver.disApprove();

      return res.send({ message: 'Record(s) dis-approved successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/deb-to-lms/convert')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'IDs are required' }]
    },
    {
      field: 'template',
      validation: [{ value: 'notEmpty', message: 'Template is required' }]
    },
    'attachments'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanApproveDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async convert(@Req() req: any, @Res() res: any) {
    const { attachments, ids, template } = req.body;

    try {
      const converter = new DebToLmsConverter(attachments, ids, template, req.user, req.university);
      await converter.convert();

      return res.send({ message: 'Record(s) approved successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/deb-to-lms/cdoe-approve')
  @Validate([
    {
      field: 'amount',
      validation: [{ value: 'notEmpty', message: 'Amount is required' }]
    },
    {
      field: 'documents',
      validation: [{ value: 'notEmpty', message: 'Documents are required' }]
    },
    {
      field: 'remarks',
      validation: [{ value: 'notEmpty', message: 'Remarks is required' }]
    },
    {
      field: 'record',
      validation: [{ value: 'notEmpty', message: 'Record ID are required' }]
    },
    {
      field: 'scholarshipType',
      validation: [{ value: 'notEmpty', message: 'Scholarship Type is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async adminApprove(@Req() req: any, @Res() res: any) {
    const { amount, documents, remarks, record, scholarshipType } = req.body;

    try {
      const converter = new DebToLmsInitialApprover(amount, documents, remarks, record, scholarshipType, req.user, req.university);
      await converter.approve();

      return res.send({ message: 'Record(s) approved successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
