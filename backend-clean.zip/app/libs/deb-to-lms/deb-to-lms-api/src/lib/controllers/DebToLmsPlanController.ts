import { CanUpdateDebToLmsDetails } from '@edorer/deb-to-lms-data';
import { DebToLmsPlanUpdater } from '../services/DebToLmsPlanUpdater';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';

@JsonController()
export class DebToLmsPlanController {
  @Put('/deb-to-lms/update-fee-plan')
  @Validate([
    {
      field: 'feeCategory',
      validation: [{ value: 'notEmpty', message: 'feeCategory is required' }]
    },
    {
      field: 'records',
      validation: [{ value: 'notEmpty', message: 'records are required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanUpdateDebToLmsDetails)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async update(@Req() req: any, @Res() res: any) {
    try {
      const { feeCategory, records } = req.body;

      const facade = new DebToLmsPlanUpdater(feeCategory, records, req.university);
      await facade.update();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
