import { DebToLmsListFacade } from '../services/DebToLmsListFacade';
import { CanDeleteDebToLms, CanUpdateDebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { DebToLmsUpdater } from '../services/DebToLmsUpdater';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class DebToLmsCrudController {
  @Get('/deb-to-lms')
  @Validate([
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    'admissionSession',
    'applicationSource',
    'city',
    'country',
    'course',
    'endDate',
    'feeStatus',
    'keyword',
    'leadSource',
    'locality',
    'nationality',
    'paymentMode',
    'paymentType',
    'program',
    'programName',
    'programType',
    'scholarshipType',
    'sendToDeb',
    'startDate',
    'state',
    'status'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const {
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        keyword,
        leadSource,
        limit,
        locality,
        nationality,
        paymentType,
        program,
        programName,
        programType,
        scholarshipType,
        sendToDeb,
        skip,
        startDate,
        paymentMode,
        state,
        status
      } = req.query;

      const facade = new DebToLmsListFacade(
        admissionSession,
        applicationSource,
        city,
        country,
        course,
        endDate,
        feeStatus,
        keyword,
        leadSource,
        limit,
        locality,
        nationality,
        paymentMode,
        paymentType,
        program,
        programName,
        programType,
        scholarshipType,
        sendToDeb,
        skip,
        startDate,
        state,
        status,
        req.user,
        req.university
      );
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/deb-to-lms/:recordId([0-9a-f]{24})')
  @Validate([
    {
      field: 'recordId',
      validation: [{ value: 'notEmpty', message: 'Coupon ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('recordId') recordId: string) {
    try {
      const data = await debToLmsRepository.findOne({ _id: recordId }).lean();

      return res.status(200).send(data);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/deb-to-lms/:debToLmsId([0-9a-f]{24})')
  @Validate([
    {
      field: 'debToLmsId',
      validation: [{ value: 'notEmpty', message: 'debToLmsId is required' }]
    },
    'aadharNumber',
    'abcId',
    'additionalContacts',
    'additionalEmails',
    'admissionDate',
    'admissionSession',
    'applicationGeneratedDatetime',
    'applicationId',
    'applicationNumber',
    'applicationSource',
    'birthDate',
    'bloodGroup',
    'city',
    'classes',
    'country',
    'course',
    'debUniqueId',
    'documents',
    'email',
    'fatherName',
    'feeCollected',
    'feeStatus',
    'gender',
    'id',
    'leadGeneratedDatetime',
    'leadId',
    'leadIntake',
    'leadSource',
    'locality',
    'name',
    'nationality',
    'outstandingFee',
    'passportNumber',
    'paymentType',
    'permanentEnrollmentNumber',
    'phoneNumber',
    'program',
    'programId',
    'programName',
    'programType',
    'provisionalAdmissionDate',
    'registrationDate',
    'remarks',
    'scholarshipAmount',
    'scholarshipAppliedDate',
    'scholarshipType',
    'sendToDeb',
    'state',
    'status',
    'totalFee'
  ])
  @UseBefore(IsAuthenticated, CanUpdateDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async update(@Req() req: any, @Res() res: any, @Param('debToLmsId') debToLmsId: string) {
    try {
      const updater = new DebToLmsUpdater(debToLmsId, req.body);
      await updater.update();

      return res.status(201).send({ message: 'Updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/deb-to-lms/delete')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'IDs are required' }]
    }
  ])
  @UseBefore(IsAuthenticated, CanDeleteDebToLms)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async delete(@Req() req: any, @Res() res: any) {
    try {
      const { ids } = req.body;

      await debToLmsRepository.destroy({ _id: { $in: ids } }, req.user._id);

      return res.send({ message: 'Record(s) deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
