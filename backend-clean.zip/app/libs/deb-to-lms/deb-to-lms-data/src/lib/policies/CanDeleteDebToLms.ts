import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Role } from '@edorer/role-data';
import { UserTypes } from '@edorer/user-data';

export class CanDeleteDebToLms implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    const { user } = req;

    if (!user) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.PENDING_STUDENT:
      case UserTypes.TEACHER:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to delete deb-to-lms records.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const role: Role = user.role;

        if (!role) return res.status(401).send({ message: 'You do not have permission to delete deb-to-lms records.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to delete deb-to-lms records.' });

        const { debToLms } = role;
        if (!debToLms) return res.status(401).send({ message: 'You do not have permission to delete deb-to-lms records.' });
        if (Object.keys(debToLms).length === 0) return res.status(401).send({ message: 'You do not have permission to delete deb-to-lms records.' });

        if (!debToLms.delete) return res.status(401).send({ message: 'You do not have permission to delete deb-to-lms records.' });

        break;
      }

      case UserTypes.ADMIN:
      case UserTypes.UNIVERSITY_OWNER: {
        break;
      }

      default:
        return res.status(401).send({ message: 'You do not have permission to delete deb-to-lms records.' });
    }

    next();
  }
}
