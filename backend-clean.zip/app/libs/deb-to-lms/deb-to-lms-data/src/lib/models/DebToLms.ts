import { DebToLmsLocalities, DebToLmsPaymentTypes, DebToLmsProgramTypes, DebToLmsScholarTypes, DebToLmsStatuses } from '../enums/DebToLmsEnum';
import { Model, MongooseModel, field, pre } from '@edorer/nems';
import { Schema, Types } from 'mongoose';

@Model('DebToLms')
export class DebToLms extends MongooseModel {
  @field({ type: String })
  aadharNumber: string;

  @field({ type: String })
  abcId: string;

  @field([{ type: String }])
  additionalContacts: string[];

  @field([{ type: String }])
  additionalEmails: string[];

  @field({ type: Date })
  admissionDate: Date;

  @field({ type: String })
  admissionSession: string;

  @field({ type: Date })
  applicationGeneratedDatetime: Date;

  @field({ type: String })
  applicationId: string;

  @field({ type: String })
  applicationNumber: string;

  @field({ type: String })
  applicationSource: string;

  @field({ type: String })
  birthDate: string;

  @field({ type: String })
  bloodGroup: string;

  @field({ type: String })
  city: string;

  @field([{ type: String }])
  classes: string[];

  @field({ type: String })
  country: string;

  @field({ type: String })
  course: string;

  @field({ type: String })
  courseId: string;

  @field([{ type: String }])
  courses: string[];

  @field({ type: String })
  debUniqueId: string;

  @field([{ type: String }])
  documents: string[];

  @field({ type: String })
  fatherName: string;

  @field({ type: Number })
  feeCollected: number;

  @field({ type: String })
  feeStatus: string;

  @field({ type: String })
  firstName: string;

  @field({ type: String })
  gender: string;

  @field({ type: String })
  id: string;

  @field({ type: String })
  idCardUrl: string;

  @field({ default: false, type: Boolean })
  isApproved: boolean;

  @field({ default: false, type: Boolean })
  isConverted: boolean;

  @field({ default: true, type: Boolean })
  isFresh: boolean;

  @field({ type: String })
  lastName: string;

  @field({ type: Date })
  leadGeneratedDatetime: Date;

  @field({ type: String })
  leadId: string;

  @field({ type: String })
  leadIntake: string;

  @field({ type: String })
  leadSource: string;

  @field({
    default: DebToLmsLocalities.RURAL,
    enum: [DebToLmsLocalities.FOREIGNER, DebToLmsLocalities.RURAL, DebToLmsLocalities.URBAN],
    type: String
  })
  locality: DebToLmsLocalities;

  @field({ type: String })
  name: string;

  @field({ type: String })
  nationality: string;

  @field({ type: Number })
  outstandingFee: number;

  @field({ type: String })
  passportNumber: string;

  @field({ type: String })
  paymentMode: string;

  @field({
    default: DebToLmsPaymentTypes.LUMP_SUM,
    enum: [DebToLmsPaymentTypes.INSTALLMENT, DebToLmsPaymentTypes.LUMP_SUM, DebToLmsPaymentTypes.YEARLY],
    type: String
  })
  paymentType: DebToLmsPaymentTypes;

  @field({ type: String })
  paymentNature: string;

  @field({ type: String })
  permanentEnrollmentNumber: string;

  @field({ type: String })
  email: string;

  @field({ type: Boolean, default: false })
  approvedByAdmin: boolean;

  @field({ type: Boolean, default: false })
  isRestricted: boolean;

  @field({ type: String })
  password: string;

  @field({ type: String })
  phoneNumber: string;

  @field({ type: String })
  program: string;

  @field({ type: String })
  programId: string;

  @field({ type: String })
  programName: string;

  @field({
    default: DebToLmsProgramTypes.ONLINE,
    enum: [DebToLmsProgramTypes.ONLINE, DebToLmsProgramTypes.OPEN],
    type: String
  })
  programType: DebToLmsProgramTypes;

  @field({ type: Date })
  provisionalAdmissionDate: Date;

  @field({ type: Date })
  registrationDate: Date;

  @field({ type: String })
  remarks: string;

  @field({ type: Number })
  scholarshipAmount: number;

  @field({ type: Date })
  scholarshipAppliedDate: Date;

  @field({
    // default: DebToLmsScholarTypes.SCHOLARSHIP,
    // enum: [DebToLmsScholarTypes.LOAN, DebToLmsScholarTypes.SCHOLARSHIP],
    required: false,
    type: String
  })
  scholarshipType: string;

  @field({ type: String })
  sendToDeb: string;

  @field({ type: String })
  state: string;

  @field({
    // default: DebToLmsStatuses.INPROGRESS,
    // enum: [DebToLmsStatuses.INPROGRESS, DebToLmsStatuses.COMPLETED],
    required: false,
    type: String
  })
  status: string;

  @field({ type: Number })
  totalFee: number;

  @field({ type: String })
  profilePicture: string;

  @field({ type: String })
  address: string;

  @field({ type: String })
  address2: string;

  @field({ type: String })
  pinCode: string;

  @field([
    {
      type: String
    }
  ])
  transactionIds: string[];

  @field({ type: Date })
  utrDate: string;

  @field({ type: String })
  utrNo: string;

  @field({
    askedBy: { ref: 'User', type: Types.ObjectId, default: null },
    attachments: [{ type: String, default: null }],
    classes: [{ type: String, default: null }],
    course: { type: String, default: null },
    feeCategory: { ref: 'FeeCategory', type: Types.ObjectId, default: null },
    program: { type: String, default: null }
  })
  transferDetails: { askedBy: any; attachments: string[]; classes: string[]; course: string; feeCategory: any; program: string };

  @field({ type: String })
  sessionIntake: string;

  @field({
    ref: 'User',
    required: false,
    type: Types.ObjectId
  })
  owner: any;

  @field({
    ref: 'University',
    required: false,
    type: Types.ObjectId
  })
  university: any;

  @field({
    type: Date
  })
  approvedAt: Date;

  @field({
    type: Date
  })
  convertedAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  @pre('save')
  async convertEmailAddress(next: Function) {
    this.email = String(this.email).toLowerCase();
    next();
  }
}
