import { MongooseRepository } from '@edorer/nems';

class DebToLmsRepository extends MongooseRepository {}

export let debToLmsRepository = new DebToLmsRepository();
