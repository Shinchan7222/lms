export enum DebToLmsFeeStatuses {
  PAID = 'Paid',
  PENDING = 'Pending'
}

export enum DebToLmsLocalities {
  FOREIGNER = 'Foreigner',
  RURAL = 'Rural',
  URBAN = 'Urban'
}

export enum DebToLmsPaymentTypes {
  INSTALLMENT = 'Payment in Installments',
  LUMP_SUM = 'Lump Sum Payment',
  YEARLY = 'Yearly Payment'
}

export enum DebToLmsProgramTypes {
  ONLINE = 'Online',
  OPEN = 'Open and Distance Learning'
}

export enum DebToLmsStatuses {
  INPROGRESS = 'In Progress',
  COMPLETED = 'Completed'
}

export enum DebToLmsScholarTypes {
  LOAN = 'Loan',
  SCHOLARSHIP = 'Scholarship'
}
