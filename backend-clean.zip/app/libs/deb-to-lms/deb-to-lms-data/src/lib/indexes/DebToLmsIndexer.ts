import { debToLmsRepository } from '@edorer/deb-to-lms-data';

export class DebToLmsIndexer {
  static async index() {
    await debToLmsRepository.ensureIndex({ code: 1, course: 1, offerType: 1, deleted: 1 });
    await debToLmsRepository.ensureIndex({ code: 1, exam: 1, offerType: 1, deleted: 1 });
    await debToLmsRepository.ensureIndex({ code: 1, offerType: 1, program: 1, deleted: 1 });
  }
}
