import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import { messageRepository } from '@edorer/message-data';
import { flowRepository } from '@edorer/flow-data';
import { chatRepository } from '@edorer/chat-data';

@JsonController()
export class MessageCrudController {

    @Post('/messages')
    @Validate([
        {
            field: 'chat',
            validation: [{ value: 'notEmpty', message: 'chat is required' }]
        },
        {
            field: 'content',
            validation: [{ value: 'notEmpty', message: 'content is required' }]
        }, 'createdAt', 'attachments'
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async create(@Req() req: any, @Res() res: any) {
        try {
            const { chat, createdAt, content, attachments } = req.body;
            const message = await messageRepository.create({
                sender: req.user._id,
                chat,
                createdAt,
                content,
                attachments
            });
            return res.send(message);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Post('/messages/applicant/:flowId([0-9a-f]{24})')
    @Validate([
        {
            field: 'flowId',
            validation: [{ value: 'notEmpty', message: 'flowId is required' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async createMessageFlow(@Req() req: any, @Res() res: any, @Param('flowId') flowId: string) {
        try {
            let flow = await flowRepository.findOne({ _id: flowId });
            if (flow) {
                const chat = await chatRepository.create({ type: 'flow', flow: flow._id });
                flow.chat = chat._id;
                await flow.save();
                return res.status(201).send({ message: 'Flow updated successfully' });
            } else {
                throw new Error('You cannot have a chat for this flow');
            }
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/messages/chat')
    @Validate([
        {
            field: 'skip',
            validation: [{ value: 'notEmpty', message: 'skip is required' }]
        },
        {
            field: 'chatId',
            validation: [{ value: 'notEmpty', message: 'chatId is required' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async find(@Req() req: any, @Res() res: any) {
        try {
            const { skip, chatId } = req.query;
            const items = await messageRepository
                .find({ chat: chatId })
                .populate({ path: 'sender', select: '_id name avatar type' })
                .skip(+skip)
                .limit(0)
                .sort({ createdAt: 1 });

            const total = await messageRepository.count({ chat: chatId });

            return res.send({ items, total });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
