import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import { chatRepository } from '@edorer/chat-data';
import { messageRepository } from '@edorer/message-data';

@JsonController()
export class MessageController {

    @Get('/messages/track-exam/:trackExam([0-9a-f]{24})')
    @Validate([
        {
            field: 'trackExam',
            validation: [{ value: 'notEmpty', message: 'trackExam is required' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async trackChatHistory(@Req() req: any, @Res() res: any, @Param('trackExam') trackExam: string) {
        try {
            let messages = [];
            const chat = await chatRepository.findOne({ trackExam }).select('_id').lean();

            if (chat) {
                messages = await messageRepository
                    .find({ chat: chat._id })
                    .populate({ path: 'sender', select: 'avatar name' })
                    .sort({ createdAt: -1 })
                    .lean();
            }
            return res.status(200).send({ messages });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
