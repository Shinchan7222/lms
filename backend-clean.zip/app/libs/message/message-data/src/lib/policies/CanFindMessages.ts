import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanFindMessages implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to view messages.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to view messages.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view messages.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view messages.' });

        const { messages } = role;
        if (messages === null) return res.status(401).send({ message: 'You do not have permission to view messages.' });
        if (messages === undefined) return res.status(401).send({ message: 'You do not have permission to view messages.' });
        if (Object.keys(messages).length === 0) return res.status(401).send({ message: 'You do not have permission to view messages.' });

        const { read } = messages;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view messages.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view messages.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view messages.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
