import { messageRepository } from '../repositories/MessageRepository';
import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanDeleteMessages implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    const { ids, user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });

        const { messages } = role;
        if (messages === null) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
        if (messages === undefined) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
        if (Object.keys(messages).length === 0) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });

        if (messages.delete === null) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
        if (messages.delete === undefined) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
        if (messages.delete === false) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await messageRepository.count({
          _id: { $in: ids },
          $or: [{ owner: user._id }, { editors: { $in: user._id } }]
        });

        if (count !== ids.length) return res.status(401).send({ message: 'You do not have permission to delete message(s).' });
        break;
      }

      default:
        break;
    }

    next();
  }
}
