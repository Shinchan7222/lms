import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanFindMessage implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to view message.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to view message.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to view message.' });

    const { messageId } = params;
    if (messageId === null) return res.status(401).send({ message: 'You do not have permission to view message.' });
    if (messageId === undefined) return res.status(401).send({ message: 'You do not have permission to view message.' });
    if (Types.ObjectId.isValid(messageId) === false) return res.status(401).send({ message: 'You do not have permission to view message.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        if (String(messageId) !== String(user._id)) return res.status(401).send({ message: 'You do not have permission to view message.' });
        break;
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to view message.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view message.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view message.' });

        const { messages } = role;
        if (messages === null) return res.status(401).send({ message: 'You do not have permission to view message.' });
        if (messages === undefined) return res.status(401).send({ message: 'You do not have permission to view message.' });
        if (Object.keys(messages).length === 0) return res.status(401).send({ message: 'You do not have permission to view message.' });

        const { read } = messages;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view message.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view message.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view message.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
