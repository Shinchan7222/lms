import { ExpressMiddlewareInterface } from 'routing-controllers';
import { messageRepository } from '../repositories/MessageRepository';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanUpdateMessage implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to update message.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to update message.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to update message.' });

    const { messageId } = params;
    if (messageId === null) return res.status(401).send({ message: 'You do not have permission to update message.' });
    if (messageId === undefined) return res.status(401).send({ message: 'You do not have permission to update message.' });
    if (Types.ObjectId.isValid(messageId) === false) return res.status(401).send({ message: 'You do not have permission to update message.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to update message.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to update message.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to update message.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to update message.' });

        const { messages } = role;
        if (messages === null) return res.status(401).send({ message: 'You do not have permission to update message.' });
        if (messages === undefined) return res.status(401).send({ message: 'You do not have permission to update message.' });
        if (Object.keys(messages).length === 0) return res.status(401).send({ message: 'You do not have permission to update message.' });

        const { write } = messages;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to update message.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to update message.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to update message.' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await messageRepository.count({
          _id: messageId,
          $or: [{ owner: user._id }, { editors: { $in: user._id } }]
        });

        if (count === 0) return res.status(401).send({ message: 'You do not have permission to update message.' });
        break;
      }

      default:
        break;
    }

    next();
  }
}
