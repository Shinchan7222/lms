import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';

export class CanCreateMessage implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to create message.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to create message.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to create message.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to create message.' });

        const { messages } = role;
        if (messages === null) return res.status(401).send({ message: 'You do not have permission to create message.' });
        if (messages === undefined) return res.status(401).send({ message: 'You do not have permission to create message.' });
        if (Object.keys(messages).length === 0) return res.status(401).send({ message: 'You do not have permission to create message.' });

        const { write } = messages;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to create message.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to create message.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to create message.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
