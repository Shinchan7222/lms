import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';
import { Types } from 'mongoose';
import { messageRepository } from '../repositories/MessageRepository';

export class CanDuplicateMessage implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { body, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (body === null) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
    if (body === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
    if (Object.keys(body).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });

    const { messageId } = body;
    if (messageId === null) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
    if (messageId === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
    if (Types.ObjectId.isValid(messageId) === false) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        const { role } = user;

        if (role === null) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });

        const { messages } = role;
        if (messages === null) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
        if (messages === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
        if (Object.keys(messages).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });

        const { write } = messages;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await messageRepository.count({
          _id: messageId,
          $or: [{ owner: user._id }, { editors: { $in: user._id } }]
        });

        if (count === 0) return res.status(401).send({ message: 'You do not have permission to duplicate message.' });
        break;
      }

      default:
        break;
    }

    next();
  }
}
