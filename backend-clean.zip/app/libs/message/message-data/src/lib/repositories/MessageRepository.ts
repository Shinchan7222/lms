import { MongooseRepository } from '@edorer/nems';

class MessageRepository extends MongooseRepository {
}

export let messageRepository = new MessageRepository();
