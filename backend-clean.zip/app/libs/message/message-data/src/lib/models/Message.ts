import { Chat, chatRepository } from '@edorer/chat-data';
import { Model, MongooseModel, field, post } from '@edorer/nems';
import { Socket } from '@edorer/socket';
import { Types } from 'mongoose';
import { messageRepository } from '../repositories/MessageRepository';

@Model('Message')
export class Message extends MongooseModel {

    @field({
        type: String
    })
    attachments: string[];

    @field({
        type: Types.ObjectId,
        ref: 'Chat'
    })
    chat: any;

    @field({
        trim: true,
        type: String
    })
    content: string;

    @field({
        ref: 'User',
        type: Types.ObjectId
    })
    sender: any;

    @field({
        default: new Date(),
        type: Date
    })
    createdAt: Date;

    @post('save')
    async sendMessageToParticipants(message: any): Promise<void> {
        const chat: Chat = await chatRepository.findOne({ _id: message.chat }).lean();
        const populatedMessage = await messageRepository.findOne({ _id: message._id }).populate({
            path: 'sender',
            select: '_id name avatar'
        }).lean();
        Socket.sendToRoom(`chat:${chat._id.toString()}`, `messages_${chat._id.toString()}`, populatedMessage)
            .then(() => {
                // console.info('socket sent');
            });
    }
}
