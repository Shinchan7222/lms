import { messageRepository } from '@edorer/message-data';

export class MessageIndexer {

    static async index() {
        await messageRepository.ensureIndex({ _id: 1, deleted: 1 });
        await messageRepository.ensureIndex({ chat: 1, deleted: 1 });
    }
}
