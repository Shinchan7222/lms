import { MessageController, MessageCrudController } from '@edorer/message-api';
import { Message, MessageIndexer } from '@edorer/message-data';
import { Nems } from '@edorer/nems';

export class MessageApp {

    controllers = [
        MessageController,
        MessageCrudController
    ];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'Message', model: Message }]);
        await MessageIndexer.index();
    }
}
