import { ApplicantGroup, ApplicantGroupIndexer } from '@edorer/applicant-group-data';
import { ApplicantGroupController } from '@edorer/applicant-group-api';
import { Nems } from '@edorer/nems';

export class ApplicantGroupApp {

    controllers = [ApplicantGroupController];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'ApplicantGroup', model: ApplicantGroup }]);
        await ApplicantGroupIndexer.index();
    }
}
