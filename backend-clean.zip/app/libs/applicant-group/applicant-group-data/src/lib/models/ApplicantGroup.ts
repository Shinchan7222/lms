import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('ApplicantGroup')
export class ApplicantGroup extends MongooseModel {

    @field([{
        ref: 'Applicant',
        type: Types.ObjectId,
    }])
    applicants: any[];

    @field({
        trim: true,
        type: String,
    })
    name: string;

    @field({
        ref: 'Domain',
        type: Types.ObjectId,
    })
    domain: any;

    @field({
        ref: 'University',
        type: Types.ObjectId,
    })
    university: any;

    @field({
        default: new Date(),
        type: Date,
    })
    createdAt: Date;
}
