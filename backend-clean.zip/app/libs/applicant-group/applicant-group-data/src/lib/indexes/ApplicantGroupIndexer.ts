import { applicantGroupRepository } from '@edorer/applicant-group-data';

export class ApplicantGroupIndexer {

    static async index() {
        await applicantGroupRepository.ensureIndex({ _id: 1, deleted: 1 });
    }

}
