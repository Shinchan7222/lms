import { PermissionRepository } from '@edorer/permission';

class ApplicantGroupRepository extends PermissionRepository {
    override featureFields = ['applicantGroups'];
    override ownerField = 'university';
}

export let applicantGroupRepository = new ApplicantGroupRepository();
