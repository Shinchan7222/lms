import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { ListFacade, UpdateFacade } from '@edorer/generic-facades';
import { Validate } from '@edorer/validator';
import { applicantGroupRepository } from '@edorer/applicant-group-data';
import { userRepository } from '@edorer/user-data';

/**
 * @description Crud Operation Controller For Applicant Group
 */
@JsonController()
export class ApplicantGroupController {

    /**
     * @description Create Applicant Group
     */
    @Post('/applicant-group')
    @Validate([
        {
            field: 'name',
            validation: [{ value: 'notEmpty', message: 'name is required' }]
        }, {
            field: 'domain',
            validation: [{ value: 'notEmpty', message: 'domain is required' }]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async create(@Req() req: any, @Res() res: any) {
        try {
            const { name, domain } = req.body;
            await applicantGroupRepository.create({
                name,
                domain,
                university: req.university._id
            });
            return res.send({ message: 'ok' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Duplicate Applicant Group
     */
    @Put('/applicant-group/duplicate/:id([0-9a-f]{24})')
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async duplicate(@Req() req: any, @Res() res: any, @Param('id') id: string) {
        try {
            let applicantGroup = await applicantGroupRepository.findOne({ _id: id });
            let newApplicantGroupRepository = await applicantGroupRepository.create({
                name: applicantGroup.name,
                domain: applicantGroup.domain,
                university: applicantGroup.university,
                applicants: applicantGroup.applicants
            });
            let applicants = await userRepository.find({ applicantGroups: { $in: [applicantGroup._id] } }).lean();
            await userRepository.update({ _id: applicants.map(o => o._id) },
                { $addToSet: { applicantGroups: newApplicantGroupRepository._id } }, { multi: true });
            return res.send({ message: 'ok' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Get Applicant Group List
     */
    @Get('/applicant-group')
    @Validate([
        {
            field: 'skip',
            validation: [{ value: 'notEmpty', message: 'skip is required' }]
        },
        {
            field: 'limit',
            validation: [{ value: 'notEmpty', message: 'limit is required' }]
        },
        'keyword',
        'action'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async find(@Req() req: any, @Res() res: any) {
        try {
            const { keyword, skip, limit } = req.query;
            const facade = new ListFacade(
                req.user, req.university, +skip,
                +limit, keyword, ['name'], applicantGroupRepository
            );
            facade.prepareQuery();
            const result = await facade.create();

            return res.status(200).send(result);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Get Applicant Group by ID
     */
    @Get('/applicant-group/:id([0-9a-f]{24})')
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async findOne(@Req() req: any, @Res() res: any, @Param('id') id: string) {
        try {
            const applicantGroupData = await applicantGroupRepository.findOne({ _id: id });
            return res.send(applicantGroupData);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Update Applicant Group
     */
    @Put('/applicant-group/:id([0-9a-f]{24})')
    @Validate([
        {
            field: 'id',
            validation: [{ value: 'notEmpty', message: 'id is required' }]
        },
        'name', 'domain'
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async update(@Req() req: any, @Res() res: any, @Param('id') id: string) {
        try {
            let facade = new UpdateFacade(
                id,
                req.body,
                ['name', 'domain'],
                applicantGroupRepository
            );
            await facade.create();
            return res.send({ message: 'ok' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Delete Applicant Group
     */
    @Put('/applicant-group/delete')
    @Validate([
        {
            field: 'ids',
            validation: [{ value: 'notEmpty', message: 'ids is required' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async delete(@Req() req: any, @Res() res: any) {
        try {
            const { ids } = req.body;
            const index = ids.findIndex(
                (o) => o.toString() === req.user._id.toString()
            );
            if (index !== -1) {
                ids.splice(index, 1);
            }
            await applicantGroupRepository.destroy({ _id: { $in: ids } }, req.user._id);
            return res.send({ message: 'deleted successful' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
