import { LiveClassRoom, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { LiveClassRoomTitleCreator } from './LiveClassRoomTitleCreator';
import { UpdateFacade } from '@edorer/generic-facades';
import { VideoSession, VideoSessionStatus, videoSessionRepository } from '@edorer/video-session-data';
import * as moment from 'moment';

export class LiveClassRoomUpdater {
  private updatedVideoSession: VideoSession;

  private liveClassRoom: LiveClassRoom;

  private readonly classes: string[];

  private readonly courseId: string;

  private readonly liveClassRoomId: string;

  private readonly notes: string;

  private readonly subjects: string[];

  private readonly title: string;

  private readonly videoSession: VideoSession;

  private readonly googleLink: string;

  constructor(
    classes: string[],
    courseId: string,
    liveClassRoomId: string,
    notes: string,
    subjects: string[],
    title: string,
    videoSession: VideoSession,
    googleLink: string
  ) {
    this.classes = classes;
    this.courseId = courseId;
    this.notes = notes;
    this.subjects = subjects;
    this.title = title;
    this.videoSession = videoSession;
    this.liveClassRoomId = liveClassRoomId;
    this.googleLink = googleLink;
  }

  async update() {
    await this.fetchLiveClassRoom();
    await this.updateVideoSession();
    await this.updateLiveClassRoom();

    return this.liveClassRoom;
  }

  private async fetchLiveClassRoom() {
    this.liveClassRoom = await liveClassRoomRepository.findOne({ _id: this.liveClassRoomId }).populate({ path: 'videoSession' }).lean();
    if (!this.liveClassRoom) {
      throw new Error('Live Class not found');
    }

    this.updatedVideoSession = this.liveClassRoom.videoSession;
  }

  private async updateVideoSession() {
    const updateBody: { [key: string]: any } = {
      duration: moment(this.videoSession.endDateTime).diff(this.videoSession.startDateTime, 'seconds'),
      endDateTime: this.videoSession.endDateTime,
      speakers: this.videoSession.speakers,
      startDateTime: this.videoSession.startDateTime
    };

    const { startDateTime } = this.updatedVideoSession;
    if (!moment(startDateTime).isSame(this.videoSession.startDateTime) && moment(startDateTime).isBefore(this.videoSession.startDateTime)) {
      updateBody.status = VideoSessionStatus.UPCOMING;
    }

    const facade = new UpdateFacade(
      this.updatedVideoSession._id,
      updateBody,
      ['duration', 'endDateTime', 'participants', 'speakers', 'startDateTime', 'status'],
      videoSessionRepository
    );

    this.updatedVideoSession = await facade.create();
  }

  private async updateLiveClassRoom() {
    const updateBody = {
      classes: this.classes,
      course: this.courseId,
      endDateTime: this.updatedVideoSession.endDateTime,
      googleLink: this.googleLink ? this.googleLink : null,
      notes: this.notes,
      startDateTime: this.updatedVideoSession.startDateTime,
      subjects: this.subjects,
      title: this.title ? this.title : await LiveClassRoomTitleCreator.title(this.classes, this.courseId)
    };

    const facade = new UpdateFacade(
      this.liveClassRoomId,
      updateBody,
      ['classes', 'course', 'endDateTime', 'notes', 'startDateTime', 'subjects', 'title', 'googleLink'],
      liveClassRoomRepository
    );

    this.liveClassRoom = await facade.create();
  }
}
