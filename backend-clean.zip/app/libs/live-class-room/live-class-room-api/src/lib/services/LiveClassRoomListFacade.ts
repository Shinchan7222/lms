import { classRepository } from '@edorer/class-data';
import { courseRepository } from '@edorer/course-data';
import { DistinctFacade, ListFacade } from '@edorer/generic-facades';
import { DomainDepartments, domainRepository } from '@edorer/domain-data';
import { liveClassRoomRepository } from '@edorer/live-class-room-data';
import { Role } from '@edorer/role-data';
import { subjectRepository } from '@edorer/subject-data';
import { Types } from 'mongoose';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';
import { VideoSessionStatus, videoSessionRepository } from '@edorer/video-session-data';
import * as moment from 'moment';

export class LiveClassRoomListFacade {
  private readonly currentUser: User;

  private readonly classes: string;

  private readonly endDate: Date;

  private readonly facade: ListFacade;

  private readonly keyword: string;

  private readonly limit: number;

  private readonly sort: number;

  private readonly skip: number;

  private readonly startDate: Date;

  private readonly status: VideoSessionStatus;

  private readonly subject: string = '';

  private readonly university: University;

  constructor(
    classes: string,
    endDate: number,
    keyword: string,
    limit: number,
    skip: number,
    sort: number = -1,
    startDate: number,
    status: VideoSessionStatus,
    subject: string = '',
    currentUser: User,
    university: University
  ) {
    this.classes = classes;
    this.currentUser = currentUser;
    this.keyword = keyword;
    this.limit = +limit;
    this.skip = +skip;
    this.sort = +sort;
    this.status = status;
    this.subject = subject;
    this.university = university;

    if (endDate) {
      this.endDate = moment(new Date(+endDate)).endOf('day').toDate();
    }

    if (startDate) {
      this.startDate = moment(new Date(+startDate)).startOf('day').toDate();
    }

    this.facade = new ListFacade(this.currentUser, this.university, this.skip, this.limit, this.keyword, ['id', 'title'], liveClassRoomRepository);
  }

  async create() {
    await this.addConditions();

    this.addPopulates();
    this.facade.prepareQuery();
    this.facade.addSort({ startDateTime: this.sort });

    return await this.facade.create();
  }

  private async addConditions() {
    this.checkCreationDate();

    await this.checkRoles();
    await this.checkStatus();

    this.checkClasses();
    this.checkSubject();
  }

  private checkCreationDate() {
    if (this.startDate && this.endDate) {
      this.facade.addConditions({ endDateTime: { $lte: this.endDate }, startDateTime: { $gte: this.startDate } });
    }
  }

  private async checkRoles() {
    switch (this.currentUser.type) {
      case UserTypes.TEACHER: {
        this.facade.deleteCondition('owner');
        const conditions = [];

        const videoSessions = await videoSessionRepository
          .find({ $or: [{ owner: this.currentUser._id }, { speakers: { $in: [this.currentUser._id] } }] })
          .lean();
        conditions.push({ videoSession: { $in: videoSessions.map((videoSession) => videoSession._id) } });

        const courses = await courseRepository.distinct('_id', {
          $or: [{ owner: this.currentUser._id }, { editors: { $in: [this.currentUser._id] } }]
        });
        conditions.push({ course: { $in: courses } });

        this.facade.addConditions({ $and: [{ $or: conditions }] });

        break;
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        this.facade.deleteCondition('owner');

        const conditions: any = [{ creator: this.currentUser._id }];

        const userRole = new Role(this.currentUser.role);
        const domainCondition = await userRole.createCondition(this.currentUser.university);

        if (Object.keys(domainCondition).length > 0) {
          conditions.push({ domain: domainCondition });
        }

        const classes = await classRepository
          .find({
            $or: conditions,
            university: this.currentUser.university._id
          })
          .lean();

        const courses = await courseRepository
          .find({
            $or: [...conditions, { owner: this.currentUser._id }],
            university: this.currentUser.university._id
          })
          .lean();

        const videoSessions = await videoSessionRepository
          .find({ speakers: { $in: [this.currentUser._id] } })
          .limit(this.limit)
          .skip(this.skip)
          .sort({ startDateTime: -1 })
          .lean();

        const classRoomConditions: any = [{ owner: this.currentUser._id }];

        if (classes.length > 0) {
          classRoomConditions.push({ classes: { $in: classes.map((c) => c._id) } });
        }

        if (courses.length > 0) {
          classRoomConditions.push({ course: { $in: courses.map((course) => course._id) } });
        }

        if (videoSessions.length > 0) {
          classRoomConditions.push({ videoSession: { $in: videoSessions.map((videoSession) => videoSession._id) } });
        }

        if (classRoomConditions.length !== 0) {
          this.facade.addConditions({ $and: [{ $or: classRoomConditions }] });
        }

        break;
      }

      case UserTypes.STUDENT: {
        this.facade.deleteCondition('owner');

        const { disallowedSubjects = [] } = this.currentUser;

        if (this.university.isParul) {
          const domains = await domainRepository.distinct('_id', {
            department: DomainDepartments.LMS,
            university: this.university._id
          });

          const classesFacade = new ListFacade(null, this.university, 0, 0, null, [], classRepository);
          classesFacade.addConditions({ isHidden: false }).addConditions({ _id: { $in: this.currentUser.classes } });
          if (domains.length > 0) classesFacade.addConditions({ domain: { $in: domains } });

          const { items } = await classesFacade.addSelect('_id').createOnlyItems();
          const classes = items.map((o) => o._id);

          const subjectsFacade = new DistinctFacade(null, this.university, '_id', null, [], subjectRepository);
          subjectsFacade.addConditions({ _id: { $nin: disallowedSubjects } });
          subjectsFacade.addConditions({ classroom: { $exists: true, $in: classes } });

          const subjects = await subjectsFacade.create();

          this.facade.addConditions({ classes: { $in: classes } });
          this.facade.addConditions({ subjects: { $in: subjects } });
        } else {
          this.facade.addConditions({ classes: { $in: this.currentUser.classes } });
          this.facade.addConditions({ subjects: { $nin: disallowedSubjects } });
        }

        break;
      }
    }
  }

  private async checkStatus() {
    try {
      if (this.status) {
        const facade = new ListFacade(null, this.university, null, null, null, [], videoSessionRepository);
        facade.addConditions({ status: this.status });
        facade.addSelect('_id');
        facade.prepareQuery();

        const { items } = await facade.createOnlyItems();

        this.facade.addConditions({ videoSession: { $in: items.map((o) => o._id) } });
      }
    } catch (error) {
      console.error(error);
    }
  }

  private checkClasses() {
    if (this.classes) {
      if ('classes' in this.facade.condition) this.facade.deleteCondition('classes');

      this.facade.addConditions({ classes: { $in: [this.classes] } });
    }
  }

  private checkSubject() {
    if (this.subject && Types.ObjectId.isValid(this.subject)) {
      if ('subject' in this.facade.condition) this.facade.deleteCondition('subject');

      this.facade.addConditions({ subjects: { $in: [this.subject] } });
    }
  }

  private addPopulates() {
    this.facade.addPopulates([
      { path: 'subjects', select: 'name' },
      { path: 'videoSession', populate: { path: 'speakers', select: 'name startDateTime' } }
    ]);
  }
}
