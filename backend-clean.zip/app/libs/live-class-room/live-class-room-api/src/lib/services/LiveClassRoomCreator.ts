import { LiveClassRoom, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { LiveClassRoomTitleCreator } from './LiveClassRoomTitleCreator';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import { VideoSession, VideoSessionTypes, videoSessionRepository } from '@edorer/video-session-data';
import * as moment from 'moment';

export class LiveClassRoomCreator {
  private createdVideoSession: VideoSession;

  private liveClassRoom: LiveClassRoom;

  private readonly classes: string[];

  private readonly courseId: string;

  private readonly notes: string;

  private readonly subjects: string[];

  private readonly title: string;

  private readonly university: University;

  private readonly user: User;

  private readonly videoSession: VideoSession;

  private readonly googleLink: any;

  constructor(
    classes: string[],
    courseId: string,
    notes: string,
    subjects: string[],
    title: string,
    googleLink: any,
    videoSession: VideoSession,
    user: User,
    university: University
  ) {
    this.classes = classes;
    this.courseId = courseId;
    this.notes = notes;
    this.subjects = subjects;
    this.title = title;
    this.university = university;
    this.user = user;
    this.videoSession = videoSession;
    this.googleLink = googleLink;
  }

  async create() {
    await this.createVideoSession();
    await this.createLiveClassRoom();

    return this.liveClassRoom;
  }

  private async createVideoSession() {
    this.createdVideoSession = await videoSessionRepository.create({
      duration: moment(this.videoSession.endDateTime).diff(this.videoSession.startDateTime, 'seconds'),
      endDateTime: this.videoSession.endDateTime,
      owner: this.user._id,
      sessionType: VideoSessionTypes.LIVE_CLASS_ROOM,
      speakers: this.videoSession.speakers,
      startDateTime: this.videoSession.startDateTime,
      university: this.university._id
    });
  }

  private async createLiveClassRoom() {
    this.liveClassRoom = await liveClassRoomRepository.create({
      classes: this.classes,
      course: this.courseId,
      endDateTime: this.createdVideoSession.endDateTime,
      googleLink: this.googleLink ? this.googleLink : null,
      notes: this.notes,
      owner: this.user._id,
      startDateTime: this.createdVideoSession.startDateTime,
      subjects: this.subjects,
      title: this.title ? this.title : await LiveClassRoomTitleCreator.title(this.classes, this.courseId),
      university: this.university._id,
      videoSession: this.createdVideoSession._id
    });
  }
}
