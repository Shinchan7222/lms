import { ListFacade } from '@edorer/generic-facades';
import { LiveClassRoom, LiveClassRoomPresenceStatus, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { University } from '@edorer/university-data';
import { User, userRepository, UserTypes } from '@edorer/user-data';
import { VideoSessionParticipant, videoSessionParticipantRepository } from '@edorer/track-video-session-data';

export class LiveClassRoomPresenceListFacade {
  private liveClassRoom: LiveClassRoom;

  private participants: VideoSessionParticipant[] = [];

  private readonly keyword: string = null;

  private readonly limit: number;

  private readonly liveClassRoomId: string;

  private readonly skip: number;

  private readonly status: string;

  private readonly university: University;

  private teachers: User[] = [];

  private users: User[] = [];

  constructor(keyword: string = null, limit: number = 10, liveClassRoomId: string, skip: number, status: string, university: University) {
    this.keyword = keyword;
    this.limit = +limit;
    this.liveClassRoomId = liveClassRoomId;
    this.skip = +skip;
    this.status = status;
    this.university = university;
  }

  async create() {
    await this.fetchLiveClassRoom();
    await this.fetchParticipants();
    await this.fetchUsers();

    return await this.prepareItems();
  }

  private async fetchLiveClassRoom() {
    this.liveClassRoom = await liveClassRoomRepository
      .findOne({ _id: this.liveClassRoomId })
      .populate({ path: 'videoSession', select: '_id speakers' })
      .lean();

    if (!this.liveClassRoom) {
      throw new Error('Live Class Room not found');
    }
  }

  private async fetchParticipants() {
    this.participants = await videoSessionParticipantRepository.find({ videoSession: this.liveClassRoom.videoSession._id }).lean();
  }

  private async fetchUsers() {
    this.teachers = await userRepository.distinct('_id', {
      _id: { $in: this.liveClassRoom.videoSession.speakers },
      type: UserTypes.TEACHER
    });

    const students = await userRepository.distinct('_id', {
      classes: { $in: this.liveClassRoom.classes },
      type: UserTypes.STUDENT
    });

    const userIds = this.teachers.concat(students);

    const facade = new ListFacade(null, this.university, 0, 0, this.keyword, ['email', 'name'], userRepository);

    facade.addConditions({ _id: { $in: userIds } });
    facade.addConditions({ type: { $in: [UserTypes.STUDENT, UserTypes.TEACHER] } });

    facade.addSelect('avatar email extraFields name type');
    facade.prepareQuery();

    const { items } = await facade.create();

    this.users = items;
  }

  private async prepareItems() {
    let items = [];
    const participantIds = this.participants.map((participant) => participant.user.toString());

    const users = this.users.slice(this.skip, this.skip + this.limit);
    for (let user of users) {
      const isAbsent = participantIds.indexOf(user._id.toString()) === -1;
      const participant = this.participants.find((o) => o.user.toString() === user._id.toString());

      items.push({
        joinDates: isAbsent === false && participant && participant.joinDates ? participant.joinDates : [],
        leaveDates: isAbsent === false && participant && participant.leaveDates ? participant.leaveDates : [],
        status: isAbsent ? LiveClassRoomPresenceStatus.ABSENT : LiveClassRoomPresenceStatus.PRESENT,
        user
      });
    }

    if (this.status && this.status === LiveClassRoomPresenceStatus.ABSENT) {
      items = items.filter((o) => o.status === LiveClassRoomPresenceStatus.ABSENT);
    }

    if (this.status && this.status === LiveClassRoomPresenceStatus.PRESENT) {
      items = items.filter((o) => o.status === LiveClassRoomPresenceStatus.PRESENT);
    }

    return { items, total: this.users.length };
  }
}
