import { LiveClassRoom, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { videoSessionRepository } from '@edorer/video-session-data';

export class LiveClassRoomsUpdateRecording {
  private readonly liveClassRoomId: string;
  private readonly url: string;

  private liveClassRoom: LiveClassRoom;

  constructor(liveClassRoomId: string, url: string) {
    this.liveClassRoomId = liveClassRoomId;
    this.url = url;
  }

  async update() {
    await this.fetchLiveClassRoom();
    await this.updateVideoSession();
  }

  private async fetchLiveClassRoom() {
    this.liveClassRoom = await liveClassRoomRepository.findOne({ _id: this.liveClassRoomId });
    if (!this.liveClassRoom) {
      throw new Error('Live Class Room not found');
    }
  }

  private async updateVideoSession() {
    await videoSessionRepository.update({ _id: this.liveClassRoom.videoSession }, { $set: { recordURL: this.url } });
  }
}
