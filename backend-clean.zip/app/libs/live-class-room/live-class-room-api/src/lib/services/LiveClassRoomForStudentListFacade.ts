import { classRepository } from '@edorer/class-data';
import { DistinctFacade, ListFacade } from '@edorer/generic-facades';
import { DomainDepartments, domainRepository } from '@edorer/domain-data';
import { liveClassRoomRepository } from '@edorer/live-class-room-data';
import { subjectRepository } from '@edorer/subject-data';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import { VideoSession, VideoSessionStatus, videoSessionRepository } from '@edorer/video-session-data';
import * as moment from 'moment';

export class LiveClassRoomForStudentListFacade {
  private videoSessions: VideoSession[] = [];

  private readonly endDate: Date;

  private readonly keyword: string;

  private readonly limit: number;

  private readonly skip: number;

  private readonly sort: number;

  private readonly startDate: Date;

  private readonly startDateTime: string;

  private readonly status: VideoSessionStatus;

  private readonly university: University;

  private readonly user: User;

  constructor(
    endDate: number,
    keyword: string,
    limit: number,
    skip: number,
    sort: number = -1,
    startDate: number,
    startDateTime: string,
    status: VideoSessionStatus,
    user: User,
    university: University
  ) {
    this.keyword = keyword;
    this.limit = +limit;
    this.sort = +sort;
    this.skip = +skip;
    this.startDateTime = startDateTime;
    this.status = status;
    this.university = university;
    this.user = user;

    if (endDate) this.endDate = moment(+endDate).endOf('day').toDate();
    if (startDate) this.startDate = moment(+startDate).startOf('day').toDate();
  }

  async create() {
    await this.fetchVideoSessions();
    return await this.fetchLiveClassRooms();
  }

  private async fetchVideoSessions() {
    try {
      const facade = new ListFacade(null, this.university, null, null, null, [], videoSessionRepository);
      if (this.status) facade.addConditions({ status: this.status });

      facade.addSelect('_id');
      facade.prepareQuery();

      const { items } = await facade.create();
      this.videoSessions = items;
    } catch (error) {
      console.error(error);
    }
  }

  private async fetchLiveClassRooms() {
    const { disallowedSubjects = [] } = this.user;

    const facade = new ListFacade(null, this.university, this.skip, this.limit, this.keyword, ['title'], liveClassRoomRepository);
    facade.addConditions({
      classes: { $in: this.user.classes },
      videoSession: { $in: this.videoSessions.map((videoSession) => videoSession._id) }
    });

    if (this.university.isParul) {
      const domains = await domainRepository.distinct('_id', {
        department: DomainDepartments.LMS,
        university: this.university._id
      });

      const classesFacade = new ListFacade(null, this.university, 0, 0, null, [], classRepository);
      classesFacade.addConditions({ isHidden: false }).addConditions({ _id: { $in: this.user.classes } });
      if (domains.length > 0) classesFacade.addConditions({ domain: { $in: domains } });

      const { items } = await classesFacade.addSelect('_id').createOnlyItems();
      const classes = items.map((o) => o._id);

      const subjectsFacade = new DistinctFacade(null, this.university, '_id', null, [], subjectRepository);
      subjectsFacade.addConditions({ _id: { $nin: disallowedSubjects } });
      subjectsFacade.addConditions({ classroom: { $exists: true, $in: classes } });

      const subjects = await subjectsFacade.create();

      facade.addConditions({ classes: { $in: classes } });
      facade.addConditions({ subjects: { $in: subjects } });
    } else {
      if (this.startDateTime) facade.addConditions({ startDateTime: { $gte: this.startDateTime } });
      if (this.startDate && this.endDate) facade.addConditions({ startDateTime: { $gte: this.startDate, $lte: this.endDate } });

      if (disallowedSubjects.length) facade.addConditions({ subjects: { $nin: disallowedSubjects } });
    }

    facade.addPopulates([
      { path: 'subjects', select: 'name' },
      { path: 'videoSession', populate: { path: 'speakers', select: 'name' } }
    ]);

    facade.prepareQuery();
    facade.addSort({ startDateTime: this.sort });

    return await facade.create();
  }
}
