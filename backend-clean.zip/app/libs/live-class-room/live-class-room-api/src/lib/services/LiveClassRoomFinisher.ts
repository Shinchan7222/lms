import { CoursePageContentTypes } from '@edorer/course-data';
import { LiveClassRoom, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { TrackCourseLectureUpdater } from '@edorer/track-course-api';
import { videoSessionParticipantRepository } from '@edorer/track-video-session-data';
import { User } from '@edorer/user-data';

export class LiveClassRoomFinisher {
  private readonly courseId: string;

  private readonly currentUser: User;

  private readonly liveClassRoomId: string;

  private liveClassRoom: LiveClassRoom;

  constructor(courseId: string, liveClassRoomId: string, currentUser: User) {
    this.courseId = courseId;
    this.currentUser = currentUser;
    this.liveClassRoomId = liveClassRoomId;
  }

  public async finish() {
    await this.fetchLiveClassRoom();
    await this.updateParticipants();
    await this.updateCourseLecture();
  }

  private async fetchLiveClassRoom() {
    try {
      this.liveClassRoom = await liveClassRoomRepository.findOne({ _id: this.liveClassRoomId }).lean();
    } catch (error) {
      console.error(error);
    }
  }

  private async updateParticipants() {
    try {
      if (!this.liveClassRoom) return;

      await videoSessionParticipantRepository.update(
        { videoSession: this.liveClassRoom.videoSession },
        { $addToSet: { leaveDates: new Date() } },
        { multi: true }
      );
    } catch (error) {
      console.error(error);
    }
  }

  private async updateCourseLecture() {
    try {
      const courseLectureUpdater = new TrackCourseLectureUpdater(
        this.courseId,
        { 'pages.liveClassRoom': this.liveClassRoomId },
        CoursePageContentTypes.SESSION,
        this.currentUser
      );

      await courseLectureUpdater.update();
    } catch (error) {
      console.error(error);
    }
  }
}
