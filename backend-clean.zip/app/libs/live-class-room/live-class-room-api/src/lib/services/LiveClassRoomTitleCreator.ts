import { Class, classRepository } from '@edorer/class-data';
import { Course, courseRepository } from '@edorer/course-data';

export class LiveClassRoomTitleCreator {
  static async title(classes: string[] = [], courseId: string) {
    if (courseId) {
      const course: Course = await courseRepository.findOne({ _id: courseId }).select('title').lean();
      if (!course) throw new Error('Course not found');

      return course.title + ' (Course)';
    }

    if (classes.length > 0) {
      const foundClasses: Class[] = await classRepository
        .find({ _id: { $in: classes } })
        .select('name')
        .lean();

      if (foundClasses.length === 0) throw new Error('Classes not found');

      return foundClasses.map((entry) => entry.name).join('-') + ' (Class)';
    }

    throw new Error('Class or Course is required');
  }
}
