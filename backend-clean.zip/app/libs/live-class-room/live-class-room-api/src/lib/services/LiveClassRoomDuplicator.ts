import { LiveClassRoom, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import { VideoSession, videoSessionRepository } from '@edorer/video-session-data';

export class LiveClassRoomDuplicator {
  private createdVideoSession: VideoSession;

  private createdLiveClassRoom: LiveClassRoom;

  private liveClassRoom: LiveClassRoom;

  private videoSession: VideoSession;

  private readonly currentUser: User;

  private readonly liveClassRoomId: string;

  private readonly university: University;

  constructor(liveClassRoomId: string, currentUser: User, university: University) {
    this.currentUser = currentUser;
    this.liveClassRoomId = liveClassRoomId;
    this.university = university;
  }

  async duplicate() {
    await this.fetchLiveClassRoom();
    await this.fetchVideoSession();

    await this.duplicateVideoSession();
    await this.duplicateLiveClassRoom();

    return this.createdLiveClassRoom;
  }

  private async fetchLiveClassRoom() {
    this.liveClassRoom = await liveClassRoomRepository.findOne({ _id: this.liveClassRoomId }).lean();
    if (!this.liveClassRoom) {
      throw new Error('Live Class not found');
    }
  }

  private async fetchVideoSession() {
    this.videoSession = await videoSessionRepository.findOne({ _id: this.liveClassRoom.videoSession }).lean();
  }

  private async duplicateVideoSession() {
    const { duration, endDateTime, owner, participants, sessionType, speakers, startDateTime, status, trivias } = this.videoSession;
    this.createdVideoSession = await videoSessionRepository.create({
      duration,
      endDateTime,
      owner,
      participants,
      sessionType,
      speakers,
      startDateTime,
      status,
      trivias,
      university: this.university._id
    });
  }

  private async duplicateLiveClassRoom() {
    const { classes, course, notes, owner, subjects } = this.liveClassRoom;
    const { endDateTime, startDateTime } = this.createdVideoSession;

    this.createdLiveClassRoom = await liveClassRoomRepository.create({
      classes,
      course,
      endDateTime,
      notes,
      owner: this.currentUser._id || owner,
      startDateTime,
      subjects,
      title: await this.prepareTitle(),
      university: this.university._id,
      videoSession: this.createdVideoSession._id
    });
  }

  private async prepareTitle(): Promise<string> {
    const title = this.liveClassRoom.title + ' copy';
    const liveClassRooms = await liveClassRoomRepository.count({ title: new RegExp(title, 'i') });
    const count = liveClassRooms + 1;

    return this.liveClassRoom.title + ' copy (' + count + ')';
  }
}
