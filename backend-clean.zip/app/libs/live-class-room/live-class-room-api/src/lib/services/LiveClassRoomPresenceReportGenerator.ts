import { DataUtils, DateUtils, PrepareExcelReport, StringUtils } from '@edorer/utils';
import { LiveClassRoom, LiveClassRoomPresenceStatus, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { User } from '@edorer/user-data';
import * as moment from 'moment-timezone';

type Presence = { joinDates: Date[]; leaveDates: Date[]; status: LiveClassRoomPresenceStatus; user: User };

export class LiveClassRoomPresenceReportGenerator {
  private items = [];

  private readonly reports: Array<Presence> = [];

  private liveClassRoom: LiveClassRoom;

  private readonly liveClassRoomId: string;

  constructor(liveClassRoomId: string, reports: Array<Presence>) {
    this.liveClassRoomId = liveClassRoomId;
    this.reports = reports;
  }

  async generate(): Promise<string> {
    await this.fetchLiveClassRoom();
    this.prepareReport();

    let domain = '';
    if (this.liveClassRoom.classes.length > 0) {
      domain = this.liveClassRoom.classes
        .filter((entry) => entry && entry.domain && entry.domain.name)
        .map((entry) => entry.domain.name)
        .join('-');
    }

    if (this.liveClassRoom.course && this.liveClassRoom.course.domain && this.liveClassRoom.course.domain.name) {
      domain = this.liveClassRoom.course.domain.name;
    }

    const converter = new PrepareExcelReport(this.items, domain, this.liveClassRoom.owner.name, this.liveClassRoom.title);
    converter.sheet = StringUtils.titleCase(this.liveClassRoom.title.replace(/[*?:\\\/\[\]]/g, '-'));

    return await converter.convert();
  }

  private async fetchLiveClassRoom() {
    this.liveClassRoom = await liveClassRoomRepository
      .findOne({ _id: this.liveClassRoomId })
      .populate({ path: 'classes', select: 'domain', populate: { path: 'domain', select: 'name' } })
      .populate({ path: 'course', select: 'domain', populate: { path: 'domain', select: 'name' } })
      .populate({ path: 'owner', select: 'name' })
      .lean();

    if (!this.liveClassRoom) {
      throw new Error('Live Class Room not found');
    }
  }

  private prepareReport() {
    for (let index = 0; index < this.reports.length; index++) {
      const report = this.reports[index];

      const { joinDates, leaveDates, status, user } = report;

      this.items.push({
        'S.No': index + 1,
        'Roll Number': DataUtils.getUserField(user.extraFields, 'Roll Number'),
        Name: user.name,
        Email: user.email,
        Status: StringUtils.titleCase(status),
        'Join Dates': joinDates.map((o) => moment(o).tz('Asia/Kolkata').format(DateUtils.DATE_FORMATS.FULL_DATE)).join(', '),
        'Leave Dates': leaveDates.map((o) => moment(o).tz('Asia/Kolkata').format(DateUtils.DATE_FORMATS.FULL_DATE)).join(', ')
      });
    }
  }
}
