import { Class, classRepository } from '@edorer/class-data';
import { Domain, domainRepository } from '@edorer/domain-data';
import { hash } from 'bcryptjs';
import { liveClassRoomRepository } from '@edorer/live-class-room-data';
import { Subject, subjectRepository } from '@edorer/subject-data';
import { University } from '@edorer/university-data';
import { User, UserTypes, userRepository } from '@edorer/user-data';
import { VideoSessionStatus, videoSessionRepository } from '@edorer/video-session-data';
import * as excelToJson from 'convert-excel-to-json';

export class LiveClassRoomsImporter {
  private readonly file: any;

  private readonly university: University;

  private readonly user: User;

  private result: any;

  constructor(file: any, user: User, university: University) {
    this.file = file;
    this.university = university;
    this.user = user;
  }

  private static async bindStudentWithClass(createdClass: Class, student: User) {
    await classRepository.update({ _id: createdClass._id }, { $addToSet: { students: student._id } }, { multi: false });

    await userRepository.update({ _id: student._id }, { $addToSet: { classes: createdClass._id } }, { multi: false });
  }

  private static async bindTeacherWithClass(createdClass: Class, teacher: User) {
    await classRepository.update({ _id: createdClass._id }, { $addToSet: { teachers: teacher._id } }, { multi: false });

    await userRepository.update({ _id: teacher._id }, { $addToSet: { classes: createdClass._id } }, { multi: false });
  }

  async upload() {
    await this.createExcelData();
    await this.createLiveSession();
  }

  private async createExcelData(): Promise<void> {
    this.result = excelToJson({
      source: this.file.buffer,
      header: {
        rows: 1
      },
      columnToKey: {
        A: 'Domain',
        B: 'Class',
        C: 'Subject',
        D: 'Roll Number',
        E: 'Student Name',
        F: 'Student Email',
        G: 'Teacher Name',
        H: 'Teacher Email',
        I: 'Start Date Time',
        J: 'End Date Time'
      }
    });
    if (!this.result) {
      throw new Error('THE EXCEL FILE HAS NO CONTENT');
    }
  }

  private async createLiveSession() {
    try {
      for (let field of this.result['Live Classes']) {
        const domain: Domain = await this.createDomain(field['Domain']);
        const createdClass: Class = await this.createClass(field['Class'], domain);
        const subject: Subject = await this.createSubject(field['Subject']);
        const teacher: User = await this.createTeacher(domain, field['Teacher Email'], field['Teacher Name']);
        const student: User = await this.createStudent(domain, field['Student Email'], field['Student Name'], field['Roll Number']);
        await LiveClassRoomsImporter.bindTeacherWithClass(createdClass, teacher);
        await LiveClassRoomsImporter.bindStudentWithClass(createdClass, student);
        await this.createLiveClassRoom(createdClass, field['End Date Time'], field['Start Date Time'], subject, teacher);
      }
    } catch (error: any) {
      console.error(error);
      throw new Error('Could not import live classes');
    }
  }

  private async createDomain(name: string) {
    return await domainRepository.findOneAndUpdate(
      { name, university: this.university._id },
      { name, university: this.university._id },
      { new: true, upsert: true }
    );
  }

  private async createClass(name: string, domain: Domain) {
    return await classRepository.findOneAndUpdate(
      { domain: domain._id, name, university: this.university._id },
      { domain: domain._id, name, university: this.university._id },
      { new: true, upsert: true }
    );
  }

  private async createSubject(name: string) {
    return await subjectRepository.findOneAndUpdate(
      { name, university: this.university._id },
      { name, university: this.university._id },
      { new: true, upsert: true }
    );
  }

  private async createTeacher(domain: Domain, email: string, name: string) {
    let teacher = await userRepository.findOne({ email, type: UserTypes.TEACHER }).lean();
    if (!teacher) {
      teacher = await userRepository.create({
        creator: this.user._id,
        domains: [domain._id],
        email,
        name,
        isEmailVerified: false,
        isPhoneVerified: false,
        password: await hash(this.university.defaultPassword, 10),
        type: UserTypes.TEACHER,
        university: this.university._id
      });
    }

    return teacher;
  }

  private async createStudent(domain: Domain, email: string, name: string, roll: string) {
    let student = await userRepository.findOne({ email, type: UserTypes.STUDENT }).lean();
    if (!student) {
      student = await userRepository.create({
        creator: this.user._id,
        domains: [domain._id],
        email,
        name,
        extraFields: [{ key: 'Roll Number', value: roll }],
        isEmailVerified: false,
        isPhoneVerified: false,
        password: await hash(this.university.defaultPassword, 10),
        type: UserTypes.STUDENT,
        university: this.university._id
      });
    }

    return student;
  }

  private async createLiveClassRoom(createdClass: Class, endDateTime: string, startDateTime: string, subject: Subject, teacher: User) {
    await liveClassRoomRepository.create({
      class: createdClass._id,
      endDateTime,
      startDateTime,
      subjects: [subject._id],
      videoSession: await this.createVideoSession(endDateTime, startDateTime, teacher)
    });
  }

  private async createVideoSession(endDateTime: string, startDateTime: string, teacher: User) {
    return await videoSessionRepository.create({
      endDateTime,
      speakers: [teacher._id],
      startDateTime,
      status: VideoSessionStatus.UPCOMING,
      university: this.university._id
    });
  }

  // private parseTime(time: string, date: any) {
  //     let startTime = time.split('-')[0].trim();
  //     let endTime = time.split('-')[1].trim();
  //     if (startTime.indexOf('am') > -1) {
  //         startTime = startTime.slice(0, startTime.indexOf('am'));
  //         let currentArr = startTime.split(':');
  //         if (+currentArr[0] === 12) {
  //             let newValue = '00';
  //             currentArr[0] = newValue + '';
  //             startTime = currentArr.join(':');
  //         }
  //     }
  //     if (endTime.indexOf('am') > -1) {
  //         endTime = endTime.slice(0, endTime.indexOf('am'));
  //         let currentArr = startTime.split(':');
  //         if (+currentArr[0] === 12) {
  //             let newValue = '00';
  //             currentArr[0] = newValue + '';
  //             endTime = currentArr.join(':');
  //         }
  //     }
  //     if (startTime.indexOf('pm') > -1) {
  //         startTime = startTime.slice(0, startTime.indexOf('pm'));
  //         let currentArr = startTime.split(':');
  //         if (+currentArr[0] > 0 && +currentArr[0] <= 11) {
  //             let newValue = +currentArr[0] + 12;
  //             currentArr[0] = newValue + '';
  //             startTime = currentArr.join(':');
  //         }
  //         if (+currentArr[0] === 12) {
  //             currentArr[0] = '12';
  //             startTime = currentArr.join(':');
  //         }
  //     }
  //
  //     if (endTime.indexOf('pm') > -1) {
  //         endTime = endTime.slice(0, endTime.indexOf('pm'));
  //         let currentArr = endTime.split(':');
  //         if (+currentArr[0] > 0 && +currentArr[0] <= 11) {
  //             let newValue = +currentArr[0] + 12;
  //             currentArr[0] = newValue + '';
  //             endTime = currentArr.join(':');
  //         }
  //         if (+currentArr[0] === 12) {
  //             currentArr[0] = '12';
  //             endTime = currentArr.join(':');
  //         }
  //     }
  //
  //     let newDateFormat = moment(date).subtract(10, 'days').calendar();
  //     let start = moment(newDateFormat + ' ' + startTime).format();
  //     let end = moment(newDateFormat + ' ' + endTime).format();
  //
  //     return { start, end };
  //
  // }
}
