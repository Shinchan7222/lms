import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { LiveClassRoomPresenceListFacade } from '../services/LiveClassRoomPresenceListFacade';
import { LiveClassRoomPresenceReportGenerator } from '../services/LiveClassRoomPresenceReportGenerator';
import { readFileSync } from 'fs';
import { Validate } from '@edorer/validator';

@JsonController()
export class LiveClassRoomPresenceController {
  @Get('/live-class-room-presences/:liveClassRoomId([0-9a-f]{24})')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'liveClassRoomId',
      validation: [{ value: 'notEmpty', message: 'Live Class Room ID is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    'keyword',
    'status'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any, @Param('liveClassRoomId') liveClassRoomId: string) {
    try {
      const { keyword, limit, skip, status } = req.query;

      const facade = new LiveClassRoomPresenceListFacade(keyword, limit, liveClassRoomId, skip, status, req.university);
      const response = await facade.create();

      return res.status(200).send(response);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/live-class-room-presences/reports/download/:liveClassRoomId([0-9a-f]{24})')
  @Validate([
    {
      field: 'liveClassRoomId',
      validation: [{ value: 'notEmpty', message: 'liveClassRoomId is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async download(@Req() req: any, @Res() res: any, @Param('liveClassRoomId') liveClassRoomId: string) {
    try {
      const facade = new LiveClassRoomPresenceListFacade(null, 10000, liveClassRoomId, 0, null, req.university);
      const { items } = await facade.create();

      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=LiveClassRoomPresenceReports.xlsx');

      const excel = new LiveClassRoomPresenceReportGenerator(liveClassRoomId, items);
      const path = await excel.generate();
      const buffer = readFileSync(path);

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; LiveClassRoomPresenceReports.xlsx`,
        'Content-Length': buffer.length
      });
      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
