import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { LiveClassRoomsImporter } from '../services/LiveClassRoomsImporter';

/**
 * @description Import Controller for LiveClassRoom
 */
@JsonController()
export class LiveClassRoomImportController {
  /**
   * @param req
   * @param res
   * @param file
   * @description Imports Live Class Rooms
   */
  @Post('/live-class-rooms/import')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async import(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      const liveClassRoomsImporter = new LiveClassRoomsImporter(file, req.user, req.university);
      await liveClassRoomsImporter.upload();

      return res.status(201).send({ message: 'UPLOADED SUCCESSFULLY' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
