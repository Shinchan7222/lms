const { spawn } = require('child_process');
import { Delete, Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Downloader, S3University } from '@edorer/s3';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity, GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { LiveClassRoomCreator } from '../services/LiveClassRoomCreator';
import { LiveClassRoomListFacade } from '../services/LiveClassRoomListFacade';
import { liveClassRoomRepository } from '@edorer/live-class-room-data';
import { LiveClassRoomUpdater } from '../services/LiveClassRoomUpdater';
import { v4 as uuidV4 } from 'uuid';
import { Validate } from '@edorer/validator';
import { videoSessionRepository } from '@edorer/video-session-data';
import { ListFacade } from '@edorer/generic-facades';
import moment = require('moment');

/**
 * @description CRUD controller for live-class-room
 */
@JsonController()
export class LiveClassRoomCrudController {
  /**
   * @param req
   * @param res
   * @description Creates one Live Class Room with the given properties
   */
  @Post('/live-class-rooms')
  @Validate([
    {
      field: 'subjects',
      validation: [{ value: 'notEmpty', message: 'Subjects are required' }]
    },
    {
      field: 'videoSession',
      validation: [{ value: 'notEmpty', message: 'Video Session is required' }]
    },
    'classes',
    'course',
    'notes',
    'title',
    'googleLink'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async create(@Req() req: any, @Res() res: any) {
    try {
      const { classes, course, notes, subjects, title, videoSession, googleLink } = req.body;

      const liveClassRoomCreator = new LiveClassRoomCreator(
        classes,
        course,
        notes,
        subjects,
        title,
        googleLink,
        videoSession,
        req.user,
        req.university
      );

      const liveClassRoom = await liveClassRoomCreator.create();

      return res.status(201).send(liveClassRoom);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Finds live-class-rooms with the given queries
   */
  @Get('/live-class-rooms')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    'classes',
    'endDate',
    'keyword',
    'sort',
    'startDate',
    'status',
    'subject'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { classes, endDate, keyword, limit, skip, sort, startDate, status, subject = '' } = req.query;

      const facade = new LiveClassRoomListFacade(classes, endDate, keyword, limit, skip, sort, startDate, status, subject, req.user, req.university);
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/live-class-rooms/list')
  @Validate([
    {
      field: 'token',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    }
  ])
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async findList(@Req() req: any, @Res() res: any) {
    try {
      const { token } = req.query;
      if (token !== 'te2o312j312ih3hi123h123') {
        return res.status(401).send({ error: 'Unauthorized' });
      }

      let list = await liveClassRoomRepository.find({
        startDateTime: { $gte: moment().startOf('day').toDate(), $lte: moment().endOf('day').toDate()}
      }).populate('videoSession').lean();

      return res.status(200).send(list);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }


  /**
   * @param req
   * @param res
   * @param liveClassRoomId
   * @description Finds one University with the given ID
   */
  @Get('/live-class-rooms/:liveClassRoomId([0-9a-f]{24})')
  @Validate([
    {
      field: 'liveClassRoomId',
      validation: [{ value: 'notEmpty', message: 'Live Class Room ID is required' }]
    }
  ])
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('liveClassRoomId') liveClassRoomId: string) {
    try {
      const liveClassRoom = await liveClassRoomRepository
        .findOne({ _id: liveClassRoomId })
        .populate({
          path: 'university',
          select:
            '-advanced.googleClientId -advanced.googleClientSecret -emailSender -smsSender -defaultPassword -driveAccessToken -driveRefreshToken -logRocket -logRocketEmail -logRocketPassword -plagiarism'
        })
        .populate({ path: 'videoSession' })
        .lean();

      return res.status(200).send(liveClassRoom);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param liveClassRoomId
   * @description Updates one University with the given changes
   */
  @Put('/live-class-rooms/:liveClassRoomId([0-9a-f]{24})')
  @Validate([
    {
      field: 'liveClassRoomId',
      validation: [{ value: 'notEmpty', message: 'Live Class Room  ID is required' }]
    },
    {
      field: 'videoSession',
      validation: [{ value: 'notEmpty', message: 'Video Session is required' }]
    },
    'classes',
    'course',
    'notes',
    'subjects',
    'title',
    'googleLink',
    'isExporting'
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async update(@Req() req: any, @Res() res: any, @Param('liveClassRoomId') liveClassRoomId: string) {
    try {
      const { classes, course, notes, subjects, title, videoSession, googleLink, isExporting } = req.body;
      const liveClassRoomUpdater = new LiveClassRoomUpdater(classes, course, liveClassRoomId, notes, subjects, title, videoSession, googleLink);
      const liveClassRoom = await liveClassRoomUpdater.update();

      if (isExporting) {
        let videoSession = await videoSessionRepository.findOne({ _id: liveClassRoom.videoSession });
        if (videoSession && videoSession.recordedURLs && videoSession.recordedURLs.length > 0 && !videoSession.recordURL) {
          let videoPaths = [];
          for (let video of videoSession.recordedURLs) {
            let downloader = new Downloader(video);
            let path = await downloader.download();
            videoPaths.push(path);
          }
          let outputPath = uuidV4() + '.mp4';
          const convert = spawn(`ffmpeg -i "concat:${videoPaths.join('|')}" -c copy /tmp/${outputPath}`, [], { shell: true });
          convert.on('exit', async () => {
            let s3 = new S3University(req.universityConfig);
            videoSession.recordURL = await s3.upload('/tmp/' + outputPath, outputPath, req.universityConfig.buckets.LMS_COURSE_VIDEOS);
            await videoSession.save();
          });
        }
      }
      return res.status(201).send(liveClassRoom);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param liveClassRoomId
   * @description Deletes University with the given IDs
   */
  @Delete('/live-class-rooms/:liveClassRoomId([0-9a-f]{24})')
  @Validate([
    {
      field: 'liveClassRoomId',
      validation: [{ value: 'notEmpty', message: 'Live Class Room ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async delete(@Req() req: any, @Res() res: any, @Param('liveClassRoomId') liveClassRoomId: string) {
    try {
      await liveClassRoomRepository.destroy({ _id: liveClassRoomId }, req.user);

      return res.status(201).send({ message: 'Live Class Room deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
