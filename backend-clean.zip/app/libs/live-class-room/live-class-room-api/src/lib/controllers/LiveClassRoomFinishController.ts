import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Param, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { LiveClassRoomFinisher } from '../services/LiveClassRoomFinisher';
import { Validate } from '@edorer/validator';

@JsonController()
export class LiveClassRoomFinishController {
  @Put('/live-class-rooms/end/:liveClassRoomId([0-9a-f]{24})')
  @Validate([
    {
      field: 'liveClassRoomId',
      validation: [{ value: 'notEmpty', message: 'liveClassRoomId is required' }]
    },
    'course'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async endLiveClassRoom(@Req() req: any, @Res() res: any, @Param('liveClassRoomId') liveClassRoomId: string) {
    try {
      const { course } = req.body;

      const liveClassRoomFinisher = new LiveClassRoomFinisher(course, liveClassRoomId, req.user);
      await liveClassRoomFinisher.finish();

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
