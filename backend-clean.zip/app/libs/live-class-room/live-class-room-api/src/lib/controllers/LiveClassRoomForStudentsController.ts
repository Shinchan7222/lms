import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { LiveClassRoomForStudentListFacade } from '../services/LiveClassRoomForStudentListFacade';
import { Validate } from '@edorer/validator';

@JsonController()
export class LiveClassRoomForStudentsController {
  @Get('/live-class-rooms/students')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    'endDate',
    'keyword',
    'sort',
    'startDate',
    'startDateTime',
    'status'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async findLiveClassrooms(@Req() req: any, @Res() res: any) {
    try {
      const { endDate, keyword, limit, skip, sort, startDate, startDateTime, status } = req.query;

      const liveClassRoomForStudentListFacade = new LiveClassRoomForStudentListFacade(
        endDate,
        keyword,
        limit,
        skip,
        sort,
        startDate,
        startDateTime,
        status,
        req.user,
        req.university
      );
      const response = await liveClassRoomForStudentListFacade.create();

      return res.status(200).send(response);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
