import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Param, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { LiveClassRoomsUpdateRecording } from '../services/LiveClassRoomsUpdateRecording';
import { Validate } from '@edorer/validator';

/**
 * @description Recording Controller for LiveClassRoom
 */
@JsonController()
export class LiveClassRoomRecordingController {
  /**
   * @param req
   * @param res
   * @param liveClassRoomId
   * @param url
   * @description Updates the recording of a Live Class Room
   */
  @Put('/live-class-rooms/:liveClassRoomId([0-9a-f]{24})/recordings')
  @Validate([
    {
      field: 'liveClassRoomId',
      validation: [{ value: 'notEmpty', message: 'Live Class Room ID is required' }]
    },
    {
      field: 'url',
      validation: [{ value: 'notEmpty', message: 'Recording URL is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async updateRecording(@Req() req: any, @Res() res: any, @Param('liveClassRoomId') liveClassRoomId: string) {
    try {
      const { url } = req.body;

      const liveClassRoomsUpdateRecording = new LiveClassRoomsUpdateRecording(liveClassRoomId, url);
      await liveClassRoomsUpdateRecording.update();
      return res.status(201).send({ message: 'RECORDING UPDATED SUCCESSFULLY' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
