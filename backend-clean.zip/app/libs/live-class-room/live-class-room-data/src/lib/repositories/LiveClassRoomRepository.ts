import { MongooseRepository } from '@edorer/nems';

class LiveClassRoomRepository extends MongooseRepository {
}

export let liveClassRoomRepository = new LiveClassRoomRepository();
