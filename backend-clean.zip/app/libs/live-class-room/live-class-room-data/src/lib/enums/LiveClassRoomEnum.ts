export enum LiveClassRoomPresenceStatus {
    ABSENT = 'absent',
    PENDING = 'pending',
    PRESENT = 'present',
}
