import { liveClassRoomRepository } from '../repositories/LiveClassRoomRepository';
import { Model, MongooseModel, field, pre } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('LiveClassRoom')
export class LiveClassRoom extends MongooseModel {
  @field({
    trim: true,
    type: String
  })
  id: string;

  @field([
    {
      ref: 'Class',
      type: Types.ObjectId
    }
  ])
  classes: any[];

  @field({
    ref: 'Course',
    type: Types.ObjectId
  })
  course: any;

  @field({
    type: Date,
    required: true
  })
  endDateTime: Date;

  @field({
    trim: true,
    type: String
  })
  notes: string;

  @field({
    ref: 'User',
    required: true,
    type: Types.ObjectId
  })
  owner: any;

  @field({
    type: Date,
    required: true
  })
  startDateTime: Date;

  @field([
    {
      ref: 'Subject',
      required: true,
      type: Types.ObjectId
    }
  ])
  subjects: any[];

  @field({
    required: true,
    type: String
  })
  title: string;

  @field({
    ref: 'VideoSession',
    required: true,
    type: Types.ObjectId
  })
  videoSession: any;

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    type: String
  })
  googleLink: string;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  @pre('save')
  async generateId(next: Function) {
    if (this.isNew) {
      try {
        await this.generateNewId();
      } catch (e) {
        console.error(e);
      }
      next();
    } else {
      next();
    }
  }

  async generateNewId(): Promise<void> {
    const latestClassroom = await liveClassRoomRepository
      .findOne({ id: { $exists: true }, _id: { $ne: this._id } })
      .sort({ id: -1 })
      .select('id')
      .lean();

    if (!latestClassroom) {
      this.id = '000000';
      return;
    }

    let codeOne = Number(latestClassroom.id);
    codeOne++;
    this.id = new Array(6 - (codeOne + '').length).fill('0').join('') + (codeOne + '');
  }
}
