import { liveClassRoomRepository } from '@edorer/live-class-room-data';

export class LiveClassRoomIndexer {
  static async index() {
    await liveClassRoomRepository.ensureIndex({ _id: 1, deleted: 1 });
    await liveClassRoomRepository.ensureIndex({ owner: 1, university: 1, title: 1, deleted: 1 });
    await liveClassRoomRepository.ensureIndex({ startDateTime: 1, deleted: 1 });
    await liveClassRoomRepository.ensureIndex({ university: 1, title: 1, class: 1, videoSession: 1, deleted: 1 });
    await liveClassRoomRepository.ensureIndex({ university: 1, title: 1, deleted: 1 });
    await liveClassRoomRepository.ensureIndex({ university: 1, classes: 1, videoSession: 1, subjects: 1, deleted: 1 });
  }
}
