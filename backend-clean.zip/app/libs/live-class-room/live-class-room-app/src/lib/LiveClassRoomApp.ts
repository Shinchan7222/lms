import { LiveClassRoom, LiveClassRoomIndexer } from '@edorer/live-class-room-data';
import {
  LiveClassRoomCrudController,
  LiveClassRoomFinishController,
  LiveClassRoomForStudentsController,
  LiveClassRoomImportController,
  LiveClassRoomPresenceController,
  LiveClassRoomRecordingController
} from '@edorer/live-class-room-api';
import { Nems } from '@edorer/nems';

export class LiveClassRoomApp {
  controllers = [
    LiveClassRoomCrudController,
    LiveClassRoomFinishController,
    LiveClassRoomForStudentsController,
    LiveClassRoomImportController,
    LiveClassRoomPresenceController,
    LiveClassRoomRecordingController
  ];

  constructor() {
    this.initDB();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'LiveClassRoom', model: LiveClassRoom }]);
    await LiveClassRoomIndexer.index();
  }
}
