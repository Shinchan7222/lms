import { ExamGuide, ExamGuideIndexer } from '@edorer/exam-guide-data';
import { ExamGuideCrudController } from '@edorer/exam-guide-api';
import { Nems } from '@edorer/nems';

export class ExamGuideApp {
  controllers = [ExamGuideCrudController];

  constructor() {
    this.initDB();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'ExamGuide', model: ExamGuide }]);
    await ExamGuideIndexer.index();
  }
}
