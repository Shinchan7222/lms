import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('ExamGuide')
export class ExamGuide extends MongooseModel {
  @field({
    default: false,
    type: Boolean
  })
  global: boolean;

  @field({
    required: true,
    type: String
  })
  name: string;

  @field({
    ref: 'User',
    type: Types.ObjectId
  })
  owner: any;

  @field([
    {
      ref: 'Program',
      type: Types.ObjectId
    }
  ])
  programs: any;

  @field({
    required: true,
    type: String
  })
  url: string;

  @field({
    type: Types.ObjectId,
    ref: 'University'
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;
}
