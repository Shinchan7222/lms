import { examGuideRepository } from '@edorer/exam-guide-data';

export class ExamGuideIndexer {
  static async index() {
    await examGuideRepository.ensureIndex({ _id: 1, deleted: 1 });
    await examGuideRepository.ensureIndex({ _id: 1, domain: 1, university: 1, deleted: 1 });
    await examGuideRepository.ensureIndex({ _id: 1, university: 1, deleted: 1 });
    await examGuideRepository.ensureIndex({ domain: 1, name: 1, deleted: 1 });
    await examGuideRepository.ensureIndex({ name: 1, deleted: 1 });
    await examGuideRepository.ensureIndex({ name: 1, university: 1, deleted: 1 });
    await examGuideRepository.ensureIndex({ owner: 1, name: 1, deleted: 1 });
    await examGuideRepository.ensureIndex({ owner: 1, university: 1, name: 1, deleted: 1 });
  }
}
