import { MongooseRepository } from '@edorer/nems';

class ExamGuideRepository extends MongooseRepository {}

export let examGuideRepository = new ExamGuideRepository();
