import { ExamGuide, examGuideRepository } from '@edorer/exam-guide-data';
import { ExamGuideListFacade } from '../services/ExamGuideListFacade';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { UpdateFacade } from '@edorer/generic-facades';
import { Validate } from '@edorer/validator';
import { url } from 'inspector';

@JsonController()
export class ExamGuideCrudController {
  /**
   * @param req
   * @param res
   * @description Creates one ExamGuide with the given properties
   */
  @Post('/exam-guides')
  @Validate([
    {
      field: 'name',
      validation: [{ value: 'notEmpty', message: 'Name is required' }]
    },
    {
      field: 'url',
      validation: [{ value: 'notEmpty', message: 'Url is required' }]
    },
    'global',
    'programs'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async create(@Req() req: any, @Res() res: any) {
    try {
      const { global, name, programs, url } = req.body;

      const createdExamGuide = await examGuideRepository.create({
        global,
        name,
        owner: req.user._id,
        programs,
        university: req.university._id,
        url
      });

      return res.status(201).send(createdExamGuide);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Finds ExamGuides with the given queries
   */
  @Get('/exam-guides')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    'program',
    'keyword'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { program, keyword, limit, skip } = req.query;

      const facade = new ExamGuideListFacade(program, keyword, limit, skip, req.user, req.university);
      const response = await facade.create();

      return res.status(200).send(response);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param templateId
   * @description Finds one ExamGuide with the given ID
   */
  @Get('/exam-guides/:examGuideId([0-9a-f]{24})')
  @Validate([
    {
      field: 'examGuideId',
      validation: [{ value: 'notEmpty', message: 'Exam Guide ID is required' }]
    }
  ])
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('examGuideId') examGuideId: string) {
    try {
      const result = await examGuideRepository.findOne({ _id: examGuideId }).lean();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param templateId
   * @description Updates one ExamGuide with the given changes
   */
  @Put('/exam-guides/:examGuideId([0-9a-f]{24})')
  @Validate([
    {
      field: 'examGuideId',
      validation: [{ value: 'notEmpty', message: 'Exam Guide ID is required' }]
    },
    'global',
    'programs',
    'name',
    'url'
  ])
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async update(@Req() req: any, @Res() res: any, @Param('examGuideId') examGuideId: string) {
    try {
      const facade = new UpdateFacade(examGuideId, req.body, ['global', 'programs', 'name', 'url'], examGuideRepository);
      await facade.create();

      return res.status(201).send({ message: 'Exam Guide updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param templateId
   * @description Deletes ExamGuides with the given IDs
   */
  @Put('/exam-guides/delete')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'Template ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async delete(@Req() req: any, @Res() res: any) {
    try {
      const { ids } = req.body;

      await examGuideRepository.destroy({ _id: { $in: ids } }, req.user._id);

      return res.status(200).send({ message: 'Template deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param templateId
   * @description Duplicates one ExamGuide with the given ID
   */
  @Put('/exam-guides/duplicate/:examGuideId([0-9a-f]{24})')
  @Validate([
    {
      field: 'examGuideId',
      validation: [{ value: 'notEmpty', message: 'ExamGuide ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async duplicate(@Req() req: any, @Res() res: any, @Param('examGuideId') examGuideId: string) {
    try {
      const f: ExamGuide = await examGuideRepository.findOne({ _id: examGuideId }).lean();
      const createdExamGuide = await examGuideRepository.create({
        global: f.global,
        name: `Copy of ${f.name}`,
        owner: req.user._id,
        programs: f.programs,
        university: req.university._id,
        url: f.url
      });

      return res.status(201).send({ message: 'ExamGuide duplicated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
