import { examGuideRepository } from '@edorer/exam-guide-data';
import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';

export class ExamGuideListFacade {
  private readonly currentUser: User;

  private readonly program: string;

  private readonly facade: ListFacade;

  private readonly keyword: string;

  private readonly limit: number;

  private readonly skip: number;

  private readonly university: University;

  constructor(program: string, keyword: string, limit: number, skip: number, currentUser: User, university: University) {
    this.currentUser = currentUser;
    this.program = program;
    this.keyword = keyword;
    this.limit = +limit;
    this.skip = +skip;
    this.university = university;

    this.facade = new ListFacade(null, this.university, +this.skip, +this.limit, this.keyword, ['name'], examGuideRepository);
  }

  async create() {
    this.checkProgram();
    this.checkUser();

    this.facade.addSort({ createdAt: 1 });

    this.facade.addPopulates([{ path: 'program', select: 'title' }]);

    return await this.facade.create();
  }

  private checkProgram() {
    if (this.program) {
      this.facade.addConditions({ program: this.program });
    }
  }

  private checkUser() {
    switch (this.currentUser.type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.PENDING_STUDENT:
      case UserTypes.STUDENT:
      case UserTypes.TEACHER: {
        this.facade.addConditions({ $and: [{ $or: [{ global: true }, { program: { $in: this.currentUser.programs } }] }] });
        break;
      }

      case UserTypes.ADMIN:
      case UserTypes.UNIVERSITY_MEMBER: {
        this.facade.addConditions({ owner: this.currentUser._id });
        break;
      }

      case UserTypes.UNIVERSITY_OWNER: {
        break;
      }
    }
  }
}
