import { StudentFeeCrudController } from '@edorer/student-fee-api';

export class StudentFeeApp {
  controllers = [StudentFeeCrudController];
}
