import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Post, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { StudentFeeFinder } from '../services/StudentFeeFinder';
import { Validate } from '@edorer/validator';

@JsonController()
export class StudentFeeCrudController {
  @Post('/student-fee-details')
  @Validate(['applicationNumber', 'enrollmentId'])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { applicationNumber, enrollmentId } = req.body;

      const facade = new StudentFeeFinder(applicationNumber, req.user, enrollmentId, req.university);
      const result = await facade.find();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
