import { debToLmsRepository } from '@edorer/deb-to-lms-data';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class StudentFeeFinder {
  private readonly enrollmentId: string;

  protected readonly applicationNumber: string;

  protected readonly currentUser: User;

  protected readonly university: University;

  constructor(applicationNumber: string, currentUser: User, enrollmentId: string, university: University) {
    this.applicationNumber = applicationNumber;
    this.currentUser = currentUser;
    this.enrollmentId = enrollmentId;
    this.university = university;
  }

  async find() {
    try {
      const or = [];
      if (this.enrollmentId) or.push({ permanentEnrollmentNumber: this.enrollmentId.toLowerCase() });
      if (this.enrollmentId) or.push({ permanentEnrollmentNumber: this.enrollmentId.toUpperCase() });
      if (this.applicationNumber) or.push({ applicationNumber: this.applicationNumber });

      return await debToLmsRepository.findOne({ $or: or, isConverted: true, university: this.university._id }).lean();
    } catch (error: any) {
      console.error(error);
      throw new Error('Error while finding student fee details');
    }
  }
}
