import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { ProctorRequestsListFacade } from '../services/ProctorRequestsListFacade';
import { Socket } from '@edorer/socket';
import { Validate } from '@edorer/validator';
import { proctorRequestRepository } from '@edorer/proctor-request-data';

/**
 * @description Crud Operation Controller Proctor Request
 */
@JsonController()
export class ProctorRequestCrudController {

    /**
     * @description Get Proctor Request List
     */
    @Get('/proctor-requests')
    @Validate([
        {
            field: 'limit',
            validation: [{ value: 'notEmpty', message: 'limit is required' }]
        },
        {
            field: 'skip',
            validation: [{ value: 'notEmpty', message: 'skip is required' }]
        },
        'keyword'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async listRequests(@Req() req: any, @Res() res: any) {
        try {
            const { keyword, limit, skip } = req.query;

            const facade = new ProctorRequestsListFacade(keyword, limit, skip, req.user, req.university);
            const result = await facade.create();

            return res.send(result);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Get One Proctor Request
     */
    @Get('/proctor-requests/:proctorRequestId([0-9a-f]{24})')
    @Validate([
        {
            field: 'proctorRequestId',
            validation: [
                { value: 'notEmpty', message: 'proctorRequestId is required' }
            ]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async proctorRequest(@Req() req: any, @Res() res: any, @Param('proctorRequestId') proctorRequestId: string) {
        try {
            const proctorRequest = await proctorRequestRepository
                .findOne({ _id: proctorRequestId })
                .populate({ path: 'exam', select: '_id' });

            return res.send(proctorRequest);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Get Proctor Request Live Proctors List
     */
    @Get('/proctor-requests/live-proctors')
    @Validate([
        {
            field: 'limit',
            validation: [{ value: 'notEmpty', message: 'limit is required' }]
        },
        {
            field: 'skip',
            validation: [{ value: 'notEmpty', message: 'skip is required' }]
        },
        'keyword'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async liveProctors(@Req() req: any, @Res() res: any) {
        try {
            const { keyword, limit, skip } = req.query;

            const facade = new ProctorRequestsListFacade(keyword, limit, skip, req.user, req.university, true);
            const result = await facade.create();

            return res.status(200).send(result);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @description Get Ping From Live Proctor
     */
    @Post('/proctor-requests/ping-from-live-proctor')
    @Validate([
        {
            field: 'request',
            validation: [{ value: 'notEmpty', message: 'request is required' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async pingLiveProctor(@Req() req: any, @Res() res: any) {
        try {
            const { request } = req.body;

            const proctorRequest = await proctorRequestRepository.count({ _id: request });

            if (proctorRequest !== 0) {
                await Socket.sendToRoom('proctors', `ping_from_live_proctor`, request);
            }

            return res.status(200).send({ message: 'Pinged successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
