import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from "@edorer/validator";
import { preFilledProctorRepository } from "@edorer/proctor-request-data";

const excelToJson = require('convert-excel-to-json');

@JsonController()
export class PreFilledProctorController {


    @Post('/pre-filled-proctor/:exam([0-9a-f]{24})')
    @Validate([
        {
            field: 'exam',
            validation: [{value: 'notEmpty', message: 'limit is required'}]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async assign(@Req() req: any, @Res() res: any, @Param('exam') exam: string, @UploadedFile('file') file: any) {
        try {
            const result = excelToJson({
                source: file.buffer,
                columnToKey: {'*': '{{columnHeader}}'},
                header: {rows: 1},
            });
            const students = result['Students'];
            let alreadyFilled = await preFilledProctorRepository.find({exam: exam}).lean();
            for (let student of students) {
                let isAlreadyFilled = alreadyFilled.find((item: any) => item.studentEmail === student['Student Email']);
                if (isAlreadyFilled) {
                    await preFilledProctorRepository.update({_id: isAlreadyFilled._id}, {
                        $set: {
                            studentEmail: student['Student Email'],
                            proctorEmail: student['Proctor Email']
                        }
                    });
                } else {
                    await preFilledProctorRepository.create({
                        exam: exam,
                        studentEmail: student['Student Email'],
                        proctorEmail: student['Proctor Email'],
                        university: req.university._id
                    });
                }
            }

            return res.send({success: true});
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({error: error.message});
        }
    }
}
