import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { FixUniversityObjectId } from '../services/FixUniversityObjectId';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { ProctorMultipleActionFacade } from '../services/ProctorMultipleActionFacade';
import { TrackExamStatus } from '@edorer/track-exam-data';
import { Validate } from '@edorer/validator';
import { proctorRequestRepository } from '@edorer/proctor-request-data';

/**
 * @description Controller for Proctor
 */
@JsonController()
export class ProctorRequestExtraController {
  /**
   * @description Get Proctor List
   */
  @Get('/proctors')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    'keyword',
    'skip',
    'action',
    'examId',
    'not_examId'
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const facade = new ProctorMultipleActionFacade(req.user, req.query);
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Get Proctor By id from track exam
   */
  @Get('/proctors/track-exams/:proctor([0-9a-f]{24})')
  @Validate([
    {
      field: 'proctor',
      validation: [{ value: 'notEmpty', message: 'proctor is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async proctorTrackExams(@Req() req: any, @Res() res: any, @Param('proctor') proctor: string) {
    try {
      const proctorRequest = await proctorRequestRepository
        .findOne({ _id: proctor })
        .populate({ path: 'owner', select: 'avatar name' })
        .populate({ path: 'trackExams', populate: [{ path: 'user', select: 'name avatar' }] })
        .lean();

      proctorRequest.trackExams = proctorRequest.trackExams.filter((trackExam) => trackExam.status === TrackExamStatus.IN_PROGRESS);

      return res.status(200).send(proctorRequest);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Get Proctor by track exam ID
   */
  @Get('/proctors/track-proctor/:trackExam([0-9a-f]{24})')
  @Validate([
    {
      field: 'trackExam',
      validation: [{ value: 'notEmpty', message: 'trackExam is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async trackProctor(@Req() req: any, @Res() res: any, @Param('trackExam') trackExam: string) {
    try {
      const proctor = await proctorRequestRepository
        .findOne({ trackExams: { $in: [trackExam] } })
        .populate({
          path: 'owner',
          select: 'avatar name'
        })
        .populate({ path: 'trackExams', populate: [{ path: 'user', select: 'name avatar' }] })
        .lean();

      return res.send(proctor);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Create Proctor For exam
   */
  @Post('/proctors')
  @Validate([
    {
      field: 'exam',
      validation: [{ value: 'notEmpty', message: 'Exam is required' }]
    },
    {
      field: 'user',
      validation: [{ value: 'notEmpty', message: 'User is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async add(@Req() req: any, @Res() res: any) {
    try {
      const { user, exam } = req.body;
      await proctorRequestRepository.create({ exam, university: req.university._id, user, owner: req.user._id });
      return res.send({ message: 'Proctor(s) added successfully to exam.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Update Proctor
   */
  @Put('/proctors')
  @Validate([
    {
      field: 'user',
      validation: [{ value: 'notEmpty', message: 'user is required' }]
    },
    {
      field: 'exam',
      validation: [{ value: 'notEmpty', message: 'exam is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async remove(@Req() req: any, @Res() res: any) {
    try {
      const { exam, user } = req.body;
      await proctorRequestRepository.destroy({ exam, user }, req.user._id);

      return res.send({ message: 'Proctor(s) removed from exam successfully.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
