import { UserTypes, User, userRepository } from '@edorer/user-data';
import { ListFacade } from '@edorer/generic-facades';
import { proctorRequestRepository } from '@edorer/proctor-request-data';

export class ProctorMultipleActionFacade {
  private readonly body: any;
  private readonly currentUser: User;
  private facade: ListFacade;
  private proctors = [];

  constructor(currentUser: User, body: any) {
    this.currentUser = currentUser;
    this.body = body;
  }

  async create() {
    const { skip, limit, keyword } = this.body;

    const proctorRequests = await proctorRequestRepository.find({ exam: this.body.examId }).populate({
      path: 'user',
      select: '_id'
    });

    if (!!proctorRequests.length) {
      for (let request of proctorRequests) {
        if (request && request.user && request.user._id) this.proctors.push(request.user._id);
      }
    }

    this.facade = new ListFacade(this.currentUser, this.currentUser.university, +skip, +limit, keyword, ['name', 'email'], userRepository);
    this.addConditions();
    this.facade.deleteCondition('owner');
    this.facade.addPopulates({ path: 'role', select: 'title' });

    return await this.facade.create();
  }

  private addConditions() {
    this.facade.addConditions({
      $and: [
        {
          $or: [{ type: UserTypes.UNIVERSITY_MEMBER }, { type: UserTypes.UNIVERSITY_OWNER }, { type: UserTypes.TEACHER }]
        }
      ]
    });

    if (this.body.examId && !this.body.not_examId) {
      this.facade.addConditions({ _id: { $in: this.proctors } });
    }
    if (this.body.not_examId) {
      this.facade.addConditions({ _id: { $nin: this.proctors } });
    }
  }
}
