import { examRepository } from '@edorer/exam-data';
import { ListFacade } from '@edorer/generic-facades';
import { proctorRequestRepository } from '@edorer/proctor-request-data';
import { trackExamRepository } from '@edorer/track-exam-data';
import { University } from '@edorer/university-data';
import { User, UserTypes, userRepository } from '@edorer/user-data';
import * as moment from 'moment';

export class ProctorRequestsListFacade {
  private facade: ListFacade;
  private readonly currentUser: User;
  private readonly keyword: string = null;
  private readonly limit: number;
  private readonly onlyToday: boolean;
  private readonly skip: number;
  private readonly university: University;

  constructor(keyword: string = null, limit: number, skip: number, currentUser: User, university: University, onlyToday = false) {
    this.currentUser = currentUser;
    this.keyword = keyword;
    this.limit = limit;
    this.onlyToday = onlyToday;
    this.skip = skip;
    this.university = university;
  }

  async create(): Promise<{ items: any[]; total: number }> {
    this.facade = new ListFacade(null, this.university._id, +this.skip, +this.limit, null, [], proctorRequestRepository);

    if (this.onlyToday) {
      const trackExams = await trackExamRepository
        .find({ startedAt: { $gte: moment().startOf('date') } })
        .select('_id')
        .lean();

      this.facade.addConditions({ trackExams: { $in: trackExams.map((trackExam) => trackExam._id) } });
    }

    if (this.keyword) {
      await this.addConditions();
    }

    this.facade.deleteCondition('owner');
    this.addConditionForTeacher();
    this.addPopulates();

    return await this.facade.create();
  }

  private async addConditions(): Promise<void> {
    await this.addExams();
    await this.addUsers();
  }

  private async addExams(): Promise<void> {
    const exams = await examRepository
      .find({
        title: new RegExp(this.keyword.toLowerCase(), 'i'),
        university: this.university._id
      })
      .select('_id')
      .lean();

    const examIds = exams.map((exam) => exam._id);

    if (examIds.length > 0) {
      this.facade.addConditions({ exam: { $in: examIds } });
    }
  }

  private async addUsers(): Promise<void> {
    const users = await userRepository
      .find({
        $or: [{ email: new RegExp(this.keyword.toLowerCase(), 'i') }, { name: new RegExp(this.keyword.toLowerCase(), 'i') }],
        university: this.university._id
      })
      .select('_id')
      .lean();

    const userIds = users.map((user) => user._id);

    if (userIds.length > 0) {
      this.facade.addConditions({ $or: [{ owner: { $in: userIds } }, { user: { $in: userIds } }] });
    }
  }

  private addConditionForTeacher() {
    if (this.currentUser.type === UserTypes.TEACHER) {
      this.facade.addConditions({ user: { $in: [this.currentUser._id] } });
    }
  }

  private addPopulates(): void {
    this.facade.query.populate({ path: 'exam', select: 'title' });
    this.facade.query.populate({ path: 'owner', select: 'avatar name' });
    this.facade.query.populate({ path: 'user', select: 'avatar name email extraFields' });
  }
}
