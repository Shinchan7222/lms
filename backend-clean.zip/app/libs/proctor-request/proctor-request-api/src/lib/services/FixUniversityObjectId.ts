export class FixUniversityObjectId {
    private readonly university: string;
    private repository: any;
    private allData: any;

    constructor(university: string , repository: any) {
        this.university = university;
        this.repository = repository;
    }

   async fix() {
        await this.fetch();
        await this.add();
    }

    async fetch() {
        this.allData = await this.repository.find( { university: { $exists: false }} , { deleted: { $eq: false } });
    }

    async add() {
        for (let repo of this.allData) {
            await this.repository.update({ _id : repo._id} , {
                $set: {
                    university: this.university
                } });
        }
    }
}
