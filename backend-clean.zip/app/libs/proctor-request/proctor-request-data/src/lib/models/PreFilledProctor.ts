import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('PreFilledProctor')
export class PreFilledProctor extends MongooseModel {

    @field({
        ref: 'Exam',
        type: Types.ObjectId,
    })
    exam: any;

    @field({
       type: String,
    })
    proctorEmail: any;

    @field({
        type: String,
    })
    studentEmail: any;

    @field({
        ref: 'University',
        required: true,
        type: Types.ObjectId,
    })
    university: any;
}
