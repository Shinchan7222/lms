import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('ProctorRequest')
export class ProctorRequest extends MongooseModel {
  @field({
    ref: 'Exam',
    type: Types.ObjectId
  })
  exam: any;

  @field({
    ref: 'User',
    type: Types.ObjectId
  })
  owner: any;

  @field([
    {
      ref: 'TrackExam',
      type: Types.ObjectId
    }
  ])
  trackExams: any[];

  @field({
    ref: 'User',
    type: Types.ObjectId
  })
  user: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @post('save')
  async notifyCreate() {
    dbOperationsNotifier.notify(
      'proctorRequest',
      {
        id: this._id,
        exam: this.exam,
        university: this.university,
        owner: this.owner
      },
      'create'
    );
  }
}
