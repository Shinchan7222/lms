import { MongooseRepository } from '@edorer/nems';

class ProctorRequestRepository extends MongooseRepository {
}

export let proctorRequestRepository = new ProctorRequestRepository();
