import { MongooseRepository } from '@edorer/nems';

class PreFilledProctorRepository extends MongooseRepository {
}

export let preFilledProctorRepository = new PreFilledProctorRepository();
