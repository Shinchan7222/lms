import { Nems } from '@edorer/nems';
import {
    PreFilledProctorController,
    ProctorRequestCrudController,
    ProctorRequestExtraController
} from '@edorer/proctor-request-api';
import { PreFilledProctor, ProctorRequest } from '@edorer/proctor-request-data';


export class ProctorRequestApp {

    controllers = [ProctorRequestExtraController, ProctorRequestCrudController, PreFilledProctorController];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{
            name: 'ProctorRequest',
            model: ProctorRequest
        }, { name: 'PreFilledProctor', model: PreFilledProctor }]);
    }
}
