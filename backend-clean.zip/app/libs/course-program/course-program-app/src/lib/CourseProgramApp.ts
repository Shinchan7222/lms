import { CourseProgram, CourseProgramIndexer } from '@edorer/course-program-data';
import { CourseProgramCrudController } from '@edorer/course-program-api';
import { Nems } from '@edorer/nems';

export class CourseProgramApp {

    controllers = [CourseProgramCrudController];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'CourseProgram', model: CourseProgram }]);
        await CourseProgramIndexer.index();
    }
}
