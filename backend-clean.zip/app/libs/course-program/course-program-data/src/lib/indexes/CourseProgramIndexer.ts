import { courseProgramRepository } from '@edorer/course-program-data';

export class CourseProgramIndexer {

    static async index() {
        await courseProgramRepository.ensureIndex({ _id: 1, deleted: 1 });
        await courseProgramRepository.ensureIndex({ owner: 1, title: 1, university: 1, deleted: 1 });
        await courseProgramRepository.ensureIndex({ title: 1, deleted: 1 });
        await courseProgramRepository.ensureIndex({ title: 1, university: 1, deleted: 1 });
        await courseProgramRepository.ensureIndex({ university: 1, deleted: 1 });
    }
}
