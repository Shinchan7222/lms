import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('CourseProgram')
export class CourseProgram extends MongooseModel {

    @field({
        type: Types.ObjectId,
        ref: 'User'
    })
    owner: any;

    @field({
        trim: true,
        type: String
    })
    title: string;

    @field({
        type: Types.ObjectId,
        ref: 'University',
        required: true
    })
    university: any;

    @field({
        default: new Date(),
        type: Date
    })
    createdAt: Date;

    @field({
        default: new Date(),
        type: Date
    })
    updatedAt: Date;

    @post('save')
    async notifyCreate() {
        dbOperationsNotifier.notify('course-program',
            {
                id: this._id,
                name: this.title,
                university: this.university,
                creator: this.owner
            },
            'create');
    }
}
