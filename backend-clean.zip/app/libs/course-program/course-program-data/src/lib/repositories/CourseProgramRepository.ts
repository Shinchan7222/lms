import { MongooseRepository } from '@edorer/nems';

class CourseProgramRepository extends MongooseRepository {
}

export let courseProgramRepository = new CourseProgramRepository();
