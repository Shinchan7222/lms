export * from './lib/controllers/CourseProgramCrudController';
