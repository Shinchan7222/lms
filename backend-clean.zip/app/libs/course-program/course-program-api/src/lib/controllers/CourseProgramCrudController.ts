import { CourseProgramListFacade } from '../facades/CourseProgramListFacade';
import { courseProgramRepository } from '@edorer/course-program-data';
import { Delete, Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { UpdateFacade } from '@edorer/generic-facades';
import { Validate } from '@edorer/validator';

/**
 * @description CRUD controller for CourseProgram
 */
@JsonController()
export class CourseProgramCrudController {

    /**
     * @param req
     * @param res
     * @description Creates a course-program
     */
    @Post('/course-programs')
    @Validate([
        {
            field: 'title',
            validation: [{ value: 'notEmpty', message: 'Title is required' }]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async create(@Req() req: any, @Res() res: any) {
        try {
            const { title } = req.body;

            await courseProgramRepository.create(
                {
                    owner: req.user._id,
                    title,
                    university: req.university._id,
                }
            );

            return res.status(201).send({ message: 'Course program created successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @param req
     * @param res
     * @description Finds course-programs based on the given queries
     */
    @Get('/course-programs')
    @Validate([
        {
            field: 'limit',
            validation: [{ value: 'notEmpty', message: 'limit is required' }]
        },
        {
            field: 'skip',
            validation: [{ value: 'notEmpty', message: 'skip is required' }]
        },
        'keyword'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async find(@Req() req: any, @Res() res: any) {
        try {
            const { keyword, limit, skip } = req.query;

            const facade = new CourseProgramListFacade(keyword, limit, skip, req.user, req.university);
            const result = await facade.create();

            return res.status(200).send(result);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/course-programs/:courseProgramId([0-9a-f]{24})')
    @Validate([
        {
            field: 'courseProgramId',
            validation: [{ value: 'notEmpty', message: 'Course Program ID is required' }]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async findOne(@Req() req: any, @Res() res: any, @Param('courseProgramId') courseProgramId: string) {
        try {
            const courseProgram = await courseProgramRepository.findOne({ _id: courseProgramId }).lean();

            return res.status(200).send(courseProgram);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @param req
     * @param res
     * @param courseProgramId
     * @description Updates a course-program
     */
    @Put('/course-programs/:courseProgramId([0-9a-f]{24})')
    @Validate([
        {
            field: 'courseProgramId',
            validation: [{ value: 'notEmpty', message: 'Course program ID is required' }]
        },
        {
            field: 'title',
            validation: [{ value: 'notEmpty', message: 'Course program title is required' }]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async update(@Req() req: any, @Res() res: any, @Param('courseProgramId') courseProgramId: string) {
        try {
            const updateFacade = new UpdateFacade(courseProgramId, req.body, ['title'], courseProgramRepository);
            await updateFacade.create();

            return res.send({ message: 'Course Program updated successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @param req
     * @param res
     * @description Deletes course-programs based on the given IDs
     */
    @Delete('/course-programs/:courseProgramId([0-9a-f]{24})')
    @Validate([
        {
            field: 'courseProgramId',
            validation: [{ value: 'notEmpty', message: 'Course program ID is required' }]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async delete(@Req() req: any, @Res() res: any, @Param('courseProgramId') courseProgramId: string) {
        try {
            await courseProgramRepository.destroy({ _id: courseProgramId }, req.user._id);

            return res.send({ message: 'Course Program deleted successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
