import { courseProgramRepository } from '@edorer/course-program-data';
import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class CourseProgramListFacade {

    private readonly currentUser: User;

    private readonly facade: ListFacade;

    private readonly keyword: string;

    private readonly limit: number;

    private readonly skip: number;

    private readonly university: University;

    constructor(keyword: string, limit: number, skip: number, currentUser: User, university: University) {
        this.currentUser = currentUser;
        this.keyword = keyword;
        this.limit = +limit;
        this.skip = +skip;
        this.university = university;

        this.facade = new ListFacade(
            this.currentUser, this.university, +this.skip, +this.limit,
            this.keyword, ['title'], courseProgramRepository, false
        );
    }

    async create() {
        this.facade.prepareQuery();

        return await this.facade.create();
    }
}
