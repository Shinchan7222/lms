export class Base64Image {

    static decode(dataString: string) {
        const matches = dataString.match(/^data:([0-9A-Za-z-+\/;=]+);base64,(.+)$/);

        if (!matches || matches.length !== 3) {
            throw new Error('Invalid base64 input string');
        }

        return {buffer: new Buffer(matches[2], 'base64')};
    }
}
