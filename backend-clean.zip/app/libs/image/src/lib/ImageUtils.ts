const allowedMimes = ['image/png', 'image/jpg', 'image/jpeg'];
const fileType = require('file-type');
const isSvg = require('is-svg');
const maxFileSize = 1024 * 1024 * 5;

export class ImageUtils {
  static isValid(image: any) {
    return (
      image.buffer.length <= maxFileSize &&
      ((fileType(image.buffer) !== null && allowedMimes.indexOf(fileType(image.buffer).mime) >= 0) || isSvg(image.buffer))
    );
  }
}
