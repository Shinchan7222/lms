import { broadCastRepository } from '@edorer/broadcast-data';

export class BroadCastIndexer {

    static async index() {
        await broadCastRepository.ensureIndex({ _id: 1, deleted: 1 });
        await broadCastRepository.ensureIndex({ university: 1, deleted: 1 });
    }
}
