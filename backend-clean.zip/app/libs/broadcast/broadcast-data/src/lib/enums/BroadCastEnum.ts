export enum BroadCastTypes {
    INDIVIDUAL= 'individual',
    MULTIPLE = 'multiple'
}
