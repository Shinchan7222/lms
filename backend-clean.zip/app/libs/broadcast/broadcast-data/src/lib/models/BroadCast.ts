import { BroadCastTypes } from '../enums/BroadCastEnum';
import { Model, MongooseModel, field, post } from '@edorer/nems';
import { Socket } from '@edorer/socket';
import { Types } from 'mongoose';

@Model('BroadCast')
export class BroadCast extends MongooseModel {

    @field({
        required: true,
        trim: true,
        type: String
    })
    content: string;

    @field({
        ref: 'Exam',
        type: Types.ObjectId
    })
    exam: any;

    @field({
        ref: 'TrackExam',
        type: Types.ObjectId
    })
    trackExam: any;

    @field({
        enum: [BroadCastTypes.INDIVIDUAL, BroadCastTypes.MULTIPLE],
        required: true,
        type: String
    })
    type: string;

    @field({
        ref: 'University',
        required: true,
        type: Types.ObjectId
    })
    university: any;

    @field({
        default: new Date(),
        type: Date
    })
    createdAt: Date;

    @post('save')
    async sendBroadCast(broadCast: any): Promise<void> {
        if (broadCast.type === BroadCastTypes.MULTIPLE && broadCast.exam) {
            Socket.sendToRoom(`exam:${broadCast.exam}`, `broadcast_${broadCast.exam}`, broadCast);
        } else if (broadCast.type === BroadCastTypes.INDIVIDUAL && broadCast.trackExam) {
            const { trackExamRepository } = require('@edorer/track-exam-data');
            const trackExam = await trackExamRepository.findOne({ _id: broadCast.trackExam }).lean();
            if (trackExam && trackExam.user) {
                Socket.send(trackExam.user, `broadcast_comment_${broadCast.trackExam}`, broadCast);
            }
        }
    }
}
