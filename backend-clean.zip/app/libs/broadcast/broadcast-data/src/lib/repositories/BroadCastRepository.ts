import { MongooseRepository } from '@edorer/nems';

class BroadCastRepository extends MongooseRepository {
}

export let broadCastRepository = new BroadCastRepository();
