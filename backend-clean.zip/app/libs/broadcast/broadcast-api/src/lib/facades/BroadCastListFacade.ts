import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { broadCastRepository, BroadCastTypes } from '@edorer/broadcast-data';

export class BroadCastListFacade {

    private readonly exam: string;

    private readonly facade: ListFacade;

    private readonly limit: number;

    private readonly skip: number;

    private readonly trackExam: string;

    private readonly university: University;

    constructor(exam: string, limit, skip, trackExam: string, university: University) {
        this.exam = exam;
        this.limit = limit;
        this.skip = skip;
        this.trackExam = trackExam;
        this.university = university;

        this.facade = new ListFacade(null, this.university, +this.skip, +this.limit, null, [''], broadCastRepository);
    }

    async create() {
        this.addConditions();

        this.facade.prepareQuery();

        return this.facade.create();
    }

    private addConditions() {
        if (!!this.exam) {
this.checkExam();
        } else if (!!this.trackExam) {
            this.checkTrackExam();
        }
    }

    private checkExam() {
        this.facade.addConditions({
            '$and': [
                { exam: this.exam },
                { type: BroadCastTypes.MULTIPLE }
            ]
        });
    }

    private checkTrackExam() {
        this.facade.addConditions({
            '$and': [
                { trackExam: this.trackExam },
                { type: BroadCastTypes.INDIVIDUAL }
            ]
        });
    }

}
