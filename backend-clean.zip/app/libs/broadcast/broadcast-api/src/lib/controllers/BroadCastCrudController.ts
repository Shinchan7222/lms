import { BroadCast, CanCreateBroadCast, broadCastRepository } from '@edorer/broadcast-data';
import { BroadCastListFacade } from '../facades/BroadCastListFacade';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

/**
 * @description CRUD controller for BroadCast
 */
@JsonController()
export class BroadCastCrudController {
	/**
	 * @param req
	 * @param res
	 * @description Creates one BroadCast with the given properties
	 */
	@Post('/broadcasts')
	@Validate([
		{
			field: 'content',
			validation: [{ value: 'notEmpty', message: 'content is required' }],
		},
		{
			field: 'type',
			validation: [{ value: 'notEmpty', message: 'type is required' }],
		},
		'exam',
		'trackExam',
	])
	@UseBefore(GetUniversity)
	@UseBefore(IsAuthenticated, CanCreateBroadCast)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async create(@Req() req: any, @Res() res: any) {
		try {
			const { content, exam, trackExam, type } = req.body;
			const broadcast: BroadCast = await broadCastRepository.create({
				content,
				exam,
				trackExam,
				type,
				university: req.university._id,
			});

			return res.status(201).send(broadcast);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}

	/**
	 * @param req
	 * @param res
	 * @description Finds BroadCasts with the given queries
	 */
	@Get('/broadcasts')
	@Validate([
		{
			field: 'skip',
			validation: [{ value: 'notEmpty', message: 'skip is required' }],
		},
		{
			field: 'limit',
			validation: [{ value: 'notEmpty', message: 'limit is required' }],
		},
		'exam',
		'trackExam',
	])
	@UseBefore(GetUniversity)
	@UseBefore(IsAuthenticated)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async find(@Req() req: any, @Res() res: any) {
		try {
			const { exam, limit, skip, trackExam } = req.query;

			const broadCastListFacade = new BroadCastListFacade(exam, limit, skip, trackExam, req.university);
			const result = await broadCastListFacade.create();

			return res.status(200).send(result);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}
}
