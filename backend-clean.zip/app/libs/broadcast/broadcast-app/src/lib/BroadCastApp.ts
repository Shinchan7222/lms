import { BroadCastCrudController } from '@edorer/broadcast-api';
import { BroadCast, BroadCastIndexer } from '@edorer/broadcast-data';
import { Nems } from '@edorer/nems';

export class BroadCastApp {

    controllers = [
        BroadCastCrudController
    ];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'BroadCast', model: BroadCast }]);
        await BroadCastIndexer.index();
    }
}
