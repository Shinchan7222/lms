import { MongooseRepository } from '@edorer/nems';

class VideoTempRepository extends MongooseRepository {
}

export let videoTempRepository = new VideoTempRepository();
