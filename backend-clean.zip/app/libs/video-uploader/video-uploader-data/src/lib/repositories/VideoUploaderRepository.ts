import { MongooseRepository } from '@edorer/nems';

class VideoUploaderRepository extends MongooseRepository {
}

export let videoUploaderRepository = new VideoUploaderRepository();
