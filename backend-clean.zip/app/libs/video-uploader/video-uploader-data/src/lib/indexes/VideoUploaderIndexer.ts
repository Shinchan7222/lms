import { videoUploaderRepository } from '@edorer/video-uploader-data';

export class VideoUploaderIndexer {

    static async index() {
        await videoUploaderRepository.ensureIndex({ _id: 1, deleted: 1 });
        await videoUploaderRepository.ensureIndex({ isDashed: 1, deleted: 1 });
        await videoUploaderRepository.ensureIndex({ url: 1, deleted: 1 });
    }

}
