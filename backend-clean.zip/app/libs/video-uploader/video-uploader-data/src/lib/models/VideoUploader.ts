import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('VideoUploader')
export class VideoUploader extends MongooseModel {
  @field([
    {
      ref: 'Course',
      type: Types.ObjectId
    }
  ])
  courses: any[];

  @field({
    type: String
  })
  dashedUrl: string;

  @field([
    {
      ref: 'Domain',
      type: Types.ObjectId
    }
  ])
  domain: any;

  @field({
    type: Boolean,
    default: false
  })
  isDashed: boolean;

  @field({
    type: Boolean
  })
  requestDashing: boolean;

  @field({
    type: Boolean,
    default: false
  })
  isWatermarked: boolean;

  @field({
    type: Boolean,
    default: false
  })
  isDashing: boolean;

  @field([
    {
      ref: 'Lecture',
      type: Types.ObjectId
    }
  ])
  lectures: any[];

  @field({
    ref: 'User',
    required: true,
    type: Types.ObjectId
  })
  owner: any;

  @field({
    default: 0,
    type: Number
  })
  priority: number;

  @field({
    type: String
  })
  title: string;

  @field({
    type: String
  })
  url: string;

  @field({
    type: String
  })
  watermarkedUrl: string;

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @field({
    type: Date
  })
  startDashing: Date;

  @field({
    type: Date
  })
  finishDashing: Date;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;
}
