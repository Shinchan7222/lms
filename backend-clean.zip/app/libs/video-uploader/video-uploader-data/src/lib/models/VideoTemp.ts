import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('VideoTemp')
export class VideoTemp extends MongooseModel {

  @field({
    type: String
  })
  unitName: string;

  @field({
    type: String
  })
  topicName: string;

  @field({
    type: String
  })
  courseName: string;

  @field({
    ref: 'University',
    type: Types.ObjectId,
    index: true
  })
  university: any;

  @field({
    type: String
  })
  url: string;

  @field({
    type: String
  })
  originalUrl: string;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

}
