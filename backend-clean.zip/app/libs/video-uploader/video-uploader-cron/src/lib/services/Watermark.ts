import { Downloader, S3University } from '@edorer/s3';
import { universityConfigurationRepository } from '@edorer/university-data';
import { v4 as uuidV4 } from 'uuid';

const fs = require('fs');
const ffmpeg = require('ffmpeg');

export class Watermark {

    TMP_FOLDER = '/tmp/';

    private readonly logoUrl: string;
    private readonly videoUrl: string;
    private readonly universityId: string;

    private logoPath: string;
    private videoPath: string;

    private watermarkedVideoPath: string;

    constructor(logoUrl: string, videoUrl: string, universityId: string) {
        this.logoUrl = logoUrl;
        this.videoUrl = videoUrl;
        this.universityId = universityId;
    }

    public async watermark() {
        try {
            await this.fetchUniversityConfig();
            await this.downloadLogo();
            await this.downloadVideo();
            await this.watermarkVideo();
            const url = await this.uploadWatermarkedVideo();
            this.destroy();
            return url;
        } catch (e) {
            throw new Error(e as any);
        }
    }

    private universityConfig: any;
    private s3: S3University;

    private async fetchUniversityConfig() {
        this.universityConfig = await universityConfigurationRepository.findOne({university: this.universityId});
        if (!this.universityConfig) {
            throw new Error('There is no university config');
        }
        this.s3 = new S3University(this.universityConfig);
    }

    private async downloadLogo() {
        let downloader = new Downloader(this.logoUrl, this.s3);
        this.logoPath = await downloader.download();
        if (!this.logoPath) {
            throw new Error('Error download logoPath');
        }
    }

    private async downloadVideo() {
        let downloader = new Downloader(this.videoUrl, this.s3);
        this.videoPath = await downloader.download();
        if (!this.videoPath) {
            throw new Error('Error download videoPath');
        }
    }

    private watermarkVideo() {
        this.watermarkedVideoPath = this.TMP_FOLDER + uuidV4() + '.' + this.videoPath.split('.').pop();
        return new Promise<void>((resolve, reject) => {
            const process = new ffmpeg(this.videoPath, {maxBuffer: 1000000 * 1000000 * 1000000});
            process.then((video: any) => {
                const settings = {
                    position: "NW",
                    margin_nord: 10,
                    margin_sud: null,
                    margin_east: 10,
                    margin_west: null
                };
                video.fnAddWatermark(this.logoPath, this.watermarkedVideoPath, settings, (error, files) => {
                    if (error) {
                        reject(error);
                    } else {
                        resolve();
                    }
                })
            });
        });
    }

    private async uploadWatermarkedVideo() {
        return await this.s3.upload(this.watermarkedVideoPath, uuidV4() + '-watermark-' + this.videoUrl.split('/').pop(), this.universityConfig.buckets.LMS_COURSE_VIDEOS);
    }

    private destroy() {
        if (fs.existsSync(this.watermarkedVideoPath)) {
            fs.unlinkSync(this.watermarkedVideoPath);
        }
        if (fs.existsSync(this.logoPath)) {
            fs.unlinkSync(this.logoPath);
        }
        if (fs.existsSync(this.videoPath)) {
            fs.unlinkSync(this.videoPath);
        }
    }
}
