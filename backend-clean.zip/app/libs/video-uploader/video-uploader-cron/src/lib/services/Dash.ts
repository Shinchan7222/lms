import { Downloader, S3University } from '@edorer/s3';
import { UniversityConfiguration, universityConfigurationRepository } from '@edorer/university-data';
import * as util from 'util';
import { unlinkSync } from 'fs';

const exec = util.promisify(require('child_process').exec);
const fs = require('fs');

export class Dash {
  private readonly videoUrl: string;
  private readonly universityId: string;

  private videoPath: string;
  private dashedVideoPath: string;

  private s3: S3University;
  private universityConfig: UniversityConfiguration;

  constructor(videoUrl: string, universityId: string) {
    this.videoUrl = videoUrl;
    this.universityId = universityId;
  }

  async dash() {
    await this.fetchUniversityConfig();
    await this.downloadVideo();
    await this.dashVideo();

    this.dashedVideoPath = await this.upload();
    if (fs.existsSync(this.videoPath)) {
      unlinkSync(this.videoPath);
    }

    return this.dashedVideoPath;
  }

  async fetchUniversityConfig() {
    let universityConfig = await universityConfigurationRepository.findOne({ university: this.universityId });
    if (!universityConfig) {
      throw new Error('There is no university config');
    }
    this.universityConfig = universityConfig;
    this.s3 = new S3University(this.universityConfig);
  }

  private async downloadVideo() {
    let downloader = new Downloader(this.videoUrl, this.s3);
    this.videoPath = await downloader.download();
  }

  private async dashVideo() {
    await exec(__dirname + '/dash.sh ' + this.videoPath, { maxBuffer: 1000000 * 1000000 * 1000000 });
  }

  private async upload() {
    const folderName = this.videoPath.split('/').pop().split('.').shift();
    const folderPath = '/tmp/' + folderName;
    const files = fs.readdirSync(folderPath);
    // await this.s3.createFolder(folderPath, this.universityConfig.buckets.LMS_COURSE_VIDEOS);
    let urls = [];
    for (let file of files) {
      let url;
      do {
        try {
          url = await this.s3.upload(folderPath + '/' + file, folderName + '/' + file, this.universityConfig.buckets.LMS_COURSE_VIDEOS);
        } catch (e) {
          console.error(e);
        }
      } while (!url);
      urls.push(url);
    }
    let mpdFileIndex = files.findIndex((o) => o.includes('.mpd'));
    return urls[mpdFileIndex];
  }
}
