import { Dash } from '../services/Dash';
import { lectureRepository } from '@edorer/lecture-data';
import { VideoUploader, videoUploaderRepository } from '@edorer/video-uploader-data';
import * as util from 'util';

const exec = util.promisify(require('child_process').exec);

class Dashing {
  private videos: VideoUploader[] = [];

  private ffmpegIsWorking: boolean;

  async init() {
    await this.checkNoFFMPEG();

    if (this.ffmpegIsWorking) return;

    await this.fetchData();
    await this.work();
  }

  private async checkNoFFMPEG() {
    try {
      const response = await exec('ps aux', { maxBuffer: 1000000 * 1000000 * 1000000 });
      this.ffmpegIsWorking = response && response.stdout.length > 0 && response.stdout.indexOf('ffmpeg') > -1;
    } catch (e) {
      console.error(e);
    }
  }

  private async fetchData() {
    this.videos = await videoUploaderRepository
      .find({
        isDashed: false
        // requestDashing: true
      })
      .sort({ priority: -1 })
      .limit(1)
      .lean();
  }

  private async work() {
    if (this.videos.length === 0) return;

    const promises = [];

    for (let video of this.videos) {
      promises.push(this.dashVideo(video));
    }

    await Promise.all(promises);
  }

  private async dashVideo(video: VideoUploader) {
    try {
      await videoUploaderRepository.update({ _id: video._id }, { $set: { isDashing: true, startDashing: new Date() } }, { multi: false });

      const dasher = new Dash(video.url, video.university);
      const dashedUrl = await dasher.dash();

      await videoUploaderRepository.update(
        { _id: video._id },
        {
          $set: {
            dashedUrl,
            finishDashing: new Date(),
            isDashed: true,
            isDashing: false
          }
        },
        { multi: false }
      );

      const lectures = await lectureRepository.find({ _id: { $in: video.lectures } }).lean();
      for (let lecture of lectures) {
        for (let page of lecture.pages) {
          if (page.video === video.url || page.video === video.watermarkedUrl) {
            page.assetUrl = dashedUrl;
            page.video = dashedUrl;
          }
        }

        await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages } }, { multi: false });
      }
    } catch (e) {
      console.error('ERROR DASHING VIDEO: ' + video.url);
      console.error(e);
    }
  }
}

export const dashing = new Dashing();
