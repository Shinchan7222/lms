import { lectureRepository } from '@edorer/lecture-data';
import { VideoUploader, videoUploaderRepository } from '@edorer/video-uploader-data';
import { Watermark } from '../services/Watermark';

class Watermarking {
  private videos: VideoUploader[] = [];

  async init() {
    await this.fetchData();
    await this.work();
  }

  private async fetchData() {
    this.videos = await videoUploaderRepository
      .find({ isWatermarked: false })
      .populate({ path: 'university', select: 'logo' })
      .sort({ priority: -1 })
      .limit(1)
      .lean();
  }

  private async work() {
    if (this.videos.length === 0) return;

    const promises = [];

    for (let video of this.videos) {
      promises.push(this.watermarkVideo(video));
    }

    await Promise.all(promises);
  }

  private watermarkVideo(video: VideoUploader) {
    return new Promise((resolve: Function) => {
      try {
        const watermark = new Watermark(video.university.logo, video.url, video.university._id);

        watermark
          .watermark()
          .then(async (watermarkedUrl: string) => {
            await videoUploaderRepository.update(
              { _id: video._id },
              {
                $set: {
                  watermarkedUrl,
                  isWatermarked: true
                }
              },
              { multi: false }
            );

            const lectures = await lectureRepository.find({ _id: { $in: video.lectures } }).lean();
            for (let lecture of lectures) {
              for (let page of lecture.pages) {
                if (page.video === video.url) {
                  page.assetUrl = watermarkedUrl;
                  page.video = watermarkedUrl;
                }
              }

              await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages } }, { multi: false });
            }

            resolve();
          })
          .catch((e) => {
            resolve();
            console.error(e);
          });
      } catch (e) {
        resolve();
        console.error(e);
      }
    });
  }
}

export const watermarking = new Watermarking();
