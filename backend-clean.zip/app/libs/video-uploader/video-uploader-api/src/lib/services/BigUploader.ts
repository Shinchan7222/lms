const Busboy = require('busboy');
const StreamConcat = require('stream-concat');
import { createReadStream, createWriteStream, mkdirSync, readdir, rmdir, statSync, unlink } from 'fs';
import { join } from 'path';

export class BigUploader {
  constructor(req: any, tmpDir: string, maxFileSize: number, maxChunkSize: number, ext: string = 'mp4') {
    this.request = req;
    this.tmpDir = tmpDir;
    this.maxFileSize = maxFileSize;
    this.maxChunkSize = maxChunkSize;
    this.dirPath = join(this.tmpDir, `${this.request.headers['uploader-file-id']}_tmp`);
    this.chunkPath = join(this.dirPath, this.request.headers['uploader-chunk-number']);
    this.chunkCount = +this.request.headers['uploader-chunk-number'];
    this.totalChunks = +this.request.headers['uploader-chunks-total'];

    this.outputFile = this.request.headers['uploader-file-id'] + '.' + ext;
  }

  private readonly request: any;
  private readonly tmpDir: string;
  private readonly maxFileSize: number;
  private readonly maxChunkSize: number;

  private readonly dirPath: string;
  private readonly chunkPath: string;
  private readonly chunkCount: number;
  private readonly totalChunks: number;
  private readonly outputFile: string;

  private static mkdirIfDoesntExist(dirPath) {
    try {
      statSync(dirPath);
    } catch (err) {
      mkdirSync(dirPath);
      return err;
    }
  }

  public upload(): Promise<string> {
    return new Promise((resolve: any, reject: any) => {
      if (!this.checkHeaders()) {
        reject(new Error('Missing header(s)'));
        return;
      }

      if (!this.checkTotalSize()) {
        reject(new Error('File is above size limit'));
        return;
      }

      try {
        const postParams = {};
        let limitReached = false;

        const busboy = new Busboy({
          headers: this.request.headers,
          limits: { files: 1, fileSize: this.maxChunkSize * 1000 * 1000 }
        });

        busboy.on('file', (fieldname, fileStream) => {
          fileStream.on('limit', () => {
            limitReached = true;
            fileStream.resume();
          });

          this.handleFile(fileStream);
        });

        busboy.on('field', (key, val) => {
          postParams[key] = val;
        });

        busboy.on('finish', () => {
          if (limitReached) {
            reject(new Error('Chunk is above size limit'));
            return;
          }
          if (this.chunkCount === this.totalChunks - 1) {
            this.mergeFiles()
              .then(() => {
                resolve(join(this.tmpDir, this.outputFile));
              })
              .catch((err) => {
                reject(err);
              });
          } else {
            resolve();
          }
        });

        this.request.pipe(busboy);
      } catch (err) {
        reject(err);
      }
    });
  }

  private checkHeaders() {
    return !(
      !this.request.headers['uploader-chunk-number'] ||
      !this.request.headers['uploader-chunks-total'] ||
      !this.request.headers['uploader-file-id'] ||
      !this.request.headers['uploader-chunks-total'].match(/^[0-9]+$/) ||
      !this.request.headers['uploader-chunk-number'].match(/^[0-9]+$/) ||
      !this.request.headers['uploader-file-id'].match(/^[0-9]+$/)
    );
  }

  private checkTotalSize() {
    return !(this.maxChunkSize * this.request.headers['uploader-chunks-total'] > this.maxFileSize);
  }

  private handleFile(fileStream: any) {
    let error: Error;
    let finished = false;
    let writeStream: any;

    const writeFile = () => {
      writeStream = createWriteStream(this.chunkPath);

      writeStream.on('error', (err) => {
        error = err;
        fileStream.resume();
      });

      writeStream.on('close', async () => {
        finished = true;
      });

      fileStream.pipe(writeStream);
    };

    // make sure chunk is in range
    if (this.chunkCount < 0 || this.chunkCount >= this.totalChunks) {
      error = new Error('Chunk is out of range');
      fileStream.resume();
    } else if (this.chunkCount === 0) {
      BigUploader.mkdirIfDoesntExist(this.dirPath);
      writeFile();
    } else {
      if (statSync(this.dirPath)) {
        writeFile();
      } else {
        error = new Error('Upload has expired');
        fileStream.resume();
      }
    }
  }

  private cleanChunks(dirPath) {
    readdir(dirPath, (err, files) => {
      let filesLength = files.length;

      files.forEach((file) => {
        unlink(join(dirPath, file), () => {
          if (--filesLength === 0) {
            rmdir(dirPath, () => {});
          }
        });
      });
    });
  }

  // public assembleChunks(fileId: string, dirPath: string, totalChunks: number) {
  //     const assembledFile = join(this.tmpDir, fileId);
  //     const pipeChunk = (chunkCount) => {
  //         let chunk = readFileSync(join(dirPath, chunkCount.toString()));
  //         appendFileSync(assembledFile, chunk);
  //         if (totalChunks > ++chunkCount) {
  //             return pipeChunk(chunkCount);
  //         } else {
  //             this.cleanChunks(dirPath);
  //             return assembledFile;
  //         }
  //     };
  //     return pipeChunk(0);
  // }

  public async mergeFiles() {
    const finalStreamFile = createWriteStream(join(this.tmpDir, this.outputFile));

    let streams = [];
    for (let i = 0; i <= this.chunkCount; i++) {
      streams.push(createReadStream(join(this.dirPath, i.toString())));
    }
    const combinedStreams = new StreamConcat(streams);
    combinedStreams.pipe(finalStreamFile);
    return new Promise((resolve: any) => {
      combinedStreams.on('end', () => {
        this.cleanChunks(this.dirPath);
        resolve();
      });
    });
  }

  // private execShellCommand(cmd) {
  //     const exec = require('child_process').exec;
  //     return new Promise((resolve, reject) => {
  //         exec(cmd, (error, stdout, stderr) => {
  //             if (error) {
  //                 console.warn(error);
  //             }
  //             resolve(stdout ? stdout : stderr);
  //         });
  //     });
  // }
}
