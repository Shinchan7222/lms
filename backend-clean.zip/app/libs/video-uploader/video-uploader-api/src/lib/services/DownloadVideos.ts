const AdmZip = require('adm-zip');
import { basename } from 'path';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { v4 as uuidV4 } from 'uuid';
import { VideoUploader, videoUploaderRepository } from '@edorer/video-uploader-data';

export class DownloadVideos {
	private readonly directory: string;
	private readonly videoIds: Array<string>;
	private readonly zipPath: string;
	private videos: Array<VideoUploader> = [];
	private readonly s3?: S3University;

	constructor(videoIds: Array<string>, universityConfig?: any) {
		this.videoIds = videoIds;
		this.directory = process.env.TEMP_DIR + 'videos-' + uuidV4();
		this.zipPath = this.directory + '.zip';
		if (universityConfig) {
			this.s3 = new S3University(universityConfig);
		}
	}

	async download() {
		this.createFolder();
		await this.fetchVideos();
		await this.downloadVideos();
		await this.createZipFile();

		return this.zipPath;
	}

	private createFolder() {
		FileUtils.removeFile(this.directory);
		FileUtils.createDirectory(this.directory);
	}

	private async fetchVideos() {
		this.videos = await videoUploaderRepository.find({ _id: { $in: this.videoIds } }).lean();
	}

	private async downloadVideos() {
		if (this.videos.length === 0) return;

		for (let video of this.videos) {
			try {
				const downloader = new Downloader(video.url, this.s3);
				const downloadedPath = await downloader.download();

				const path = basename(downloadedPath);
				FileUtils.moveFile(downloadedPath, `${this.directory}/${path}`);
			} catch (error) {
				console.error(error);
			}
		}
	}

	private async createZipFile() {
		try {
			const zip = new AdmZip();

			zip.addLocalFolder(this.directory, 'Videos');
			zip.writeZip(this.zipPath);

			await FileUtils.removeDirectory(this.directory);
		} catch (error: any) {
			console.error(error);
			throw new Error(error);
		}
	}
}
