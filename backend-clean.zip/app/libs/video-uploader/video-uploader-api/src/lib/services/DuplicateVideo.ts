import { VideoUploader, videoUploaderRepository } from '@edorer/video-uploader-data';

export class DuplicateVideo {

    private video: VideoUploader;

    private readonly videoId: string;

    constructor(videoId: string) {
        this.videoId = videoId;
    }

    async duplicate() {
        await this.fetchVideo();
        await this.duplicateVideo();
    }

    private async fetchVideo() {
        this.video = await videoUploaderRepository.findOne({ _id: this.videoId }).lean();
        if (!this.video) {
            throw new Error('Video not found');
        }
    }

    private async prepareTitle(): Promise<string> {
        const { title } = this.video;
        let copy = ' copy';
        let videos: VideoUploader[];
        if (title.indexOf('copy') > -1) {
            videos = await videoUploaderRepository.find({ title: { $regex: `.*${(title.slice(0, title.indexOf('copy'))).trim()}.*` } });
            if (videos && videos.length) {
                copy = copy + ` (${videos.length})`;
            }
        } else {
            videos = await videoUploaderRepository.find({ title: { $regex: `.*${title}.*` } });
            if (videos && videos.length) {
                copy = copy + ` (${videos.length})`;
            }
        }

        const findCopy = title.indexOf('copy');
        if (findCopy !== -1) {
            return title.slice(0, title.indexOf('copy')) + copy;
        } else {
            return title + copy;
        }
    }

    private async duplicateVideo() {
        const {
            courses,
            dashedUrl,
            domain,
            finishDashing,
            isDashed,
            isDashing,
            isWatermarked,
            lectures,
            owner,
            priority,
            startDashing,
            university,
            url,
            watermarkedUrl
        } = this.video;

        const title = await this.prepareTitle();

        await videoUploaderRepository.create({
            courses,
            dashedUrl,
            domain,
            finishDashing,
            isDashed,
            isDashing,
            isWatermarked,
            lectures,
            owner,
            priority,
            startDashing,
            title,
            university,
            url,
            watermarkedUrl
        });
    }
}
