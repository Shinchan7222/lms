import { ListFacade } from '@edorer/generic-facades';
import { Role } from '@edorer/role-data';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';
import { courseRepository } from '@edorer/course-data';
import { videoUploaderRepository } from '@edorer/video-uploader-data';

export class VideoListFacade {
  private readonly facade: ListFacade;

  private readonly course: string;

  private readonly domain: string;

  private readonly keyword: string;

  private readonly limit: number;

  private readonly secure: string;

  private readonly skip: number;

  private readonly university: University;

  private readonly user: User;

  constructor(course: string, domain: string, keyword: string, limit: number, secure: string, skip: number, user: User, university: University) {
    this.course = course;
    this.domain = domain;
    this.keyword = keyword;
    this.limit = +limit;
    this.secure = secure;
    this.skip = +skip;
    this.user = user;
    this.university = university;

    this.facade = new ListFacade(this.user, this.university, +skip, +limit, null, [], videoUploaderRepository);
  }

  async create() {
    this.checkCourse();
    this.checkDomain();
    this.checkSecured();

    await this.checkKeyword();
    await this.checkUserType();

    this.addPopulates();

    this.facade.prepareQuery();

    return await this.facade.create();
  }

  private async checkUserType() {
    if (this.user.type === UserTypes.UNIVERSITY_MEMBER) {
      const userRole = new Role(this.user.role);
      const domainCondition = await userRole.createCondition(this.user.university);
      this.facade.addConditions({ domain: domainCondition });
    } else if (this.user.type === UserTypes.TEACHER) {
      this.facade.deleteCondition('owner');
      this.facade.addConditions({ domain: { $in: this.user.domains } });
    }
  }

  private checkSecured() {
    if (this.secure) {
      if (this.secure === 'isDashing') {
        this.facade.addConditions({ isDashing: true });
      }

      if (this.secure === 'isDashed') {
        this.facade.addConditions({ isDashed: true });
      }
    }
  }

  private checkCourse() {
    if (this.course) {
      this.facade.addConditions({ courses: { $in: this.course } });
    }
  }

  private checkDomain() {
    if (this.domain) {
      this.facade.addConditions({ domain: this.domain });
    }
  }

  private async checkKeyword() {
    if (this.keyword) {
      const orCondition: any = [{ title: new RegExp(this.keyword, 'i') }, { url: new RegExp(this.keyword, 'i') }];

      // tslint:disable-next-line:max-line-length
      const courseFacade = new ListFacade(this.user, this.university, this.skip, this.limit, this.keyword, ['title', 'id'], courseRepository);
      courseFacade.addSelect('_id');

      const { items, total } = await courseFacade.create();
      if (total > 0) {
        const courseIds = items.map((course) => course._id);
        orCondition.push({ courses: { $in: courseIds } });
      }

      this.facade.addConditions({ $or: orCondition });
    }
  }

  private addPopulates() {
    this.facade.addPopulates([
      { path: 'domain', select: 'name' },
      { path: 'courses', select: 'title' },
      { path: 'lectures', select: 'title' }
    ]);
  }
}
