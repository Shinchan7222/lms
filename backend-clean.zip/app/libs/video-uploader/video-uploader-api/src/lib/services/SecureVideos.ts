import { videoUploaderRepository } from '@edorer/video-uploader-data';

export class SecureVideos {
  private readonly videoId: string;

  constructor(videoId: string) {
    this.videoId = videoId;
  }

  async secure() {
    await this.updatePriority();
  }

  private async updatePriority() {
    const mostImportantVideo = await videoUploaderRepository.findOne({}).sort({ priority: -1 }).lean();

    await videoUploaderRepository.update(
      { _id: this.videoId },
      { $set: { priority: mostImportantVideo.priority ? mostImportantVideo.priority + 1 : 1 } },
      { multi: false }
    );
  }
}
