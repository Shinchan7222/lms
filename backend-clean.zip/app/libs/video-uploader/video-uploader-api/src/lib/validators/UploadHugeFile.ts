import { BigUploader } from '../services/BigUploader';
import { ExpressMiddlewareInterface, getMetadataArgsStorage } from 'routing-controllers';

export const UploadHugeFile = (ext: string = 'mp4'): Function => {
  return (objectOrFunction: Object | Function, methodName?: string) => {
    class UploadFileMiddleware implements ExpressMiddlewareInterface {
      use(req: any, res: any, next?: (err?: any) => any): any {
        const bigUploader = new BigUploader(req, process.env.TEMP_DIR, 2000000000000, 1000000, ext);
        bigUploader
          .upload()
          .then((file: string) => {
            if (file) {
              req.file = file;
              next();
            } else {
              res.writeHead(204, 'No Content');
              res.end();
            }
          })
          .catch((err: { message: string | string[] }) => {
            if (err.message === 'Missing header(s)') {
              res.writeHead(400, 'Bad Request', { 'Content-Type': 'text/plain' });
              res.end('Missing uploader-* header');
              return;
            }

            if (err.message === 'Missing Content-Type') {
              res.writeHead(400, 'Bad Request', { 'Content-Type': 'text/plain' });
              res.end('Missing Content-Type');
              return;
            }

            if (err.message.includes('Unsupported content type')) {
              res.writeHead(400, 'Bad Request', { 'Content-Type': 'text/plain' });
              res.end('Unsupported content type');
              return;
            }

            if (err.message === 'Chunk is out of range') {
              res.writeHead(400, 'Bad Request', { 'Content-Type': 'text/plain' });
              res.end('Chunk number must be between 0 and total chunks - 1 (0 indexed)');
              return;
            }
            if (err.message === 'File is above size limit') {
              res.writeHead(413, 'Payload Too Large', { 'Content-Type': 'text/plain' });
              res.end(`File is too large. Max fileSize is: 500MB`);
              return;
            }

            if (err.message === 'Chunk is above size limit') {
              res.writeHead(413, 'Payload Too Large', { 'Content-Type': 'text/plain' });
              res.end(`Chunk is too large. Max chunkSize is: 1000000MB`);
              return;
            }

            if (err && err.message === 'Upload has expired') {
              res.writeHead(410, 'Gone', { 'Content-Type': 'text/plain' });
              res.end(err.message);
              return;
            }
          });
      }
    }

    const metadataMiddleware: any = {
      target: UploadFileMiddleware,
      isGlobal: false,
      priority: 0,
      afterAction: false
    };
    getMetadataArgsStorage().middlewares.push(metadataMiddleware);

    const metadataFunction: any = {
      middleware: UploadFileMiddleware,
      target: methodName ? objectOrFunction.constructor : (objectOrFunction as Function),
      method: methodName,
      afterAction: false
    };
    getMetadataArgsStorage().uses.push(metadataFunction);
  };
};
