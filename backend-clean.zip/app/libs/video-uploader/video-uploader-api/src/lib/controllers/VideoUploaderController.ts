import { Get, JsonController, Post, Req, Res, UseBefore } from 'routing-controllers';
import { GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { lectureRepository } from '@edorer/lecture-data';
import { S3University } from '@edorer/s3';
import { SecureVideos } from '../services/SecureVideos';
import { StringUtils } from '@edorer/utils';
import { UploadHugeFile } from '../validators/UploadHugeFile';
import { v4 as uuidV4 } from 'uuid';
import { Validate } from '@edorer/validator';
import { videoUploaderRepository } from '@edorer/video-uploader-data';
import { watermarking } from '@edorer/video-uploader-cron';

@JsonController()
export class VideoUploaderController {
  @Post('/upload/video')
  @UseBefore(GetUniversityConfig)
  @UseBefore(IsAuthenticated)
  @UploadHugeFile()
  async upload(@Req() req: any, @Res() res: any) {
    try {
      const { courses, lectures, useCloud } = req.query;

      const s3 = new S3University(req.universityConfig);

      let title = req.file.split('/').pop();
      if (req.headers['uploader-file-name']) {
        title = StringUtils.slug(req.headers['uploader-file-name']);
      }

      const url = await s3.upload(req.file, uuidV4() + '-' + title, req.universityConfig.buckets.LMS_COURSE_VIDEOS);

      await videoUploaderRepository.create({
        courses,
        isDashed: false,
        isWatermarked: false,
        lectures,
        owner: req.user._id,
        title,
        university: req.university._id,
        url
      });
      return res.status(200).send({ url, time: 60 });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/watermark/try')
  async tryWatermark(@Req() req: any, @Res() res: any) {
    try {
      await watermarking.init();
      return res.status(200).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/tmp/check')
  async tmpCheck(@Req() req: any, @Res() res: any) {
    try {
      const { execSync } = require('child_process');
      const output = execSync('df -h /tmp').toString();
      return res.type('text/plain').send(output);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/dash/check')
  async makeSureOfDash(@Req() req: any, @Res() res: any) {
    try {
      const videos = await videoUploaderRepository.find({ isDashed: true }).populate('lectures').lean();

      for (let video of videos) {
        for (let lecture of video.lectures) {
          let update = false;
          if (lecture) {
            for (let page of lecture.pages) {
              if (page.video !== video.dashedUrl) {
                page.video = video.dashedUrl;
                update = true;
              }
            }
            if (update) {
              await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages } }, { multi: false });
            }
          }
        }
      }

      return res.status(200).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/video-uploads/increase-priority')
  @Validate([
    {
      field: 'videoId',
      validation: [{ value: 'notEmpty', message: 'videoId is required' }]
    }
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(IsAuthenticated)
  async increasePriority(@Req() req: any, @Res() res: any) {
    try {
      const guardian = new SecureVideos(req.query.videoId);
      await guardian.secure();

      return res.status(200).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  // @Get('/upload/video-migrate')
  // async migrate(@Req() req: any, @Res() res: any) {
  //     try {
  //         const videos = await videoUploaderRepository.find({course: {$exists: true}}).lean();
  //
  //         for (let video of videos) {
  //             if (!video.lectures && !video.courses) {
  //                 await videoUploaderRepository.update({_id: video._id}, {
  //                     $set: {
  //                         lectures: [video.lecture],
  //                         courses: [video.course],
  //                         title: video.url.split('/').pop().split('.').shift()
  //                     }
  //                 });
  //             }
  //         }
  //
  //         return res.status(200).send({message: 'ok'});
  //     } catch (error: any) {
  //         console.error(error);
  //         return res.status(400).send({error: error.message});
  //     }
  // }
}
