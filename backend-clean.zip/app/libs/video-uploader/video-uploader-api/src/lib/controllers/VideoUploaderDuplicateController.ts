import { DuplicateVideo } from '../services/DuplicateVideo';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class VideoUploaderDuplicateController {

    @Get('/video-uploads/duplicate/:videoId([0-9a-f]{24})')
    @Validate([
        {
            field: 'videoId',
            validation: [{ value: 'notEmpty', message: 'Video ID is required' }]
        }
    ])
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async duplicate(@Req() req: any, @Res() res: any, @Param('videoId') videoId: string) {
        try {
            const duplicateVideo = new DuplicateVideo(videoId);
            await duplicateVideo.duplicate();

            return res.status(200).send({ message: 'Video duplicated successfully.' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
