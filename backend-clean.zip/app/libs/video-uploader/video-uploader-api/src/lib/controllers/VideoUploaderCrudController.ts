import { Delete, Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity, GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { S3University } from '@edorer/s3';
import { StringUtils } from '@edorer/utils';
import { UpdateFacade } from '@edorer/generic-facades';
import { UploadHugeFile } from '../validators/UploadHugeFile';
import { Validate } from '@edorer/validator';
import { VideoListFacade } from '../services/VideoListFacade';
import { v4 as uuidV4 } from 'uuid';
import { videoUploaderRepository } from '@edorer/video-uploader-data';

@JsonController()
export class VideoUploaderCrudController {
  @Post('/video-uploads')
  @Validate([
    {
      field: 'domain',
      validation: [{ value: 'notEmpty', message: 'Domain IDs are required' }]
    }
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  @UploadHugeFile()
  async create(@Req() req: any, @Res() res: any) {
    try {
      const { domain } = req.query;

      const s3 = new S3University(req.universityConfig);

      let title = req.file.split('/').pop();
      if (req.headers['uploader-file-name']) {
        title = StringUtils.slug(req.headers['uploader-file-name']);
      }
      const url = await s3.upload(req.file, uuidV4() + '-' + title, req.universityConfig.buckets.LMS_COURSE_VIDEOS);

      await videoUploaderRepository.create({
        domain,
        isDashed: false,
        isWatermarked: false,
        owner: req.user._id,
        title,
        university: req.university._id,
        url
      });
      return res.status(200).send({ url, time: 60 });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/video-uploads')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    'course',
    'domain',
    'keyword',
    'secure'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { course, domain, keyword, limit, skip, secure } = req.query;

      const videoListFacade = new VideoListFacade(course, domain, keyword, limit, secure, skip, req.user, req.university);
      const result = await videoListFacade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/video-uploads/:videoId([0-9a-f]{24})')
  @Validate([
    {
      field: 'domain',
      validation: [{ value: 'notEmpty', message: 'Domain IDs are required' }]
    },
    {
      field: 'videoId',
      validation: [{ value: 'notEmpty', message: 'Video ID is required' }]
    },
    'title'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async update(@Req() req: any, @Res() res: any, @Param('videoId') videoId: string) {
    try {
      const facade = new UpdateFacade(videoId, req.body, ['domain', 'title'], videoUploaderRepository);
      await facade.create();

      return res.status(200).send({ message: 'Video updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Delete('/video-uploads/:videoId([0-9a-f]{24})')
  @Validate([
    {
      field: 'videoId',
      validation: [{ value: 'notEmpty', message: 'Video ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async delete(@Req() req: any, @Res() res: any, @Param('videoId') videoId: string) {
    try {
      await videoUploaderRepository.destroy({ _id: videoId }, req.user);

      return res.status(200).send({ message: 'Video deleted successfully.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
