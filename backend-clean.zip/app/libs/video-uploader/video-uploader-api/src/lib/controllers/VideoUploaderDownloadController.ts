import { DownloadVideos } from '../services/DownloadVideos';
import { FileUtils } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { readFileSync } from 'fs';
import { Validate } from '@edorer/validator';

@JsonController()
export class VideoUploaderDownloadController {
	@Get('/video-uploads/download')
	@Validate([
		{
			field: 'videoIds',
			validation: [{ value: 'notEmpty', message: 'Video IDs are required' }],
		},
	])
	@UseBefore(GetUniversityConfig)
	@UseBefore(IsAuthenticated)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async download(@Req() req: any, @Res() res: any) {
		try {
			const { videoIds } = req.query;

			const videosDownloader = new DownloadVideos(videoIds, req.universityConfig);
			const path = await videosDownloader.download();

			const buffer = readFileSync(path);

			res.writeHead(200, {
				'Content-disposition': `attachment;attachment; filename=Videos.zip`,
				'Content-Length': buffer.length,
			});

			FileUtils.removeFile(path);

			return res.end(buffer);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}
}
