const schedule = require('node-schedule');
import { CronRegistry } from '@edorer/cron-data';
import { dashing, watermarking } from '@edorer/video-uploader-cron';
import { Nems } from '@edorer/nems';
import { VideoUploader, VideoUploaderIndexer, VideoTemp } from '@edorer/video-uploader-data';
import { VideoUploaderController, VideoUploaderCrudController } from '@edorer/video-uploader-api';
import { VideoUploaderDownloadController, VideoUploaderDuplicateController } from '@edorer/video-uploader-api';

export class VideoUploaderApp {
  controllers = [];

  constructor(noCron = false) {
    this.initDB();

    this.controllers.push(VideoUploaderController);
    this.controllers.push(VideoUploaderCrudController);
    this.controllers.push(VideoUploaderDownloadController);
    this.controllers.push(VideoUploaderDuplicateController);

    if (!noCron) {
      this.initCrons();
    }
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'VideoUploader', model: VideoUploader }, { name: 'VideoTemp', model: VideoTemp }]);
    await VideoUploaderIndexer.index();
  }

  async initCrons() {
    CronRegistry.getInstance().register('watermarking', watermarking.init, watermarking);
    CronRegistry.getInstance().register('dashing', dashing.init, dashing);

    schedule.scheduleJob('0 0 * * *', async () => {
      await CronRegistry.getInstance().reset('watermarking');
      await CronRegistry.getInstance().reset('dashing');
    });
  }
}
