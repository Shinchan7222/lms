const multer = require('multer');
import { ExpressMiddlewareInterface, getMetadataArgsStorage } from 'routing-controllers';

export const UploadFile = (name: string): Function => {
  return (objectOrFunction: Object | Function, methodName?: string) => {
    class UploadFileMiddleware implements ExpressMiddlewareInterface {
      use(request: any, response: any, next?: (err?: any) => any): any {
        multer().single(name)(request, response, (err: any) => {
          if (err || !request.file) {
            response.status(400).send(err);
          } else {
            next();
          }
        });
      }
    }

    const metadataMiddleware: any = {
      target: UploadFileMiddleware,
      isGlobal: false,
      priority: 0,
      afterAction: false
    };
    getMetadataArgsStorage().middlewares.push(metadataMiddleware);

    const metadataFunction: any = {
      middleware: UploadFileMiddleware,
      target: methodName ? objectOrFunction.constructor : (objectOrFunction as Function),
      method: methodName,
      afterAction: false
    };
    getMetadataArgsStorage().uses.push(metadataFunction);
  };
};
