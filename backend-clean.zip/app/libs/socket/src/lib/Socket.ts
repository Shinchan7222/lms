import { getIO } from '@edorer/pool-app';
import * as CryptoJS from 'crypto-js';

const SOCKET_ENCRYPT_KEY = 'sdm8Yy6OCCH5Du/IxBC3yJ17gkEECG3VEUwnQgGFyNKs0OyvdCtNi2AxTzUcQE94';

export class Socket {
    static encrypt(data: any): string {
        return CryptoJS.AES.encrypt(JSON.stringify(data), SOCKET_ENCRYPT_KEY).toString();
    }

    static async send(userId: string, event: string, data: any) {
        const io = getIO();
        if (!io) {
            console.error('[Socket] IO not initialized, cannot send to user:', userId, event);
            return;
        }
        const encrypted = Socket.encrypt(data);
        io.to('user:' + userId).emit(event, encrypted);
    }

    static async sendToRoom(room: string, event: string, data: any) {
        const io = getIO();
        if (!io) {
            console.error('[Socket] IO not initialized, cannot send to room:', room, event);
            return;
        }

        // Deep diagnostics
        const totalConnected = io.sockets ? io.sockets.sockets.size : 0;
        let socketsInRoom = 0;
        let roomExists = false;

        try {
            // Check adapter rooms directly
            const adapter = io.sockets.adapter;
            roomExists = adapter.rooms.has(room);
            const roomSet = adapter.rooms.get(room);
            socketsInRoom = roomSet ? roomSet.size : 0;

            console.log(`[Socket] sendToRoom room=${room} event=${event} | total_connected=${totalConnected} room_exists=${roomExists} sockets_in_room=${socketsInRoom}`);

            if (!roomExists) {
                // List all rooms for debugging
                const allRooms = Array.from(adapter.rooms.keys()).filter(r => r.startsWith('videoSession:'));
                console.log(`[Socket] All videoSession rooms: ${allRooms.join(', ') || 'NONE'}`);
            }
        } catch (e) {
            const diag = e instanceof Error ? e.message : String(e);
            console.log(`[Socket] sendToRoom room=${room} event=${event} (diagnostics failed: ${diag})`);
        }

        const encrypted = Socket.encrypt(data);
        io.to(room).emit(event, encrypted);

        console.log(`[Socket] EMITTED event=${event} to room=${room} (${socketsInRoom} sockets)`);
    }
}
