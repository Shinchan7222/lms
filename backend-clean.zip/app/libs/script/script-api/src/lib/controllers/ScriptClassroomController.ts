import { CanExecuteScript } from '@edorer/script-data';
import { Class, classRepository } from '@edorer/class-data';
import { ClassroomWork, classroomWorkRepository } from '@edorer/classroom-work-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';

@JsonController()
export class ScriptClassroomController {
  @Get('/scripts/delete-classroom-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async deleteCourseAssets(@Req() req: any, @Res() res: any) {
    try {
      const classrooms: Class[] = await classRepository
        .findWithDeleted({
          name: {
            $in: [
              'BATCH-2-August-MBA-ONLINE-2023-24',
              'BATCH-3-September-MBA-ONLINE-2023-24',
              'BATCH-4-OCTOBER-MBA-ONLINE-2023-24',
              'BATCH-1-August-MBA-ONLINE-2023-24'
            ]
          },
          university: '5ffda431be794b82dd8d1281'
        })
        .select('chapters galleries intro')
        .lean();

      let urls = [];

      const classroomWorks: ClassroomWork[] = await classroomWorkRepository
        .findWithDeleted({ classroom: { $in: classrooms.flatMap((o) => o._id) } })
        .lean();

      for (let classroomWork of classroomWorks) {
        if (classroomWork.document) urls.push(classroomWork.document);
        if (classroomWork.images) urls = urls.concat(classroomWork.images);
        if (classroomWork.video) urls.push(classroomWork.video);

        urls = urls.filter(Boolean);
        urls = [...new Set(urls)];
      }

      urls = urls.filter((url) => url.startsWith('https://s3.ap-south-1.amazonaws.com/'));

      let deletedUrl = 0;
      // const minIO: any// = new MinIO();
      //
      // for (let url of urls) {
      //     try {
      //         await minIO.delete(url);
      //     } catch (error) {
      //         console.error(`Could not delete ${url}`);
      //     } finally {
      //         deletedUrl++;
      //
      //     }
      // }

      await classroomWorkRepository.update({ _id: { $in: classroomWorks.flatMap((o) => o._id) } }, { $set: { deleted: true } });

      return res.status(400).send({ message: 'Sent' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
