import { applicantGroupRepository } from '@edorer/applicant-group-data';
import { assignmentRepository } from '@edorer/assignment-data';
import { CanExecuteScript } from '@edorer/script-data';
import { classRepository } from '@edorer/class-data';
import { courseRepository } from '@edorer/course-data';
import { Domain, domainRepository } from '@edorer/domain-data';
import { examRepository } from '@edorer/exam-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { programRepository } from '@edorer/program-data';
import { roleRepository } from '@edorer/role-data';
import { subDomainRepository } from '@edorer/sub-domain-data';
import { Types } from 'mongoose';
import { userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import { videoUploaderRepository } from '@edorer/video-uploader-data';

@JsonController()
export class ScriptDomainController {

    @Get('/scripts/add-subdomains-to-domain')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addSubDomains(@Req() req: any, @Res() res: any) {
        try {
            const subDomains = await subDomainRepository.find({ isMigrated: { $exists: true } }).select('_id').lean();
            const subDomainIds = subDomains.map(subDomain => subDomain._id);

            await domainRepository.update(
                { _id: Types.ObjectId('628d010378d06cb414d7c83d') },
                { $set: { subDomains: subDomainIds } },
                { multi: false }
            );

            console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

            return res.status(200).send({ message: 'Request sent to export exams' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Get('/scripts/replace-domain-names')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async replaceDomains(@Req() req: any, @Res() res: any) {
        try {
            const newDomain = '609fa636b594203e173ac7ab';
            const oldDomains = ['63ac3b923f05a6eb316741fd'];

            await applicantGroupRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
            await assignmentRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
            await classRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
            await courseRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
            await examRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
            await programRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
            await subDomainRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
            await videoUploaderRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });

            await roleRepository.update(
                { 'domains.exceptions': { $in: oldDomains } },
                { $addToSet: { 'domains.exceptions': newDomain } },
                { multi: true }
            ).lean();

            await roleRepository.update(
                { 'domains.selected': { $in: oldDomains } },
                { $addToSet: { 'domains.selected': newDomain } },
                { multi: true }
            ).lean();

            await userRepository.update(
                { domains: { $in: oldDomains } },
                { $addToSet: { domains: newDomain } },
                { multi: true }
            );

            await domainRepository.update({ _id: { $in: oldDomains } }, { deleted: true }, { multi: true });

            console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

            return res.status(200).send({ message: 'Request sent to export exams' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Get('/scripts/remove-duplicate-domains/:university([0-9a-f]{24})')
    @Validate([
        {
            field: 'university',
            validation: [{ value: 'notEmpty', message: 'University ID is required' }]
        }
    ])
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async removeDuplicateDomains(@Req() req: any, @Res() res: any, @Param('university') university: string) {
        try {
            const uniqueDomains = await domainRepository.distinct('name', { university });
            for (let name of uniqueDomains) {
                const domains: Domain[] = await domainRepository.find({ name, university }).lean();

                if (domains.length > 0) {
                    const newDomain = domains[0]._id;
                    const oldDomains = domains.slice(1).map(entry => entry._id);

                    console.warn(newDomain, oldDomains);

                    if (oldDomains.length > 0) {
                        await applicantGroupRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
                        await assignmentRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
                        await classRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
                        await courseRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
                        await examRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
                        await programRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
                        await subDomainRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });
                        await videoUploaderRepository.update({ domain: { $in: oldDomains } }, { domain: newDomain }, { multi: true });

                        await roleRepository.update(
                            { 'domains.exceptions': { $in: oldDomains } },
                            { $addToSet: { 'domains.exceptions': newDomain } },
                            { multi: true }
                        ).lean();

                        await roleRepository.update(
                            { 'domains.selected': { $in: oldDomains } },
                            { $addToSet: { 'domains.selected': newDomain } },
                            { multi: true }
                        ).lean();

                        await userRepository.update(
                            { domains: { $in: oldDomains } },
                            { $addToSet: { domains: newDomain } },
                            { multi: true }
                        );

                        await domainRepository.update({ _id: { $in: oldDomains } }, { deleted: true }, { multi: true });
                    }
                }
            }

            console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

            return res.status(200).send({ message: 'Request sent to export exams' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }


}
