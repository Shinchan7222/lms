import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { Get, JsonController, Post, QueryParam, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { CourseUploaderService } from '../services/course-uploader/CourseUploaderService';
import { VideoUploaderService } from '../services/course-uploader/VideoUploaderService';
import { CourseCreator } from '../services/course-uploader/CourseCreator';
import { VideoTextConverterService } from '../services/VideoTextConverterService';
import { AssignmentGeneratorService } from '../services/AssignmentGeneratorService';
import { QuestionGeneratorService } from '../services/QuestionGeneratorService';
import { VideoToUploadExcelParser } from '../services/course-uploader/VideoToUploadExcelParser';
import { videoToUploadCron } from '../services/course-uploader/VideoToUploadCron';
import { courseRepository } from '@edorer/course-data';
import { CourseChecker } from '../services/course-uploader/CourseChecker';
import { DuplicateRemover } from '../services/course-uploader/DuplicateRemover';
import { SimpleVideoUploadService } from '../services/course-uploader/SimpleVideoUploadService';
import { SyllabusUploadService } from '../services/course-uploader/SyllabusUploadService';
import { CourseStructureReorganizerService } from '../services/course-uploader/CourseStructureReorganizerService';
import { CourseStructureFixerService } from '../services/course-uploader/CourseStructureFixerService';
import { VideoRetryService } from '../services/course-uploader/VideoRetryService';
import { CourseLectureUpdater } from '../services/course-uploader/CourseLectureUpdater';
import { CourseDetailsSyncerService } from '../services/course-uploader/CourseDetailsSyncerService';
import { DuplicateChapterCheckerService } from '../services/course-uploader/DuplicateChapterCheckerService';
import { DuplicateChapterMergerService } from '../services/course-uploader/DuplicateChapterMergerService';
import { DuplicateLectureCheckerService } from '../services/course-uploader/DuplicateLectureCheckerService';
import { DuplicateLectureRemoverService } from '../services/course-uploader/DuplicateLectureRemoverService';
import { LectureReorderingService } from '../services/course-uploader/LectureReorderingService';
import { OrphanLectureMergerService } from '../services/course-uploader/OrphanLectureMergerService';
import { lectureRepository } from '@edorer/lecture-data';
import { chapterRepository } from '@edorer/chapter-data';
import { CourseConsistencyCheckerService } from '../services/course-uploader/CourseConsistencyCheckerService';
import { EmptyLectureDetectionService } from '../services/course-uploader/EmptyLectureDetectionService';



import { videoToUploadRepository } from '@edorer/script-data';
import { Types } from 'mongoose';
import { videoTempRepository } from '@edorer/video-uploader-data';

@JsonController()
export class CourseUploadScriptController {

  @Post('/scripts/course-upload/upload-excel')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async uploadExcel(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const courseUploaderService = new CourseUploaderService(file, req.university._id);
      const result = await courseUploaderService.process();

      return res.status(200).send({
        message: 'Excel file processed successfully',
        success: result.success,
        errors: result.errors,
        totalProcessed: result.success + result.errors.length
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }



  @Post('/scripts/lectures/count-drive-videos')
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async countDriveVideos(@Req() req: any, @Res() res: any) {
    try {
      const universityId = "6926b7a2687c78188b6036ea";
      const count = await lectureRepository.count({
        'pages.0.video': { $regex: /drive/i }
      });

      return res.status(200).send({
        message: 'Counted lectures with drive videos',
        count
      });
    } catch (error: any) {
      console.error(error);
      return res.status(500).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/fix-drive-videos')
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async fixDriveVideos(@Req() req: any, @Res() res: any) {
    try {
      const universityId = "6926b7a2687c78188b6036ea";

      // Find lectures with drive videos in first page
      const lectures = await lectureRepository.find({
        // university: universityId,
        'pages.0.video': { $regex: /drive/i }
      }).lean();

      if (!lectures || lectures.length === 0) {
        return res.status(200).send({
          message: 'No lectures found with drive videos',
          updatedCount: 0
        });
      }

      console.log(`Found ${lectures.length} lectures with drive videos`);

      let updatedCount = 0;
      let notFoundCount = 0;
      const notFoundTitles: string[] = [];

      for (const lecture of lectures) {
        // Clean title: Remove "Unit {i} " prefix
        // Regex looks for "Unit " followed by digits and a space/dash/colon or just space at start
        let cleanTitle = lecture.title.trim();
        // Common pattern "Unit 1 - Title" or "Unit 1: Title" or "Unit 1 Title"
        cleanTitle = cleanTitle.replace(/^Unit\s+\d+\s*[:\-\s]\s*/i, '');

        // Search in VideoToUpload
        const videoRecord = await videoTempRepository.findOne({
          // university: universityId, // Assuming we search in same university matches
          topicName: { $regex: new RegExp(`^${cleanTitle}$`, 'i') }, // Exact match case insensitive
          university: universityId
        }).sort({ createdAt: -1 }).lean();

        if (videoRecord && videoRecord.url && videoRecord.url.length > 0) {
          const newVideoUrl = videoRecord.url;

          await lectureRepository.update(
            { _id: lecture._id },
            {
              $set: {
                'pages.0.video': newVideoUrl,
                'pages.0.assetUrl': newVideoUrl
              }
            }
          );
          updatedCount++;
        } else {
          notFoundCount++;
          notFoundTitles.push(`${lecture.title} -> ${cleanTitle}`);
        }
      }

      return res.status(200).send({
        message: 'Finished fixing drive videos',
        totalFound: lectures.length,
        updatedCount,
        notFoundCount,
        notFoundTitles: notFoundTitles.slice(0, 50) // Limit output
      });

    } catch (error: any) {
      console.error(error);
      return res.status(500).send({ error: error.message });
    }
  }


  @Post('/scripts/video-upload/upload-excel')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async uploadVideoExcel(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const parser = new VideoToUploadExcelParser(file, req.university._id);
      const result = await parser.parseAndStore();

      return res.status(200).send({
        message: 'Excel file processed and stored successfully',
        success: result.success,
        duplicates: result.duplicates,
        errors: result.errors,
        totalProcessed: result.success + result.errors.length + result.duplicates
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/video-to-upload/duplicate-mba')
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async duplicateMBAVideos(@Req() req: any, @Res() res: any) {
    try {


      const videos = await videoToUploadRepository.find({
        university: "6926b7a2687c78188b6036ea",
        programName: 'MBA',
        status: 'done'
      }).lean();

      if (!videos || videos.length === 0) {
        return res.status(404).send({ message: 'No videos found to duplicate' });
      }

      console.log(`Found ${videos.length} videos to duplicate`);

      const newVideos = videos.map((video: any) => {
        const { _id, createdAt, updatedAt, ...rest } = video;
        return {
          ...rest,
          university: "696d1c678d9bc887a4d21407",
          status: 'done' // Keep status as done as requested
        };
      });

      await videoToUploadRepository.insertMany(newVideos);

      return res.status(200).send({
        message: 'Videos duplicated successfully',
        count: newVideos.length
      });
    } catch (error: any) {
      console.error(error);
      return res.status(500).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/reset-error-drive-videos')
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async resetErrorDriveVideos(@Req() req: any, @Res() res: any) {
    try {
      const universityId = "6926b7a2687c78188b6036ea";

      // Find lectures with drive videos in first page
      const lectures = await lectureRepository.find({
        // university: universityId, 
        'pages.0.video': { $regex: /drive/i }
      }).lean();

      if (!lectures || lectures.length === 0) {
        return res.status(200).send({
          message: 'No lectures found with drive videos',
          updatedCount: 0
        });
      }

      console.log(`Found ${lectures.length} lectures with drive videos`);

      let updatedCount = 0;
      let notFoundCount = 0;

      for (const lecture of lectures) {
        // Clean title: Remove "Unit {i} " prefix
        let cleanTitle = lecture.title.trim();
        cleanTitle = cleanTitle.replace(/^Unit\s+\d+\s*[:\-\s]\s*/i, '');

        // Search in VideoToUpload for ERROR status
        const videoRecord = await videoToUploadRepository.findOne({
          topicName: { $regex: new RegExp(`^${cleanTitle}$`, 'i') },
          // university: universityId,
          status: 'error'
        }).lean();

        if (videoRecord) {
          // Reset to pending
          await videoToUploadRepository.update(
            { _id: videoRecord._id },
            {
              $set: {
                status: 'pending',
                errorMessage: null // Clear error message
              }
            }
          );
          updatedCount++;
        } else {
          notFoundCount++;
        }
      }

      return res.status(200).send({
        message: 'Finished resetting error video uploads',
        totalFound: lectures.length,
        updatedCount,
        notFoundCount
      });

    } catch (error: any) {
      console.error(error);
      return res.status(500).send({ error: error.message });
    }
  }

  @Post('/scripts/course-structure/duplicate-mba-courses')
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async duplicateMBACourses(@Req() req: any, @Res() res: any) {
    try {
      const sourceUniversityId = "6926b7a2687c78188b6036ea";
      const targetUniversityId = "696d1c678d9bc887a4d21407";

      // 1. Find all MBA courses in source university
      const courses = await courseRepository.find({
        university: sourceUniversityId,
        title: { $regex: /MBA/i },
        deleted: false
      }).lean();

      if (!courses || courses.length === 0) {
        return res.status(404).send({ message: 'No MBA courses found in source university' });
      }

      console.log(`Found ${courses.length} MBA courses to duplicate`);

      let duplicatedCount = 0;

      // 2. Iterate and duplicate
      for (const course of courses) {
        // Deep copy course (excluding _id, createdAt, updatedAt)
        const { _id: sourceCourseId, title, createdAt, updatedAt, chapters: sourceChapters, ...courseRest } = course;

        console.log(`Duplicating Course: ${title}`);

        const newCourseObj = {
          ...courseRest,
          title: title, // Keep same title
          university: new Types.ObjectId(targetUniversityId),
          chapters: [], // Will populate with new chapters
          students: [], // Reset students
          classStudents: [], // Reset class students
          reviews: {}, // Reset reviews
          createdAt: new Date(),
          updatedAt: new Date()
        };

        const newCourseFn = await courseRepository.create(newCourseObj);
        const newCourse = newCourseFn.toObject();

        // 3. Duplicate Chapters
        if (sourceChapters && sourceChapters.length > 0) {
          // We need to fetch chapters because the course object usually only has IDs in the array if not populated, 
          // but generic find might not populate. safer to fetch.
          // However, if the `courses` above are from .lean(), fields are populated only if .populate() was not called? 
          // Usually `chapters` is an array of ObjectIds in the schema.

          const newChapterIds: any[] = [];

          for (const chapterId of sourceChapters) {
            const chapter = await chapterRepository.findOne({ _id: chapterId }).lean();
            if (!chapter) continue;

            const { _id: sourceChapterId, lectures: sourceLectures, createdAt: cCreatedAt, updatedAt: cUpdatedAt, ...chapterRest } = chapter;

            const newChapterObj = {
              ...chapterRest,
              university: new Types.ObjectId(targetUniversityId),
              course: newCourse._id,
              lectures: [], // Will populate with new lectures
              createdAt: new Date(),
              updatedAt: new Date()
            };

            const newChapterFn = await chapterRepository.create(newChapterObj);
            const newChapter = newChapterFn.toObject();

            // 4. Duplicate Lectures
            const newLectureIds: any[] = [];
            if (sourceLectures && sourceLectures.length > 0) {
              for (const lectureId of sourceLectures) {
                // Need lectureRepository here. Assuming it's imported or I need to import it.
                // Since I can't import in this block easily without top-level, I'll assume I'll add the import in a separate call 
                // or I can try to dynamic import? No, that's messy in TS usually.
                // I'll use `lectureRepository` and if it fails I'll fix imports.
                const lecture = await lectureRepository.findOne({ _id: lectureId }).lean();
                if (!lecture) continue;

                const { _id: sourceLectureId, pages, createdAt: lCreatedAt, updatedAt: lUpdatedAt, ...lectureRest } = lecture;

                const newLectureObj = {
                  ...lectureRest,
                  university: new Types.ObjectId(targetUniversityId),
                  course: newCourse._id,
                  pages: [], // Explicitly empty pages as requested
                  createdAt: new Date(),
                  updatedAt: new Date()
                };

                const newLectureFn = await lectureRepository.create(newLectureObj);
                const newLecture = newLectureFn.toObject();
                newLectureIds.push(newLecture._id);
              }
            }

            // Update new chapter with new lectures
            await chapterRepository.update({ _id: newChapter._id }, { lectures: newLectureIds });
            newChapterIds.push(newChapter._id);
          }

          // Update new course with new chapters
          await courseRepository.update({ _id: newCourse._id }, { chapters: newChapterIds });
        }

        duplicatedCount++;
      }

      return res.status(200).send({
        message: 'MBA Courses structure duplicated successfully',
        count: duplicatedCount
      });

    } catch (error: any) {
      console.error('Error duplicating MBA courses:', error);
      return res.status(500).send({ error: error.message });
    }
  }

  @Post('/scripts/video-upload/simple-upload-excel')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async uploadSimpleVideoExcel(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new SimpleVideoUploadService(file, req.university._id);
      const result = await service.process();

      return res.status(200).send({
        message: 'Simple video upload processed successfully',
        success: result.success,
        duplicates: result.duplicates,
        errors: result.errors,
        totalProcessed: result.success + result.errors.length + result.duplicates
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-upload/upload-syllabus')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async uploadSyllabus(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'File is required' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new SyllabusUploadService(file, req.university._id);
      const result = await service.process();

      if (result.success) {
        return res.status(200).send({
          message: 'Syllabus uploaded successfully',
          url: result.url
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to upload syllabus'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-upload/rename-syllabus')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async renameSyllabus(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new SyllabusUploadService(null, req.university._id);
      const result = await service.renameLectures();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully renamed ${result.count} lecture(s) to 'Course Criteria'`,
          count: result.count
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to rename lectures'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-upload/remove-syllabus')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async removeSyllabus(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new SyllabusUploadService(null, req.university._id);
      const result = await service.removeSyllabusChapters();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully removed ${result.count} Syllabus chapter(s)`,
          count: result.count
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to remove Syllabus chapters'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-upload/remove-duplicate-syllabus')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async removeDuplicateSyllabus(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new SyllabusUploadService(null, req.university._id);
      const result = await service.removeDuplicateLectures();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully removed ${result.count} duplicate Course Criteria lecture(s)`,
          count: result.count
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to remove duplicate lectures'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-upload/reorder-syllabus')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async reorderSyllabus(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new SyllabusUploadService(null, req.university._id);
      const result = await service.reorderSyllabusChapters();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully reordered ${result.count} courses`,
          count: result.count
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to reorder Syllabus chapters'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-structure/organize-chapters')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async organizeChapters(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new CourseStructureReorganizerService(req.university._id);
      const result: any = await service.organizeChapters();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully organized ${result.count} course(s)`,
          count: result.count,
          changes: result.changes
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to organize course chapters'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/video-upload/reset-stale-tasks')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async resetStaleTasks(@Req() req: any, @Res() res: any) {
    try {
      const count = await videoToUploadCron.resetStaleTasks();

      return res.status(200).send({
        message: `Reset ${count} stale task(s) back to pending`,
        count
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/video-upload/init')
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async init(@Req() req: any, @Res() res: any) {
    try {
      for (let i = 0; i < 10; i++) {
        await videoToUploadCron.init();
        await new Promise(resolve => setTimeout(resolve, 5000));
      }

      return res.status(200).send({
        message: `Reset stale task(s) back to pending`
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/video-upload/refresh-token')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async refreshGoogleDriveToken(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      // Create a dummy service instance to access the refresh method
      // We need to pass a dummy file, but it won't be used
      const dummyFile = { buffer: Buffer.from('') };
      const videoUploaderService = new VideoUploaderService(dummyFile, req.university._id, 1);

      const newToken = await videoUploaderService.refreshGoogleDriveToken();

      return res.status(200).send({
        message: 'Token refreshed successfully',
        token: {
          access_token: newToken.access_token,
          expiry_date: newToken.expiry_date,
          token_type: newToken.token_type
        }
      });
    } catch (error: any) {
      console.error('Error refreshing token:', error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-creator/create-course')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async createCourse(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any, @QueryParam('tab') tabName: string) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!tabName) {
        return res.status(400).send({ error: 'Tab name is required (e.g., BCA)' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const courseCreator = new CourseCreator(
        file,
        req.university._id,
        tabName
      );

      const result = await courseCreator.process();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully created ${result.courseIds.length} course(s)`,
          courseIds: result.courseIds,
          errors: result.errors
        });
      } else {
        return res.status(400).send({
          error: 'Failed to create courses',
          courseIds: result.courseIds,
          errors: result.errors
        });
      }
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-creator/check-course')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async checkCourse(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any, @QueryParam('tab') tabName: string) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!tabName) {
        return res.status(400).send({ error: 'Tab name is required (e.g., BCA)' });
      }

      const courseChecker = new CourseChecker(file, tabName);
      const result = await courseChecker.process();

      console.log('================================================')
      console.log(JSON.stringify(result, null, 2));


      return res.status(200).send({
        message: `Checked ${result.totalCourses} course(s) with ${result.totalTopics} total topic(s)`,
        ...result
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-creator/remove-duplicates')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async removeDuplicates(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any, @QueryParam('tab') tabName: string) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!tabName) {
        return res.status(400).send({ error: 'Tab name is required (e.g., BCA)' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const duplicateRemover = new DuplicateRemover(file, req.university._id, tabName);
      const result = await duplicateRemover.process();

      console.log('================================================');
      console.log('Duplicate Removal Results:');
      console.log(JSON.stringify(result, null, 2));

      return res.status(200).send({
        message: `Processed ${result.totalCoursesProcessed} course(s), removed ${result.totalLecturesRemoved} duplicate lecture(s) from ${result.totalChaptersProcessed} chapter(s)`,
        ...result
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/video-text/convert')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async convertVideoText(@Req() req: any, @Res() res: any) {
    try {
      const universityId = '6926b7a2687c78188b6036ea';

      const courses = await courseRepository
        .find({
          title: { $regex: /^BBA - / },
          university: universityId,
          deleted: false
        })
        .select('_id title')
        .lean();

      if (courses.length === 0) {
        return res.status(200).send({
          message: 'No courses found matching criteria',
          success: 0,
          errors: 0,
          totalProcessed: 0,
          results: []
        });
      }

      // Process courses in batches of 7 in parallel
      const batchSize = 7;
      const allResults: any[] = [];
      let totalSuccess = 0;
      let totalErrors = 0;

      for (let i = 0; i < courses.length; i += batchSize) {
        const batch = courses.slice(i, i + batchSize);

        // Process batch in parallel
        const batchPromises = batch.map(async (course) => {
          try {
            const videoTextConverterService = new VideoTextConverterService(course._id.toString());
            const result = await videoTextConverterService.process();
            return {
              courseId: course._id.toString(),
              courseTitle: course.title,
              ...result
            };
          } catch (error: any) {
            console.error(`Error processing course ${course._id}:`, error);
            return {
              courseId: course._id.toString(),
              courseTitle: course.title,
              success: 0,
              errors: 0,
              results: [],
              error: error.message || 'Failed to process course'
            };
          }
        });

        const batchResults = await Promise.all(batchPromises);

        // Aggregate results
        batchResults.forEach((result: any) => {
          allResults.push(result);
          totalSuccess += result.success || 0;
          totalErrors += result.errors || 0;
        });
      }

      return res.status(200).send({
        message: `Video text conversion processed for ${courses.length} course(s)`,
        success: totalSuccess,
        errors: totalErrors,
        totalProcessed: totalSuccess + totalErrors,
        coursesProcessed: courses.length,
        results: allResults
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/assignments/generate')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async generateAssignments(@Req() req: any, @Res() res: any) {
    try {
      const universityId = '696d1c678d9bc887a4d21407';
      const courses = await courseRepository
        .find({
          university: universityId,
          deleted: false
        })
        .select('_id title')
        .lean();

      if (courses.length === 0) {
        return res.status(200).send({
          message: 'No courses found matching criteria',
          success: 0,
          errors: 0,
          totalProcessed: 0,
          results: []
        });
      }

      // Process courses one by one
      const allResults: any[] = [];
      let totalSuccess = 0;
      let totalErrors = 0;

      for (const course of courses) {
        try {
          const assignmentGeneratorService = new AssignmentGeneratorService(course._id.toString());
          const result = await assignmentGeneratorService.process();

          allResults.push({
            courseId: course._id.toString(),
            courseTitle: course.title,
            success: result.success,
            errors: result.errors,
            results: result.results
          });

          totalSuccess += result.success || 0;
          totalErrors += result.errors || 0;
        } catch (error: any) {
          console.error(`Error processing course ${course._id}:`, error);
          allResults.push({
            courseId: course._id.toString(),
            courseTitle: course.title,
            success: 0,
            errors: 0,
            results: [],
            error: error.message || 'Failed to process course'
          });
          totalErrors += 1;
        }
      }

      return res.status(200).send({
        message: `Assignment generation processed for ${courses.length} course(s)`,
        success: totalSuccess,
        errors: totalErrors,
        totalProcessed: totalSuccess + totalErrors,
        coursesProcessed: courses.length,
        results: allResults
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/questions/generate')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async generateQuestions(@Req() req: any, @Res() res: any) {
    try {
      const universityId = '696d1c678d9bc887a4d21407';

      const courses = await courseRepository
        .find({
          university: universityId,
          deleted: false
        })
        .select('_id title')
        .lean();

      if (courses.length === 0) {
        return res.status(200).send({
          message: 'No courses found matching criteria',
          success: 0,
          errors: 0,
          totalProcessed: 0,
          results: []
        });
      }

      // Process courses one by one
      const allResults: any[] = [];
      let totalSuccess = 0;
      let totalErrors = 0;

      for (const course of courses) {
        try {
          const questionGeneratorService = new QuestionGeneratorService(course._id.toString());
          const result = await questionGeneratorService.process();

          allResults.push({
            courseId: course._id.toString(),
            courseTitle: course.title,
            success: result.success,
            errors: result.errors,
            results: result.results
          });

          totalSuccess += result.success || 0;
          totalErrors += result.errors || 0;
        } catch (error: any) {
          console.error(`Error processing course ${course._id}:`, error);
          allResults.push({
            courseId: course._id.toString(),
            courseTitle: course.title,
            success: 0,
            errors: 0,
            results: [],
            error: error.message || 'Failed to process course'
          });
          totalErrors += 1;
        }
      }

      return res.status(200).send({
        message: `Question generation processed for ${courses.length} course(s)`,
        success: totalSuccess,
        errors: totalErrors,
        totalProcessed: totalSuccess + totalErrors,
        coursesProcessed: courses.length,
        results: allResults
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-structure/reorganize')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async reorganizeCourseStructure(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new CourseStructureReorganizerService(req.university._id);
      const result: any = await service.process();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully reorganized ${result.count} course(s)`,
          count: result.count,
          changes: result.changes
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to reorganize course structure'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-structure/fix-units')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async fixCourseUnits(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new CourseStructureFixerService(req.university._id);
      const result = await service.process();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully fixed unit indexing for ${result.count} course(s)`,
          count: result.count,
          changes: result.changes
        });
      } else {
        return res.status(400).send({
          error: result.error || 'Failed to fix unit indexing'
        });
      }

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
  @Post('/scripts/video-upload/retry-fast-completions')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async retryFastCompletions(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new VideoRetryService();
      const result = await service.retryFastCompletions();

      return res.status(200).send({
        message: `Processed ${result.processed} task(s), updated ${result.updated} task(s)`,
        ...result
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-creator/update-lectures')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async updateCourseLectures(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const updater = new CourseLectureUpdater(
        file,
        req.university._id
      );

      const result = await updater.process();

      if (result.success) {
        return res.status(200).send({
          message: `Successfully updated lectures for ${result.courseIds.length} course(s)`,
          courseIds: result.courseIds,
          errors: result.errors
        });
      } else {
        return res.status(400).send({
          error: 'Failed to update course lectures',
          courseIds: result.courseIds,
          errors: result.errors
        });
      }
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-details/sync-syllabus')
  // @UseBefore(CanExecuteScript)
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async syncSyllabus(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new CourseDetailsSyncerService(req.university._id);
      const result = await service.process();

      return res.status(200).send({
        message: 'Syllabus sync process completed',
        ...result
      });

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/course/duplicates')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async getDuplicateChapters(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new DuplicateChapterCheckerService(req.university._id);
      const result = await service.process();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course/merge-duplicates')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async mergeDuplicateChapters(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new DuplicateChapterMergerService(req.university._id);
      const result = await service.process();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/lecture/duplicates')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async getDuplicateLectures(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new DuplicateLectureCheckerService(req.university._id);
      const result = await service.process();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      console.log(result);
      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/lecture/remove-duplicates')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async removeDuplicateLectures(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new DuplicateLectureRemoverService(req.university._id);
      const result = await service.process();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/lecture/reorder-check')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async checkLectureOrder(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new LectureReorderingService(req.university._id);
      const result = await service.check();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/lecture/reorder')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async reorderLectures(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new LectureReorderingService(req.university._id);
      const result = await service.process();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/lecture/orphan-check')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async checkOrphans(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new OrphanLectureMergerService(req.university._id);
      const result = await service.check();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/lecture/merge-orphans')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async mergeOrphans(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new OrphanLectureMergerService(req.university._id);
      const result = await service.process();

      if (result.error) {
        return res.status(400).send({ error: result.error });
      }

      return res.status(200).send(result);

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-upload/verify-consistency')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async verifyConsistency(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new CourseConsistencyCheckerService(file, req.university._id);
      const result = await service.verify();

      return res.status(200).send({
        message: 'Consistency verification complete',
        success: result.success,
        results: result.results
      });

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/course-upload/process-consistency')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async processConsistency(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      if (!file) {
        return res.status(400).send({ error: 'Excel file is required' });
      }

      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new CourseConsistencyCheckerService(file, req.university._id);
      const result = await service.process();

      return res.status(200).send({
        message: 'Consistency processing complete',
        success: result.success,
        results: result.results
      });

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/check-empty-pages')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async checkEmptyPages(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new EmptyLectureDetectionService(req.university._id);
      const result = await service.checkEmptyPages();

      return res.status(200).send({
        message: 'Empty pages check complete',
        success: result.success,
        results: result.results
      });

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/check-no-content')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async checkNoContent(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new EmptyLectureDetectionService(req.university._id);
      const result = await service.checkNoContent();

      return res.status(200).send({
        message: 'No content check complete',
        success: result.success,
        results: result.results
      });

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/check-and-fix-empty-lectures')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async checkAndFixEmptyLectures(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      const service = new EmptyLectureDetectionService(req.university._id);
      const result = await service.checkAndFixEmptyLectures();

      return res.status(200).send({
        message: 'Empty lectures auto-fix check complete',
        success: result.success,
        results: result.results
      });

    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/check-mewar-videos')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async checkMewarVideos(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      // First, get all courses for this university
      const courses = await courseRepository.find({
        university: req.university._id,
        deleted: false
      }).lean();

      if (!courses || courses.length === 0) {
        return res.status(200).send({
          message: 'No courses found for this university',
          totalCount: 0,
          courses: []
        });
      }

      const courseIds = courses.map(c => c._id);

      // Find all lectures with mewaruniversity videos for these courses
      const lectures = await lectureRepository.find({
        course: { $in: courseIds },
        'pages.0.video': { $regex: /.*mewaruniversity.*/i }
      }).populate('course').lean();

      if (!lectures || lectures.length === 0) {
        return res.status(200).send({
          message: 'No lectures found with mewaruniversity videos',
          totalCount: 0,
          courses: []
        });
      }

      // Group by course
      const courseMap = new Map<string, { courseId: string; courseTitle: string; lectureCount: number }>();

      for (const lecture of lectures) {
        const course = lecture.course as any;
        if (course && course._id) {
          const courseId = course._id.toString();
          if (courseMap.has(courseId)) {
            courseMap.get(courseId)!.lectureCount++;
          } else {
            courseMap.set(courseId, {
              courseId: courseId,
              courseTitle: course.title || 'Unknown',
              lectureCount: 1
            });
          }
        }
      }

      const coursesWithVideos = Array.from(courseMap.values());

      return res.status(200).send({
        message: 'Found lectures with mewaruniversity videos',
        totalCount: lectures.length,
        courseCount: coursesWithVideos.length,
        courses: coursesWithVideos
      });

    } catch (error: any) {
      console.error(error);
      return res.status(500).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/verify-mewar-videos')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async verifyMewarVideos(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      // First, get all courses for this university
      const courses = await courseRepository.find({
        university: req.university._id,
        deleted: false
      }).lean();

      if (!courses || courses.length === 0) {
        return res.status(200).send({
          message: 'No courses found for this university',
          totalCount: 0,
          lectures: []
        });
      }

      const courseIds = courses.map(c => c._id);

      // Find all lectures with mewaruniversity videos for these courses
      const lectures = await lectureRepository.find({
        course: { $in: courseIds },
        'pages.0.video': { $regex: /.*mewaruniversity.*/i }
      }).populate('course').lean();

      if (!lectures || lectures.length === 0) {
        return res.status(200).send({
          message: 'No lectures found with mewaruniversity videos',
          totalCount: 0,
          lectures: []
        });
      }

      // Build detailed list
      const lectureDetails = lectures.map((lecture: any) => {
        const course = lecture.course as any;
        return {
          lectureId: lecture._id.toString(),
          lectureTitle: lecture.title || 'Unknown',
          courseId: course?._id?.toString() || 'Unknown',
          courseTitle: course?.title || 'Unknown',
          videoUrl: lecture.pages?.[0]?.video || '',
          assetUrl: lecture.pages?.[0]?.assetUrl || ''
        };
      });

      // Get sample video URLs (first 10)
      const sampleUrls = lectureDetails.slice(0, 10).map(l => l.videoUrl);

      return res.status(200).send({
        message: 'Verification complete',
        totalCount: lectures.length,
        sampleVideoUrls: sampleUrls,
        lectures: lectureDetails
      });

    } catch (error: any) {
      console.error(error);
      return res.status(500).send({ error: error.message });
    }
  }

  @Post('/scripts/lectures/remove-mewar-videos')
  @UseBefore(GetUniversity)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async removeMewarVideos(@Req() req: any, @Res() res: any) {
    try {
      if (!req.university || !req.university._id) {
        return res.status(400).send({ error: 'University not found' });
      }

      // First, get all courses for this university
      const courses = await courseRepository.find({
        university: req.university._id,
        deleted: false
      }).lean();

      if (!courses || courses.length === 0) {
        return res.status(200).send({
          message: 'No courses found for this university',
          removedCount: 0,
          lectureIds: []
        });
      }

      const courseIds = courses.map(c => c._id);

      // Find all lectures with mewaruniversity videos for these courses
      const lectures = await lectureRepository.find({
        course: { $in: courseIds },
        'pages.0.video': { $regex: /.*mewaruniversity.*/i }
      }).lean();

      if (!lectures || lectures.length === 0) {
        return res.status(200).send({
          message: 'No lectures found with mewaruniversity videos',
          removedCount: 0,
          lectureIds: []
        });
      }

      console.log(`Found ${lectures.length} lectures with mewaruniversity videos to remove`);

      let removedCount = 0;
      const removedLectureIds: string[] = [];
      const errors: string[] = [];

      for (const lecture of lectures) {
        try {
          // Remove video and assetUrl from pages[0]
          await lectureRepository.update(
            { _id: lecture._id },
            {
              $set: {
                'pages.0.video': '',
                'pages.0.assetUrl': ''
              }
            }
          );
          removedCount++;
          removedLectureIds.push(lecture._id.toString());
        } catch (err: any) {
          errors.push(`Failed to update lecture ${lecture._id}: ${err.message}`);
        }
      }

      return res.status(200).send({
        message: 'Finished removing mewaruniversity videos',
        totalFound: lectures.length,
        removedCount: removedCount,
        lectureIds: removedLectureIds,
        errors: errors.length > 0 ? errors : undefined
      });

    } catch (error: any) {
      console.error(error);
      return res.status(500).send({ error: error.message });
    }
  }
}




