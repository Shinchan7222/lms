const cheerio = require('cheerio');
const excelToJson = require('convert-excel-to-json');
const mammoth = require('mammoth');
const nodeHtmlToImage = require('node-html-to-image');
import { CanExecuteScript } from '@edorer/script-data';
import { classRepository } from '@edorer/class-data';
import { Exam, examRepository } from '@edorer/exam-data';
import { examEnrollmentRepository } from '@edorer/exam-enrollment-data';
import { ExamPointCalculator } from '@edorer/exam-api';
import { ExportExamsForVec } from '../services/ExportExamsForVec';
import { FileUtils } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated, User, userRepository } from '@edorer/user-data';
import { Open } from 'unzipper';
import { PerformanceReportPDFGenerator } from '@edorer/exam-report-api';
import { Question, QuestionDifficulty } from '@edorer/question-data';
import { trackExamRepository } from '@edorer/track-exam-data';
import { Types } from 'mongoose';
import { Validate } from '@edorer/validator';
import { writeFileSync } from 'fs';
import moment = require('moment');

@JsonController()
export class ScriptExamController {
  @Post('/scripts/export-exams-by-ids')
  @Validate([
    {
      field: 'examIds',
      validation: [{ value: 'notEmpty', message: 'Exam IDs are required' }]
    },
    {
      field: 'owner',
      validation: [{ value: 'notEmpty', message: 'Owner is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async exportExamsByIds(@Req() req: any, @Res() res: any) {
    try {
      const { examIds, owner } = req.body;
      const path = process.env.TEMP_DIR + 'exams';

      await FileUtils.removeDirectory(path);
      FileUtils.createDirectory(path);

      const exams: Exam[] = await examRepository.find({ _id: { $in: examIds } }).lean();

      for (let index = 0; index < exams.length; index++) {
        const exam = exams[index];
        const exportExamsForVec = new ExportExamsForVec(exam, owner);
        const convertedExam: any = await exportExamsForVec.convert();

        writeFileSync(path + '/' + 'category-' + (index + 1) + '.json', JSON.stringify(convertedExam.categories));
        writeFileSync(path + '/' + 'groupQuestion-' + (index + 1) + '.json', JSON.stringify(convertedExam.groupQuestions));
        writeFileSync(path + '/' + 'question-' + (index + 1) + '.json', JSON.stringify(convertedExam.questions));

        delete convertedExam.categories;
        delete convertedExam.questions;
        writeFileSync(path + '/' + 'exam-' + (index + 1) + '.json', JSON.stringify(convertedExam));
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Request sent to export exams' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-exam-total-points/:universityId([0-9a-f]{24})')
  @Validate([
    {
      field: 'universityId',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTotalPoints(@Req() req: any, @Res() res: any, @Param('universityId') universityId: string) {
    try {
      const exams: Exam[] = await examRepository
        .find({ autoCalculatePoint: true, university: universityId })
        .populate({ path: 'questions', select: 'points' })
        .lean();

      for (let exam of exams) {
        const totalMarks = exam.questions.reduce((acc: number, question: Question) => acc + question.points.positive, 0);
        await examRepository.update({ _id: exam._id }, { $set: { totalMarks } }, { multi: false });
      }

      return res.status(200).send({ message: 'Request sent to export exams' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-exam-editors-and-owners')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixExamEditorsAndOwners(@Req() req: any, @Res() res: any, @UploadedFile('zipFile') zipFile: any) {
    res.connection.setTimeout(0);
    try {
      setTimeout(async () => {
        const rootDir = process.env.TEMP_DIR + 'parul';

        await FileUtils.removeDirectory(rootDir);
        FileUtils.createDirectory(rootDir);

        const directory = await Open.buffer(zipFile.buffer);
        const jsonFiles = directory.files.filter((filePath) => filePath.path.includes('.json'));
        for (let jsonFile of jsonFiles) {
          const fileName = jsonFile.path.split('/').pop();
          writeFileSync(rootDir + '/' + fileName, await jsonFile.buffer());
        }

        if (FileUtils.fileExists(rootDir + '/owners.json')) {
          const path = rootDir + '/owners.json';
          const items = await FileUtils.readLargeData(path);

          for (let item of items) {
            const { exams, owner } = item;
            await examRepository.update({ _id: { $in: exams } }, { $set: { owner } }, { multi: true });
          }
        }

        if (FileUtils.fileExists(rootDir + '/editors.json')) {
          const path = rootDir + '/editors.json';
          const items = await FileUtils.readLargeData(path);

          for (let item of items) {
            const { _id, editors } = item;
            await examRepository.update({ _id }, { $addToSet: { editors } }, { multi: false });
          }
        }

        await FileUtils.removeDirectory(rootDir);

        console.warn('===== ===== ===== ===== MIGRATED ===== ===== ===== =====');
      }, 1000);

      return res.status(201).send({ message: 'Requested to import' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/check-pdf-report')
  @Validate([
    {
      field: 'trackExamId',
      validation: [{ value: 'notEmpty', message: 'Track Exam ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(GetUniversity)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async checkPdfReport(@Req() req: any, @Res() res: any) {
    try {
      const { trackExamId } = req.body;

      const filePath = process.env.TEMP_DIR + trackExamId + '.pdf';
      await FileUtils.removeFile(filePath);
      await FileUtils.writeFile(filePath);

      const trackExam = await trackExamRepository
        .findOne({ _id: trackExamId })
        .populate({
          path: 'exam',
          select: 'completionMail title university',
          populate: 'university'
        })
        .populate({ path: 'user' })
        .populate({ path: 'questions' });

      const performanceReportPDFGenerator = new PerformanceReportPDFGenerator(trackExam, req.user.university);
      await performanceReportPDFGenerator.generate();

      console.warn('===== ===== ===== ===== GENERATED ===== ===== ===== =====');

      return res.status(201).send({ message: 'Requested to import' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/check-exams-availability-by-ids')
  @Validate([
    {
      field: 'examIds',
      validation: [{ value: 'notEmpty', message: 'Exam IDs are required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async checkExamAvailabilityByIds(@Req() req: any, @Res() res: any) {
    try {
      const { examIds } = req.body;
      const exams = await examRepository.find({ _id: { $in: examIds } }).lean();
      const foundExams = exams.map((exam) => exam._id.toString());

      const notFound = [];

      for (let examId of examIds) {
        if (foundExams.indexOf(examId) === -1) {
          notFound.push(examId);
        }
      }

      return res.status(200).send({ notFound });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-exam-points-by-university')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixExamPointsByUniversity(@Req() req: any, @Res() res: any) {
    try {
      const { university } = req.body;
      const exams = await examRepository
        .find({ autoCalculatePoint: true, fetch: { $exists: true }, totalMarks: 0, university })
        .populate({ path: 'questions', select: 'category difficulty' })
        .select('fetch questions')
        .lean();

      for (let exam of exams) {
        const categories = [];
        const questions = exam.questions;

        for (let question of questions) {
          if (categories.indexOf([question.category]) === -1) {
            categories.push(question.category);
          }
        }

        const fetch = {};
        for (let category of categories) {
          fetch[category] = {
            easy: questions.filter((q) => q.category === category && q.difficulty === QuestionDifficulty.EASY).length,
            hard: questions.filter((q) => q.category === category && q.difficulty === QuestionDifficulty.HARD).length,
            medium: questions.filter((q) => q.category === category && q.difficulty === QuestionDifficulty.MEDIUM).length
          };
        }

        const updatedExam = await examRepository.findOneAndUpdate(
          { _id: exam._id },
          { fetch },
          {
            multi: false,
            new: true
          }
        );

        const examPointCalculator = new ExamPointCalculator(updatedExam);
        const totalMarks = await examPointCalculator.calculate();

        await examRepository.update({ _id: exam._id }, { totalMarks }, { multi: false });
      }

      return res.status(200).send({ message: 'Points fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-exam-domains')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixExamDomains(@Req() req: any, @Res() res: any) {
    try {
      const exams = await examRepository.find({ domain: { $exists: true, $ne: null } }).lean();
      for (let exam of exams) {
        await examRepository.update({ _id: exam._id }, { $set: { domain: [exam.domain] } }, { multi: false });
      }

      return res.status(200).send({ message: 'Domains fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/add-exam-students-from-enrollments/:exam')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addStudentsFromEnrollments(@Req() req: any, @Res() res: any, @Param('exam') exam: string) {
    try {
      const students = await examEnrollmentRepository.distinct('students', { exam });

      await examRepository.update({ _id: exam }, { $addToSet: { students } }, { multi: true });

      return res.status(200).send({ message: 'Domains fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/add-exam-from-doc')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fromEnrollments(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      const result = await mammoth.convertToHtml({ buffer: file.buffer });
      result.value = result.value.replace(/Q\d\./g, '').replace(/Q\d/g, '');
      const paragraphs = [];
      const $ = cheerio.load(result.value);

      const examTitle = $('strong').eq(4).text();
      const duration = $('strong').eq(7).text();
      const questionSections = $('table tr');

      return res.status(200).send({ paragraphs });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/generate-certificates-from-excel')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async generateCertificates(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      const result = excelToJson({
        source: file.buffer,
        header: {
          rows: 1
        },
        columnToKey: {
          A: 'name',
          B: 'total',
          C: 'grade',
          D: 'certificateType',
          E: 'email'
        }
      });

      const students = result['Sheet1'];

      let serial = 2024110540;

      const outstanding =
        'https://s3.ap-southeast-1.amazonaws.com/parul-private-cloud-media/1fe0df1f-f337-4ed0-a748-855355795604-outstanding-certificate.jpg';
      const aPlus = 'https://s3.ap-southeast-1.amazonaws.com/parul-private-cloud-media/b1516765-1338-4de1-9405-0af1044d44d9-a-plus-certificate.jpg';

      for (let i = 0; i < students.length; i++) {
        const student = students[i];

        serial++;

        await nodeHtmlToImage({
          quality: 100,
          output: `${process.env.TEMP_DIR}certificates/${student.name}-${serial}.png`,
          html: `<html>
        			  <body style="width: 2000px; height: 1341px;">
        			 <div
          style="
            font-family: Arial, sans-serif;
            width: 2000px;
            height: 1341px;
            background-image: url('${student.grade.toLowerCase() === 'outstanding' ? outstanding : aPlus}');
            background-size: cover;
            position: relative;
            padding: 20px;
            box-sizing: border-box;
          "
        >
          <p style="padding-top: 50px; padding-right: 100px; text-align: right; font-size: 28px">${serial}</p>
          <p style="padding-top: 410px; text-align: center; font-size: 40px">${student.name}</p>
        			  </body>
        			</html>
        			`
        });
      }

      return res.status(200).send({ paragraphs: '' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-enrolled-students/:examId')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fix(@Req() req: any, @Res() res: any, @Param('examId') examId: string) {
    try {
      const students: string[] = await examEnrollmentRepository.distinct('students', { exam: examId, deleted: false });
      await examRepository.update({ _id: examId }, { $set: { students } });

      return res.status(200).send({ paragraphs: '' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/generate-certificates')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async generateCertificate(@Req() req: any, @Res() res: any) {
    try {
      let tracks = await trackExamRepository
        .find({
          exam: '66dfbc85859f490107f41d1d',
          certificate: { $exists: true },
          startedAt: { $gte: moment('2024-11-14 00:00:00').toDate() }
        })
        .lean();
      let queue = [];
      for (let track of tracks) {
        let promise = nodeHtmlToImage({
          quality: 100,
          output: `/tmp/certificates/${track._id}.png`,
          html: track.certificate,
          puppeteerArgs: {
            defaultViewport: {
              width: 2420,
              height: 1600
            }
          }
        });
        queue.push(promise);
        if (queue.length === 10) {
          await Promise.all(queue);
          queue = [];
        }
      }
      if (queue.length > 0) {
        await Promise.all(queue);
      }

      return res.status(200).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-class-students')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixClassStudents(@Req() req: any, @Res() res: any) {
    try {
      const exam: Exam = await examRepository.findOne({ _id: '67665d80c12a812c23ba761a' }).lean();
      const students = await examEnrollmentRepository.distinct('students', { exam: exam._id });

      const users = await userRepository
        .find({ _id: { $in: students } })
        .select('classes')
        .lean();

      const { classStudents = [] } = exam;

      const classesMap: Record<string, boolean> = [...new Set(classStudents.flatMap((classStudent) => classStudent.classes))].reduce((map, cls) => {
        map[cls] = true;
        return map;
      }, {} as Record<string, boolean>);

      console.log(classesMap);

      const studentClassesMap: Record<string, boolean> = {};
      for (let classStudent of classStudents) {
        studentClassesMap[classStudent.student] = true;
      }

      console.log(studentClassesMap);

      for (let user of users) {
        if (studentClassesMap[String(user._id)]) continue;

        const clsStd: Record<string, string> = {};

        for (let cls of user.classes) {
          if (classesMap[String(cls)]) {
            clsStd[String(cls)] = String(cls);
          }
        }

        if (Object.keys(clsStd).length === 0) {
          const userClass = await classRepository
            .findOne({ _id: { $in: user.classes }, domain: { $in: exam.domain } })
            .select('_id')
            .lean();

          if (userClass) {
            const p = { student: user._id, classes: [Types.ObjectId(userClass._id)] };

            await examRepository.update({ _id: exam._id }, { $push: { classStudents: [p] } });
          } else {
            continue;
          }
        } else {
          const p = { student: user._id, classes: Object.keys(clsStd).map((o) => Types.ObjectId(o)) };

          await examRepository.update({ _id: exam._id }, { $push: { classStudents: [p] } });
        }
      }

      return res.status(200).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
