import { CanExecuteScript } from '@edorer/script-data';
import { Class, classRepository } from '@edorer/class-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { User, userRepository, UserTypes } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptClassController {
  @Post('/scripts/attach-id-to-classes')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async attachIdToClasses(@Req() req: any, @Res() res: any) {
    const { university } = req.body;

    try {
      const classes: Class[] = await classRepository.find({ university, id: { $exists: false } }).lean();

      const latestClass = await classRepository
        .findOne({ id: { $exists: true } })
        .sort({ id: -1 })
        .lean();

      const bulkOperations = [];
      for (let index = 0; index < classes.length; index++) {
        const classItem = classes[index];

        bulkOperations.push({
          updateOne: {
            filter: { _id: classItem._id },
            update: { $set: { id: String(Number(latestClass.id || 0) + index + 1).padStart(6, '0') } }
          }
        });
      }

      await classRepository.bulkWrite(bulkOperations);

      return res.send({ message: 'done' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/remove-unwanted-classes/:university')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeUnwantedClasses(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const teachers: User[] = await userRepository.find({ type: UserTypes.TEACHER, university }).lean();

      for (let teacher of teachers) {
        if (!teacher.classes || !teacher.classes.length) continue;

        const classes: string[] = await classRepository.distinct('_id', {
          _id: { $in: teacher.classes },
          deleted: false,
          isHidden: false,
          university
        });
        await userRepository.update({ _id: teacher._id }, { $set: { classes } });
      }

      return res.status(400).send({ message: 'Updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/remove-class-all-students/:classId')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeClassStudents(@Req() req: any, @Res() res: any, @Param('classId') classId: string) {
    try {
      await userRepository.update({ classes: { $in: [classId] }, type: 'student' }, { $pull: { classes: { $in: [classId] } } }, { multi: true });
      await classRepository.update({ _id: classId }, { $set: { students: [] } });

      return res.status(400).send({ message: 'Updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
