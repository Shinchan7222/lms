import { CanExecuteScript } from '@edorer/script-data';
import { classRepository } from '@edorer/class-data';
import { DataUtils, FileUtils, Json2Excel } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { PaymentRequest, paymentRequestRepository } from '@edorer/payment-request-data';
import { PluginExecutor } from '@edorer/plugin-api';
import { readdirSync, readFileSync } from 'fs';
import { trackExamRepository } from '@edorer/track-exam-data';
import { Types } from 'mongoose';
import { UserDynamicData, userDynamicDataRepository } from '@edorer/user-dynamic-data';
import { UserTypes, userRepository, User } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import * as excelToJson from 'convert-excel-to-json';
import * as moment from 'moment';
import { S3University } from '@edorer/s3';
import { UniversityConfiguration, universityConfigurationRepository } from '@edorer/university-data';

@JsonController()
export class ScriptUserController {
  @Post('/scripts/remove-duplicate-users-same-day')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeDuplicateUsersSameDay(@Req() req: any, @Res() res: any) {
    try {
      const { university } = req.body;

      const duplicateGroups = await userRepository.aggregate([
        { $match: { university: Types.ObjectId(university) } },
        {
          $group: {
            _id: {
              email: '$email',
              type: '$type',
              day: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }
            },
            ids: { $push: '$_id' },
            count: { $sum: 1 }
          }
        },
        { $match: { count: { $gt: 1 } } }
      ]);

      let deletedCount = 0;
      const deletedGroups: Array<{ email: string; type: any; day: string; kept: any; deleted: any[] }> = [];

      for (const group of duplicateGroups) {
        const [keptId, ...duplicateIds] = group.ids;

        await userRepository.deleteMany({ _id: { $in: duplicateIds } });

        deletedCount += duplicateIds.length;
        deletedGroups.push({
          email: group._id.email,
          type: group._id.type,
          day: group._id.day,
          kept: keptId,
          deleted: duplicateIds
        });

        console.warn(`deleted ${duplicateIds.length} duplicate(s) for ${group._id.email} / ${group._id.day}`);
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ groups: duplicateGroups.length, deletedCount, deletedGroups });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/remove-duplicate-users-by-university')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeDuplicateUsers(@Req() req: any, @Res() res: any) {
    try {
      const { university } = req.body;

      const duplicateEmails = await FileUtils.readLargeData(process.env.TEMP_DIR + 'emails.json');

      for (let duplicateEmail of duplicateEmails) {
        const { email } = duplicateEmail;
        const [firstUser, ...restUsers] = await userRepository.find({ email, type: UserTypes.STUDENT }).select('_id').lean();
        const restUserIds = restUsers.map((restUser) => restUser._id);

        await userRepository.deleteMany({ _id: { $in: restUserIds }, type: UserTypes.STUDENT, university });
        await trackExamRepository.update({ user: { $in: restUserIds } }, { $set: { user: firstUser._id } }, { multi: true });

        console.warn('deleted ==>', email);
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ duplicateEmails });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/add-classes-to-students-by-university/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addClassesToUsers(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const students = JSON.parse(
        JSON.stringify([
          {
            Name: 'Patel Mallikakumari Bhikhubhai',
            Email: 'phd001@paruluniversity.ac.in',
            Phone: 9687219912,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd001'
          },
          {
            Name: 'Hazarani Soniya Kishanchand',
            Email: 'phd002@paruluniversity.ac.in',
            Phone: 9601487556,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd002'
          },
          {
            Name: 'Gurpreet Kaur Bamrah',
            Email: 'phd003@paruluniversity.ac.in',
            Phone: 9167689157,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd003'
          },
          {
            Name: 'Irra Dhar',
            Email: 'phd004@paruluniversity.ac.in',
            Phone: 8219635499,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd004'
          },
          {
            Name: 'Jain Nidhi Bhagwatilal',
            Email: 'phd005@paruluniversity.ac.in',
            Phone: 8780563337,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd005'
          },
          {
            Name: 'Ahammad Sameer C',
            Email: 'phd006@paruluniversity.ac.in',
            Phone: 9072330025,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd006'
          },
          {
            Name: 'Prachi Sunildutt Patel',
            Email: 'phd007@paruluniversity.ac.in',
            Phone: 9638136530,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd007'
          },
          {
            Name: 'Bhaware Bharti Bhimrao',
            Email: 'phd008@paruluniversity.ac.in',
            Phone: 9823095314,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd008'
          },
          {
            Name: 'Patel Krupaben Arvindkumar',
            Email: 'phd009@paruluniversity.ac.in',
            Phone: 7874622983,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd009'
          },
          {
            Name: 'Bamania Kinjal Hitesh Bhai',
            Email: 'phd010@paruluniversity.ac.in',
            Phone: 7984601836,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd010'
          },
          {
            Name: 'Parmar Ankitakumari Karshanbhai',
            Email: 'phd011@paruluniversity.ac.in',
            Phone: 7434035303,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd011'
          },
          {
            Name: 'Darji Himanshu Jagdishbhai ',
            Email: 'phd012@paruluniversity.ac.in',
            Phone: 8780363639,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd012'
          },
          {
            Name: 'Vipul Devchandbhai Dudhat',
            Email: 'phd013@paruluniversity.ac.in',
            Phone: 9879979793,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd013'
          },
          {
            Name: 'Patel Karankumar Satishbhai ',
            Email: 'phd014@paruluniversity.ac.in',
            Phone: 8347999323,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd014'
          },
          {
            Name: 'Santhosh Abhinav',
            Email: 'phd015@paruluniversity.ac.in',
            Phone: 9537349119,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd015'
          },
          {
            Name: 'Deore Vinod Gulabarao',
            Email: 'phd016@paruluniversity.ac.in',
            Phone: 9687634344,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd016'
          },
          {
            Name: 'Khairnar Nandkishor Dattatray',
            Email: 'phd017@paruluniversity.ac.in',
            Phone: 9960452002,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd017'
          },
          {
            Name: 'Abhishek Kumar Vijay Prakash Tiwari ',
            Email: 'phd018@paruluniversity.ac.in',
            Phone: 9624773802,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd018'
          },
          {
            Name: 'Hit Harishbhai Patel',
            Email: 'phd019@paruluniversity.ac.in',
            Phone: 9925322134,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd019'
          },
          {
            Name: 'Chavan Ashok Girdhar ',
            Email: 'phd020@paruluniversity.ac.in',
            Phone: 9737013163,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd020'
          },
          {
            Name: 'Naynika Panchal ',
            Email: 'phd021@paruluniversity.ac.in',
            Phone: 8875319277,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd021'
          },
          {
            Name: 'Girase Dharmendra Komalsing',
            Email: 'phd022@paruluniversity.ac.in',
            Phone: 7709947663,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd022'
          },
          {
            Name: 'Darvekar Jayeshbhai Manoharbhai',
            Email: 'phd023@paruluniversity.ac.in',
            Phone: 9558796584,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd023'
          },
          {
            Name: 'Gajipara Parth Valjibhai ',
            Email: 'phd024@paruluniversity.ac.in',
            Phone: 9724234849,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd024'
          },
          {
            Name: 'Deshmukh Sagar Sambhaji',
            Email: 'phd025@paruluniversity.ac.in',
            Phone: 9372666788,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd025'
          },
          {
            Name: 'Kazi Sagufta Mohammadfariduddin',
            Email: 'phd026@paruluniversity.ac.in',
            Phone: 9228365786,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd026'
          },
          {
            Name: 'Prakashkumar Pravinbhai Gohil',
            Email: 'phd027@paruluniversity.ac.in',
            Phone: 9558922827,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd027'
          },
          {
            Name: 'Arun Kumar Upadhyay',
            Email: 'phd028@paruluniversity.ac.in',
            Phone: 8320113505,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd028'
          },
          {
            Name: 'Pathan Shenila Anwarkhan',
            Email: 'phd029@paruluniversity.ac.in',
            Phone: 9898156279,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd029'
          },
          {
            Name: 'Yogesh Tukaram Patel ',
            Email: 'phd030@paruluniversity.ac.in',
            Phone: 7990648988,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd030'
          },
          {
            Name: 'Shah Nishitkumar Subhashchandra',
            Email: 'phd031@paruluniversity.ac.in',
            Phone: 9426762587,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd031'
          },
          {
            Name: 'Abdul Rahman Turay',
            Email: 'phd032@paruluniversity.ac.in',
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd032'
          },
          {
            Name: 'Bhatt Devanshi Ketanbhai',
            Email: 'phd033@paruluniversity.ac.in',
            Phone: 9558960446,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd033'
          },
          {
            Name: 'Garasia Divyangana Subhashchandra ',
            Email: 'phd034@paruluniversity.ac.in',
            Phone: 9712390771,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd034'
          },
          {
            Name: 'Parmar Devrajsinh J',
            Email: 'phd035@paruluniversity.ac.in',
            Phone: 9081171073,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd035'
          },
          {
            Name: 'Damor Naishadhibahen Pravinbhai ',
            Email: 'phd036@paruluniversity.ac.in',
            Phone: 9265480211,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd036'
          },
          {
            Name: 'Vala Vedant Vijaybhai  ',
            Email: 'phd037@paruluniversity.ac.in',
            Phone: 9106921927,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd037'
          },
          {
            Name: 'Chauhan Akanksha Kiritbhai',
            Email: 'phd038@paruluniversity.ac.in',
            Phone: 8200220939,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd038'
          },
          {
            Name: 'Durgesh Soni',
            Email: 'phd039@paruluniversity.ac.in',
            Phone: 9924641864,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd039'
          },
          {
            Name: 'Bhojak Avani Alkeshkumar',
            Email: 'phd040@paruluniversity.ac.in',
            Phone: 7016887927,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd040'
          },
          {
            Name: 'Dave Dishaben Jayantibhai',
            Email: 'phd041@paruluniversity.ac.in',
            Phone: 8485909815,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd041'
          },
          {
            Name: 'Parmar Sagar Pravinbhai',
            Email: 'phd042@paruluniversity.ac.in',
            Phone: 8849443258,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd042'
          },
          {
            Name: 'V. Jegatheeswaran',
            Email: 'phd043@paruluniversity.ac.in',
            Phone: 8754573428,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd043'
          },
          {
            Name: 'Vikash Kumar ',
            Email: 'phd044@paruluniversity.ac.in',
            Phone: 7742075975,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd044'
          },
          {
            Name: 'Himani Rakesh Chawla',
            Email: 'phd045@paruluniversity.ac.in',
            Phone: 6353854353,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd045'
          },
          {
            Name: 'Pathak Shivang Bharatbhai',
            Email: 'phd046@paruluniversity.ac.in',
            Phone: 8460076903,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd046'
          },
          {
            Name: 'Bhatt Hetav Devang',
            Email: 'phd047@paruluniversity.ac.in',
            Phone: 8128428683,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd047'
          },
          {
            Name: 'Sunayna Sarkar',
            Email: 'phd048@paruluniversity.ac.in',
            Phone: 8140095652,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd048'
          },
          {
            Name: 'Mecwan Fedrick Williambhai',
            Email: 'phd049@paruluniversity.ac.in',
            Phone: 9510523295,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd049'
          },
          {
            Name: 'Thakore Hetal Vikramsinh',
            Email: 'phd050@paruluniversity.ac.in',
            Phone: 9664877797,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd050'
          },
          {
            Name: 'Brahmaniya Nishaben Mahendrabhai ',
            Email: 'phd051@paruluniversity.ac.in',
            Phone: 9510418148,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd051'
          },
          {
            Name: 'Ridhhi Joshi(pandya)',
            Email: 'phd052@paruluniversity.ac.in',
            Phone: 9409236613,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd052'
          },
          {
            Name: 'Heenaben Bharatsinh Rathod',
            Email: 'phd053@paruluniversity.ac.in',
            Phone: 9408083088,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd053'
          },
          {
            Name: 'Sana Hamidi',
            Email: 'phd054@paruluniversity.ac.in',
            Phone: 8826912658,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd054'
          },
          {
            Name: 'Malkani Simran Manishbhai ',
            Email: 'phd055@paruluniversity.ac.in',
            Phone: 9106170726,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd055'
          },
          {
            Name: 'Anindita Ghosh ',
            Email: 'phd056@paruluniversity.ac.in',
            Phone: 9113591772,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd056'
          },
          {
            Name: 'Nusrat Jahan',
            Email: 'phd057@paruluniversity.ac.in',
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd057'
          },
          {
            Name: 'Patel Nayanaben Hirabhai ',
            Email: 'phd058@paruluniversity.ac.in',
            Phone: 8238874900,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd058'
          },
          {
            Name: 'Sirdeshpande Malhari Kamalakar',
            Email: 'phd059@paruluniversity.ac.in',
            Phone: 9422186085,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd059'
          },
          {
            Name: 'Dr.Channabasavanna Patil',
            Email: 'phd060@paruluniversity.ac.in',
            Phone: 9731426577,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd060'
          },
          {
            Name: 'Dr Vinita Patil',
            Email: 'phd061@paruluniversity.ac.in',
            Phone: 9819790384,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd061'
          },
          {
            Name: 'Dr. Rupadevi Hosamath',
            Email: 'phd062@paruluniversity.ac.in',
            Phone: 7349373214,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd062'
          },
          {
            Name: 'Aayasha Parveen',
            Email: 'phd063@paruluniversity.ac.in',
            Phone: 7248778982,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd063'
          },
          {
            Name: 'Dr Patel Drashtiben Vasantbhai ',
            Email: 'phd064@paruluniversity.ac.in',
            Phone: 9408766911,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd064'
          },
          {
            Name: 'Vikram Sharma ',
            Email: 'phd065@paruluniversity.ac.in',
            Phone: 7869759384,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd065'
          },
          {
            Name: 'Dr Priyanka Gudisa',
            Email: 'phd066@paruluniversity.ac.in',
            Phone: 6394689956,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd066'
          },
          {
            Name: 'Doshi Dhara Manishkumar ',
            Email: 'phd067@paruluniversity.ac.in',
            Phone: 7096002294,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd067'
          },
          {
            Name: 'Vijeta Vishalkumar Rana',
            Email: 'phd068@paruluniversity.ac.in',
            Phone: 9931551661,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd068'
          },
          {
            Name: 'Bharadia Mital Narendrabhai',
            Email: 'phd069@paruluniversity.ac.in',
            Phone: 7698311943,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd069'
          },
          {
            Name: 'Atul Kaushikchandra Pandya',
            Email: 'phd070@paruluniversity.ac.in',
            Phone: 9099040578,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd070'
          },
          {
            Name: 'Thakkar Ketan Sanjaybhai',
            Email: 'phd071@paruluniversity.ac.in',
            Phone: 9574310741,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd071'
          },
          {
            Name: 'Rai Shibi Jitendra',
            Email: 'phd072@paruluniversity.ac.in',
            Phone: 9265407169,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd072'
          },
          {
            Name: 'Kritika Pancholi',
            Email: 'phd073@paruluniversity.ac.in',
            Phone: 8141000010,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd073'
          },
          {
            Name: 'Shah Tithi Mayur',
            Email: 'phd074@paruluniversity.ac.in',
            Phone: 9662257576,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd074'
          },
          {
            Name: 'Deepanshu Sharma',
            Email: 'phd075@paruluniversity.ac.in',
            Phone: 9646617238,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd075'
          },
          {
            Name: 'Ajay Kumar Sharma',
            Email: 'phd076@paruluniversity.ac.in',
            Phone: 6354599399,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd076'
          },
          {
            Name: 'N.C. Ajay Vishwath',
            Email: 'phd077@paruluniversity.ac.in',
            Phone: 7060904546,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd077'
          },
          {
            Name: 'Bhatt Ritul Shailesh',
            Email: 'phd078@paruluniversity.ac.in',
            Phone: 8238012143,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd078'
          },
          {
            Name: 'Chauhan Harshil Narendrabhai',
            Email: 'phd079@paruluniversity.ac.in',
            Phone: 9687881569,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd079'
          },
          {
            Name: 'Rana Tejaskumar Rajeshbhai',
            Email: 'phd080@paruluniversity.ac.in',
            Phone: 8000576417,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd080'
          },
          {
            Name: 'Mehta Charmi Padmakantbhai',
            Email: 'phd081@paruluniversity.ac.in',
            Phone: 7990655783,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd081'
          },
          {
            Name: 'Raithatha Hiren Bharatbhai',
            Email: 'phd082@paruluniversity.ac.in',
            Phone: 9924871643,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd082'
          },
          {
            Name: 'Ganesh Patidar',
            Email: 'phd083@paruluniversity.ac.in',
            Phone: 9826577998,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd083'
          },
          {
            Name: 'Chetan Kumar Verma',
            Email: 'phd084@paruluniversity.ac.in',
            Phone: 9755753758,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd084'
          },
          {
            Name: 'Rathod Santosh',
            Email: 'phd085@paruluniversity.ac.in',
            Phone: 9663458990,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd085'
          },
          {
            Name: 'Mairale Atul Deelip',
            Email: 'phd086@paruluniversity.ac.in',
            Phone: 9503665364,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd086'
          },
          {
            Name: 'Patil Ashish Kailas',
            Email: 'phd087@paruluniversity.ac.in',
            Phone: 8080698250,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd087'
          },
          {
            Name: 'Nandanwar Sneha Ashok',
            Email: 'phd088@paruluniversity.ac.in',
            Phone: 7405756644,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd088'
          },
          {
            Name: 'Parmar Jayshreeben Kanubhai',
            Email: 'phd089@paruluniversity.ac.in',
            Phone: 9898675116,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd089'
          },
          {
            Name: 'Pandhi Bhagyesha Manishkumar',
            Email: 'phd090@paruluniversity.ac.in',
            Phone: 8238056959,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd090'
          },
          {
            Name: 'Patil Bharti Devidas',
            Email: 'phd091@paruluniversity.ac.in',
            Phone: 8805540075,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd091'
          },
          {
            Name: 'Gondaliya Pankajkumar Ravidas',
            Email: 'phd092@paruluniversity.ac.in',
            Phone: 8000677774,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd092'
          },
          {
            Name: 'Rana Ishita Jayendrasinh',
            Email: 'phd093@paruluniversity.ac.in',
            Phone: 8866451240,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd093'
          },
          {
            Name: 'Kapdi Kranti Kamalakant',
            Email: 'phd094@paruluniversity.ac.in',
            Phone: 9619610494,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd094'
          },
          {
            Name: 'Patil Manohar Bhika',
            Email: 'phd095@paruluniversity.ac.in',
            Phone: 9404558796,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd095'
          },
          {
            Name: 'Desale Madhuri Shriram',
            Email: 'phd096@paruluniversity.ac.in',
            Phone: 9822720977,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd096'
          },
          {
            Name: 'Aparna Gupta',
            Email: 'phd097@paruluniversity.ac.in',
            Phone: 6897647948,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd097'
          },
          {
            Name: 'Shaikh Amin Farooqbhai',
            Email: 'phd098@paruluniversity.ac.in',
            Phone: 9173118305,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd098'
          },
          {
            Name: 'Khushboo Pandey ',
            Email: 'phd099@paruluniversity.ac.in',
            Phone: 9412447569,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd099'
          },
          {
            Name: 'Raulji Krishnaben Maheshkumar',
            Email: 'phd100@paruluniversity.ac.in',
            Phone: 9879288274,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd100'
          },
          {
            Name: 'Dessai Saurabh Sandeep',
            Email: 'phd101@paruluniversity.ac.in',
            Phone: 9011229644,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd101'
          },
          {
            Name: 'Shah Jaydeep Pradipkumar',
            Email: 'phd102@paruluniversity.ac.in',
            Phone: 9860286943,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd102'
          },
          {
            Name: 'Patel Devendra R.',
            Email: 'phd103@paruluniversity.ac.in',
            Phone: 9725001401,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd103'
          },
          {
            Name: 'Dave Vibhutiben Prakashbhai',
            Email: 'phd104@paruluniversity.ac.in',
            Phone: 9426127314,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd104'
          },
          {
            Name: 'Dubal Sonal Jayantilal Manjulaben',
            Email: 'phd105@paruluniversity.ac.in',
            Phone: 9969255390,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd105'
          },
          {
            Name: 'Suthar Henilkumar Dilipbhai',
            Email: 'phd106@paruluniversity.ac.in',
            Phone: 7874684635,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd106'
          },
          {
            Name: 'Vaishali Shivajiappa Sanjore',
            Email: 'phd107@paruluniversity.ac.in',
            Phone: 9029136596,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd107'
          },
          {
            Name: 'Vyas Rushi Uday',
            Email: 'phd108@paruluniversity.ac.in',
            Phone: 7069971375,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd108'
          },
          {
            Name: 'Kulkarni Santosh Suhas',
            Email: 'phd109@paruluniversity.ac.in',
            Phone: 7841843878,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd109'
          },
          {
            Name: 'Kamleshkumar Bhailalbhai Shah',
            Email: 'phd110@paruluniversity.ac.in',
            Phone: 9825031334,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd110'
          },
          {
            Name: 'Khambhati Vishakhaben Prafulchandra',
            Email: 'phd111@paruluniversity.ac.in',
            Phone: 8320241672,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd111'
          },
          {
            Name: 'Patel Yamini Dashrathbhai',
            Email: 'phd112@paruluniversity.ac.in',
            Phone: 8128371413,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd112'
          },
          {
            Name: 'Nair Anubha Mohankumar ',
            Email: 'phd113@paruluniversity.ac.in',
            Phone: 7046179702,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd113'
          },
          {
            Name: 'Pandey Madhuri Dhruvakumar',
            Email: 'phd114@paruluniversity.ac.in',
            Phone: 9426836519,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd114'
          },
          {
            Name: 'Kumvaishali Chimanlal Makwana',
            Email: 'phd115@paruluniversity.ac.in',
            Phone: 8866331927,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd115'
          },
          {
            Name: ' Upadhyaya Vaishali Jayendrabhai',
            Email: 'phd116@paruluniversity.ac.in',
            Phone: 9228879719,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd116'
          },
          {
            Name: 'Patel Swetaben Sanjaybhai',
            Email: 'phd117@paruluniversity.ac.in',
            Phone: 9687312018,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd117'
          },
          {
            Name: 'Jaideep Charan',
            Email: 'phd118@paruluniversity.ac.in',
            Phone: 7597474200,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd118'
          },
          {
            Name: 'Riddhi Mukeshbhai Sevak',
            Email: 'phd119@paruluniversity.ac.in',
            Phone: 9408470260,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd119'
          },
          {
            Name: 'Pratapsinh Bhagwandas Vaghela',
            Email: 'phd120@paruluniversity.ac.in',
            Phone: 9409315363,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd120'
          },
          {
            Name: 'Atul Devshanker Pandya',
            Email: 'phd121@paruluniversity.ac.in',
            Phone: 9898578743,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd121'
          },
          {
            Name: 'Megha Sharadkumar Joshi ',
            Email: 'phd122@paruluniversity.ac.in',
            Phone: 9016966897,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd122'
          },
          {
            Name: 'Dipika Kalita',
            Email: 'phd123@paruluniversity.ac.in',
            Phone: 7002941187,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd123'
          },
          {
            Name: 'Kukreja Komal Gopalbhai',
            Email: 'phd124@paruluniversity.ac.in',
            Phone: 9998568861,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd124'
          },
          {
            Name: 'Saini Pushpa Shankarlal',
            Email: 'phd125@paruluniversity.ac.in',
            Phone: 9879262295,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd125'
          },
          {
            Name: 'Shaunak Rajiv Shah',
            Email: 'phd126@paruluniversity.ac.in',
            Phone: 8160605244,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd126'
          },
          {
            Name: 'Sumanchna',
            Email: 'phd127@paruluniversity.ac.in',
            Phone: 8860677507,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd127'
          },
          {
            Name: 'Vaibhav Agrawal',
            Email: 'phd128@paruluniversity.ac.in',
            Phone: 8445443963,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd128'
          },
          {
            Name: 'Uzodinma Peter Eznduka',
            Email: 'phd129@paruluniversity.ac.in',
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd129'
          },
          {
            Name: 'Deepa Ailsinghani',
            Email: 'phd130@paruluniversity.ac.in',
            Phone: 9403545995,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd130'
          },
          {
            Name: 'Prajapati Kuldipkumar Jyantilal',
            Email: 'phd131@paruluniversity.ac.in',
            Phone: 8128181896,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd131'
          },
          {
            Name: 'Bhuvaneshwari K K',
            Email: 'phd132@paruluniversity.ac.in',
            Phone: 7561807442,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd132'
          },
          {
            Name: 'Goswami Manish Prabhatgiri',
            Email: 'phd133@paruluniversity.ac.in',
            Phone: 9376939625,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd133'
          },
          {
            Name: 'Kinjal Narendrabhai Patel',
            Email: 'phd134@paruluniversity.ac.in',
            Phone: 9408607665,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd134'
          },
          {
            Name: 'Susanta Kumar Satapathy',
            Email: 'phd135@paruluniversity.ac.in',
            Phone: 9337129403,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd135'
          },
          {
            Name: 'Javed Gulamnabi Dudhwala ',
            Email: 'phd136@paruluniversity.ac.in',
            Phone: 9727775437,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd136'
          },
          {
            Name: 'Chavda Shaileshkumar Ganpatbhai',
            Email: 'phd137@paruluniversity.ac.in',
            Phone: 9924711512,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd137'
          },
          {
            Name: 'Kolugoori Kiran',
            Email: 'phd138@paruluniversity.ac.in',
            Phone: 6261921995,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd138'
          },
          {
            Name: 'Sumitra Chauhan',
            Email: 'phd139@paruluniversity.ac.in',
            Phone: 9926930640,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd139'
          },
          {
            Name: 'Kanazariya Sandipkumar Baladevbhai',
            Email: 'phd140@paruluniversity.ac.in',
            Phone: 9173871182,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd140'
          },
          {
            Name: 'Payalben Mahendrabhai Patel',
            Email: 'phd141@paruluniversity.ac.in',
            Phone: 9173437991,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd141'
          },
          {
            Name: 'Kajal Kumari Valand',
            Email: 'phd142@paruluniversity.ac.in',
            Phone: 6375392344,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd142'
          },
          {
            Name: 'Ashruti Bhatt',
            Email: 'phd143@paruluniversity.ac.in',
            Phone: 8433109427,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd143'
          },
          {
            Name: 'Abhinav Ganeshsingh Bais',
            Email: 'phd144@paruluniversity.ac.in',
            Phone: 8830687743,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd144'
          },
          {
            Name: 'Paratwar Tirthesh Devichand',
            Email: 'phd145@paruluniversity.ac.in',
            Phone: 8149971648,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd145'
          },
          {
            Name: 'Vasandiya Kinjalbahen Dilipsinh',
            Email: 'phd146@paruluniversity.ac.in',
            Phone: 7567549649,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd146'
          },
          {
            Name: 'Kapadia Monali Maganbhai',
            Email: 'phd147@paruluniversity.ac.in',
            Phone: 9725279275,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd147'
          },
          {
            Name: 'Pravin Narayan Kirdat',
            Email: 'phd148@paruluniversity.ac.in',
            Phone: 9960511497,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd148'
          },
          {
            Name: 'Imran Yusuf Alana',
            Email: 'phd149@paruluniversity.ac.in',
            Phone: 9969436263,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd149'
          },
          {
            Name: 'Nehaben Gunvantbhai Prajapati',
            Email: 'phd150@paruluniversity.ac.in',
            Phone: 9978777533,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd150'
          },
          {
            Name: 'Sharma Himanshu Kamleshbhai',
            Email: 'phd151@paruluniversity.ac.in',
            Phone: 9558852091,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd151'
          },
          {
            Name: 'Bagde Mehul Padmakar',
            Email: 'phd152@paruluniversity.ac.in',
            Phone: 7721959183,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd152'
          },
          {
            Name: 'Bhabhor Atulkumar Rameshbhai ',
            Email: 'phd153@paruluniversity.ac.in',
            Phone: 8200964345,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd153'
          },
          {
            Name: 'Sachinandan Basak',
            Email: 'phd154@paruluniversity.ac.in',
            Phone: 9940294453,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd154'
          },
          {
            Name: 'Shah Niyati Shreyas',
            Email: 'phd155@paruluniversity.ac.in',
            Phone: 8469104732,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd155'
          },
          {
            Name: 'Shrikant Wamanrao Bute',
            Email: 'phd156@paruluniversity.ac.in',
            Phone: 9890144785,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd156'
          },
          {
            Name: 'Pathak Khushiben Ashishkumar',
            Email: 'phd157@paruluniversity.ac.in',
            Phone: 9426534970,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd157'
          },
          {
            Name: 'Dr. B Lalremruata',
            Email: 'phd158@paruluniversity.ac.in',
            Phone: 7338128681,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd158'
          },
          {
            Name: 'Sorathiya Kirti Dineshbhai',
            Email: 'phd159@paruluniversity.ac.in',
            Phone: 8849647484,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd159'
          },
          {
            Name: 'Hupparage Vrushabh Balaso',
            Email: 'phd160@paruluniversity.ac.in',
            Phone: 7744928525,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd160'
          },
          {
            Name: 'Virendra Pratap Singh Rathor',
            Email: 'phd161@paruluniversity.ac.in',
            Phone: 7905922023,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd161'
          },
          {
            Name: 'Siddheshwar Lalaso Shinde',
            Email: 'phd162@paruluniversity.ac.in',
            Phone: 9028811992,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd162'
          },
          {
            Name: 'Sukanya Mohan Korewar',
            Email: 'phd163@paruluniversity.ac.in',
            Phone: 9657837505,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd163'
          },
          {
            Name: 'Umbarkar Komal Vinayak ',
            Email: 'phd164@paruluniversity.ac.in',
            Phone: 9359963506,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd164'
          },
          {
            Name: 'Chidrewar Gajanan Uttamrao',
            Email: 'phd165@paruluniversity.ac.in',
            Phone: 9974604440,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd165'
          },
          {
            Name: 'Mohd. Shahebaz A Naeem Deshmukh',
            Email: 'phd166@paruluniversity.ac.in',
            Phone: 9604726173,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd166'
          },
          {
            Name: 'Vivek Bhaurao Tonge',
            Email: 'phd167@paruluniversity.ac.in',
            Phone: 9890204007,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd167'
          },
          {
            Name: 'Patel Rutvi Mahendrakumar',
            Email: 'phd168@paruluniversity.ac.in',
            Phone: 9426170410,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd168'
          },
          {
            Name: 'Chavhan Vaibhav Narayanrao',
            Email: 'phd169@paruluniversity.ac.in',
            Phone: 9595588836,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd169'
          },
          {
            Name: 'Yadav Riddhi Rameshchandra',
            Email: 'phd170@paruluniversity.ac.in',
            Phone: 9428764774,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd170'
          },
          {
            Name: 'Patel Falguni Thakorbhai',
            Email: 'phd171@paruluniversity.ac.in',
            Phone: 9724950678,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd171'
          },
          {
            Name: 'Dhole Rakesh Subhash ',
            Email: 'phd172@paruluniversity.ac.in',
            Phone: 7776844655,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd172'
          },
          {
            Name: 'Vishakha Sainath Jawanjal',
            Email: 'phd173@paruluniversity.ac.in',
            Phone: 8888305765,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd173'
          },
          {
            Name: 'Deepika Yadav',
            Email: 'phd174@paruluniversity.ac.in',
            Phone: 8890056467,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd174'
          },
          {
            Name: 'Vijay Pandita',
            Email: 'phd175@paruluniversity.ac.in',
            Phone: 7043303011,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd175'
          },
          {
            Name: 'Soni Jaykumar Dineshchandra',
            Email: 'phd176@paruluniversity.ac.in',
            Phone: 8866864021,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd176'
          },
          {
            Name: 'Sawant Nikita Vishnu ',
            Email: 'phd177@paruluniversity.ac.in',
            Phone: 9987710519,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd177'
          },
          {
            Name: 'Divya Chouhan ',
            Email: 'phd178@paruluniversity.ac.in',
            Phone: 9752953316,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd178'
          },
          {
            Name: 'Patel Arpita Ashvin',
            Email: 'phd179@paruluniversity.ac.in',
            Phone: 9825731188,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd179'
          },
          {
            Name: 'Memon Hiba Mohd Aslam',
            Email: 'phd180@paruluniversity.ac.in',
            Phone: 7276172446,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd180'
          },
          {
            Name: 'Syed Zubair Ahmed Syed Muzaffar Ahmed ',
            Email: 'phd181@paruluniversity.ac.in',
            Phone: 9036500388,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd181'
          },
          {
            Name: 'Bhatt Chaitali Janardanbhai ',
            Email: 'phd182@paruluniversity.ac.in',
            Phone: 8866141997,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd182'
          },
          {
            Name: 'Vishal Kaneriya',
            Email: 'phd183@paruluniversity.ac.in',
            Phone: 7574829036,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd183'
          },
          {
            Name: 'Sunita Singh',
            Email: 'phd184@paruluniversity.ac.in',
            Phone: 9818957722,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd184'
          },
          {
            Name: 'Amaresh Kumar',
            Email: 'phd185@paruluniversity.ac.in',
            Phone: 8460614295,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd185'
          },
          {
            Name: 'Mangwana Susan Vongayi',
            Email: 'phd186@paruluniversity.ac.in',
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd186'
          },
          {
            Name: 'Brajendra Kumar Rai',
            Email: 'phd187@paruluniversity.ac.in',
            Phone: 7619932580,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd187'
          },
          {
            Name: 'Parmar Ashwinbhai Ravjibhai',
            Email: 'phd188@paruluniversity.ac.in',
            Phone: 9998983912,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd188'
          },
          {
            Name: 'Darji Binita Rajnikant',
            Email: 'phd189@paruluniversity.ac.in',
            Phone: 9998889822,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd189'
          },
          {
            Name: 'Ramani Manish Maheshbhai ',
            Email: 'phd190@paruluniversity.ac.in',
            Phone: 9773196695,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd190'
          },
          {
            Name: 'Nishant Trivedi',
            Email: 'phd191@paruluniversity.ac.in',
            Phone: 8427349469,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd191'
          },
          {
            Name: 'Palak Trivedi',
            Email: 'phd192@paruluniversity.ac.in',
            Phone: 9998031516,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd192'
          },
          {
            Name: 'Mahida Digvijaysinh Bhikhusinh',
            Email: 'phd193@paruluniversity.ac.in',
            Phone: 9106514470,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd193'
          },
          {
            Name: 'Sagar More',
            Email: 'phd194@paruluniversity.ac.in',
            Phone: 8983158798,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd194'
          },
          {
            Name: 'Shekh Suzan Salimbhai',
            Email: 'phd195@paruluniversity.ac.in',
            Phone: 9714480071,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd195'
          },
          {
            Name: 'Shashank Shekhar',
            Email: 'phd196@paruluniversity.ac.in',
            Phone: 7990556287,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd196'
          },
          {
            Name: 'Chitra A Kundu',
            Email: 'phd197@paruluniversity.ac.in',
            Phone: 8178255310,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd197'
          },
          {
            Name: 'Manisha Dilip Mangala',
            Email: 'phd198@paruluniversity.ac.in',
            Phone: 9408143271,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd198'
          },
          {
            Name: 'Imoro Mohammed',
            Email: 'phd199@paruluniversity.ac.in',
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd199'
          },
          {
            Name: 'Hima Sasidharan',
            Email: 'phd200@paruluniversity.ac.in',
            Phone: 7433697731,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd200'
          },
          {
            Name: 'Pradeep Kumar',
            Email: 'phd201@paruluniversity.ac.in',
            Phone: 7814832402,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd201'
          },
          {
            Name: 'Prem Kumar',
            Email: 'phd202@paruluniversity.ac.in',
            Phone: 9023466210,
            Classes: 'PHD Exam Jan 2023',
            Domains: 'Exam-PHD',
            'Domain Department': 'EXAM',
            'Roll Number': 'phd202'
          }
        ])
      );

      const emails = students.map((student) => student.Email);

      const classes = await classRepository.findOne({ name: 'PHD Exam Jan 2023' }).lean();
      if (classes && classes._id) {
        await userRepository.update({ email: { $in: emails }, university }, { $addToSet: { classes: [classes._id] } }, { multi: true });
      }

      return res.status(200).send({ message: 'Classes added successfully.' });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/convert-students-to-applicants')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async convertStudentsToApplicants(@Req() req: any, @Res() res: any) {
    try {
      const emails = [
        'soniriddhi.soni@gmail.com',
        'stonk2004@gmail.com',
        'bhavnanishraddha04@gmail.com',
        'ranjantanisha16@gmail.com',
        'hetvipitroda06@gmail.com',
        'enu.ishaan0690@gmail.com',
        'shahkashvi1708@gmail.com',
        'diyashah7129@gmail.com',
        'moshmi1977@gmail.com',
        'sohakhanam8182@gmail.com',
        'khandhalarupa@gmail.com',
        'meetdesai.design@gmail.com',
        'riddhithakkar3608@gmail.com',
        'aaryap2511@gmail.com',
        'nishitparmar2003@gmail.com',
        'devyanigahilot08@gmail.com',
        'zaveripg@yahoo.com',
        'thakermunir@gmail.com',
        'trushakadia1912@gmail.com',
        'chovatiyak45@gmail.com',
        'samikshya.nanda.4848@gmail.com',
        'bharvi.patel123bharvi@gmail.com',
        'utkarshya480@gmail.com',
        'falakanand2000@gmail.com',
        'upasaniatharva0@gmail.com',
        'snehaladdha2@gmail.com',
        'savitaute@gmail.com',
        'shanya.shah2005@gmail.com',
        'patwala.krishna012@gmail.com',
        'yesha.parikh.2020@gmail.com',
        'hritviparekh@gmail.com',
        'gopi63370@gmail.com',
        'hitaishinimehta@gmail.com',
        'rutvababaria@gmail.com',
        'suhaniii.ravalll@gmail.com',
        'chauhanpiyush570@gmail',
        'imuskaanchellani@gmail.com',
        'prathameshpatil3221@gmail.com',
        'hrishi.dahivelkar@gmail.com',
        'ipreet0605@gmail.com',
        'hardit.artist@gmail.com',
        'neerajdob26@gmail.com',
        'menonshraddha942@gmail.com',
        'shambhavikadam3@gmail.com',
        'nandinividulkar@gmail.com'
      ];
      // for (let email of emails) {
      //     const user = await userRepository.findOne({ email }).lean();
      //     if (user) {
      //         const applicant = await applicantRepository.create({
      //             avatar: user.avatar,
      //             creator: user._id,
      //             email: user.email,
      //             name: user.name,
      //             owner: user._id,
      //             university: user.university,
      //         });

      //         await userDynamicDataRepository.create({
      //             user: user._id
      //         });

      //         await userRepository.update(
      //             { _id: user._id },
      //             { $set: { applicant: applicant._id } },
      //             { multi: false },
      //         );
      //     }
      // }

      await userRepository.update({ email: { $in: emails } }, { $set: { type: UserTypes.APPLICANT } }, { multi: true });

      return res.status(200).send({ message: 'Classes added successfully.' });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/add-applicants-classes')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addClasses(@Req() req: any, @Res() res: any) {
    try {
      const classIds = [
        '63de39d8337e840035714051',
        '63de3d19337e8400357141d2',
        '63de3d23e7c32e002a8c3518',
        '63de3d2d5e285c001c2f09dd',
        '63de3d37e7c32e002a8c3529',
        '63de3d3f337e840035714216',
        '63de3d47337e840035714225',
        '63de3d50e7c32e002a8c353c',
        '63de3d5a337e840035714245',
        '63de3d63337e840035714254',
        '63de3d6f5e285c001c2f0a13',
        '63de3d775e285c001c2f0a22'
      ];

      for (let index = 0; index < classIds.length; index++) {
        const userIds = await userRepository
          .find({ classes: { $in: [Types.ObjectId('63dbb5a38f293f7af7289664')] }, type: UserTypes.APPLICANT })
          .select('_id')
          .skip(index * 500)
          .limit(500)
          .lean();

        await userRepository.update({ _id: { $in: userIds } }, { $addToSet: { classes: [classIds[index]] } }, { multi: true });
      }

      return res.status(200).send({ message: 'Classes added successfully.' });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/export-users-with-pending-fees-by-university/:university([0-9a-f]{24})')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async userPendingFees(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const students: User[] = await userRepository
        .find({ type: UserTypes.STUDENT, university })
        .populate({ path: 'classes' })
        .populate({ path: 'domains' })
        .lean();
      const studentIds = students.map((student) => student._id);
      const paymentRequests: PaymentRequest[] = await paymentRequestRepository
        .find({ university, user: { $in: studentIds } })
        .sort({ createdAt: -1 })
        .lean();

      const items = [];

      for (let student of students) {
        const classes = student.classes.map((entry) => entry.name).join(', ');
        const domains = student.domains.map((entry) => entry.name).join(', ');
        const paymentRequest = paymentRequests.find((entry: PaymentRequest) => entry.user.toString() === student._id.toString());

        const item = {
          Name: student.name,
          Email: student.email,
          Classes: classes,
          Domains: domains,
          'Pending Fees': paymentRequest ? paymentRequest.requestedAmount : '--'
        };

        items.push(item);
      }

      const converter = new Json2Excel(items);
      converter.sheet = 'Students with Pending fees';

      const reportPath = await converter.convert();
      const buffer = readFileSync(reportPath);

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; Courses.xlsx`,
        'Content-Length': buffer.length
      });

      return res.end(buffer);
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/check-uploaded-users')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async checkUsers(@Req() req: any, @Res() res: any, @UploadedFile('file') file: any) {
    try {
      const result = excelToJson({
        source: file.buffer,
        header: {
          rows: 1
        }
      });

      const users = result['Users'];

      const emails = users.map((user) => user['B'].toLowerCase());

      const foundUsers = [];
      for (let email of emails) {
        const user = await userRepository.findOneWithDeleted({ email }).lean();
        foundUsers.push({ email, isFound: !!user });
      }

      return res.status(200).send({ foundUsers });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/check-and-fix-user-registrations')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixUserRegistrations(@Req() req: any, @Res() res: any) {
    try {
      const users = await userRepository
        .find({ 'extraFields.value': new RegExp('OLMN', 'i') })
        .select('extraFields')
        .lean();
      console.warn(users.length);

      for (let user of users) {
        const { extraFields } = user;

        const extraField = extraFields.findIndex((entry) => entry.key === 'Registration Number');
        const [first, second, third, fourth] = extraFields[extraField].value.split('-');

        extraFields[extraField].value = [first, third, fourth].join('-');

        await userRepository.update({ _id: user._id }, { $set: { extraFields } }, { multi: false });
      }

      return res.status(200).send({ users });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-user-references')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixUserReferences(@Req() req: any, @Res() res: any) {
    try {
      const entries = [
        {
          email: 'ravinder3679ansh@gmail.com',
          reference: 'Upgrad'
        },
        {
          email: 'singhonkar949@gmail.com',
          reference: 'Upgrad'
        },
        {
          email: 'garudkarpkg@gmail.com',
          reference: 'Upgrad'
        },
        {
          email: 'sumitrajandhingra@gmail.com',
          reference: 'Upgrad'
        },
        {
          email: 'ayushawasthi442@gmail.com',
          reference: 'BlackBoard'
        },
        {
          email: 'monikachauhan5848@gmail.com',
          reference: 'BlackBoard'
        },
        {
          email: 'sushma8178006423@gmail.com',
          reference: 'BlackBoard'
        },
        {
          email: 'mramirvlogs@gmail.com',
          reference: 'BlackBoard'
        }
      ];

      const users = await userRepository.find({ email: { $in: entries.map((entry) => entry.email) } }).lean();
      for (let index = 0; index < users.length; index++) {
        const user = users[index];
        const dynamicData: UserDynamicData = await userDynamicDataRepository.findOne({ user: user._id }).lean();
        if (dynamicData) {
          const { data = [] } = dynamicData;
          const field = data.findIndex((entry) => entry.key && entry.key === 'Referred By');
          if (field !== -1) {
            data[field].value = entries[index].reference;
          } else {
            data.push({ key: 'Referred By', value: entries[index].reference });
          }

          await userDynamicDataRepository.update({ user: user._id }, { $set: { data } }, { multi: false });
        }
      }

      return res.status(200).send({ users });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-user-extra-fields')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixUserExtraFields(@Req() req: any, @Res() res: any) {
    try {
      const users = await userRepository
        .find({
          $or: [{ 'extraFields.key': 'Application number' }, { 'extraFields.key': 'Registration No.' }, { 'extraFields.key': 'Roll number' }]
        })
        .lean();

      for (let user of users) {
        const { extraFields } = user;

        const applicationIndex = extraFields.findIndex((entry) => entry.key === 'Application number');
        const registrationIndex = extraFields.findIndex((entry) => entry.key === 'Registration No.');
        const rollIndex = extraFields.findIndex((entry) => entry.key === 'Roll number');

        if (applicationIndex !== -1) {
          extraFields[applicationIndex].key = 'Application Number';
        }

        if (registrationIndex !== -1) {
          extraFields[registrationIndex].key = 'Registration Number';
        }

        if (rollIndex !== -1) {
          extraFields[rollIndex].key = 'Roll Number';
        }

        await userRepository.update({ _id: user._id }, { $set: { extraFields } }, { multi: false });
      }

      return res.status(200).send({ message: 'Extra fields updated successfully.' });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-user-programs')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixUserPrograms(@Req() req: any, @Res() res: any) {
    try {
      const users = await userRepository
        .find({
          $or: [{ 'extraFields.value': 'Application number' }, { 'extraFields.key': 'Registration No.' }, { 'extraFields.key': 'Roll number' }]
        })
        .lean();

      for (let user of users) {
        const { extraFields } = user;

        const applicationIndex = extraFields.findIndex((entry) => entry.key === 'Application number');
        const registrationIndex = extraFields.findIndex((entry) => entry.key === 'Registration No.');
        const rollIndex = extraFields.findIndex((entry) => entry.key === 'Roll number');

        if (applicationIndex !== -1) {
          extraFields[applicationIndex].key = 'Application Number';
        }

        if (registrationIndex !== -1) {
          extraFields[registrationIndex].key = 'Registration Number';
        }

        if (rollIndex !== -1) {
          extraFields[rollIndex].key = 'Roll Number';
        }

        await userRepository.update({ _id: user._id }, { $set: { extraFields } }, { multi: false });
      }

      return res.status(200).send({ message: 'Extra fields updated successfully.' });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-student-roll-nos')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixStudentRollNumbers(@Req() req: any, @Res() res: any) {
    try {
      const users = await userRepository
        .find({
          'extraFields.key': 'Roll Number',
          createdAt: { $gte: moment().subtract(2, 'month').startOf('day') },
          type: UserTypes.STUDENT,
          university: Types.ObjectId('6112294a2e080a442b7d5ad9')
        })
        .sort({ createdAt: -1 })
        .lean();

      const dynamicDatas = await userDynamicDataRepository
        .find({
          'data.key': 'program',
          user: { $in: users.map((user) => user._id) }
        })
        .lean();

      for (let user of users) {
        const dynamicData: UserDynamicData = dynamicDatas.find((entry) => entry.user.toString() === user._id.toString());
        if (!dynamicData) {
          continue;
        }

        const { data = [] } = dynamicData;

        if (data.length === 0) {
          continue;
        }

        const programField = data.find((entry) => entry.key && entry.key === 'program');
        if (!programField) {
          continue;
        }

        if ((programField.value as string).indexOf('July') === -1) {
          continue;
        }

        const userData = DataUtils.arrayToHash(data);

        const pluginExecutor = new PluginExecutor('61912c80d4643d7b7f7ce2d7', { ...user, ...userData });
        const value = await pluginExecutor.execute();

        const { extraFields } = user;
        const rollIndex = extraFields.findIndex((entry) => entry.key === 'Roll Number');
        if (rollIndex !== -1) {
          extraFields[rollIndex].value = value;
        }

        await userRepository.update({ _id: user._id }, { $set: { extraFields } }, { multi: false });
      }

      return res.status(200).send({ message: 'Roll numbers updated successfully.' });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/update-profile-pictures')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updateProfilePictures(@Req() req: any, @Res() res: any) {
    try {
      const files = readdirSync('/tmp/profiles');
      const usersMap = new Map<string, string>();

      const universityConfig: UniversityConfiguration = await universityConfigurationRepository.findOne({
        university: '6112294a2e080a442b7d5ad9'
      });

      for (let file of files) {
        const filename = file.split('.').slice(0, -1).join('.');
        if (!filename) continue;

        const s3 = new S3University(universityConfig, true);
        const url = await s3.upload(`/tmp/profiles/${file}`, file, universityConfig.buckets.ASSETS);

        usersMap.set(filename, url);
      }

      const users = await userRepository
        .find({
          'extraFields.key': 'Roll Number',
          'extraFields.value': { $in: Array.from(usersMap.keys()) },
          university: Types.ObjectId('6112294a2e080a442b7d5ad9')
        })
        .lean();

      const bulkOperations = [];

      for (let user of users) {
        const avatar = usersMap.get(user.extraFields.find((entry) => entry && entry.key === 'Roll Number')?.value || '');
        if (!avatar) continue;

        bulkOperations.push({
          updateOne: {
            filter: { _id: user._id },
            update: { $set: { avatar } }
          }
        });
      }

      const BATCH_SIZE = 100;
      for (let i = 0; i < bulkOperations.length; i += BATCH_SIZE) {
        const batch = bulkOperations.slice(i, i + BATCH_SIZE);
        await userRepository.bulkWrite(batch);
      }

      return res.status(200).send({ message: 'Roll numbers updated successfully.' });
    } catch (error: any) {
      return res.status(400).send({ message: error.message });
    }
  }
}
