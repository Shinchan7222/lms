import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { User, UserTypes, userRepository } from '@edorer/user-data';
import { UserDynamicData, userDynamicDataRepository } from '@edorer/user-dynamic-data';

@JsonController()
export class ScriptApplicantController {
  @Get('/scripts/fix-applicant-ids')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixApplicantIds(@Req() req: any, @Res() res: any) {
    try {
      const applicants: User[] = await userRepository
        .find({ 'extraFields.value': new RegExp('//', 'i'), type: { $in: [UserTypes.APPLICANT, UserTypes.STUDENT] } })
        .lean();

      for (let applicant of applicants) {
        const { extraFields } = applicant;

        const extraField = extraFields.findIndex((entry) => entry && entry.key === 'Application Number');
        if (extraField === -1) {
          continue;
        }

        const userDynamicData: UserDynamicData = await userDynamicDataRepository.findOne({ user: applicant._id }).lean();

        if (!userDynamicData) {
          continue;
        }

        const { data } = userDynamicData;
        if (data.length === 0) {
          continue;
        }

        const selectedCourse = data.find((entry) => entry.key && entry.key === 'Select Course');
        if (!selectedCourse) {
          continue;
        }

        const [first, last] = extraFields[extraField].value.split('//');
        extraFields[extraField].value = [first, selectedCourse.value, last].join('/');

        await userRepository.update({ _id: applicant._id }, { $set: { extraFields } }, { multi: false });
      }

      return res.status(200).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
