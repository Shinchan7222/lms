import { CanExecuteScript } from '@edorer/script-data';
import { dynamicFormRepository } from '@edorer/dynamic-form-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';

@JsonController()
export class ScriptDynamicFormController {
  @Get('/scripts/add-link-dynamic-form-variables')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async linkVariables(@Req() req: any, @Res() res: any) {
    try {
      const forms = await dynamicFormRepository.find({ university: '6112294a2e080a442b7d5ad9' }).lean();

      for (let form of forms) {
        const { sections } = form;

        for (let section of sections) {
          for (let row of section.rows) {
            for (let input of row.inputs) {
              if (input.name === 'Birth Date') {
                input.properties['Linked to Variables'] = 'DOB';
              }

              if (input.name === 'Gender') {
                input.properties['Linked to Variables'] = 'Gender';
              }

              // if (input.name === 'Phone Number') {
              //   input.properties['Linked to Variables'] = 'Gender';
              // }
            }
          }
        }

        await dynamicFormRepository.update({ _id: form._id }, { $set: { sections } });
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Request sent to export exams' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
