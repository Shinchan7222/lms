import { CanExecuteScript } from '@edorer/script-data';
import { DebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { DebToLmsConverter } from '@edorer/deb-to-lms-api';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { User, userRepository } from '@edorer/user-data';
import { universityRepository } from '@edorer/university-data';
import { Types } from 'mongoose';

@JsonController()
export class ScriptDebController {
  @Get('/scripts/attach-plain-password')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addSubDomains(@Req() req: any, @Res() res: any) {
    try {
      const debs: DebToLms[] = await debToLmsRepository
        .find({ isConverted: true, password: { $exists: true } })
        .select('_id email password')
        .lean();

      const map = {};

      for (let { email, password } of debs) {
        map[String(email).toLowerCase()] = password;
      }

      const emails = Object.keys(map);

      if (emails.length === 0) {
        return res.status(400).send({ message: 'No deb found' });
      }

      const users: User[] = await userRepository
        .find({ email: { $in: emails } })
        .select('_id email plainPassword')
        .lean();

      if (users.length === 0) {
        return res.status(400).send({ message: 'No user found' });
      }

      const bulkOperations = [];

      for (let user of users) {
        if (user.plainPassword) continue;

        const email = String(user.email).toLowerCase();

        if (!map[email]) continue;

        bulkOperations.push({
          updateOne: {
            filter: { _id: user._id },
            update: {
              $set: {
                plainPassword: map[email]
              }
            }
          }
        });
      }

      if (bulkOperations.length > 0) {
        await userRepository.bulkWrite(bulkOperations);
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Request sent to export exams' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/attach-program-id')
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addProgramId(@Req() req: any, @Res() res: any) {
    try {
      const debs: DebToLms[] = await debToLmsRepository
        .find({ programId: { $exists: false } })
        .select('_id email')
        .lean();

      for (let deb of debs) {
        const user = await userRepository
          .findOne({ $or: [{ email: deb.email.toLowerCase() }, { email: deb.email.toUpperCase() }] })
          .populate({ path: 'programs', select: 'id' })
          .lean();
        if (!user) continue;

        const { programs } = user;
        const [program] = programs;

        if (!program) continue;
        if (!program?.id) continue;

        const programId = program.id.padStart(6, '0');

        await debToLmsRepository.update({ _id: deb._id }, { $set: { programId: programId } });
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Request sent to export exams' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/convert-deb-students')
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async convertStudents(@Req() req: any, @Res() res: any) {
    try {
      const university = await universityRepository.findOne({ _id: new Types.ObjectId('5ffda431be794b82dd8d1281') });
      const user = await userRepository.findOne({ _id: new Types.ObjectId('6022888ee228eabad282c71e') });

      if (!university || !user) {
        return res.status(400).send({ message: 'University or user not found' });
      }

      const debs: string[] = await debToLmsRepository.distinct('_id', {
        deleted: false,
        isApproved: true,
        permanentEnrollmentNumber: {
          $in: [
            '2501A02600022',
            '2501A02600021',
            '2501A02600020',
            '2501A02600018',
            '2501A02600017',
            '2501A02600016',
            '2501A02600015',
            '2501A02600014',
            '2501A02600013',
            '2501A02600012',
            '2501A02600011',
            '2501A02600009',
            '2501A02600008',
            '2501A02600007',
            '2501A02600006',
            '2501A02600005',
            '2501A02600004',
            '2501A02600003',
            '2501A02600002',
            '2501A02800039',
            '2501A02800041',
            '2501A02800038',
            '2501A02800037',
            '2501A02800034',
            '2501A02800033',
            '2501A02800031',
            '2501A02800001',
            '2501A02800032',
            '2501A02800028',
            '2501A02800021',
            '2501A02800019',
            '2501A02800022',
            '2501A02800018',
            '2501A02800027',
            '2501A02800017',
            '2501A02800014',
            '2501A02800023',
            '2501A02800020',
            '2501A02800013',
            '2501A02800035',
            '2501A02800026',
            '2501A02800015',
            '2501A02800024',
            '2501A02800011',
            '2501A02800016',
            '2501A02800025',
            '2501A02800010',
            '2501A02800040',
            '2501A02800006',
            '2501A02800007',
            '2501A02800005',
            '2501A02800004',
            '2501A02800012',
            '2501A02800003',
            '2501A02800009',
            '2501A02800008',
            '2501A02800029',
            '2501A02800036',
            '2501A02800030',
            '2501A02800002'
          ]
        }
      });

      const converter = new DebToLmsConverter([], debs, 'deb-to-lms', user, university);
      await converter.convert();

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Request sent to export exams' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
