import { CanExecuteScript } from '@edorer/script-data';
import { courseRepository } from '@edorer/course-data';
import { DistinctFacade } from '@edorer/generic-facades';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Program, programRepository } from '@edorer/program-data';
import { ProgramResult, programResultRepository } from '@edorer/program-result-data';
import { trackCourseRepository } from '@edorer/track-course-data';
import { TrackProgram, trackProgramRepository } from '@edorer/track-program-data';
import { User, UserTypes, userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import moment = require('moment-timezone');
import { Types } from 'mongoose';

@JsonController()
export class ScriptTrackProgramController {
  @Get('/scripts/update-track-programs-available-courses/:programId')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updateTrackProgramAvailableCourses(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const program = await programRepository.findOne({ _id: programId }).lean();
      if (!program) throw new Error("Program doesn't exist");

      const trackPrograms = await trackProgramRepository.find({ program: programId }).lean();

      const bulkOperations = [];

      for (let trackProgram of trackPrograms) {
        const { curriculum } = program;
        const { currentYear, currentStep } = trackProgram;

        const { yearData } = curriculum[currentYear - 1];
        const semester = yearData[currentStep - 1];

        const availableCourses = semester.data.filter((entry) => !entry.isElective).map((entry) => entry.course);

        bulkOperations.push({
          updateOne: {
            filter: { _id: trackProgram._id },
            update: { $set: { availableCourses } }
          }
        });
      }

      if (bulkOperations.length !== 0) {
        await trackProgramRepository.bulkWrite(bulkOperations);
      }

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/update-all-track-programs-available-courses/:university')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updateAllTrackProgramAvailableCourses(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const programs = await programRepository.find({ university }).select('curriculum').lean();

      for (let program of programs) {
        const trackPrograms = await trackProgramRepository.find({ program: program._id }).lean();

        const bulkOperations = [];

        for (let trackProgram of trackPrograms) {
          const { curriculum } = program;
          const { currentYear, currentStep } = trackProgram;

          const { yearData } = curriculum[currentYear - 1];
          const semester = yearData[currentStep - 1];

          const availableCourses = semester.data.map((entry) => entry.course);

          bulkOperations.push({
            updateOne: {
              filter: { _id: trackProgram._id },
              update: { $set: { availableCourses } }
            }
          });
        }

        if (bulkOperations.length !== 0) {
          await trackProgramRepository.bulkWrite(bulkOperations);
        }
      }

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-track-programs')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackPrograms(@Req() req: any, @Res() res: any) {
    try {
      const students = await programRepository.distinct('students', { _id: '660a7730822d6e001226aade' });

      const users = [];

      for (let user of students) {
        const trackProgram = await trackProgramRepository.count({ user, program: '660a7730822d6e001226aade' });
        if (trackProgram !== 0) continue;

        users.push(user);
      }

      if (users.length !== 0) {
        await programRepository.update({ _id: '660a7730822d6e001226aade' }, { $pull: { students: { $in: users } } }, { multi: false });
        await userRepository.update({ _id: { $in: users } }, { $pull: { programs: { $in: ['660a7730822d6e001226aade'] } } }, { multi: true });
      }

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-track-program-courses/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackProgramCourses(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const program: Program = await programRepository.findOne({ _id: programId }).lean();
      const trackPrograms: TrackProgram[] = await trackProgramRepository.find({ program: programId }).lean();

      for (let trackProgram of trackPrograms) {
        const { curriculum } = program;
        const { currentYear, currentStep, user } = trackProgram;

        const { yearData } = curriculum[currentYear - 1];
        const semester = yearData[currentStep - 1];

        const availableCourses = semester.data.filter((entry) => !entry.isElective).map((entry) => entry.course);

        await trackProgramRepository.update({ _id: trackProgram._id }, { $set: { availableCourses } }, { multi: false });

        // await userRepository.update({ _id: user }, { $set: { courses: availableCourses } }, { multi: true });

        // await courseRepository.update({ students: { $in: [user] } }, { $pull: { students: user } }, { multi: true });
        // await courseRepository.update({ _id: { $in: availableCourses } }, { $addToSet: { students: [user] } }, { multi: true });

        // await trackCourseRepository.update({ course: { $nin: availableCourses }, user }, { $set: { deleted: true } }, { multi: true });
      }

      return res.status(200).send({ message: 'Track program courses updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-program-results/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixProgramResults(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const users = await programResultRepository.distinct('user', { program: programId });

      for (let user of users) {
        const result: ProgramResult = await programResultRepository
          .findOne({ dms: { $ne: '' }, program: programId, user })
          .sort({ createdAt: 1 })
          .lean();

        if (!result) continue;

        await programResultRepository.update({ program: programId, user, _id: { $ne: result._id } }, { $set: { deleted: true } }, { multi: true });
      }

      return res.status(200).send({ message: 'Result updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-program-enrollments')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixProgramEnrollments(@Req() req: any, @Res() res: any) {
    try {
      const { university } = req.body;

      const users: User[] = await userRepository.find({ university, type: UserTypes.STUDENT, 'programs.0': { $exists: true } }).lean();

      for (let user of users) {
        await programRepository.update({ students: { $in: [user._id] } }, { $pull: { students: { $in: [user._id] } } }, { multi: true });
        await programRepository.update({ _id: { $in: user.programs } }, { $addToSet: { students: user._id } }, { multi: true });
      }

      return res.status(200).send({ message: 'Updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/remove-duplicate-program-tracks')
  @Validate([
    {
      field: 'programIds',
      validation: [{ value: 'notEmpty', message: 'Programs are required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeDuplicateTracks(@Req() req: any, @Res() res: any) {
    try {
      const { programIds } = req.body;
      const programs = await programRepository.find({ _id: { $in: programIds } }).lean();

      for (let program of programs) {
        const users: string[] = await trackProgramRepository.distinct('user', { program, deleted: false }).lean();

        for (let user of users) {
          const trackProgram = await trackProgramRepository.findOneWithDeleted({ user, program }).sort({ createdAt: -1 }).lean();
          await trackProgramRepository.update({ user, program, _id: { $ne: trackProgram._id } }, { $set: { deleted: true } }, { multi: true });
        }
      }

      return res.status(200).send({ message: 'Deleted' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/remove-duplicate-program-results')
  @Validate([
    {
      field: 'program',
      validation: [{ value: 'notEmpty', message: 'Program is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeDuplicateResults(@Req() req: any, @Res() res: any) {
    try {
      const { program } = req.body;

      const facade = new DistinctFacade(null, null, 'user', null, [], programResultRepository);
      facade.addConditions({ program });

      const users = await facade.create();

      for (let user of users) {
        const result = await programResultRepository
          .findOne({ user, program, dmc: new RegExp('https://s3.ap-south-1.amazonaws.com/lms-parul-media/232275', 'i') })
          .lean();
        if (!result) continue;

        // await programResultRepository.update({ user, program, dmc: { $eq: '' } }, { $set: { deleted: true } }, { multi: true });
        await programResultRepository.update({ user, program, _id: { $ne: result._id } }, { $set: { deleted: true } }, { multi: true });
      }

      // { dmc: new RegExp('https://s3.ap-south-1.amazonaws.com/lms-parul-media/232275', 'i') }, { $set: { deleted: false } })

      return res.status(200).send({ message: 'Deleted' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-program-enrollments-new')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixPrograms(@Req() req: any, @Res() res: any) {
    try {
      const facade = new DistinctFacade(null, null, 'program', null, [], trackProgramRepository);
      const programs = await facade.addConditions({ createdAt: { $gte: moment().startOf('D') } }).create();

      for (let program of programs) {
        const facade = new DistinctFacade(null, null, 'user', null, [], trackProgramRepository);
        const users = await facade.addConditions({ createdAt: { $gte: moment().startOf('D') }, program }).create();

        await programRepository.update({ _id: program }, { $pull: { students: { $in: users } } }, { multi: true });
        await userRepository.update({ _id: { $in: users } }, { $pull: { programs: { $in: [program] } } }, { multi: true });
        await trackProgramRepository.update({ program, user: { $in: users } }, { $set: { deleted: true } }, { multi: true });
      }

      return res.status(200).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/remove-unavailable-program-users')
  @Validate([
    {
      field: 'programIds',
      validation: [{ value: 'notEmpty', message: 'Programs are required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeUnavailableTrackUsers(@Req() req: any, @Res() res: any) {
    try {
      const { programIds } = req.body;
      const programs = await programRepository.find({ _id: { $in: programIds } }).lean();

      const bulkOperations = [];

      for (let program of programs) {
        const users: string[] = await trackProgramRepository.distinct('user', { program, deleted: false }).lean();

        for (let user of users) {
          const count = await userRepository.count({ _id: user });

          if (count === 0) {
            bulkOperations.push({
              updateOne: {
                filter: { user, program },
                update: { $set: { deleted: true } }
              }
            });
          }
        }
      }

      if (bulkOperations.length !== 0) {
        await trackProgramRepository.bulkWrite(bulkOperations);
      }

      return res.status(200).send({ message: 'Deleted' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/update-track-programs-semester-wise-courses')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updateTrackProgramSemesterWiseCourses(@Req() req: any, @Res() res: any) {
    try {
      const trackPrograms = await trackProgramRepository
        .find({
          // program: '680f003e18618c0069a3254e'
          // semesterWiseCourses: { $exists: false },
          // user: '6620b4bed33e990020559ca2'
        })
        .populate({ path: 'program', select: 'curriculum' })
        .lean();

      const bulkOperations = [];

      for (const trackProgram of trackPrograms) {
        if (!trackProgram?.program?.curriculum) continue;

        // Fetch all track courses for this user once instead of querying for each course
        const userTrackCourses = await trackCourseRepository.find({ user: trackProgram.user }).select('course').lean();

        // Create a Set for O(1) lookups
        const userCourseIds = new Set(userTrackCourses.map((tc) => tc.course.toString()));

        const semesterWiseCourses = [];

        for (let i = 0; i < trackProgram.program.curriculum.length; i++) {
          const curriculum = trackProgram.program.curriculum[i];

          for (let j = 0; j < curriculum.yearData.length; j++) {
            const yearData = curriculum.yearData[j];

            // Filter courses that exist in user's track courses
            const courses = yearData.data.filter((data) => data?.course && userCourseIds.has(data.course.toString())).map((data) => data.course);

            semesterWiseCourses.push({ year: i + 1, semester: j + 1, courses });
          }
        }

        bulkOperations.push({
          updateOne: {
            filter: { _id: trackProgram._id },
            update: { $set: { semesterWiseCourses } }
          }
        });
      }

      if (bulkOperations.length !== 0) {
        const BATCH_SIZE = 500;

        for (let i = 0; i < bulkOperations.length; i += BATCH_SIZE) {
          const batch = bulkOperations.slice(i, i + BATCH_SIZE);
          await trackProgramRepository.bulkWrite(batch);
        }
      }

      console.log('========== DONE ============');

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-user-courses-by-track-programs')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixUserCourses(@Req() req: any, @Res() res: any) {
    try {
      const programIds = [
        // new Types.ObjectId('61a5507e97984bf3fbb31c56'),
        // new Types.ObjectId('61b215594bfba1002e079df2'),
        // new Types.ObjectId('61b3446141d8500020190d9d'),
        // new Types.ObjectId('61b351f64bfba1002e07a12c'),
        // new Types.ObjectId('61cd86a8940446002a51eaa5'),
        // new Types.ObjectId('61cdb4ef3a3f79003c70a93b'),
        // new Types.ObjectId('61f21a2fbe3a4d0024fd5282'),
        // new Types.ObjectId('624461a6dfd4385f3fdea764'),
        // new Types.ObjectId('627b784d367dd6002d48cddf'),
        // new Types.ObjectId('6284ca1a1068c1002cf543b8'),
        // new Types.ObjectId('62860d7f24ab6200382dc529'),
        // new Types.ObjectId('62c451f818ae740035f10f9d'),
        // new Types.ObjectId('637313cbb9065c001df1f070'),
        // new Types.ObjectId('637314148130f700361372c6'),
        // new Types.ObjectId('63731b497404de002bdc2340'),
        // new Types.ObjectId('63731b62c24a910024acff4d'),
        // new Types.ObjectId('6423f452ea9ba30024f13309'),
        // new Types.ObjectId('6423f4c466a70e001d767324'),
        // new Types.ObjectId('6423f511538667002ccac5f1'),
        // new Types.ObjectId('6423f9964f1901003731f0a9'),
        // new Types.ObjectId('6423f9c54f1901003731f0f8'),
        // new Types.ObjectId('646df173235e63002451a27a'),
        // new Types.ObjectId('6482b241b0ee78001d07dcca'),
        // new Types.ObjectId('64c74165bfe2480024c477ec'),
        // new Types.ObjectId('650abbfa7c754704ffbfa127'),
        // new Types.ObjectId('650abcc1c272230024343550'),
        // new Types.ObjectId('650abd063c98a205363646ae'),
        // new Types.ObjectId('650abd447e142e001ddd7511'),
        // new Types.ObjectId('650abd973c98a2053636477f'),
        // new Types.ObjectId('653f2bb5f582b0001c61ab5f'),
        // new Types.ObjectId('65d08587fe13f40019cdf9bc'),
        // new Types.ObjectId('660a7730822d6e001226aade'),
        // new Types.ObjectId('660cff4ddfd10b002a9aca4e'),
        // new Types.ObjectId('660d0178f97b4100186ff5a8'),
        // new Types.ObjectId('660d037dc965700011b8d8ac'),
        // new Types.ObjectId('660d047ac965700011b8d8e8'),
        // new Types.ObjectId('662a1e7b56304900217ac42c'),
        // new Types.ObjectId('662a217b56304900217ac84b'),
        // new Types.ObjectId('662f37a985ca03001aa61a6a'),
        // new Types.ObjectId('6631c5f03e6bbb0027bb3839'),
        // new Types.ObjectId('6645d723235f1d02f56038a2'),
        // new Types.ObjectId('66a26d8e7aa82100213a68b7'),
        // new Types.ObjectId('66a285697e692d00e2efd092'),
        // new Types.ObjectId('66a287ff6c1c8e00c4e62ecc'),
        // new Types.ObjectId('66a3312e94911d0027e19a65'),
        // new Types.ObjectId('66a335a8574e0400208eb10a'),
        // new Types.ObjectId('66a33c0578f8e400e529bbaf'),
        // new Types.ObjectId('66a33fedf247a000128a8032'),
        // new Types.ObjectId('66a340f5d645b90013bbd7bc'),
        // new Types.ObjectId('66a34120d645b90013bbd7d5'),
        // new Types.ObjectId('66b07247c270a80027efb2f5'),
        // new Types.ObjectId('67c81c2a1a519c292c4fcde1'),
        // new Types.ObjectId('67d11fabacf9cc57c28885d6'),
        // new Types.ObjectId('67d120da4dfdd167d4cc9055'),
        // new Types.ObjectId('67d12259afc48b588b699b6a'),
        // new Types.ObjectId('67d122e360117d550e7673d0'),
        // new Types.ObjectId('67d123c26dcb70535e843ee2'),
        // new Types.ObjectId('67d1244c040b64562f8bb23e'),
        // new Types.ObjectId('67d1355a60117d550e767e5e'),
        // new Types.ObjectId('67d135d0a410385aa32cdaf9'),
        // new Types.ObjectId('67d1368a2b264d5728a92e10'),
        // new Types.ObjectId('67da5371a79b73531c9704ac'),
        // new Types.ObjectId('680f003e18618c0069a3254e'),
        // new Types.ObjectId('68676633eabcb60048743ea7'),
        // new Types.ObjectId('68676bc0d5f0b5001248650f'),
        // new Types.ObjectId('68676d2fd5f0b500124865fa'),
        // new Types.ObjectId('68676f7400137700d7d00d49'),
        // new Types.ObjectId('68677089a5a1f700530c1dae'),
        // new Types.ObjectId('68677156d5f0b50012486a00'),
        // new Types.ObjectId('686772a255ecee003299c4df'),
        // new Types.ObjectId('6867734800137700d7d010a8'),
        // new Types.ObjectId('6867745a8b702c007432e5f2'),
        // new Types.ObjectId('686775b0a00a5700a0ce0337'),
        // new Types.ObjectId('68b13b90e3a8b6141e0023bc'),
        // new Types.ObjectId('68b13c2244bd1d144a5bd419'),
        // new Types.ObjectId('68b13c509e4fac13f2be22b6'),
        // new Types.ObjectId('68b13ca7c3aba713e7338565'),
        // new Types.ObjectId('68e3422d0b1b250f30a9106f'),
        // new Types.ObjectId('6965b50e66763d1217be9e9f'),
        // new Types.ObjectId('6965b63a0b6f0d0c94b1021f'),
        // new Types.ObjectId('6965b6cf60be2c0ed1b9790a'),
        // new Types.ObjectId('6965b733f373460c9fe57ae5'),
        // new Types.ObjectId('6965b78666763d1217bea10e'),
        // new Types.ObjectId('6965b7d2c37410120c8ebc5c'),
        // new Types.ObjectId('6965b841f373460c9fe57c0d'),
        // new Types.ObjectId('6965b8b5cf596b0efd2e92ac'),
        // new Types.ObjectId('6965b90f6b1b190c3c8748eb'),
        // new Types.ObjectId('699e77b240d09d2e1db251aa')
        new Types.ObjectId('660d0178f97b4100186ff5a8')
        // new Types.ObjectId('67162197fb249c01523936d4')
      ];

      const users = await userRepository.distinct('_id', { programs: { $in: programIds }, type: UserTypes.STUDENT, processed: false });

      for (let user of users) {
        const programs: string[] = await trackProgramRepository.distinct('program', { program: { $in: programIds }, user }).lean();
        if (programs.length === 0) continue;

        const programCourses = await programRepository.distinct('curriculum.yearData.data.course', { _id: { $in: programs } });
        if (programCourses.length === 0) continue;

        const trackCourses = await trackCourseRepository.findWithDeleted({ user, course: { $nin: programCourses } }).lean();
        if (trackCourses.length === 0) continue;

        const courses = trackCourses.map((o) => o.course);
        if (courses.length === 0) continue;

        await userRepository.update({ _id: user }, { $set: { courses, processed: true } });

        await courseRepository.update({ students: { $in: [user] } }, { $pull: { students: user } }, { multi: true });
        await courseRepository.update({ _id: { $in: courses } }, { $addToSet: { students: user } }, { multi: true });

        await trackCourseRepository.updateWithDeleted(
          { _id: { $in: trackCourses.map((o) => o._id) }, user },
          { $set: { deleted: false } },
          { multi: true }
        );
      }

      return res.status(200).send({ message: 'Track program courses updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
