import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { trackAssignmentRepository } from '@edorer/track-assignment-data';
import { userDynamicDataRepository } from '@edorer/user-dynamic-data';
import { userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptTrackAssignmentController {

    @Get('/scripts/fix-track-assignment-members/:assignment')
    @Validate([
        {
            field: 'assignment',
            validation: [{ value: 'notEmpty', message: 'Assignment ID is required' }]
        }
    ])
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async fixTrackMembers(@Req() req: any, @Res() res: any, @Param('assignment') assignment: string) {
        try {
            const trackAssignments = await trackAssignmentRepository.find({ assignment }).lean();
            for (let trackAssignment of trackAssignments) {
                const { user } = trackAssignment;
                const dynamicData = await userDynamicDataRepository.findOne({ "data.key": "Team Member 2 Email", user }).lean();
                if (dynamicData && dynamicData.data) {
                    const { data } = dynamicData;
                    const member1 = data.find(entry => entry.key === 'Team Member 2 Email').value;
                    const member2 = data.find(entry => entry.key === 'Team Member 3 Email').value;
                    const member3 = data.find(entry => entry.key === 'Team Member 4 Email').value;

                    const emails = [...new Set([member1, member2, member3].filter(Boolean))];

                    const users = [];

                    for (let email of emails) {
                        const emailUser = await userRepository.findOne({ email, university: '60df0d1c8e1fcb53f4704498' }).lean();
                        if (emailUser) {
                            users.push(emailUser._id);
                        }
                    }

                    const members = [user, ...users].map(entry => entry.toString());

                    await trackAssignmentRepository.update(
                        { _id: trackAssignment._id },
                        { $set: { members: [...new Set(members)] } },
                        { multi: false },
                    );
                }
            }

            return res.status(201).send({ message: 'Members fixed successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }
}
