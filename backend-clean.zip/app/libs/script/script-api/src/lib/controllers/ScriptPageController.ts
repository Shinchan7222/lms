import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Page, pageRepository } from '@edorer/page-builder-data';

@JsonController()
export class ScriptPageController {
  @Post('/scripts/update-page-headers')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updatePageHeaders(@Req() req: any, @Res() res: any) {
    try {
      const homePage: Page = await pageRepository
        .findOne({
          isHomePage: true,
          university: '6112294a2e080a442b7d5ad9'
        })
        .lean();

      const header = homePage.contents[1];

      const pages: Page[] = await pageRepository.find({
        $or: [{ isHomePage: { $exists: false } }, { isHomePage: false }],
        university: '6112294a2e080a442b7d5ad9'
      });

      for (let page of pages) {
        const [socialContacts, h, ...contents] = page.contents;
        await pageRepository.findOneAndUpdate({ _id: page._id }, { $set: { contents: [socialContacts, header, ...contents] } });
      }

      return res.status(200).send({ message: 'Page headers updated.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/update-page-footers')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updatePageFooters(@Req() req: any, @Res() res: any) {
    try {
      const homePage: Page = await pageRepository
        .findOne({
          isHomePage: true,
          university: '6112294a2e080a442b7d5ad9'
        })
        .lean();

      const footer = homePage.contents.find((entry) => entry.type === 'footer' && entry.styleType === 'Style 1');

      const pages: Page[] = await pageRepository.find({
        $or: [{ isHomePage: { $exists: false } }, { isHomePage: false }],
        university: '6112294a2e080a442b7d5ad9'
      });

      for (let page of pages) {
        const { contents } = page;
        const footerIndex = contents.findIndex((entry) => entry.type === 'footer' && entry.styleType === 'Style 1');
        if (footerIndex === -1) {
          contents.push(footer);
        } else {
          contents.splice(footerIndex, 1, footer);
        }

        await pageRepository.findOneAndUpdate({ _id: page._id }, { $set: { contents } });
      }

      return res.status(200).send({ message: 'Page footers updated.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
