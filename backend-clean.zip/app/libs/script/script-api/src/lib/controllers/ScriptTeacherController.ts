import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { UserTypes, userRepository } from '@edorer/user-data';

@JsonController()
export class ScriptTeacherController {

    @Get('/scripts/fix-teacher-classes')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async fixTeacherClasses(@Req() req: any, @Res() res: any) {
        try {
            const teachers = await userRepository.find({ type: UserTypes.TEACHER }).lean();
            for (let teacher of teachers) {
                await userRepository.update(
                    { _id: teacher._id },
                    { $set: { classes: teacher.classesThatITeach } },
                    { multi: false }
                );
            }

            return res.status(201).send({ message: 'Updated successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

}
