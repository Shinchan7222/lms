import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { S3University } from '@edorer/s3';
import { chapterRepository } from '@edorer/chapter-data';
import { courseRepository } from '@edorer/course-data';
import { lectureRepository } from '@edorer/lecture-data';
import { readdirSync } from 'fs';
import { universityConfigurationRepository } from '@edorer/university-data';
import { v4 as uuidV4 } from 'uuid';
import { videoUploaderRepository } from '@edorer/video-uploader-data';

@JsonController()
export class ScriptMigrationMMDUController {

    @Get('/scripts/migrate-mmdu-videos')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async migrateMMDU(@Req() req: any, @Res() res: any) {
        res.connection.setTimeout(0);
        try {
            setTimeout(async () => {
                let university = '6112294a2e080a442b7d5ad9';
                let universityConfig = await universityConfigurationRepository.findOne({ university: '6112294a2e080a442b7d5ad9' });
                let lectures = await lectureRepository.find({
                    'pages.0.html': { $regex: /player.vimeo/ },
                    'pages.0.assetUrl': { $exists: false }
                });
                let files = readdirSync('/home/ubuntu/vimeo');
                for (let lecture of lectures) {
                    const regex = /iframe src=\"https:\/\/player\.vimeo\.com\/video\/.*\?/gm;
                    let content = lecture.pages[0].html;
                    let result = regex.exec(content);
                    if (result !== null) {
                        let match = result[0];
                        let id = match.replace('iframe src="https://player.vimeo.com/video/', '')
                            .replace('?', '');
                        if (id.length === 9) {
                            let file = files.find(o => o.indexOf(id) > -1);
                            if (file) {
                                console.warn(file);
                                const s3 = new S3University(universityConfig);
                                if (!lecture.course) {
                                    let chapter = await chapterRepository.findOne({ lectures: lecture._id }).select('_id');
                                    if (chapter) {
                                        let course = await courseRepository.findOne({ chapters: chapter._id }).select('_id');
                                        if (course) {
                                            lecture.course = course._id;
                                        }
                                    }
                                }
                                if (lecture.course) {
                                    const url = await s3.upload(
                                        '/home/ubuntu/vimeo/' + file, uuidV4() + '-' + file,
                                        universityConfig.buckets.LMS_COURSE_VIDEOS, false
                                    );
                                    await videoUploaderRepository.create({
                                        url,
                                        isDashed: false,
                                        isWatermarked: false,
                                        courses: [lecture.course],
                                        lectures: [lecture._id],
                                        owner: lecture.owner,
                                        university
                                    });
                                    lecture.pages[0].contentType = 'video';
                                    lecture.pages[0].assetUrl = url;
                                    lecture.pages[0].time = 60;
                                    await lectureRepository.update({ _id: lecture._id }, {
                                        $set: {
                                            pages: lecture.pages,
                                            course: lecture.course
                                        }
                                    }, { multi: false });
                                }
                            } else {
                                console.error('NO FILE FOUND');
                                console.error(id);
                            }
                        } else {
                            console.error('WRONG ID');
                            console.error(id);
                        }
                    }
                }
            }, 1000);

            return res.status(201).send({ message: 'GOOD' });
        } catch
            (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Get('/scripts/migrate-mmdu-videos2')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async migrateMMDU2(@Req() req: any, @Res() res: any) {
        res.connection.setTimeout(0);
        try {
            setTimeout(async () => {
                let lectures = await lectureRepository.find({ 'pages.0.video': '$pages.0.assetUrl' });
                for (let lecture of lectures) {
                    lecture.pages[0].video = lecture.pages[0].assetUrl;
                    await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages } }, { multi: false });
                }
            }, 1000);

            return res.status(201).send({ message: 'GOOD' });
        } catch
            (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }
}
