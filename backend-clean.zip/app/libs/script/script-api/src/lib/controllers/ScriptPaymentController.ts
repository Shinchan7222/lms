import { CanExecuteScript } from '@edorer/script-data';
import { checkPaymentStatus } from '@edorer/payment-cron';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { paymentRepository } from '@edorer/payment-data';

@JsonController()
export class ScriptPaymentController {
  @Get('/scripts/remove-duplicate-payments/:university([0-9a-f]{24})')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async remove(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const users = await paymentRepository.distinct('user', { university });

      for (let user of users) {
        const payments = await paymentRepository.find({ university, user }).lean();

        for (let payment of payments) {
        }
      }

      return res.status(201).send({ message: 'Removed successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-payments-status')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fix(@Req() req: any, @Res() res: any) {
    try {
      await checkPaymentStatus.init();

      return res.status(201).send({ message: 'Fixed successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
