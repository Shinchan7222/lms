import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';
import { categoryRepository } from '@edorer/category-data';
import { questionRepository } from '@edorer/question-data';

@JsonController()
export class ScriptCategoryController {

    @Get('/scripts/delete-duplicate-categories/:university([0-9a-f]{24})')
    @Validate([
        {
            field: 'university',
            validation: [{ value: 'notEmpty', message: 'University ID is required' }]
        }
    ])
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async deleteDuplicateCategories(@Req() req: any, @Res() res: any, @Param('university') university: string) {
        try {
            const names = await categoryRepository.distinct('name', { university });
            for (let name of names) {
                const [first, ...categories] = await categoryRepository.find({ name, university }).lean();
                const categoryIds = categories.map(c => c._id);
                await categoryRepository.destroy({ _id: { $in: categoryIds } }, '6320803dc681c6002059d222');
                await questionRepository.update({ category: { $in: categoryIds } }, { category: first._id }, { multi: true });
            }

            return res.status(200).send({ message: 'Request sent to export exams' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }
}
