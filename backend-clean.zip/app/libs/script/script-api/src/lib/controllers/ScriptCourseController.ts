const axios = require('axios');
import { CanExecuteScript } from '@edorer/script-data';
import { Chapter, chapterRepository } from '@edorer/chapter-data';
import { Course, courseRepository } from '@edorer/course-data';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils, Json2Excel, StringUtils } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { mailer } from '@edorer/mailer';
import { readFileSync } from 'fs';
import { trackCourseRepository } from '@edorer/track-course-data';
import { universityConfigurationRepository } from '@edorer/university-data';
import { v4 as uui } from 'uuid';
import { classRepository } from '@edorer/class-data';
import { userRepository } from '@edorer/user-data';

@JsonController()
export class ScriptCourseController {
  @Get('/scripts/courses-with-missing-files')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async coursesWithMissingFiles(@Req() req: any, @Res() res: any) {
    try {
      const courses = await courseRepository
        .find({ courseStatus: 'Missing Files', university: '5ffda431be794b82dd8d1281' })
        .populate({ path: 'chapters', select: 'lectures title', populate: { path: 'lectures', select: 'pages title' } })
        .select('title chapters')
        .skip(0)
        .limit(200)
        .lean();

      for (let course of courses) {
        const missingPages = [];
        const lectures = course.chapters.flatMap((chapter) => chapter.lectures);
        const pages = lectures.flatMap((lecture) => lecture.pages);

        for (let page of pages) {
          if (page.assetUrl) {
            try {
              const axiosResponse = await axios.head(page.assetUrl);
              const urlExists = axiosResponse !== undefined && (axiosResponse.status < 400 || axiosResponse.status >= 500);
              if (!urlExists) {
                missingPages.push(page.title);
              }
            } catch (error: any) {
              missingPages.push(page.title);
            }
          }
        }

        course.missingPages = missingPages;
        delete course.chapters;
      }

      const items = [];
      for (let course of courses) {
        items.push({
          ID: course._id,
          NAME: course.title,
          PAGES: course.missingPages.join(', ')
        });
      }

      const converter = new Json2Excel(items);
      const reportPath = await converter.convert();
      const buffer = readFileSync(reportPath);
      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; courses.xlsx`,
        'Content-Length': buffer.length
      });
      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/fix-course-galleries')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixCourseGalleries(@Req() req: any, @Res() res: any) {
    try {
      const courses = await courseRepository
        .find({ 'galleries.0': { $exists: true } })
        .select('galleries')
        .lean();

      for (let course of courses) {
        let galleries = [];

        for (let gallery of course.galleries) {
          if (typeof gallery === 'string') {
            galleries.push(gallery);
          } else {
            galleries.push(gallery.url);
          }
        }

        galleries = galleries.filter((gallery) => gallery);

        await courseRepository.update({ _id: course._id }, { $set: { galleries } }, { multi: false });
      }

      return res.status(200).end({ message: 'Fixed successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/unattempted-courses')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async unAttemptedCourses(@Req() req: any, @Res() res: any) {
    try {
      const courses: Course[] = await courseRepository.find({ university: '5ffda431be794b82dd8d1281' }).select('_id id title').lean();

      const items = [];
      for (let course of courses) {
        const tracks = await trackCourseRepository.count({ course: course._id });
        if (tracks === 0) {
          items.push({ ID: course.id, Name: course.title });
        }
      }

      const converter = new Json2Excel(items);
      const reportPath = await converter.convert();

      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
      mailOptions.html = 'Hi' + '<br/><br/>Please find the attachment for questions of exam';
      mailOptions.subject = 'Courses List';
      mailOptions.to = 'baten.mab@gmail.com';
      mailOptions.attachments = [{ filename: 'courses.xlsx', path: reportPath }];

      mailer.init();
      await mailer.send(mailOptions);

      return res.status(400).send({ message: 'Sent' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/delete-course-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async deleteCourseAssets(@Req() req: any, @Res() res: any) {
    try {
      const courses: Course[] = await courseRepository
        .findWithDeleted({
          id: { $in: ['004295', '004310', '004309', '004305', '004172', '004304', '004288'] },
          university: '5ffda431be794b82dd8d1281'
        })
        .select('chapters galleries intro')
        .lean();

      let urls = [];
      for (let course of courses) {
        if (course.intro) urls.push(course.intro);
      }

      const chapters: Chapter[] = await chapterRepository
        .findWithDeleted({ _id: { $in: courses.flatMap((o) => o.chapters) } })
        .select('lectures')
        .lean();

      const lectures: Lecture[] = await lectureRepository
        .find({ _id: { $in: chapters.flatMap((o) => o.lectures) } })
        .select('pages')
        .lean();

      for (let lecture of lectures) {
        for (let page of lecture.pages) {
          if (page.assetUrl) urls.push(page.assetUrl);
          if (page.images) urls = urls.concat(page.images);
          if (page.pdf) urls.push(page.pdf);
          if (page.storedURI) urls.push(page.storedURI);
          if (page.video) urls.push(page.video);
        }

        urls = urls.filter(Boolean);
        urls = [...new Set(urls)];
      }

      urls = urls.filter((url) => url.startsWith('https://s3.ap-south-1.amazonaws.com/'));

      // let deletedUrl = 0;
      // const minIO:any;// = new MinIO();
      //
      // for (let url of urls) {
      //   try {
      //     await minIO.delete(url);
      //   } catch (error) {
      //     console.error(`Could not delete ${url}`);
      //   } finally {
      //     deletedUrl++;
      //
      //   }
      // }

      await chapterRepository.update({ _id: { $in: courses.flatMap((o) => o.chapters) } }, { $set: { deleted: true } });
      await lectureRepository.update({ _id: { $in: chapters.flatMap((o) => o.lectures) } }, { $set: { deleted: true } });

      return res.status(400).send({ message: 'Sent' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-course-assets/:courseId')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferCourseAssets(@Req() req: any, @Res() res: any, @Param('courseId') courseId: string) {
    try {
      const course: Course = await courseRepository.findOne({ _id: courseId }).select('university').lean();
      if (!course) {
        return res.status(400).send({ error: 'Course was not found' });
      }

      const lectures = await lectureRepository
        .find({
          // 'pages.contentType': { $in: ['document', 'video'] },
          'pages.contentType': 'video',
          $or: [{ isShifted: { $exists: false } }, { isShifted: { $eq: false } }],
          course: courseId
        })
        .lean();

      const universityConfig = await universityConfigurationRepository.findOne({ university: course.university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      for (let lecture of lectures) {
        const { pages } = lecture;

        for (let page of pages) {
          try {
            switch (page.contentType) {
              // case 'document':
              //   if (page.assetUrl && page.assetUrl.startsWith('https://minio.paruluniversity.ac.in')) {
              //     const url = page.assetUrl;
              //     const downloader = new Downloader(url);
              //     const downloadedUrl = await downloader.download();

              //     if (typeof downloadedUrl === 'string' && FileUtils.readFile(downloadedUrl).length > 0) {
              //       const filename = StringUtils.slug(url.split('/').pop()) + '.' + url.split('.').pop();

              //       const s3 = new S3University(universityConfig, true);
              //       const uploadedUrl = await s3.uploadBuffer(
              //         FileUtils.readFile(downloadedUrl),
              //         uui() + '-' + filename,
              //         universityConfig.buckets.LMS_COURSE_VIDEOS
              //       );

              //       page.assetUrl = uploadedUrl;
              //       page.previousUrl = url;
              //       page.storedURI = uploadedUrl;

              //       await lectureRepository.update({ _id: lecture._id }, { $set: { pages, isShifted: true } });
              //     }

              //     if (FileUtils.fileExists(downloadedUrl)) {
              //       FileUtils.removeFile(downloadedUrl);
              //     }
              //   }
              //   break;

              case 'video':
                if (page.video && page.video.startsWith('https://minio.paruluniversity.ac.in')) {
                  const url = page.video;
                  const downloader = new Downloader(url);
                  const downloadedUrl = await downloader.download();

                  if (typeof downloadedUrl === 'string' && FileUtils.readFile(downloadedUrl).length > 0) {
                    const filename = StringUtils.slug(url.split('/').pop()) + '.' + url.split('.').pop();

                    const s3 = new S3University(universityConfig, true);
                    const uploadedUrl = await s3.uploadBuffer(
                      FileUtils.readFile(downloadedUrl),
                      uui() + '-' + filename,
                      universityConfig.buckets.LMS_COURSE_VIDEOS
                    );

                    page.assetUrl = uploadedUrl;
                    page.previousUrl = url;
                    page.storedURI = uploadedUrl;
                    page.video = uploadedUrl;

                    await lectureRepository.update({ _id: lecture._id }, { $set: { pages, isShifted: true } });
                  }

                  if (FileUtils.fileExists(downloadedUrl)) {
                    FileUtils.removeFile(downloadedUrl);
                  }
                }
                break;

              default:
                break;
            }
          } catch {}
        }
      }

      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
      mailOptions.html = `Hi, Shifted all lectures of course ${courseId}`;
      mailOptions.subject = 'ASSET TRANSFER';
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();
      await mailer.send(mailOptions);

      return res.status(200).send({
        // assetUrls
        // images,
        lectures
        // storedURIs, contents, embeds, intros, previewIntros, imgs
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/remove-unwanted-course-students/:courseId')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeUnwantedCourseStudents(@Req() req: any, @Res() res: any, @Param('courseId') courseId: string) {
    try {
      const course: Course = await courseRepository.findOne({ _id: courseId }).lean();
      const classes = await classRepository.distinct('_id', { domain: course.domain });

      const users = await userRepository
        .find({ classes: { $nin: classes }, courses: { $in: [courseId] } })
        .select('_id')
        .lean();
      const userIds = users.map((user) => user._id);

      await userRepository.update({ _id: { $in: userIds } }, { $pull: { courses: { $in: [courseId] } } }, { multi: true });
      await courseRepository.update({ _id: courseId }, { $pullAll: { students: userIds } }, { multi: false });

      return res.status(200).send({ message: 'Ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
