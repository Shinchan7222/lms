import { CanExecuteScript } from '@edorer/script-data';
import { Downloader, S3 } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { UserDynamicData, userDynamicDataRepository } from '@edorer/user-dynamic-data';
import { UserTypes, userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptUserDynamicDataController {
  @Post('/scripts/add-nationality/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async exportExamsByIds(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const applicants = await userRepository.find({ type: UserTypes.APPLICANT, university }).select('_id').lean();
      const userIds = applicants.map((applicant) => applicant._id);
      const userDynamicDatas = await userDynamicDataRepository.find({ user: { $in: userIds } }).lean();

      for (let userDynamicData of userDynamicDatas) {
        let pushed = false;
        let { data } = userDynamicData;
        data = [...data];

        const nationality = data.findIndex((d) => d.key === 'Nationality');
        if (nationality === -1) {
          data.push({ key: 'Nationality', value: 'Indian' });
          pushed = true;
        }

        if (pushed) {
          await userDynamicDataRepository.update({ _id: userDynamicData._id }, { $set: data }, { multi: false });
        }
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/check-key')
  @Validate([
    {
      field: 'key',
      validation: [{ value: 'notEmpty', message: 'Key is required' }]
    }
  ])
  // @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async checkKey(@Req() req: any, @Res() res: any) {
    try {
      const { key } = req.body;
      let uploaded = false;

      const userDynamicDatas = await userDynamicDataRepository.find({ key: new RegExp(key, 'i') }).lean();
      for (let userDynamicData of userDynamicDatas) {
        const data = userDynamicData.data.find((entry) => entry.key && entry.key.toLowerCase() === key.toLowerCase());
        if (data && data.value) {
          console.warn(userDynamicData._id);
          uploaded = true;
        }
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====', uploaded);

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/update-program')
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updateProgram(@Req() req: any, @Res() res: any) {
    try {
      const key = 'program';
      const value = 'Master of Computer Application (Jan -2024)';

      const userDynamicDatas: UserDynamicData[] = await userDynamicDataRepository.find({ 'data.key': key, 'data.value': value }).lean();
      for (let userDynamicData of userDynamicDatas) {
        await userDynamicDataRepository
          .findOneAndUpdate(
            { _id: userDynamicData._id },
            {
              $pull: {
                data: { key, value }
              }
            },
            { multi: false }
          )
          .lean();

        await userDynamicDataRepository
          .findOneAndUpdate(
            { _id: userDynamicData._id },
            {
              $addToSet: {
                data: { key, value: 'Master Of Computer Application (Jan -2024)' }
              }
            },
            { multi: false }
          )
          .lean();
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-value-urls/:user')
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixValueUrls(@Req() req: any, @Res() res: any, @Param('user') user: string) {
    try {
      const userDynamicData: UserDynamicData = await userDynamicDataRepository.findOne({ user }).lean();
      for (let data of userDynamicData.data) {
        if (data.value && String(data.value).includes('https') && !String(data.value).includes('.pdf')) {
          try {
            const d = new Downloader(data.value as string);
            const url = await d.download();

            const b = FileUtils.readFile(url);
            if (b.length > 0) {
              const u = new S3();
              const s = await u.uploadBuffer(b);

              data.value = s;
            } else {
              data.value = '--';
            }
          } catch (error) {
            data.value = '--';
            console.error('Error', error);
          }
        }
      }

      await userDynamicDataRepository.update({ _id: userDynamicData._id }, { $set: { data: userDynamicData.data } }, { multi: false });

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/add-address-and-passport-number/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updateAddressAndPassportNumber(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const userIds = await userRepository.distinct('_id', { type: UserTypes.APPLICANT, university });
      const userDynamicDatas = await userDynamicDataRepository.find({ user: { $in: userIds } }).lean();

      const bulkOperations = [];

      for (let userDynamicData of userDynamicDatas) {
        let { data } = userDynamicData;
        data = [...data];

        const passport = data.find((d) => d && d.key && d.key === 'Passport number');
        if (passport) {
          data.push({ key: 'Passport Number', value: passport.value });
        }

        const passportNumber = data.find((d) => d && d.key && d.key === 'Passport Number');
        if (passportNumber) {
          data.push({ key: 'Passport number', value: passportNumber.value });
        }

        const admissionYear = data.find((d) => d && d.key && d.key === 'Admission Year');
        if (!admissionYear) {
          data.push({ key: 'Admission Year', value: '2024' });
        }

        const country = data.find((d) => d && d.key && d.key.trim() === 'Country');
        if (!country) {
          data.push({ key: 'Country', value: 'India' });
        } else {
          data.push({ key: 'Country', value: country.value });
        }

        const address = data.find((d) => d && d.key && d.key.trim() === 'Address Line 1');
        if (!address) {
          data.push({ key: 'Address', value: 'Not Provided' });
        } else if (address.value && String(address.value).trim() === '') {
          data.push({ key: 'Address', value: address.value });
        }

        bulkOperations.push({
          updateOne: {
            filter: { _id: userDynamicData._id },
            update: { $set: { data } }
          }
        });
      }

      while (bulkOperations.length > 0) {
        const sliced = bulkOperations.splice(0, 100);
        await userDynamicDataRepository.bulkWrite(sliced);
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
