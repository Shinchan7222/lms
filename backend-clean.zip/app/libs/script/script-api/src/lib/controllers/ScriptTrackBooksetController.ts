import { BookSetOrderCreator } from '@edorer/bookset-track-api';
import { booksetTrackRepository } from '@edorer/bookset-track-data';
import { debToLmsRepository } from '@edorer/deb-to-lms-data';
import { dynamicFormRepository } from '@edorer/dynamic-form-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { trackFormRepository } from '@edorer/track-form-data';
import { userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import { universityRepository } from '@edorer/university-data';
import * as excelToJson from 'convert-excel-to-json';
import { Types } from 'mongoose';
import { ScriptBooksetOrderItemsUpdater } from '../services/ScriptBooksetOrderItemsUpdater';

@JsonController()
export class ScriptTrackBooksetController {
  @Post('/scripts/create-bookset-orders')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async createBooksetOrders(@Req() req: any, @Res() res: any) {
    const { university } = req.body;
    const uni = await universityRepository.findOne({ _id: university }).lean();

    try {
      const forms = await dynamicFormRepository.find({ forBooksets: true, university }).lean();
      if (!forms.length) {
        return res.send({ createdCount: 0, failed: [], message: 'No forBooksets forms found' });
      }

      const formIds = forms.map((form) => form._id);
      const trackForms = await trackFormRepository.find({ forBooksets: true }).lean();

      let createdCount = 0;

      const failed: Array<{ formId: string; programId: string }> = [];

      for (const trackForm of trackForms) {
        const existingTrack = await booksetTrackRepository.findOne({ form: trackForm.form, user: trackForm.user }).lean();
        if (existingTrack) continue;

        try {
          const creator = new BookSetOrderCreator(String(trackForm.form), String(trackForm.user), uni);
          await creator.create();
          createdCount++;
        } catch (error) {
          let programId = '';
          try {
            const user = await userRepository.findOne({ _id: trackForm.user }).lean();
            if (user?.email) {
              const debProfile = await debToLmsRepository
                .findOne({ $or: [{ email: user.email.toUpperCase() }, { email: user.email.toLowerCase() }] })
                .lean();
              programId = debProfile?.programId || '';
            }
          } catch (innerError) {
            // Ignore lookup failures and still return form details.
          }

          failed.push({
            formId: String(trackForm.form),
            programId
          });
        }
      }

      return res.send({
        createdCount,
        failed,
        message: 'done'
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/update-track-bookset-booksets')
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async updateTrackBooksetBooksets(@Req() req: any, @Res() res: any, @UploadedFile('file', { required: true }) file: any) {
    try {
      const result = excelToJson({
        columnToKey: { '*': '{{columnHeader}}' },
        header: { rows: 1 },
        source: file.buffer
      });

      const results = result['Booksets'];

      for (const row of results) {
        const orderId = row['Order ID'];
        const bookset = row['Bookset'];

        await booksetTrackRepository.update({ orderId }, { $set: { bookset: Types.ObjectId(bookset) } });
      }

      return res.send({ message: 'done' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/update-bookset-order-items')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async updateBooksetOrderItems(@Req() req: any, @Res() res: any) {
    try {
      const { university } = req.body;
      const uni = await universityRepository.findOne({ _id: university }).lean();

      if (!uni) {
        throw new Error('University not found');
      }

      const updater = new ScriptBooksetOrderItemsUpdater(uni);
      const result = await updater.update();

      return res.send({
        ...result,
        message: 'done'
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
