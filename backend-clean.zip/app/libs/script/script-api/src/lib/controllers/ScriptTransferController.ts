import { assetsRepository } from '@edorer/assets-data';
import { CanExecuteScript } from '@edorer/script-data';
import { chapterRepository } from '@edorer/chapter-data';
import { classroomWorkRepository } from '@edorer/classroom-work-data';
import { courseRepository } from '@edorer/course-data';
import { examRepository } from '@edorer/exam-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Json2Excel } from '@edorer/utils';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { pageRepository } from '@edorer/page-builder-data';
import { programRepository } from '@edorer/program-data';
import { programResultRepository } from '@edorer/program-result-data';
import { questionRepository } from '@edorer/question-data';
import { readFileSync } from 'fs';
import { RestoreAwsDocuments } from '../services/RestoreAwsDocuments';
import { RestoreLocalDocuments } from '../services/RestoreLocalDocuments';
import { TransferAssets } from '../services/TransferAssets';
import { TransferClassroomWorks } from '../services/TransferClassroomWorks';
import { TransferCourseAssets } from '../services/TransferCourseAssets';
import { TransferCourseLectures } from '../services/TransferCourseLectures';
import { TransferExamAssets } from '../services/TransferExamAssets';
import { TransferPageAssets } from '../services/TransferPageAssets';
import { TransferProgramAssets } from '../services/TransferProgramAssets';
import { TransferProgramResults } from '../services/TransferProgramResults';
import { TransferQuestionAssets } from '../services/TransferQuestionAssets';
import { TransferUniversityAssets } from '../services/TransferUniversityAssets';
import { TransferUserDynamics } from '../services/TransferUserDynamics';
import { universityConfigurationRepository, universityRepository } from '@edorer/university-data';
import { userDynamicDataRepository } from '@edorer/user-dynamic-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptTransferController {
  @Get('/scripts/transfer-courses-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferCourseAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const courses = await courseRepository
        .find({
          $or: [{ intro: { $exists: true, $ne: null } }, { 'galleries.0': { $exists: true, $ne: null } }],
          university
        })
        .select('galleries intro')
        .sort({ createdAt: -1 })
        .lean();

      if (!courses.length) {
        return res.status(200).send({ message: 'No courses found for processing' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferCourseAssets(courses, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Assets transferred successfully',
        processedCount: courses.length
      });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-exams-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferExamAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const exams = await examRepository
        .find({
          logo: { $exists: true, $ne: null },
          university
        })
        .select('logo')
        .sort({ createdAt: -1 })
        .lean();

      if (!exams.length) {
        return res.status(200).send({ message: 'No exams found for processing' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferExamAssets(exams, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Assets transferred successfully',
        processedCount: exams.length
      });
    } catch (error: any) {
      console.error('Transfer exams error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-programs-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferProgramAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const programs = await programRepository
        .find({
          $or: [{ backgroundImage: { $exists: true, $ne: null } }, { intro: { $exists: true, $ne: null } }, { logo: { $exists: true, $ne: null } }],
          university
        })
        .select('backgroundImage intro logo')
        .sort({ createdAt: -1 })
        .lean();

      if (!programs.length) {
        return res.status(200).send({ message: 'No programs found for processing' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferProgramAssets(programs, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Assets transferred successfully',
        processedCount: programs.length
      });
    } catch (error: any) {
      console.error('Transfer programs error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-lectures-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferLectureAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const courses = await courseRepository.distinct('_id', { university });

      const lectures = await lectureRepository
        .find({
          'pages.contentType': { $in: ['document', 'video'] },
          $or: [
            { 'pages.assetUrl': { $regex: 'amazonaws.com' } },
            { 'pages.images': { $regex: 'amazonaws.com' } },
            { 'pages.video': { $regex: 'amazonaws.com' } }
          ],
          course: { $in: courses }
        })
        .sort({ createdAt: -1 })
        .lean();

      console.log(lectures.length);

      if (!lectures.length) return res.status(200).send({ message: 'No lectures found for processing' });

      const uni = await universityRepository.findOne({ _id: university }).lean();
      if (!uni) return res.status(400).send({ error: 'University not found' });

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
      if (!universityConfig) return res.status(400).send({ error: 'University configuration not found' });

      const transferer = new TransferCourseLectures(lectures, uni, universityConfig, false);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Assets transferred successfully',
        processedCount: lectures.length
      });
    } catch (error: any) {
      console.error('Transfer course lectures error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-questions-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferQuestionAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const exams = await examRepository.distinct('_id', { university }).lean();

      const questions = await questionRepository
        .find({
          $or: [
            { content: { $regex: 'amazonaws.com' } }
            // { content: new RegExp('https://minio.paruluniversity.ac.in', 'i') }
          ],
          exam: { $in: exams }
        })
        .sort({ createdAt: -1 })
        .lean();

      if (!questions.length) {
        return res.status(200).send({ message: 'No questions found for processing' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferQuestionAssets(questions, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Assets transferred successfully',
        processedCount: questions.length
      });
    } catch (error: any) {
      console.error('Transfer questions error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const assets = await assetsRepository
        .find({
          $or: [
            { url: { $regex: 'amazonaws.com' } }
            // { url: new RegExp('https://minio.paruluniversity.ac.in', 'i') }
          ],
          university
        })
        .select('url')
        .sort({ createdAt: -1 })
        .lean();

      if (!assets.length) {
        return res.status(200).send({ message: 'No assets found for processing' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferAssets(assets, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Assets transferred successfully',
        processedCount: assets.length
      });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-dynamic-data/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferExtras(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const assets = await userDynamicDataRepository
        .find({
          // university,

          $or: [
            { 'data.value': { $regex: 'amazonaws.com' } }
            // { 'data.value': new RegExp('https://minio.paruluniversity.ac.in', 'i') }
          ]
        })
        .select('data')
        .sort({ createdAt: -1 })
        .lean();

      if (!assets.length) {
        return res.status(200).send({ message: 'No assets found for processing' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferUserDynamics(assets, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Assets transferred successfully',
        processedCount: assets.length
      });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-classroom-works/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferClassroomWorks(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const classroomWorks = await classroomWorkRepository
        .find({
          $or: [
            { document: { $regex: 'amazonaws.com' } },
            // { document: new RegExp('https://minio.paruluniversity.ac.in', 'i') },
            { images: { $regex: 'amazonaws.com' } },
            // { images: new RegExp('https://minio.paruluniversity.ac.in', 'i') },
            { video: { $regex: 'amazonaws.com' } }
            // { video: new RegExp('https://minio.paruluniversity.ac.in', 'i') }
          ],
          university
        })
        .sort({ createdAt: 1 })
        .lean();

      if (!classroomWorks.length) {
        return res.status(200).send({ message: 'No works found for processing' });
      }

      const uni = await universityRepository.findOne({ _id: university }).lean();

      if (!uni) {
        return res.status(400).send({ error: 'University not found' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferClassroomWorks(classroomWorks, uni, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Classroom works transferred successfully',
        processedCount: classroomWorks.length
      });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-program-results/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferProgramResults(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const programResults = await programResultRepository
        .find({ dmc: { $regex: 'amazonaws.com' }, university })
        .sort({ createdAt: -1 })
        .lean();

      if (!programResults.length) {
        return res.status(200).send({ message: 'No results found for processing' });
      }

      const uni = await universityRepository.findOne({ _id: university }).lean();

      if (!uni) {
        return res.status(400).send({ error: 'University not found' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferProgramResults(programResults, uni, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Program results transferred successfully',
        processedCount: programResults.length
      });
    } catch (error: any) {
      console.error('Transfer result error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-page-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferPageAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const programResults = await pageRepository
        .find({
          $or: [{ 'contents.details.sectionCards.icon': { $regex: 'amazonaws.com' } }, { 'contents.preview': { $regex: 'amazonaws.com' } }],
          university
        })
        .sort({ createdAt: -1 })
        .lean();

      if (!programResults.length) {
        return res.status(200).send({ message: 'No results found for processing' });
      }

      const uni = await universityRepository.findOne({ _id: university }).lean();

      if (!uni) {
        return res.status(400).send({ error: 'University not found' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferPageAssets(programResults, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Program results transferred successfully',
        processedCount: programResults.length
      });
    } catch (error: any) {
      console.error('Transfer result error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-university-assets/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferUniversityAssets(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const programResults = await universityRepository
        .find({
          $or: [
            { logo: { $regex: 'amazonaws.com' } },
            { loginImage: { $regex: 'amazonaws.com' } },
            { whiteLogo: { $regex: 'amazonaws.com' } },
            { favicon: { $regex: 'amazonaws.com' } },
            { smallLogo: { $regex: 'amazonaws.com' } }
          ],
          _id: university
        })
        .sort({ createdAt: -1 })
        .lean();

      if (!programResults.length) {
        return res.status(200).send({ message: 'No results found for processing' });
      }

      const uni = await universityRepository.findOne({ _id: university }).lean();

      if (!uni) {
        return res.status(400).send({ error: 'University not found' });
      }

      const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      const transferer = new TransferUniversityAssets(programResults, universityConfig);
      await transferer.transfer();

      return res.status(200).send({
        message: 'Program results transferred successfully',
        processedCount: programResults.length
      });
    } catch (error: any) {
      console.error('Transfer result error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/restore-documents/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'batch',
      validation: [{ value: 'notEmpty', message: 'Batch is required' }]
    },
    {
      field: 'instance',
      validation: [{ value: 'notEmpty', message: 'Instance is required' }]
    },
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async restoreDocuments(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    const { batch, instance } = req.body;

    try {
      const restorer = new RestoreAwsDocuments(batch, instance, university);
      await restorer.restore();

      return res.status(200).send({ message: 'Restored successfully' });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/restore-local-documents/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'batch',
      validation: [{ value: 'notEmpty', message: 'Batch is required' }]
    },
    {
      field: 'instance',
      validation: [{ value: 'notEmpty', message: 'Instance is required' }]
    },
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async restoreLocalDocuments(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    const { batch, instance } = req.body;

    try {
      const restorer = new RestoreLocalDocuments(batch, instance, university);
      await restorer.restore();

      return res.status(200).send({ message: 'Restored successfully' });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/find-minio-documents/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async findMinioDocuments(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const courses = await courseRepository.distinct('_id', { university });
      const lectureIds = await chapterRepository.distinct('lectures', { course: { $in: courses } });

      const lectures = await lectureRepository
        .find({
          'pages.video': new RegExp('https://minio.paruluniversity.ac.in', 'i'),
          // 'pages.contentType': { $in: ['document', 'video'] },
          // $or: [
          // { 'pages.assetUrl': new RegExp('https://minio.paruluniversity.ac.in', 'i') },
          // { 'pages.images': new RegExp('https://minio.paruluniversity.ac.in', 'i') },
          // { 'pages.video': new RegExp('https://minio.paruluniversity.ac.in', 'i') }
          // ],
          _id: { $in: lectureIds }
        })
        .populate({
          path: 'course',
          populate: {
            path: 'domain'
          }
        })
        .sort({ createdAt: -1 })
        .lean();

      const isValidUrl = (url: string) => url.includes('https://minio.paruluniversity.ac.in');

      const reports = [];

      // Create a map to group URLs by course and domain
      const courseMap = new Map();

      lectures.forEach((lecture: Lecture) => {
        const urlSet = new Set<string>();

        // Extract course and domain information
        const courseTitle = lecture.course?.title || 'Unknown Course';
        const domainTitle = lecture.course?.domain?.name || 'Unknown Domain';

        // Create a unique key for this course/domain combination
        const key = `${courseTitle}|${domainTitle}`;

        // Initialize entry in the map if it doesn't exist
        if (!courseMap.has(key)) {
          courseMap.set(key, {
            CourseId: lecture.course?.id,
            Course: courseTitle,
            Domain: domainTitle,
            Urls: new Set<string>()
          });
        }

        // Collect URLs from the lecture
        lecture.pages?.forEach((page) => {
          if (page.assetUrl && isValidUrl(page.assetUrl)) urlSet.add(page.assetUrl);
          if (page.video && isValidUrl(page.video)) urlSet.add(page.video);

          page.images?.forEach((img) => {
            if (isValidUrl(img)) urlSet.add(img);
          });
        });

        // Add URLs to the course/domain entry
        const entry = courseMap.get(key);
        urlSet.forEach((url) => entry.Urls.add(url));
      });

      // Convert the map to the final report format
      courseMap.forEach((entry, key) => {
        const report = {
          CourseId: entry.CourseId,
          Course: entry.Course,
          Domain: entry.Domain,
          Count: entry.Urls.size
        };

        if (report.Count > 0) {
          reports.push(report);
        }
      });

      const converter = new Json2Excel(reports, null, 'LecturesWithMissingMinio');
      converter.sheet = 'LecturesWithMissingMinio';

      const path = await converter.convert();
      const buffer = readFileSync(path);

      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=LecturesWithMissingMinio.xlsx');

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; LecturesWithMissingMinio.xlsx`,
        'Content-Length': buffer.length
      });

      return res.end(buffer);
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }
}
