import { Base64Image, ImageHandler, ImageUtils } from '@edorer/image';
import { CanExecuteScript } from '@edorer/script-data';
import { Exam, examRepository } from '@edorer/exam-data';
import { ExportExamsForVec } from '../services/ExportExamsForVec';
import { FileUtils } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { parse } from 'node-html-parser';
import { Question, questionRepository } from '@edorer/question-data';
import { QuestionUtils } from '@edorer/question-api';
import { Validate } from '@edorer/validator';
import { writeFileSync } from 'fs';

@JsonController()
export class ScriptQuestionController {
  @Get('/scripts/check-questions-with-issues/:university')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackScores(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const exams: Exam[] = await examRepository.find({ university }).populate({ path: 'questions' }).lean();

      const response: { [key: string]: string } = {};

      for (let exam of exams) {
        const defectedQuestions = [];

        const { questions } = exam;

        for (let index = 0; index < questions.length; index++) {
          const question: Question = questions[index];
          const { options } = question;

          const correctOptions = options.map((option) => option.isCorrect).filter((option) => !!option).length;

          if (correctOptions === 0 || correctOptions > 1) {
            defectedQuestions.push(index + 1);
          }
        }

        response[exam.title] = defectedQuestions.join(', ');
      }
      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send(response);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/export-questions-by-university/:university')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    },
    {
      field: 'owner',
      validation: [{ value: 'notEmpty', message: 'Owner is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async exportUniversityQuestions(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const { owner } = req.body;

      const path = process.env.TEMP_DIR + 'questions';
      await FileUtils.removeDirectory(path);
      FileUtils.createDirectory(path);

      const exams: Exam[] = await examRepository.find({ university }).lean();

      const groupQuestions = [];

      for (let index = 0; index < exams.length; index++) {
        const exam = exams[index];

        const exportExamsForVec = new ExportExamsForVec(exam, owner);
        const convertedExam: any = exportExamsForVec.convert();

        groupQuestions.push(...convertedExam.groupQuestions);

        writeFileSync(path + '/' + 'exams-' + (index + 1) + '.json', JSON.stringify(convertedExam));
      }

      writeFileSync(path + '/' + 'groupQuestions.json', JSON.stringify(groupQuestions));

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Request sent to export' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-question-points')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixQuestionPoints(@Req() req: any, @Res() res: any) {
    try {
      await questionRepository.update(
        { point: { $eq: 0 }, points: { $exists: false } },
        { $set: { points: { positive: 0, negative: 0 } } },
        { multi: true }
      );

      await questionRepository.update(
        { point: { $eq: 1 }, points: { $exists: false } },
        { $set: { points: { positive: 1, negative: 0 } } },
        { multi: true }
      );

      await questionRepository.update(
        { point: { $exists: false }, points: { $exists: false } },
        { $set: { points: { positive: 1, negative: 0 } } },
        { multi: true }
      );

      const withPointQuestions = await questionRepository.find({ point: { $exists: true }, points: { $exists: false } }).lean();
      for (let question of withPointQuestions) {
        await questionRepository.update({ _id: question._id }, { $set: { points: { positive: question.point, negative: 0 } } }, { multi: false });
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Questions updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-question-categories/:examId')
  @Validate([
    {
      field: 'examId',
      validation: [{ value: 'notEmpty', message: 'Exam ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixQuestionCategory(@Req() req: any, @Res() res: any, @Param('examId') examId: string) {
    try {
      const exam: Exam = await examRepository.findOne({ _id: examId }).lean();
      const category = '63d3bc99597505f049f94e71';
      const subCategory = '63d3bcafc32d44f0ebcca9af';

      await questionRepository.update({ _id: { $in: exam.questions } }, { $set: { category, subCategory } }, { multi: true });

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Category updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-question-images-by-exam/:examId([0-9a-f]{24})')
  @Validate([
    {
      field: 'examId',
      validation: [{ value: 'notEmpty', message: 'Exam ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixQuestionImages(@Req() req: any, @Res() res: any, @Param('examId') examId: string) {
    try {
      const exam: Exam = await examRepository.findOne({ _id: examId }).lean();
      const questions: Question[] = await questionRepository.find({ _id: { $in: exam.questions } }).lean();

      for (let question of questions) {
        await questionRepository.update({ _id: question._id }, { $set: { oldContent: question.content } }, { multi: false });

        const base64Images = question.content.match(/src=\"data:image\/([a-zA-Z]*);base64,([^\"]*)\"/g);
        if (base64Images) {
          for (let base64image of base64Images) {
            let baseImage = base64image.replace('src="', '').replace('"', '');
            let image = Base64Image.decode(baseImage);
            if (ImageUtils.isValid(image)) {
              let handler = new ImageHandler(image);
              await handler.prepareUploadingS3().wait();
              question.content = question.content.replace(baseImage, handler.displayResult().url);
            }
          }
        }

        await questionRepository.update({ _id: question._id }, { $set: { content: question.content } }, { multi: false });
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Questions updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/parse-question-content/:examId([0-9a-f]{24})')
  @Validate([
    {
      field: 'examId',
      validation: [{ value: 'notEmpty', message: 'Exam ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async parseQuestionContent(@Req() req: any, @Res() res: any, @Param('examId') examId: string) {
    try {
      const exam: Exam = await examRepository.findOne({ _id: examId }).lean();
      const questions: Question[] = await questionRepository.find({ _id: { $in: exam.questions } }).lean();

      for (let question of questions) {
        const textContent = QuestionUtils.convertHtmlToText(parse(question.content).innerText);
        await questionRepository.update({ _id: question._id }, { $set: { textContent } }, { multi: false });
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Questions updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
