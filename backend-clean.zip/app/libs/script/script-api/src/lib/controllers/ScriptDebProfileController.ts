import { CanExecuteScript } from '@edorer/script-data';
import { DebStudentIdCardGenerator } from '@edorer/deb-student-profile-api';
import { DebToLms, debToLmsRepository } from '@edorer/deb-to-lms-data';
import { existsSync, readFileSync, unlinkSync } from 'fs';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { S3University } from '@edorer/s3';
import { universityConfigurationRepository } from '@edorer/university-data';
import { v4 } from 'uuid';

@JsonController()
export class ScriptDebProfileController {
  @Get('/scripts/upload-deb-profile-id-card')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async updateProfileIds(@Req() req: any, @Res() res: any) {
    try {
      // Find profiles that need ID cards
      const profiles: DebToLms[] = await debToLmsRepository.find({ idCardUrl: { $exists: false } }).lean();

      if (!profiles.length) {
        return res.status(200).send({ message: 'No profiles need ID cards' });
      }

      console.log(`Processing ${profiles.length} profiles...`);

      const bulkOperations = [];
      const universityConfigCache = {};
      let processedCount = 0;

      // Process profiles in smaller batches to prevent memory issues
      const BATCH_SIZE = 50;
      for (let i = 0; i < profiles.length; i += BATCH_SIZE) {
        const batch = profiles.slice(i, Math.min(i + BATCH_SIZE, profiles.length));

        // Process each profile in the batch
        for (const profile of batch) {
          const profileId = profile._id;

          try {
            // Get university config (from cache if available)
            let universityConfig = universityConfigCache[profile.university];
            if (!universityConfig) {
              universityConfig = await universityConfigurationRepository.findOne({ university: profile.university }).lean();

              if (!universityConfig) continue;

              universityConfigCache[profile.university] = universityConfig;
            }

            // Generate ID card
            const generator = new DebStudentIdCardGenerator(profileId);
            const pdfPath = await generator.generate();

            try {
              // Upload to S3
              const buffer = readFileSync(pdfPath);
              const s3 = new S3University(universityConfig);
              const filename = `deb-id-card-${v4()}-${profileId}.pdf`;
              const idCardUrl = await s3.uploadBuffer(buffer, filename, universityConfig.buckets.ASSETS);

              // Add to bulk update operation
              bulkOperations.push({
                updateOne: {
                  filter: { _id: profileId },
                  update: { $set: { idCardUrl } }
                }
              });

              processedCount++;
            } finally {
              // Clean up temporary file regardless of success/failure
              try {
                if (existsSync(pdfPath)) {
                  unlinkSync(pdfPath);
                }
              } catch (err) {
                console.warn(`Failed to delete temporary file ${pdfPath}`);
              }
            }
          } catch (profileError) {
            console.error(`Error processing profile ${profileId}:`, profileError);
            // Continue with other profiles
          }
        }

        // Save progress periodically to avoid losing work if script times out
        if (bulkOperations.length >= 100) {
          await debToLmsRepository.bulkWrite(bulkOperations);
          console.log(`Saved batch of ${bulkOperations.length} updates`);
          bulkOperations.length = 0; // Clear array while maintaining reference
        }
      }

      // Save any remaining operations
      if (bulkOperations.length > 0) {
        await debToLmsRepository.bulkWrite(bulkOperations);
      }

      return res.status(200).send({
        message: 'ID cards generated and uploaded',
        processed: processedCount,
        total: profiles.length
      });
    } catch (error: any) {
      console.error('Failed to process ID cards:', error);
      return res.status(500).send({ error: error.message });
    }
  }
}
