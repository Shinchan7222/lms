import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { LiveClassRoom, liveClassRoomRepository } from '@edorer/live-class-room-data';
import { VideoSession, VideoSessionTypes, videoSessionRepository } from '@edorer/video-session-data';
import * as moment from 'moment';
import axios from 'axios';

@JsonController()
export class ScriptLiveClassRoomController {
  @Post('/scripts/add-video-session-to-live-class-rooms')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addVideoSessionToWebinar(@Req() req: any, @Res() res: any) {
    try {
      const liveClassRooms = await liveClassRoomRepository
        .find({
          endTime: { $exists: true },
          startTime: { $exists: true },
          videoSession: { $exists: false }
        })
        .lean();
      for (let liveClassRoom of liveClassRooms) {
        const videoSession = await videoSessionRepository.create({
          createdAt: liveClassRoom.createdAt,
          duration: moment(liveClassRoom.endTime).diff(liveClassRoom.startTime, 'seconds'),
          endDateTime: liveClassRoom.endTime,
          owner: liveClassRoom.teacher,
          participants: [],
          sessionType: VideoSessionTypes.LIVE_CLASS_ROOM,
          speakers: [liveClassRoom.teacher],
          startDateTime: liveClassRoom.startTime,
          // tslint:disable-next-line:max-line-length
          status: liveClassRoom.status === 'not started' ? 'upcoming' : liveClassRoom.status === 'started' ? 'ended' : liveClassRoom.status,
          university: liveClassRoom.university,
          updatedAt: liveClassRoom.updatedAt
        });

        await liveClassRoomRepository.update({ _id: liveClassRoom._id }, { $set: { videoSession: videoSession._id } }, { multi: false });
      }

      return res.status(201).send({ message: 'Video Session added successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-live-class-room-titles')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixLiveClassRoomTitles(@Req() req: any, @Res() res: any) {
    try {
      const liveClassRooms: LiveClassRoom[] = await liveClassRoomRepository
        .find({ course: { $exists: true, $ne: null } })
        .populate({ path: 'course', select: 'title' })
        .lean();

      for (let liveClassRoom of liveClassRooms) {
        if (liveClassRoom.course && liveClassRoom.course.title) {
          const title = liveClassRoom.course.title + ' (Course)';

          await liveClassRoomRepository.update({ _id: liveClassRoom._id }, { $set: { title } }, { multi: false });
        }
      }

      return res.status(201).send({ message: 'Title fixed successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-live-class-room-classes')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixLiveClassRoomClasses(@Req() req: any, @Res() res: any) {
    try {
      const liveClassRooms = await liveClassRoomRepository.find({ class: { $exists: true, $ne: null } }).lean();

      for (let liveClassRoom of liveClassRooms) {
        await liveClassRoomRepository.update({ _id: liveClassRoom._id }, { $set: { classes: [liveClassRoom.class] } }, { multi: true });
      }

      return res.status(201).send({ message: 'Classes fixed successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/add-live-class-room-dates')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addLiveClassRoomDates(@Req() req: any, @Res() res: any) {
    try {
      const liveClassrooms = await liveClassRoomRepository
        .find({ endDateTime: { $exists: false }, startDateTime: { $exists: false }, videoSession: { $exists: true } })
        .populate('videoSession')
        .lean();

      for (let liveClassroom of liveClassrooms) {
        if (liveClassroom.videoSession && liveClassroom.videoSession.endDateTime && liveClassroom.videoSession.startDateTime) {
          await liveClassRoomRepository.update(
            { _id: liveClassroom._id },
            {
              $set: {
                endDateTime: liveClassroom.videoSession.endDateTime,
                startDateTime: liveClassroom.videoSession.startDateTime
              }
            },
            { multi: false }
          );
        }
      }

      return res.status(201).send({ message: 'Classroom fixed successfully.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/delete-live-classroom-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async deleteCourseAssets(@Req() req: any, @Res() res: any) {
    try {
      const liveClassrooms: LiveClassRoom[] = await liveClassRoomRepository
        .findWithDeleted({
          videoSession: { $exists: true },
          university: '5ffda431be794b82dd8d1281'
        })
        .select('videoSession')
        .lean();

      let urls = [];

      const videoSessions: VideoSession[] = await videoSessionRepository
        .findWithDeleted({ _id: { $in: liveClassrooms.flatMap((o) => o.videoSession) } })
        .select('recordedURLs recordURL')
        .lean();

      for (let videoSession of videoSessions) {
        if (videoSession.recordURL) urls.push(videoSession.recordURL);
        if (videoSession.recordedURLs) urls = urls.concat(videoSession.recordedURLs);

        urls = urls.filter(Boolean);
        urls = [...new Set(urls)];
      }

      urls = urls.filter((url) => url.startsWith('https://s3.ap-south-1.amazonaws.com/'));

      let deletedUrl = 0;
      // const minIO = new MinIO();
      // let minIO: any;
      // for (let url of urls) {
      //     try {
      //         await minIO.delete(url);
      //     } catch (error) {
      //         console.error(`Could not delete ${url}`);
      //     } finally {
      //         deletedUrl++;
      //
      //     }
      // }

      await videoSessionRepository.update({ _id: { $in: videoSessions.flatMap((o) => o._id) } }, { $set: { deleted: true } });

      return res.status(400).send({ message: 'Sent' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/check-and-fix-video-sessions/:university([0-9a-f]{24})')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async checkAndFixSessionVideos(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const liveClassrooms: LiveClassRoom[] = await liveClassRoomRepository
        .find({
          startDateTime: { $gte: moment().subtract(1, 'months').toDate(), $lte: moment().toDate() },
          // university: '5ffda431be794b82dd8d1281',
          university,
          videoSession: { $exists: true }
        })
        .populate({ path: 'videoSession', select: 'status recordURL' })
        .lean();

      const bulkOperations = [];

      for (let liveClassroom of liveClassrooms) {
        const { videoSession } = liveClassroom;
        if (!videoSession) continue;

        if (typeof videoSession === 'string') continue;

        const { status, recordURL } = videoSession;
        if (recordURL) continue;
        if (status !== 'ended') continue;

        try {
          const recordURL = `https://storage.googleapis.com/parul-session-recordings/${liveClassroom._id}.mp4`;
          await axios.head(recordURL);

          bulkOperations.push({
            updateOne: {
              filter: { _id: videoSession._id },
              update: { $set: { recordURL } }
            }
          });
        } catch (error) {
          console.error(error);
        }
      }

      if (bulkOperations.length) {
        await videoSessionRepository.bulkWrite(bulkOperations);
      }

      return res.status(400).send({ message: 'Sent' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/move-subject-to-subjects')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async subjectToSubjects(@Req() req: any, @Res() res: any) {
    try {
      const liveClassrooms = await liveClassRoomRepository.find({ subject: { $exists: true, $ne: null } }).lean();

      const bulkOperations = [];

      for (let liveClassroom of liveClassrooms) {
        try {
          bulkOperations.push({
            updateOne: {
              filter: { _id: liveClassroom._id },
              update: { $set: { subjects: [liveClassroom.subject] } }
            }
          });
        } catch (error) {
          console.error(error);
        }
      }

      if (bulkOperations.length) {
        await liveClassRoomRepository.bulkWrite(bulkOperations);
      }

      return res.status(400).send({ message: 'Moved' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/attach-live-classroom-ids')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async attachIds(@Req() req: any, @Res() res: any) {
    try {
      let id = await liveClassRoomRepository.count({ id: { $exists: true, $ne: null } });
      const liveClassrooms = await liveClassRoomRepository.find({ id: { $exists: false } }).lean();

      const bulkOperations = [];

      for (let liveClassroom of liveClassrooms) {
        id++;

        bulkOperations.push({
          updateOne: {
            filter: { _id: liveClassroom._id },
            update: { $set: { id: String(id).padStart(6, '0') } }
          }
        });
      }

      if (bulkOperations.length) {
        await liveClassRoomRepository.bulkWrite(bulkOperations);
      }

      return res.status(200).send({ message: 'Attached' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
