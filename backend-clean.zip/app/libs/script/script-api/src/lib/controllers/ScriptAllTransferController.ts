import { assetsRepository } from '@edorer/assets-data';
import { CanExecuteScript } from '@edorer/script-data';
import { classroomWorkRepository } from '@edorer/classroom-work-data';
import { courseRepository } from '@edorer/course-data';
import { examRepository } from '@edorer/exam-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { lectureRepository } from '@edorer/lecture-data';
import { programRepository } from '@edorer/program-data';
import { programResultRepository } from '@edorer/program-result-data';
import { questionRepository } from '@edorer/question-data';
import { TransferAssets } from '../services/TransferAssets';
import { TransferClassroomWorks } from '../services/TransferClassroomWorks';
import { TransferCourseAssets } from '../services/TransferCourseAssets';
import { TransferCourseLectures } from '../services/TransferCourseLectures';
import { TransferExamAssets } from '../services/TransferExamAssets';
import { TransferProgramAssets } from '../services/TransferProgramAssets';
import { TransferProgramResults } from '../services/TransferProgramResults';
import { TransferQuestionAssets } from '../services/TransferQuestionAssets';
import { TransferUserDynamics } from '../services/TransferUserDynamics';
import { universityConfigurationRepository, universityRepository } from '@edorer/university-data';
import { userDynamicDataRepository } from '@edorer/user-dynamic-data';

@JsonController()
export class ScriptAllTransferController {
  @Get('/scripts/transfer-all-courses-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferCourseAssets(@Req() req: any, @Res() res: any) {
    const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

    try {
      for (let university of universities) {
        const courses = await courseRepository
          .find({
            $or: [{ intro: { $exists: true, $ne: null } }, { 'galleries.0': { $exists: true, $ne: null } }],
            university
          })
          .select('galleries intro')
          .sort({ createdAt: -1 })
          .lean();

        if (!courses.length) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig.length) continue;

        const transferer = new TransferCourseAssets(courses, universityConfig);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-exams-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferExamAssets(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const exams = await examRepository
          .find({ logo: { $exists: true, $ne: null }, university })
          .select('logo')
          .sort({ createdAt: -1 })
          .lean();

        if (!exams.length) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferExamAssets(exams, universityConfig);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer exams error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-programs-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferProgramAssets(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const programs = await programRepository
          .find({
            $or: [{ backgroundImage: { $exists: true, $ne: null } }, { intro: { $exists: true, $ne: null } }, { logo: { $exists: true, $ne: null } }],
            university
          })
          .select('backgroundImage intro logo')
          .sort({ createdAt: -1 })
          .lean();

        if (!programs.length) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferProgramAssets(programs, universityConfig);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer programs error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-lectures-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferLectureAssets(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const courses = await courseRepository.distinct('_id', { university });

        const lectures = await lectureRepository
          .find({
            'pages.contentType': { $in: ['document', 'video'] },
            $or: [
              { 'pages.assetUrl': { $regex: 'amazonaws.com' } },
              { 'pages.images': { $regex: 'amazonaws.com' } },
              { 'pages.video': { $regex: 'amazonaws.com' } }
            ],
            course: { $in: courses }
          })
          .sort({ createdAt: -1 })
          .lean();

        if (!lectures.length) continue;

        const uni = await universityRepository.findOne({ _id: university }).lean();
        if (!uni) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferCourseLectures(lectures, uni, universityConfig, false);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer course lectures error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-questions-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferQuestionAssets(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const exams = await examRepository.find({ university }).select('_id').lean();

        const questions = await questionRepository
          .find({
            $or: [{ content: { $regex: 'amazonaws.com' } }],
            exam: { $in: exams.map((exam) => exam._id) }
          })
          .sort({ createdAt: -1 })
          .lean();

        if (!questions.length) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferQuestionAssets(questions, universityConfig);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer questions error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferAssets(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const assets = await assetsRepository
          .find({
            $or: [{ url: { $regex: 'amazonaws.com' } }],
            university
          })
          .select('url')
          .sort({ createdAt: -1 })
          .lean();

        if (!assets.length) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferAssets(assets, universityConfig);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-university-assets')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferAllAssets(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const assets = await assetsRepository
          .find({ $or: [{ url: { $regex: 'amazonaws.com' } }], university })
          .select('url')
          .sort({ createdAt: -1 })
          .lean();

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferAssets(assets, universityConfig);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-dynamic-data')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferExtras(@Req() req: any, @Res() res: any) {
    try {
      const assets = await userDynamicDataRepository
        .find({ 'data.value': { $regex: 'amazonaws.com' } })
        .select('data')
        .sort({ createdAt: -1 })
        .lean();

      if (!assets.length) return;

      const universityConfig = await universityConfigurationRepository.findOne({}).lean();
      if (!universityConfig) return;

      const transferer = new TransferUserDynamics(assets, universityConfig);
      await transferer.transfer();

      return res.status(200).send({ message: 'Assets transferred successfully' });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-classroom-works')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferClassroomWorks(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const classroomWorks = await classroomWorkRepository
          .find({
            $or: [{ document: { $regex: 'amazonaws.com' } }, { images: { $regex: 'amazonaws.com' } }, { video: { $regex: 'amazonaws.com' } }],
            university
          })
          .sort({ createdAt: 1 })
          .lean();

        if (!classroomWorks.length) continue;

        const uni = await universityRepository.findOne({ _id: university }).lean();
        if (!uni) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferClassroomWorks(classroomWorks, uni, universityConfig, false);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Classroom works transferred successfully' });
    } catch (error: any) {
      console.error('Transfer course error:', error);

      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/scripts/transfer-all-program-results')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferProgramResults(@Req() req: any, @Res() res: any) {
    try {
      const universities = await universityConfigurationRepository.distinct('university', { university: { $exists: true, $ne: null } });

      for (let university of universities) {
        const programResults = await programResultRepository
          .find({ dmc: { $regex: 'amazonaws.com' }, university })
          .sort({ createdAt: -1 })
          .lean();

        if (!programResults.length) continue;

        const uni = await universityRepository.findOne({ _id: university }).lean();
        if (!uni) continue;

        const universityConfig = await universityConfigurationRepository.findOne({ university }).lean();
        if (!universityConfig) continue;

        const transferer = new TransferProgramResults(programResults, uni, universityConfig);
        await transferer.transfer();
      }

      return res.status(200).send({ message: 'Program results transferred successfully' });
    } catch (error: any) {
      console.error('Transfer result error:', error);

      return res.status(400).send({ error: error.message });
    }
  }
}
