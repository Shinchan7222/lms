import { CanExecuteScript } from '@edorer/script-data';
import { courseRepository } from '@edorer/course-data';
import { DistinctFacade } from '@edorer/generic-facades';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Program, programRepository } from '@edorer/program-data';
import { ProgramEnrollment } from '@edorer/student-api';
import { ProgramResult, programResultRepository } from '@edorer/program-result-data';
import { trackCourseRepository } from '@edorer/track-course-data';
import { TrackProgram, trackProgramRepository } from '@edorer/track-program-data';
import { User, UserTypes, userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import moment = require('moment-timezone');

@JsonController()
export class ScriptProgramController {
  @Post('/scripts/attach-id-to-programs')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async attachIdToPrograms(@Req() req: any, @Res() res: any) {
    const { university } = req.body;

    try {
      const programs = await programRepository.find({ university });
      for (let program of programs) {
        await program.generateNewId();
        await program.save();
      }

      return res.send({ message: 'done' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/scripts/add-track-programs')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addTrackPrograms(@Req() req: any, @Res() res: any) {
    try {
      const { university } = req.body;

      const programs = await programRepository.find({ university }).lean();
      for (let program of programs) {
        const { students } = program;
        if (students.length > 0) {
          await userRepository.update({ _id: { $in: students } }, { $addToSet: { programs: program._id } }, { multi: true });
        }

        for (let student of students) {
          const trackProgram = await trackProgramRepository.count({ user: student, program: program._id });
          if (trackProgram === 0) {
            const enroll = new ProgramEnrollment(null, [], null, program._id, [student]);
            await enroll.enroll();
          }
        }
      }

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-track-programs')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackPrograms(@Req() req: any, @Res() res: any) {
    try {
      const students = await programRepository.distinct('students', { _id: '660a7730822d6e001226aade' });

      const users = [];

      for (let user of students) {
        const trackProgram = await trackProgramRepository.count({ user, program: '660a7730822d6e001226aade' });
        if (trackProgram !== 0) continue;

        users.push(user);
      }

      if (users.length !== 0) {
        await programRepository.update({ _id: '660a7730822d6e001226aade' }, { $pull: { students: { $in: users } } }, { multi: false });
        await userRepository.update({ _id: { $in: users } }, { $pull: { programs: { $in: ['660a7730822d6e001226aade'] } } }, { multi: true });
      }

      return res.status(200).send({ message: 'Added' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-track-program-courses/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackProgramCourses(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const program: Program = await programRepository.findOne({ _id: programId }).lean();
      const trackPrograms: TrackProgram[] = await trackProgramRepository.find({ program: programId }).lean();

      for (let trackProgram of trackPrograms) {
        const { curriculum } = program;
        const { currentYear, currentStep, user } = trackProgram;

        const { yearData } = curriculum[currentYear - 1];
        const semester = yearData[currentStep - 1];

        const availableCourses = semester.data.map((entry) => entry.course);

        await trackProgramRepository.update({ _id: trackProgram._id }, { $set: { availableCourses } }, { multi: false });

        await userRepository.update({ _id: user }, { $set: { courses: availableCourses } }, { multi: true });

        await courseRepository.update({ students: { $in: [user] } }, { $pull: { students: user } }, { multi: true });

        await courseRepository.update({ _id: { $in: availableCourses } }, { $addToSet: { students: [user] } }, { multi: true });

        await trackCourseRepository.update({ course: { $nin: availableCourses }, user }, { $set: { deleted: true } }, { multi: true });
      }

      return res.status(200).send({ message: 'Track program courses updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-program-results/:programId([0-9a-f]{24})')
  @Validate([
    {
      field: 'programId',
      validation: [{ value: 'notEmpty', message: 'Program is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixProgramResults(@Req() req: any, @Res() res: any, @Param('programId') programId: string) {
    try {
      const users = await programResultRepository.distinct('user', { program: programId });

      for (let user of users) {
        const result: ProgramResult = await programResultRepository
          .findOne({ dms: { $ne: '' }, program: programId, user })
          .sort({ createdAt: 1 })
          .lean();

        if (!result) continue;

        await programResultRepository.update({ program: programId, user, _id: { $ne: result._id } }, { $set: { deleted: true } }, { multi: true });
      }

      return res.status(200).send({ message: 'Result updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-program-enrollments')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixProgramEnrollments(@Req() req: any, @Res() res: any) {
    try {
      const { university } = req.body;

      const users: User[] = await userRepository.find({ university, type: UserTypes.STUDENT, 'programs.0': { $exists: true } }).lean();

      for (let user of users) {
        await programRepository.update({ students: { $in: [user._id] } }, { $pull: { students: { $in: [user._id] } } }, { multi: true });
        await programRepository.update({ _id: { $in: user.programs } }, { $addToSet: { students: user._id } }, { multi: true });
      }

      return res.status(200).send({ message: 'Updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/remove-duplicate-program-results')
  @Validate([
    {
      field: 'program',
      validation: [{ value: 'notEmpty', message: 'Program is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeDuplicateResults(@Req() req: any, @Res() res: any) {
    try {
      const { program } = req.body;

      const facade = new DistinctFacade(null, null, 'user', null, [], programResultRepository);
      facade.addConditions({ program });

      const users = await facade.create();

      for (let user of users) {
        const result = await programResultRepository.findOneWithDeleted({ user, program }).sort({ createdAt: -1 }).lean();

        if (!result) continue;

        // await programResultRepository.update({ user, program, dmc: { $eq: '' } }, { $set: { deleted: true } }, { multi: true });
        await programResultRepository.update({ user, program, _id: { $ne: result._id } }, { $set: { deleted: true } }, { multi: true });
      }

      // { dmc: new RegExp('https://s3.ap-south-1.amazonaws.com/lms-parul-media/232275', 'i') }, { $set: { deleted: false } })

      return res.status(200).send({ message: 'Deleted' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-program-enrollments-new')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixPrograms(@Req() req: any, @Res() res: any) {
    try {
      const facade = new DistinctFacade(null, null, 'program', null, [], trackProgramRepository);
      const programs = await facade.addConditions({ createdAt: { $gte: moment().startOf('D') } }).create();

      for (let program of programs) {
        const facade = new DistinctFacade(null, null, 'user', null, [], trackProgramRepository);
        const users = await facade.addConditions({ createdAt: { $gte: moment().startOf('D') }, program }).create();

        await programRepository.update({ _id: program }, { $pull: { students: { $in: users } } }, { multi: true });
        await userRepository.update({ _id: { $in: users } }, { $pull: { programs: { $in: [program] } } }, { multi: true });
        await trackProgramRepository.update({ program, user: { $in: users } }, { $set: { deleted: true } }, { multi: true });
      }

      return res.status(200).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
