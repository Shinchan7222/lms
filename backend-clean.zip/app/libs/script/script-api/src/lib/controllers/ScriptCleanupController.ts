import { CanExecuteScript } from '@edorer/script-data';
import { CleanupDeletedCourses } from '../services/CleanupDeletedCourses';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptCleanupController {
  @Post('/scripts/cleanup-deleted-courses/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'university is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async cleanupDeletedCourses(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const facade = new CleanupDeletedCourses(university);
      await facade.cleanup();

      return res.status(200).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
