import { Assets, assetsRepository } from '@edorer/assets-data';
import { CanExecuteScript } from '@edorer/script-data';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils, StringUtils } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { universityConfigurationRepository } from '@edorer/university-data';
import { v4 as uui } from 'uuid';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptAssetController {
  @Get('/scripts/transfer-assets')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferAssets(@Req() req: any, @Res() res: any) {
    const { limit } = req.query;

    try {
      const assets: Assets[] = await assetsRepository
        .find({
          $or: [{ url: new RegExp('https://s3-ap-south-1.amazonaws.com', 'i') }, { url: new RegExp('https://minio.paruluniversity.ac.in', 'i') }]
        })
        .limit(limit)
        .lean();

      const universityConfig = await universityConfigurationRepository.findOne({ university: '61d28e1a940446002a51f59b' }).lean();

      if (!universityConfig) {
        return res.status(400).send({ error: 'University configuration not found' });
      }

      for (let asset of assets) {
        try {
          const url = asset.url;
          const downloader = new Downloader(url);
          const downloadedUrl = await downloader.download();

          if (typeof downloadedUrl === 'string' && FileUtils.readFile(downloadedUrl).length > 0) {
            const filename = StringUtils.slug(url.split('/').pop()) + '.' + url.split('.').pop();

            const s3 = new S3University(universityConfig, true);
            const uploadedUrl = await s3.uploadBuffer(
              FileUtils.readFile(downloadedUrl),
              uui() + '-' + filename,
              universityConfig.buckets.LMS_COURSE_VIDEOS
            );

            await assetsRepository.update({ _id: asset._id }, { $set: { url: uploadedUrl } });
          }

          if (FileUtils.fileExists(downloadedUrl)) {
            FileUtils.removeFile(downloadedUrl);
          }
        } catch {}
      }

      return res.status(200).send({
        message: 'Assets transferred successfully'
      });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
