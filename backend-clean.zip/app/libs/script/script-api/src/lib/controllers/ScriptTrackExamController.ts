const AdmZip = require('adm-zip');
import { abandoningTrackExam } from '@edorer/track-exam-cron';
import { AIFixFormatter } from '@edorer/track-exam-api';
import { CanExecuteScript } from '@edorer/script-data';
import { classRepository } from '@edorer/class-data';
import { classroomWorkRepository } from '@edorer/classroom-work-data';
import { CodeCompiler } from '@edorer/compiler';
import { courseRepository } from '@edorer/course-data';
import { Downloader, S3University } from '@edorer/s3';
import { examRepository } from '@edorer/exam-data';
import { existsSync, readdirSync, readFileSync, writeFileSync } from 'fs';
import { FileUtils, Json2Excel } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { lectureRepository } from '@edorer/lecture-data';
import { mailer } from '@edorer/mailer';
import { MigrationUtils } from '../services/MigrationUtils';
import { Open } from 'unzipper';
import { ProctorRequest, proctorRequestRepository } from '@edorer/proctor-request-data';
import { Question, questionRepository, QuestionTypes } from '@edorer/question-data';
import { ReviewRequest, reviewRequestRepository, ReviewRequestTypes } from '@edorer/review-request-data';
import { subjectRepository } from '@edorer/subject-data';
import { TrackExam, TrackExamAnswer, TrackExamStatus, trackExamRepository } from '@edorer/track-exam-data';
import { TrackExamAddAnswer } from '@edorer/track-exam-api';
import { Types } from 'mongoose';
import { UniversityConfiguration, universityConfigurationRepository } from '@edorer/university-data';
import { v4 as uuidV4 } from 'uuid';
import { Validate } from '@edorer/validator';
import * as moment from 'moment';
import axios from 'axios';

@JsonController()
export class ScriptTrackExamController {
  @Get('/scripts/fix-track-scores/:exam')
  @Validate([
    {
      field: 'exam',
      validation: [{ value: 'notEmpty', message: 'Exam ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackScores(@Res() res: any, @Param('exam') exam: string) {
    res.connection.setTimeout(0);

    try {
      setTimeout(async () => {
        const trackExams: TrackExam[] = await trackExamRepository
          .find({ exam })
          .populate({ path: 'questions', select: 'points' })
          .populate({ path: 'user', select: 'email' })
          .select('answers user questions')
          .sort({ startedAt: -1 })
          .lean();

        for (let trackExam of trackExams) {
          const questionsPoint = trackExam.questions.reduce((acc: number, question: Question) => {
            return acc + question.points.positive;
          }, 0);

          const score = trackExam.answers.reduce((acc, curr) => acc + curr.point, 0);
          const percentage = +Number((score / questionsPoint) * 100).toFixed(2);

          await trackExamRepository.update({ _id: trackExam._id }, { $set: { percentage, score } }, { multi: false });
        }

        console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');
      }, 1000);

      return res.status(201).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-track-abandon-end-time')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackAbandonEndTime(@Res() res: any) {
    res.connection.setTimeout(0);
    try {
      setTimeout(async () => {
        const trackExams: TrackExam[] = await trackExamRepository
          .find({ endsAt: { $exists: true }, status: TrackExamStatus.ABANDONED })
          .sort({ startedAt: -1 })
          .lean();

        for (let trackExam of trackExams) {
          await trackExamRepository.update({ _id: trackExam._id }, { $set: { endedAt: trackExam.endsAt } }, { multi: false });
        }

        console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');
      }, 1000);

      return res.status(201).send({ message: 'Requested to modify' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/abandon-track-exams')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async abandonTrackExams(@Res() res: any) {
    try {
      await abandoningTrackExam.init();

      return res.status(200).send({ message: 'Tracks abandoned successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/count-unique-track-users/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async countUniqueTrackUsers(@Res() res: any, @Param('university') university: string) {
    try {
      const excludedExamIds = [
        '61d9a4b4c5ad300027a0fcb4',
        '61d9ae1bc5ad300027a0fede',
        '61d9ae3031f197002e9aaf59',
        '61e119e2ccedba001eecb95a',
        '61f0d95b490b77002b6ed5b5',
        '61e11a5b6f238f00337de74d',
        '61e11b1968a201002c3520f7',
        '61e11ac4ccedba001eecb978'
      ];

      const exams = await examRepository
        .find({ _id: { $nin: excludedExamIds }, university: Types.ObjectId(university) })
        .select('_id')
        .lean();

      const examIds = exams.map((exam) => Types.ObjectId(exam._id));

      const users: string[] = await trackExamRepository.distinct('user', { exam: { $in: examIds } });

      return res.status(200).send({ count: users.length });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-track-exam-answers/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackExamAnswers(@Res() res: any, @Param('university') university: string) {
    try {
      const trackExams: TrackExam[] = await trackExamRepository
        .find({ university: Types.ObjectId(university) })
        .select('_id answers questions')
        .lean();

      for (let trackExam of trackExams) {
        const answers = trackExam.answers.reverse();
        const answerMap: { [key: string]: any } = {};

        for (let answer of answers) {
          const question = answer.questionId.toString();
          if (!(question in answerMap)) {
            answerMap[question] = answer;
          }
        }

        await trackExamRepository.update({ _id: trackExam._id }, { $set: { answers: Object.values(answerMap) } }, { multi: false });
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Answers updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/add-track-exam-users')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addTrackExamUsers(@Req() req: any, @Res() res: any) {
    try {
      console.warn('WORKING WITH ==>', this.addTrackExamUsers.name);
      const { limit, skip } = req.body;

      const trackExams = await trackExamRepository
        .find({
          $or: [{ user: { $exists: false } }, { user: { $eq: null } }],
          university: { $exists: true, $ne: null }
        })
        .limit(+limit)
        .skip(+skip * +limit)
        .lean();

      console.warn('TRACKS LENGTH ==>', trackExams.length);

      for (let trackExam of trackExams) {
        trackExam.user = await MigrationUtils.createUserWithEmail(trackExam.email, trackExam.name, trackExam.university);
        await MigrationUtils.updateData('add track exams user', [trackExam], trackExamRepository);
      }

      console.warn('DONE WITH', this.addTrackExamUsers.name);

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Answers updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-track-exam-points-for-programming-questions/:examId([0-9a-f]{24})')
  @Validate([
    {
      field: 'examId',
      validation: [{ value: 'notEmpty', message: 'Exam ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackExamPointsForProgrammingQuestions(@Res() res: any, @Param('examId') examId: string) {
    try {
      console.warn('WORKING');
      const trackExams = await trackExamRepository
        .find({ 'answers.0': { $exists: true }, exam: examId })
        .populate({ path: 'questions' })
        .lean();

      for (let trackExam of trackExams) {
        const answers = trackExam.answers;

        for (let trackAnswer of answers) {
          let point = 0;
          const question = trackExam.questions.find((q) => String(q._id) === String(trackAnswer.questionId));
          const { compiledResult } = trackAnswer;
          const { visibleEvaluations, hiddenEvaluations } = compiledResult;

          for (let visibleEvaluation of visibleEvaluations) {
            const { expectedOutput, output } = visibleEvaluation;
            const option = question.options[0];

            if (expectedOutput === output) {
              point += option.point;
            } else {
              point += 0;
            }
          }

          for (let index = 0; index < hiddenEvaluations.length; index++) {
            const hiddenEvaluation = hiddenEvaluations[index];
            const { expectedOutput, output } = hiddenEvaluation;
            const option = question.options[index + 1];

            if (expectedOutput === output) {
              point += option.point;
            } else {
              point += 0;
            }
          }

          trackAnswer.point = point;
        }

        const questionPoint = trackExam.questions.reduce((acc: number, question: Question) => acc + question.points.positive, 0);
        const answerScore = trackExam.answers.reduce((acc: number, answer: TrackExamAnswer) => acc + answer.point, 0);

        const score = answerScore;
        const percentage = Math.max(0, Math.floor((answerScore / questionPoint) * 100));

        await trackExamRepository.update({ _id: trackExam._id }, { $set: { answers, percentage, score } }, { multi: false });
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Answers updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/get-track-exam-video-answers-urls')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async getTrackVideoAnswers(@Res() res: any) {
    try {
      const examIds = ['63999ff9cbd48b00241e5d57', '6399b54bcbd48b00241ebe2c', '639a04de20338b0022f3f22a', '639aaa99db0b45002bed2ee3'];
      const exams = await examRepository
        .find({ _id: { $in: examIds } })
        .select('title')
        .lean();

      const items = [];

      for (let exam of exams) {
        const { title } = exam;
        const trackExams: TrackExam[] = await trackExamRepository
          .find({
            exam: exam._id,
            startedAt: { $gte: moment('2023-01-28').startOf('day'), $lte: moment('2023-01-28').endOf('day') }
          })
          .populate({ path: 'user', select: 'email name' })
          .lean();

        for (let trackExam of trackExams) {
          const { answers, user } = trackExam;
          const videoAnswers = answers.filter((answer) => answer.videos.length > 0);

          const item: { [key: string]: string } = {
            'Exam Name': title || '',
            'Student Name': user.name || '',
            'Student Email': user.email || ''
          };

          for (let index = 0; index < videoAnswers.length; index++) {
            const videoAnswer = videoAnswers[index];
            item[`Video Answer ${index + 1}`] = videoAnswer.videos[0].url || '';
          }

          items.push(item);
        }
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      let converter = new Json2Excel(items);
      const reportPath = await converter.convert();
      const buffer = readFileSync(reportPath);
      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; applicants.xlsx`,
        'Content-Length': buffer.length
      });
      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/add-track-exam-answers/:trackExam')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async addAnswers(@Res() res: any, @Param('trackExam') trackExam: string) {
    try {
      const answers = [
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79d46'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79d76'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d5e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d66'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79d86'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79cce'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d16'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79cee'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d4e'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79d7e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d3e'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79d6e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79ce6'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79d2e'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79d36'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79d26'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d0e'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79cfe'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79cde'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79cc6'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d1e'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79cf6'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79d56'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79cd6'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79d06'
        },
        {
          answer: [
            '<p>On the topic has revealed people believe negative character traits and values dominate social media. According to a recent pointed out values like self-control, forgiveness, fairness, honesty, and humility were lacking on social media. People of all ages constantly use Instagram, Twitter, Tik Tok, and other media. No exploration of the media values could eschew the role of social media in particular. People feels these media the development of morals and healthy values. Many persons experience anxiety over the impact on their values and moral development. Almost they said negative character traits like hostility, anger, hatred, ignorance, and arrogance were frequently demonstrated.</p>'
          ],
          questionId: '61c22d9ce7229f0027c14cd6'
        },
        {
          answer: [
            '<p>Bilangan Penduduk dalam bandar ialah 1,500,000 orang.</p><p>Bilangan dewasa ialah 49000 lebih daripada kanak-kanak.</p><p>Bilang kanak-kanak ialah:</p><p><br></p><p>1,500,000/ 2</p><p>= 750,000 - 49000</p><p>Jawapan bilangan kanak-kanak ialah</p><p>=701,000 orang.</p>'
          ],
          questionId: '61cdedc360dcb2002315b727'
        },
        {
          answer: [
            '<p>Buat masa ini terdapat usaha-usaha Kerajaan dalam membantu warga emas yang telah menabur bakti kepada kemajuan negara. Bantuan Orang Tua berbentuk wang kepada warga emas yang boleh berdikari dan mempunyai tempat tinggal. Perkhidmatan institusi kepada golongan warga emas seperti Rumah Seri Kenangan untuk warga emas yang boleh berdikari, hidup sebatang kara dan tidak mempunyai tempat tinggal dan Rumah Ehsan untuk warga emas yang tidak boleh menguruskan diri sendiri, hidup sebatang kara dan tidak mempunyai tempat tinggal. Pusat perkhidmatan aktiviti warga emas juga merupakan satu usaha yang boleh disediakan kepada warga emas yang tinggal di dalam sesebuah komuniti.</p>'
          ],
          questionId: '61c22d9ce7229f0027c14cda'
        },
        {
          answer: [
            '<p>Bilangan botol minyak masak yang dibeli oleh Puan Noriah ialah:</p><p><br></p><p>Jumlah Harga 2 Kopi ialah RM25.80</p><p>Harga seunit beras ialah RM32.50</p><p><br></p><p>RM100.00-RM4.50</p><p>=RM95.50 (Jumlah keseluruhan bil)</p><p><br></p><p>Jumlah Harga minyak masak ialah</p><p>RM95.50 - RM25.80 - RM32.50</p><p>=RM37.20/18.60 (harga seunit minyak masak)</p><p>Bilangan botol minyak masak yang dibeli oleh Puan Noriah ialah:</p><p>2 botol</p>'
          ],
          questionId: '61c22d9ce7229f0027c14ce2'
        },
        {
          answer: [
            '<p>Mobile phones are the largest invention of technology, and nowadays are being used all over the world. The medium for communicating with people is a lot easier due to the huge use of mobile phontrackExam. The healthy problems due to the massive use of mobile phones are increasing day by day. According to researches, the network can cause health problem caused by mobile phones huge ustrackExam. But there are many disadvantage to using a mobile phone too. Blood barriers, dizziness, ear problems, and brain damage are some of the bad effects one may get if they use mobile phones too much. Many driving accidents take place because the driver was using his mobile phone while driving.&nbsp;</p>'
          ],
          questionId: '61c22d9ce7229f0027c14cd2'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79c1e'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79cae'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79c46'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79c26'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79c4e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79c56'
        },
        {
          answer: [
            '<p>Reading and writing are basic skills upon all other academic achievements are based. I have spent a lot of time working where I will be able to utilize my skills and expand my horizons relation. On a personal level, I believe that my most meaningful achievement have helped me further these dream of mintrackExam. I believe in helping people regardless of their nation, race or creed. I believe for being a better person so I can best help myself and others around mtrackExam. My success and my accomplishments in the academic will herald a beginning of the fulfillment of my personal and professional goal.</p><p class="ql-indent-2"> </p>'
          ],
          questionId: '61c22d9ce7229f0027c14cde'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79c96'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79c16'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79c76'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79c2e'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79c06'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79c3e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79c66'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79c6e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79c8e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79c5e'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79bfe'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79cb6'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79cb6'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79c9e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79ca6'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79c36'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79c0e'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79cbe'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79c7e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79b96'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79bf6'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79be6'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79bd6'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79bee'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79ba6'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79bde'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79b9e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79b36'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79b76'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79b4e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79b56'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79b6e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79b3e'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79b5e'
        },
        {
          answer: ['0'],
          questionId: '61c22d1edd26ca0039c79b66'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79b46'
        },
        {
          answer: ['1'],
          questionId: '61c22d1edd26ca0039c79bae'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79bb6'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79bc6'
        },
        {
          answer: ['3'],
          questionId: '61c22d1edd26ca0039c79bbe'
        },
        {
          answer: ['2'],
          questionId: '61c22d1edd26ca0039c79bce'
        }
      ];

      await trackExamRepository.update({ _id: trackExam }, { $set: { answers } }, { multi: false });

      return res.send({ message: 'updated' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/track-exams-programming-questions-answers')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(StartRequest)
  @UseBefore(FinishRequest)
  async dl(@Req() req: any, @Res() res: any) {
    try {
      const { limit, skip } = req.query;
      const offset = +skip * +limit;

      const zip = new AdmZip();
      const zipPath = `${process.env.TEMP_DIR}compro-answers-${offset}-.zip`;
      const directory = process.env.TEMP_DIR + `backup-logrocket-${offset}`;

      await FileUtils.removeDirectory(directory);
      FileUtils.createDirectory(directory);

      const token =
        'bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwczovL2xvZ3JvY2tldC5jb20vaXNJbXBlcnNvbmF0ZWQiOmZhbHNlLCJ1c2VyX2lkIjoiYXV0aDB8NjgwMzcxYmEzZjBjODI1MDNhNTM1MGFkIiwiY2xpZW50SUQiOiJGb1VZVFhRUXdRUHQ5akh2bFFnTWlMelFnNjBOS0ZOVyIsImlkZW50aXRpZXMiOlt7InVzZXJfaWQiOiI2ODAzNzFiYTNmMGM4MjUwM2E1MzUwYWQiLCJwcm92aWRlciI6ImF1dGgwIiwiY29ubmVjdGlvbiI6IlVzZXJuYW1lLVBhc3N3b3JkLUF1dGhlbnRpY2F0aW9uIiwiaXNTb2NpYWwiOmZhbHNlfV0sImNyZWF0ZWRfYXQiOiIyMDI1LTA0LTE5VDA5OjQ5OjQ2LjA1N1oiLCJlbWFpbCI6ImNvbnN1bHRhZGQxOTA0MjVAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiY29uc3VsdGFkZDE5MDQyNUBnbWFpbC5jb20iLCJuaWNrbmFtZSI6ImNvbnN1bHRhZGQxOTA0MjUiLCJwaWN0dXJlIjoiaHR0cHM6Ly9zLmdyYXZhdGFyLmNvbS9hdmF0YXIvMjE3MWQ0ZTBkMmZiYTFiMzA3MjBmYjllYzNiYTk5ZGM_cz00ODAmcj1wZyZkPWh0dHBzJTNBJTJGJTJGY2RuLmF1dGgwLmNvbSUyRmF2YXRhcnMlMkZjby5wbmciLCJ1cGRhdGVkX2F0IjoiMjAyNS0wNC0yOVQwNzoxOTo1NS45NzlaIiwidXNlcl9tZXRhZGF0YSI6e30sImFwcF9tZXRhZGF0YSI6e30sImh0dHBzOi8vbG9ncm9ja2V0O2NvbS9pc0ltcGVyc29uYXRlZCI6ZmFsc2UsImlzcyI6Imh0dHBzOi8vbG9naW4ubG9ncm9ja2V0LmNvbS8iLCJzdWIiOiJhdXRoMHw2ODAzNzFiYTNmMGM4MjUwM2E1MzUwYWQiLCJhdWQiOiJGb1VZVFhRUXdRUHQ5akh2bFFnTWlMelFnNjBOS0ZOVyIsImlhdCI6MTc0NTkxMTE5NiwiZXhwIjoxNzQ1OTk3NTk2LCJhdF9oYXNoIjoiZDl0dDBRTm44SklmUmhidEQzMXNBZyIsIm5vbmNlIjoiS3dufn5uVWtJMk5YUDJuajBDeDFnd0RCMUtEWmFUUG4ifQ.6gz258SxXsrimgxAXprNTVCqKF-IBBU7gF3j11VG_dk';

      const trackExams = await trackExamRepository
        .find({ exam: Types.ObjectId('6807b2274ebbc70020e63008'), 'answers.0': { $exists: false } })
        .populate({ path: 'user', select: 'email' })
        .sort({ startedAt: -1 })
        .limit(+limit)
        .skip(offset)
        .lean();

      let count = 1;

      for (let trackExam of trackExams) {
        if (trackExam.user && trackExam.user.email) {
          const email = trackExam.user.email;

          if (!existsSync(directory + '/' + trackExam._id + '.json')) {
            try {
              let request1 = await axios.post(
                'https://app.logrocket.com/v1/graphql',
                // {
                //   operationName: 'Sessions',
                //   variables: {
                //     appID: appId,
                //     sourceAppID: null,
                //     filters: [
                //       {
                //         email: {
                //           operator: 'CONTAINS',
                //           strings: [email]
                //         }
                //       }
                //     ],
                //     groupedFilters: [],
                //     newestCursor: '1745929710850',
                //     oldestCursor: '1745324910850',
                //     retentionMonths: 1,
                //     disablePagination: false,
                //     exactCount: false,
                //     limit: 5000,
                //     offset: 0
                //   },
                //   query:
                //     'query Sessions($appID: ID!, $newestCursor: String, $oldestCursor: String, $cursor: String, $date: Float, $filters: [SessionFilter!], $groupedFilters: [[SessionFilter!]!], $retentionMonths: Int, $disablePagination: Boolean, $sourceAppID: String, $exactCount: Boolean) {\n  app(id: $appID, sourceAppID: $sourceAppID) {\n    appID\n    sessionInfo(newestCursor: $newestCursor, oldestCursor: $oldestCursor, cursor: $cursor, date: $date, filters: $filters, groupedFilters: $groupedFilters, retentionMonths: $retentionMonths, disablePagination: $disablePagination, exactCount: $exactCount) {\n      sessions {\n        browserInfo {\n          href\n          useragent\n          platform\n          __typename\n        }\n        deviceInfo {\n          deviceName\n          deviceType\n          manufacturer\n          release\n          __typename\n        }\n        user {\n          name\n          email\n          userID\n          isAnonymous\n          __typename\n        }\n        location {\n          country\n          region\n          city\n          ip\n          __typename\n        }\n        activity {\n          videoTime\n          start\n          end\n          href\n          __typename\n        }\n        date\n        id\n        duration\n        eventCount\n        hasIntercomShow\n        hasZendeskShow\n        isDeleted\n        __typename\n      }\n      cursor\n      newestCursor\n      nextCursor\n      prevCursor\n      sessionOffset\n      sessionCount\n      isEstimatedCount\n      scanInfo {\n        count\n        total\n        horizon\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n'
                // },
                {
                  operationName: 'Sessions',
                  variables: {
                    appID: 'a8oxgy/consultadd',
                    filters: [
                      {
                        email: {
                          operator: 'CONTAINS',
                          strings: [email]
                        }
                      }
                    ],
                    groupedFilters: [],
                    newestCursor: '1745929710850',
                    oldestCursor: '1745324910850',
                    retentionMonths: 1,
                    disablePagination: false,
                    exactCount: false,
                    isExtendedSessionRetentionQuery: false
                  },
                  query:
                    'query Sessions($appID: ID!, $newestCursor: String, $oldestCursor: String, $cursor: String, $timeRanges: [TimeRange!], $date: Float, $filters: [SessionFilter!], $groupedFilters: [[SessionFilter!]!], $retentionMonths: Int, $disablePagination: Boolean, $sourceAppID: String, $exactCount: Boolean, $isExtendedSessionRetentionQuery: Boolean, $pageSize: Int) {\n  app(id: $appID, sourceAppID: $sourceAppID) {\n    appID\n    sessionInfo(newestCursor: $newestCursor, oldestCursor: $oldestCursor, cursor: $cursor, timeRanges: $timeRanges, date: $date, filters: $filters, groupedFilters: $groupedFilters, retentionMonths: $retentionMonths, disablePagination: $disablePagination, exactCount: $exactCount, isExtendedSessionRetentionQuery: $isExtendedSessionRetentionQuery, pageSize: $pageSize) {\n      sessions {\n        browserInfo {\n          href\n          useragent\n          platform\n          __typename\n        }\n        deviceInfo {\n          deviceName\n          deviceType\n          manufacturer\n          release\n          __typename\n        }\n        user {\n          name\n          email\n          userID\n          isAnonymous\n          __typename\n        }\n        location {\n          country\n          region\n          city\n          ip\n          __typename\n        }\n        activity {\n          videoTime\n          start\n          end\n          href\n          __typename\n        }\n        date\n        id\n        duration\n        eventCount\n        hasIntercomShow\n        hasZendeskShow\n        isDeleted\n        hasExtendedRetention\n        __typename\n      }\n      cursor\n      newestCursor\n      nextCursor\n      prevCursor\n      sessionOffset\n      sessionCount\n      isEstimatedCount\n      scanInfo {\n        count\n        total\n        horizon\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n'
                },
                { headers: { authorization: token }, timeout: 0 }
              );

              if (request1.data.data.app.sessionInfo.sessions.length > 0) {
                const requests = [];
                for (let ss = 0; ss < request1.data.data.app.sessionInfo.sessions.length; ss++) {
                  let recording = request1.data.data.app.sessionInfo.sessions[ss].id;
                  let r2 = await axios.post(
                    'https://app.logrocket.com/v1/graphql',
                    {
                      operationName: 'SessionQuery',
                      variables: { appID: 'a8oxgy/consultadd', recordingID: recording },
                      query:
                        'query SessionQuery($appID: ID!, $recordingID: ID!) {\n  schemaVersion\n  app(id: $appID) {\n    recording(id: $recordingID) {\n      duration {\n        startTime\n        endTime\n        __typename\n      }\n      minBufferTime\n      tabIDs\n      activeTabTimes {\n        time\n        tabID\n        __typename\n      }\n      tabStructure {\n        tabID\n        isRootTab\n        __typename\n      }\n      activity(timeout: 5000) {\n        startTime\n        endTime\n        __typename\n      }\n      ...metadataInfo\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment metadataInfo on Recording {\n  metadata {\n    release\n    sdkVersion\n    browserInfo {\n      href\n      codeName\n      language\n      name\n      platform\n      useragent\n      version\n      referrer\n      __typename\n    }\n    user {\n      userID\n      name\n      email\n      isAnonymous\n      sessionCount\n      firstSeen\n      lastSeen\n      totalActivity\n      traits {\n        field\n        value\n        __typename\n      }\n      __typename\n    }\n    viewportSize {\n      width\n      height\n      __typename\n    }\n    location {\n      country\n      region\n      city\n      ip\n      __typename\n    }\n    initialPageLoadMetrics {\n      initialPageLoadTime\n      timeToFirstByte\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n'
                    },
                    { headers: { authorization: token }, timeout: 0 }
                  );

                  const tabs = r2.data.data.app.recording.tabIDs;
                  for (let tab of tabs) {
                    let r3 = await axios.post(
                      'https://app.logrocket.com/v1/graphql',
                      {
                        operationName: 'NetworkRowsQuery',
                        variables: {
                          appID: 'a8oxgy/consultadd',
                          recordingID: `${recording}/${tab}`,
                          offset: 0,
                          limit: 50000
                        },
                        query:
                          'query NetworkRowsQuery($appID: ID!, $recordingID: ID!, $offset: Int, $limit: Int) {\n  app(id: $appID) {\n    recording(id: $recordingID) {\n      thread(id: 1) {\n        networkRows(offset: $offset, limit: $limit) {\n          id\n          request {\n            seqID\n            time\n            url\n            method\n            operationName\n            operationType\n            __typename\n          }\n          response {\n            seqID\n            time\n            status\n            __typename\n          }\n          resource {\n            initiatorType\n            mimeType\n            __typename\n          }\n          tabID\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n'
                      },
                      {
                        headers: {
                          authorization: token
                        },
                        timeout: 0
                      }
                    );
                    const rawNetwork = r3.data.data.app.recording.thread.networkRows;
                    const reqs = rawNetwork.filter((a) => a.request && !a.response);
                    const pages = [];
                    for (let rw of reqs) {
                      if (rw.request && rw.request.url === `https://api.edorer.com/api/track-exams/compile/${trackExam._id}`) {
                        pages.push(rw);
                      }
                    }

                    for (let p of pages) {
                      const q4 = await axios.post(
                        'https://app.logrocket.com/v1/graphql',
                        {
                          operationName: 'GetNetworkInfo',
                          variables: {
                            reqID: p.request.seqID,
                            appID: 'a8oxgy/consultadd',
                            recordingID: recording + '/' + tab,
                            requestBodiesAndHeaders: true
                          },
                          query:
                            'query GetNetworkInfo($reqID: ID!, $resID: ID, $appID: ID!, $recordingID: ID!, $requestBodiesAndHeaders: Boolean!) {\n  app(id: $appID) {\n    appID\n    recording(id: $recordingID) {\n      id\n      thread(id: 1) {\n        id\n        networkDetail(reqID: $reqID, resID: $resID) {\n          request {\n            time\n            url\n            method\n            credentials\n            mode\n            referrer\n            ...requestFragment @include(if: $requestBodiesAndHeaders)\n            __typename\n          }\n          response {\n            time\n            status\n            responseType\n            ...responseFragment @include(if: $requestBodiesAndHeaders)\n            __typename\n          }\n          primaryFrame {\n            lineNumber\n            columnNumber\n            fileName\n            functionName\n            __typename\n          }\n          resource {\n            initiatorType\n            mimeType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment requestFragment on NetworkRequest {\n  body\n  headers\n  __typename\n}\n\nfragment responseFragment on NetworkResponse {\n  body\n  headers\n  __typename\n}\n'
                        },
                        {
                          headers: {
                            authorization: token
                          },
                          timeout: 0
                        }
                      );

                      requests.push(q4.data.data.app.recording.thread.networkDetail);
                    }
                  }
                }

                if (requests.length > 0) {
                  if (!existsSync(directory + '/' + trackExam._id + '.json')) {
                    writeFileSync(directory + '/' + trackExam._id + '.json', JSON.stringify({ requests }));
                  }

                  const filteredRequests = requests.filter((entry) => entry?.request?.body?.isSubmission);

                  for (let { request } of filteredRequests) {
                    const { body } = request;

                    const compiler = new CodeCompiler(body, body.question);
                    const { editorMode, files, isSubmission, language: editorLanguage, question, theme: editorTheme } = body;

                    const result = await (isSubmission ? compiler.judgeSubmission(false) : compiler.judge());

                    console.log('RESULT', result);

                    if (isSubmission) {
                      const addAnswerFacade = new TrackExamAddAnswer(files[0].content, question, trackExam._id, {
                        isCorrect: result.verdictDetails.isAccepted,
                        editorLanguage,
                        editorMode,
                        editorTheme,
                        ...result
                      });

                      await addAnswerFacade.create();
                    }
                  }
                }
              } else {
                count++;
              }
            } catch (error: any) {
              console.error(error);
              count++;
            }
          }
        }

        console.warn('DONE ' + trackExam._id, count);
        count++;
      }

      zip.addLocalFolder(directory, `answers-${offset}`);
      zip.writeZip(zipPath);

      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
      mailOptions.subject = 'Tracks';
      mailOptions.to = 'baten.mab@gmail.com';
      mailOptions.attachments = [
        {
          filename: `answers-${offset}.zip`,
          path: zipPath
        }
      ];

      mailer.init();
      await mailer.send(mailOptions);

      // await FileUtils.removeDirectory(zipPath);
      // FileUtils.removeFile(zipPath);
      // await FileUtils.removeDirectory(directory);

      console.warn('DONE WITH LOG ROCKET');

      return res.send({ message: 'updated' });
    } catch (error: any) {
      console.error(JSON.stringify(error));
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-track-answers')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async storeAnswers(@Res() res: any, @UploadedFile('file') file: any) {
    try {
      const directory = await Open.buffer(file.buffer);
      let tempFolder = process.env.TEMP_DIR + uuidV4();
      await directory.extract({ path: tempFolder, concurrency: 5 });
      const [answersFolder] = readdirSync(tempFolder);

      if (existsSync(tempFolder + '/' + answersFolder)) {
        tempFolder += '/' + answersFolder;
      }

      const directoryFiles = FileUtils.directoryFiles(tempFolder).filter((entry) => entry.includes('json'));

      let count = 0;
      for (let directoryFile of directoryFiles) {
        const trackExamId = directoryFile.split('.').shift();
        console.warn(trackExamId);
        const { requests } = JSON.parse(FileUtils.readData(tempFolder + '/' + directoryFile));
        const answers = requests.map((entry) => entry.request.body).filter((entry) => entry.isSubmission);

        const filteredAnswers: Record<string, any> = {};
        for (let answer of answers) {
          if (!(answer.question in filteredAnswers)) {
            filteredAnswers[answer.question] = answer;
          }
        }

        for (let answer of Object.values(filteredAnswers)) {
          const { editorMode, files, isSubmission, language: editorLanguage, question, theme: editorTheme } = answer;
          if (files.length > 0 && Object.keys(files[0]).length > 0) {
            const fixer = new AIFixFormatter(files[0].content);
            const fixedContent = await fixer.fix();

            if (fixedContent) {
              files[0].content = fixedContent.trim();
            }

            const compiler = new CodeCompiler(answer, question);

            const result = await (isSubmission ? compiler.judgeSubmission(false) : compiler.judge());
            if (isSubmission) {
              const addAnswerFacade = new TrackExamAddAnswer(files[0].content, question, trackExamId, {
                isCorrect: result && result.verdictDetails && result.verdictDetails.isAccepted ? result.verdictDetails.isAccepted : false,
                editorLanguage,
                editorMode,
                editorTheme,
                ...result
              });
              await addAnswerFacade.create();
            }
          }
        }

        count++;
        console.warn('Out of ', directoryFiles.length, ' completed ', count);

        FileUtils.removeFile(tempFolder + '/' + directoryFile);
      }

      await FileUtils.removeDirectory(tempFolder);
      return res.status(201).send({ message: 'Pushed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/attach-proctor-request-to-track-exams')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async attachProctorRequests(@Res() res: any) {
    try {
      const proctorRequests: ProctorRequest[] = await proctorRequestRepository.find({ deleted: false }).lean();
      for (let proctorRequest of proctorRequests) {
        await trackExamRepository.update({ exam: proctorRequest.exam }, { $set: { proctorRequest: proctorRequest._id } }, { multi: true });
      }

      return res.status(201).send({ message: 'Proctor requests attached successfully.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/attach-review-request-to-track-exams')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async attachReviewRequests(@Res() res: any) {
    try {
      const reviewRequests: ReviewRequest[] = await reviewRequestRepository.find({ type: ReviewRequestTypes.EXAM }).lean();
      for (let reviewRequest of reviewRequests) {
        if (reviewRequest.trackExams && reviewRequest.trackExams.length > 0) {
          await trackExamRepository.update(
            { _id: { $in: reviewRequest.trackExams } },
            { $set: { reviewRequest: reviewRequest._id } },
            { multi: true }
          );
        }
      }

      return res.status(201).send({ message: 'Review requests attached successfully.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/end-track-exams/:exam([0-9a-f]{24})')
  @Validate([
    {
      field: 'exam',
      validation: [{ value: 'notEmpty', message: 'Exam is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async endTrackExams(@Res() res: any, @Param('exam') exam: string) {
    try {
      const trackExams = await trackExamRepository.find({ exam, status: TrackExamStatus.IN_PROGRESS }).lean();

      for (let trackExam of trackExams) {
        await trackExamRepository.update(
          { _id: trackExam._id },
          { $set: { endedAt: trackExam.endsAt, status: TrackExamStatus.ENDED } },
          { multi: false }
        );
      }

      return res.status(200).send({ message: 'Ended' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/end-track-exams-by-university/:university([0-9a-f]{24})')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async endTrackExamsByUniversity(@Res() res: any, @Param('university') university: string) {
    try {
      const trackExams = await trackExamRepository
        .find({
          endsAt: { $exists: true, $lt: moment().toDate() },
          status: TrackExamStatus.IN_PROGRESS,
          university
        })
        .lean();

      let tracks = trackExams.length;

      console.warn(trackExams.length);

      for (let trackExam of trackExams) {
        await trackExamRepository.update(
          { _id: trackExam._id },
          { $set: { endedAt: trackExam.endsAt, status: TrackExamStatus.ENDED } },
          { multi: false }
        );
        tracks--;

        console.warn(tracks);
      }

      return res.status(200).send({ message: 'Ended successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/fix-compilation')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixCompilation(@Res() res: any) {
    try {
      const trackExams = await trackExamRepository
        .find({
          exam: '6880723ea69ddf0020dbe3a6',
          score: 0
        })
        .populate('questions')
        .sort({ createdAt: -1 })
        .lean();

      for (let trackExam of trackExams) {
        for (let answer of trackExam.answers) {
          try {
            const compiler = new CodeCompiler(
              {
                files: [{ content: answer.answer[0] }],
                language: answer.compiledResult.editorLanguage,
                theme: answer.compiledResult.editorTheme
              },
              answer.questionId
            );
            let result: any = await compiler.judgeSubmission(false);
            answer.compiledResult = result;

            if (result && result.evaluations) {
              answer.point = result.evaluations.reduce((curr, evaluation) => {
                const { expectedOutput, output, point } = evaluation;
                return curr + (expectedOutput === output ? point : 0);
              }, 0);
            }
          } catch (error) {
            console.error(error);
          }
        }
        trackExam.score = trackExam.answers.reduce((a, b) => a + b.point, 0);
        const questionPoint = trackExam.questions.reduce((acc: number, question: Question) => acc + question.points.positive, 0);
        trackExam.percentage = Math.max(0, Math.floor((trackExam.score / questionPoint) * 100));
        await trackExamRepository.update(
          { _id: trackExam._id },
          {
            $set: {
              score: trackExam.score,
              percentage: trackExam.percentage,
              answers: trackExam.answers
            }
          }
        );
      }

      return res.status(200).send({ message: 'Ended successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error });
    }
  }

  @Get('/scripts/transfer-classroom-works')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferClassroomWorks(@Res() res: any) {
    try {
      let universityConfig: UniversityConfiguration = await universityConfigurationRepository.findOne();
      const classes = await classRepository.find({
        name: ['BATCH-1-August-MBA-ONLINE-2023-24', 'BATCH-2-August-MBA-ONLINE-2023-24', 'BATCH-3-September-MBA-ONLINE-2023-24']
      });
      for (let classroom of classes) {
        setTimeout(async () => {
          const subjects = await subjectRepository.find({ classroom: classroom._id });
          for (let subject of subjects) {
            const works = await classroomWorkRepository.find({ subject: subject._id });
            for (let work of works) {
              try {
                if (work.type === 'document' && work.document.indexOf('minio') > -1) {
                  let downloaded = new Downloader(work.document);
                  let path = await downloaded.download();
                  if (path) {
                    let s3 = new S3University(universityConfig);
                    work.document = await s3.upload(path, work.document.split('/').pop(), universityConfig.buckets.ASSETS);
                    await classroomWorkRepository.update({ _id: work._id }, { $set: { document: work.document } });
                  }
                }
              } catch (e) {}
            }
          }
        });
      }

      return res.status(201).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Get('/scripts/transfer-courses')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async transferCourses(@Res() res: any) {
    try {
      let universityConfig: UniversityConfiguration = await universityConfigurationRepository.findOne();
      // const courses = await courseRepository.find({id: ['004295', '004310', '004309', '004305', '004172', '004304', '004288']});
      const courses = await courseRepository.find({ id: ['004305'] });
      for (let course of courses) {
        setTimeout(async () => {
          const lectures = await lectureRepository.find({ course: course._id });
          for (let lecture of lectures) {
            for (let page of lecture.pages) {
              try {
                if ((page.contentType === 'document' || page.contentType === 'video') && page.assetUrl.indexOf('minio') > -1) {
                  let downloaded = new Downloader(page.assetUrl);
                  let path = await downloaded.download();
                  if (path) {
                    let s3 = new S3University(universityConfig);
                    page.assetUrl = await s3.upload(path, page.assetUrl.split('/').pop(), universityConfig.buckets.ASSETS);
                  }
                }
              } catch (e) {}
            }
            await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages } });
          }
        });
      }

      return res.status(201).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-track-exam-scores/:university')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackExamScores(@Req() req: any, @Res() res: any, @Param('university') university: string) {
    try {
      const { limit, skip } = req.body;

      setTimeout(async () => {
        const exams = await examRepository
          .find({
            createdAt: { $lte: new Date() },
            university
          })
          .limit(+limit)
          .skip(+skip * +limit)
          .sort({ createdAt: -1 })
          .lean();

        const examIds = exams.map((o) => o._id);

        const trackExams: TrackExam[] = await trackExamRepository.find({ exam: { $in: examIds } }).lean();

        for (let trackExam of trackExams) {
          let questions = await questionRepository.distinct('_id', {
            _id: { $in: trackExam.questions },
            type: { $in: [QuestionTypes.SINGLE_SELECT, QuestionTypes.MULTIPLE_SELECT, QuestionTypes.ORDERING, QuestionTypes.MATCHING] }
          });

          questions = questions.map((o) => String(o));

          for (let answer of trackExam.answers) {
            if (questions.indexOf(String(answer.questionId)) === -1) continue;

            try {
              const modifyAnswer = new TrackExamAddAnswer(answer.answer, String(answer.questionId), trackExam._id);
              await modifyAnswer.create();
            } catch (error) {
              console.error(error);
            }
          }
        }

        const mailOptions: any = {};
        mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
        mailOptions.subject = 'Tracks';
        mailOptions.to = 'abdul@edorer.com';
        mailOptions.html = `${examIds.join(', ')}`;

        mailer.init();
        await mailer.send(mailOptions);
      }, 1000);

      return res.status(201).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/fix-track-exam-scores-by-exams')
  @Validate([
    {
      field: 'exams',
      validation: [{ value: 'notEmpty', message: 'Exam IDs are required' }]
    },
    {
      field: 'score',
      validation: [{ value: 'notEmpty', message: 'Score is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixTrackExamScoresByExams(@Req() req: any, @Res() res: any) {
    try {
      const exams = await examRepository.find({ _id: { $in: req.body.exams } }).lean();
      const examIds = exams.map((o) => o._id);

      const trackExams: TrackExam[] = await trackExamRepository
        .find({
          exam: { $in: examIds },
          score: { $gte: req.body.score },
          status: { $ne: TrackExamStatus.IN_PROGRESS }
        })
        .lean();

      if (trackExams.length === 0) {
        return res.status(201).send({ message: 'No track exams found to process' });
      }

      const allQuestionIds = [...new Set(trackExams.flatMap((te) => te.questions))];

      const allQuestions = await questionRepository
        .find({ _id: { $in: allQuestionIds } })
        .select('_id points')
        .lean();

      const questionMap = new Map(allQuestions.map((q) => [q._id.toString(), q]));

      const bulkOperations: any[] = [];

      for (const trackExam of trackExams) {
        const trackExamQuestions = trackExam.questions.map((qId) => questionMap.get(qId.toString())).filter((q): q is Question => q !== undefined);

        if (trackExamQuestions.length === 0) continue;

        const validQuestionIds = new Set(trackExamQuestions.map((q) => q._id.toString()));

        const uniqueQuestionScores = new Map<string, number>();
        const uniqueQuestionMaxPoints = new Map<string, number>();

        for (const answer of trackExam.answers) {
          const questionIdStr = answer.questionId.toString();
          if (!validQuestionIds.has(questionIdStr)) continue;

          const question = questionMap.get(questionIdStr) as Question;
          if (!question) continue;

          if (!uniqueQuestionScores.has(questionIdStr) || answer.point > uniqueQuestionScores.get(questionIdStr)) {
            uniqueQuestionScores.set(questionIdStr, answer.point || 0);
          }

          if (!uniqueQuestionMaxPoints.has(questionIdStr)) {
            uniqueQuestionMaxPoints.set(questionIdStr, question.points.positive);
          }
        }

        const recalculatedScore = Array.from(uniqueQuestionScores.values()).reduce((acc, point) => acc + point, 0);

        const maxPossiblePoints = Array.from(uniqueQuestionMaxPoints.values()).reduce((acc, point) => acc + point, 0);

        const finalScore = Math.min(recalculatedScore, maxPossiblePoints);
        const finalPercentage = maxPossiblePoints > 0 ? Math.max(0, Math.floor((finalScore / maxPossiblePoints) * 100)) : 0;

        if (finalScore !== trackExam.score) {
          bulkOperations.push({
            updateOne: {
              filter: { _id: trackExam._id },
              update: {
                $set: {
                  score: finalScore,
                  percentage: finalPercentage,
                  updatedAt: new Date()
                }
              }
            }
          });
        }
      }

      let processedCount = 0;
      const BATCH_SIZE = 25;
      for (let i = 0; i < bulkOperations.length; i += BATCH_SIZE) {
        const batch = bulkOperations.slice(i, i + BATCH_SIZE);
        if (batch.length > 0) {
          const result = await trackExamRepository.bulkWrite(batch);
          processedCount += result.modifiedCount || 0;
        }
      }

      console.log(`Processed ${processedCount} track exams out of ${trackExams.length}`);

      return res.status(201).send({
        message: 'Fixed',
        processed: {
          trackExams: trackExams.length,
          modifiedTrackExams: processedCount
        }
      });
    } catch (error: any) {
      console.error('Error in fixTrackExamScoresByExams:', error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/track-exam-with-more-points')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async tracksWithMorePoints(@Res() res: any) {
    try {
      const trackExams: TrackExam[] = await trackExamRepository
        .find({ exam: '6733003c2a95b4e056e622ea' })
        .populate({ path: 'user', select: 'email' })
        .select('questions user')
        .lean();

      const users: Record<string, number> = {};

      for (let { questions, user } of trackExams) {
        if (questions.length > 60) users[user.email] = questions.length;
      }

      const tableRows = Object.entries(users)
        .map(([key, value]) => `<tr><td>${key}</td><td>${value}</td></tr>`)
        .join('');

      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
      mailOptions.subject = 'Tracks';
      mailOptions.to = 'abdul@edorer.com';
      mailOptions.html = `
      <div style="background-color: lightgray; width: 100%; display: flex; align-items: center; gap: 16px; padding:16px">
        <div style="width: 500px;">
          <div style="width: 100%; margin-bottom: 16px">
            <h3>Total tracks: ${Object.keys(users).length}</h3>
          </div>

          <table style="width: 100%" border="1" cellpadding="5" cellspacing="0">
            <thead>
              <tr>
                <th>Email</th>
                <th>Points</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
          </table>
        </div>
      </div>
      `;

      mailer.init();
      await mailer.send(mailOptions);

      return res.status(201).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/replace-question-ids/:examId')
  @Validate([
    {
      field: 'examId',
      validation: [{ value: 'notEmpty', message: 'Exam ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async replaceTrackQuestions(@Res() res: any, @Param('examId') examId: string) {
    try {
      const questions = {
        '67fdf61cf15a84e90e70b0c5': '67f379bb3020586945fd41ef',
        '67f379bb3020586945fd4203': '67fdf61df15a84e90e70b0d9',
        '67f379bb3020586945fd420d': '67fdf61df15a84e90e70b0e3',
        '67f379bb3020586945fd4217': '67fdf61df15a84e90e70b0ed',
        '67f379bb3020586945fd4221': '67fdf61df15a84e90e70b0f7',
        '67f379bb3020586945fd422b': '67fdf61df15a84e90e70b101',
        '67f379bb3020586945fd4235': '67fdf61df15a84e90e70b10b',
        '67f379bb3020586945fd423f': '67fdf61df15a84e90e70b115',
        '67f379bb3020586945fd4249': '67fdf61df15a84e90e70b11f',
        '67f379bb3020586945fd4253': '67fdf61df15a84e90e70b129',
        '67f379bb3020586945fd425d': '67fdf61df15a84e90e70b133',
        '67f379bc3020586945fd4267': '67fdf61df15a84e90e70b13d',
        '67f379bc3020586945fd4271': '67fdf61df15a84e90e70b147',
        '67f379bc3020586945fd427b': '67fdf61df15a84e90e70b151',
        '67f379bc3020586945fd4285': '67fdf61df15a84e90e70b15b',
        '67f379bc3020586945fd428f': '67fdf61ef15a84e90e70b165',
        '67f379bc3020586945fd4299': '67fdf61ef15a84e90e70b16f',
        '67f379bc3020586945fd42a3': '67fdf61ef15a84e90e70b179',
        '67f379bc3020586945fd42ad': '67fdf61ef15a84e90e70b183',
        '67f379bc3020586945fd42b7': '67fdf61ef15a84e90e70b18d',
        '67f379bc3020586945fd42c1': '67fdf61ef15a84e90e70b197',
        '67fdfad6dd0556ea2de5111f': '67fdf61cf15a84e90e70b0cf',
        '67f379bb3020586945fd41f9': '67fdfaf62cf06aea756bfecf'
      };

      const trackExams: TrackExam[] = await trackExamRepository.find({ exam: examId }).lean();

      const bulkOperations = [];

      for (let trackExam of trackExams) {
        const { answers = [], questions: trackQuestions = ([] = []) } = trackExam;

        for (let answer of answers) {
          if (String(answer.questionId) in questions) {
            answer.questionId = questions[String(answer.questionId)];
          }
        }

        for (let index = 0; index < trackQuestions.length; index++) {
          const question = trackQuestions[index];

          if (String(question) in questions) {
            trackQuestions[index] = questions[String(question)];
          }
        }

        bulkOperations.push({
          updateOne: {
            filter: { _id: trackExam._id },
            update: { $set: { answers, questions: trackQuestions } }
          }
        });
      }

      await trackExamRepository.bulkWrite(bulkOperations);

      await questionRepository.update({ _id: { $in: Object.keys(questions) }, exam: examId }, { $set: { deleted: true } }, { multi: true });
      await examRepository.update({ _id: examId }, { $pullAll: { questions: Object.keys(questions) } }, { multi: false });
      await examRepository.update({ _id: examId }, { $addToSet: { questions: Object.values(questions) } }, { multi: false });

      return res.status(201).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/restore-track-exam-answers/:trackExam')
  @Validate([
    {
      field: 'answers',
      validation: [{ value: 'notEmpty', message: 'Answers are required' }]
    },
    {
      field: 'trackExam',
      validation: [{ value: 'notEmpty', message: 'Track Exam ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(StartRequest)
  @UseBefore(FinishRequest)
  async restoreTrackExamAnswers(@Req() req: any, @Res() res: any, @Param('trackExam') trackExam: string) {
    try {
      const { answers } = req.body;

      for (let answer of answers) {
        try {
          const addAnswerFacade = new TrackExamAddAnswer(answer.answer, answer.question, trackExam);
          await addAnswerFacade.create();
        } catch (error: any) {
          console.error(error);
        }
      }

      console.warn('DONE WITH LOG ROCKET');

      return res.send({ message: 'updated' });
    } catch (error: any) {
      console.error(JSON.stringify(error));
      return res.status(400).send({ message: error.message });
    }
  }
}
