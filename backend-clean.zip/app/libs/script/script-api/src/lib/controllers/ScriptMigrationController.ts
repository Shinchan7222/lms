import { CanExecuteScript } from '@edorer/script-data';
import { Class, classRepository } from '@edorer/class-data';
import { FileUtils } from '@edorer/utils';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { ImportDataForMigration } from '../services/ImportDataForMigration';
import { ImportParulDataForMigration } from '../services/ImportParulDataForMigration';
import { JsonController, Param, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';
import { userRepository } from '@edorer/user-data';

@JsonController()
export class ScriptMigrationController {

    @Post('/scripts/import-data-for-migration-by-admin/:email')
    @Validate([
        {
            field: 'email',
            validation: [{ value: 'notEmpty', message: 'Email is required' }]
        }
    ])
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async importDataForMigration(@Req() req: any, @Res() res: any, @Param('email') email: string, @UploadedFile('zipFile') zipFile: any) {
        res.connection.setTimeout(0);
        const rootDir = process.env.TEMP_DIR + email + '_' + Date.now();
        try {

            await FileUtils.removeDirectory(rootDir);
            FileUtils.createDirectory(rootDir);

            const exportDataForMigration = new ImportDataForMigration(email, rootDir, zipFile);
            await exportDataForMigration.import();

            await FileUtils.removeDirectory(rootDir);

            console.warn('===== ===== ===== ===== MIGRATED SUCCESSFULLY ===== ===== ===== =====');

            return res.status(201).send({ message: 'Requested to import' });
        } catch (error: any) {
            console.error(error);
            await FileUtils.removeDirectory(rootDir);
            return res.status(400).send({ message: error.message });
        }
    }

    @Post('/scripts/import-parul-data-for-migration')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async importParulDataForMigration(@Req() req: any, @Res() res: any, @UploadedFile('zipFile') zipFile: any) {
        res.connection.setTimeout(0);
        try {
            setTimeout(async () => {
                const rootDir = process.env.TEMP_DIR + 'parul';

                await FileUtils.removeDirectory(rootDir);
                FileUtils.createDirectory(rootDir);

                const exportDataForMigration = new ImportParulDataForMigration(rootDir, zipFile);
                await exportDataForMigration.import();

                await FileUtils.removeDirectory(rootDir);

                console.warn('===== ===== ===== ===== MIGRATED ===== ===== ===== =====');
            }, 1000);

            return res.status(201).send({ message: 'Requested to import' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Post('/scripts/add-students-to-classes')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addStudentsToClasses(@Req() req: any, @Res() res: any) {
        try {
            setTimeout(async () => {
                const migratedClasses: Class[] = await classRepository
                    .find({ isMigrated: true, students: { $size: 0 } })
                    .sort({ createdAt: -1 })
                    .lean();
                let count = migratedClasses.length;

                for (let migratedClass of migratedClasses) {
                    const users = await userRepository.find({ classes: { $in: [migratedClass._id] } }).select('_id').lean();
                    const userIds = users.map(user => user._id);

                    if (userIds.length > 0) {
                        await classRepository.update(
                            { _id: migratedClass._id },
                            { $set: { students: userIds } },
                            { multi: false }
                        );
                    }
                    count--;

                    console.warn('===== ===== ===== ===== UPDATED ===== ===== ===== =====', count);
                }

                console.warn('===== ===== ===== ===== ADDED ===== ===== ===== =====');
            }, 1000);

            return res.status(201).send({ message: 'Requested to import' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }
}
