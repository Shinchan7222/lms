import { CanExecuteScript } from '@edorer/script-data';
import { examRegistrationRepository } from '@edorer/exam-registration-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { programRepository } from '@edorer/program-data';

@JsonController()
export class ScriptExamRegistrationController {

    @Get('/scripts/add-exam-registrations-title')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addExamRegistrationsTitle(@Req() req: any, @Res() res: any) {
        try {
            const examRegistrations = await examRegistrationRepository
                .find({ program: { $exists: true }, title: { $exists: false } })
                .lean();

            for (let examRegistration of examRegistrations) {
                const { program } = examRegistration;
                const { title } = await programRepository.findOne({ _id: program }).lean();

                await examRegistrationRepository.update(
                    { _id: examRegistration._id },
                    { $set: { title } },
                    { multi: false },
                );
            }

            return res.status(200).send({ message: 'Titles added successfully' });
        } catch (error: any) {
            return res.status(400).send({ message: error.message });
        }
    }
}
