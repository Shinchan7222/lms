import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { TrackCourse, trackCourseRepository } from '@edorer/track-course-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptTrackCourseController {
  @Post('/scripts/remove-duplicate-track-course-lectures/:course')
  @Validate([
    {
      field: 'course',
      validation: [{ value: 'notEmpty', message: 'Course ID is required' }]
    }
  ])
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeDuplicateTrackCourseLectures(@Req() req: any, @Res() res: any, @Param('course') course: string) {
    try {
      const trackCourses: TrackCourse[] = await trackCourseRepository.find({ course, 'completedLectures.0': { $exists: true } }).lean();
      const results: TrackCourse[] = JSON.parse(JSON.stringify(trackCourses));

      for (let trackCourse of results) {
        await trackCourseRepository.update(
          { _id: trackCourse._id },
          { $set: { completedLectures: [...new Set(trackCourse.completedLectures)] } },
          { multi: true }
        );
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(201).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }

  @Post('/scripts/remove-all-duplicate-track-course-lectures')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async removeAllDuplicateTrackCourseLectures(@Req() req: any, @Res() res: any) {
    try {
      const trackCourses: TrackCourse[] = await trackCourseRepository.find({ 'completedLectures.0': { $exists: true } }).lean();
      const results: TrackCourse[] = JSON.parse(JSON.stringify(trackCourses));

      for (let trackCourse of results) {
        await trackCourseRepository.update(
          { _id: trackCourse._id },
          { $set: { completedLectures: [...new Set(trackCourse.completedLectures)] } },
          { multi: true }
        );
      }

      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(201).send({ message: 'Fixed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
