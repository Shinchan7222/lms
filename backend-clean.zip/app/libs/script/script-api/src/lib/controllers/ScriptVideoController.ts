import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { videoUploaderRepository } from '@edorer/video-uploader-data';

@JsonController()
export class ScriptVideoController {
  @Post('/scripts/fix-video-titles')
  @UseBefore(CanExecuteScript)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fixVideoTitle(@Req() req: any, @Res() res: any) {
    try {
      const videos = await videoUploaderRepository.find({ url: { $exists: true } }).lean();
      for (let video of videos) {
        const courses = video.course ? [video.course] : [];
        const lectures = video.lecture ? [video.lecture] : [];

        const url = video.url.split('/').pop();
        const names = url.split('-');
        const [, , , , , ...titles] = names;
        console.warn(titles);

        await videoUploaderRepository.update({ _id: video._id }, { $set: { courses, lectures, title: titles.join('-') } }, { multi: false });
      }
      console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

      return res.status(200).send({ message: 'Videos title added successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
