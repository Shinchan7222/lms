import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Support, supportRepository } from '@edorer/support-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptSupportController {
  @Post('/scripts/attach-id-to-supports')
  @Validate([
    {
      field: 'university',
      validation: [{ value: 'notEmpty', message: 'University is required' }]
    }
  ])
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async attachIdToSupports(@Req() req: any, @Res() res: any) {
    const { university } = req.body;

    try {
      const supports: Support[] = await supportRepository.find({ id: { $exists: false }, university });
      for (let support of supports) {
        await support.generateNewId();
        await support.save();
      }

      return res.send({ message: 'done' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
