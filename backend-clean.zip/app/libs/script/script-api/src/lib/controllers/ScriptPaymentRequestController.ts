import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UploadedFile, UseAfter, UseBefore } from 'routing-controllers';
import { PaymentRequest, paymentRequestRepository, PaymentRequestType } from '@edorer/payment-request-data';
import { User, userRepository } from '@edorer/user-data';
import { Program, programRepository } from '@edorer/program-data';
import moment = require('moment');
import { PaymentGateway, paymentGatewayRepository, PaymentGatewayTypes } from '@edorer/payment-gateway-data';
import { Types } from 'mongoose';
const excelToJson = require('convert-excel-to-json');

@JsonController()
export class ScriptPaymentRequestController {

    @Get('/scripts/fix-payment-request-model')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async fixTrackScores(@Req() req: any, @Res() res: any) {
        res.connection.setTimeout(0);
        try {
            setTimeout(async () => {
                const paymentRequests: PaymentRequest[] = await paymentRequestRepository
                    .find({})
                    .select('requestedAmount')
                    .lean();

                for (let paymentRequest of paymentRequests) {
                    await paymentRequestRepository.update(
                        { _id: paymentRequest._id },
                        { $set: { leftAmount: paymentRequest.requestedAmount } },
                        { multi: false }
                    );
                }

                console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');
            }, 1000);

            return res.status(201).send({ message: 'Requested to import' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Get('/scripts/add-module-ids-to-payment-requests')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addModuleIds(@Req() req: any, @Res() res: any) {
        try {
            const paymentRequests: PaymentRequest[] = await paymentRequestRepository.find({ moduleId: { $exists: false } }).lean();

            for (let paymentRequest of paymentRequests) {
                let moduleId;
                if (paymentRequest.course) {
                    moduleId = paymentRequest.course;
                } else if (paymentRequest.exam) {
                    moduleId = paymentRequest.exam;
                } else if (paymentRequest.program) {
                    moduleId = paymentRequest.program;
                }

                await paymentRequestRepository.update({ _id: paymentRequest._id }, { $set: { moduleId } }, { multi: false });
            }

            console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

            return res.status(201).send({ message: 'Added module ids' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Post('/scripts/add-payment-requests/:university([0-9a-f]{24})')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addPaymentRequests(@Req() req: any, @Res() res: any, @Param('university') university: string, @UploadedFile('file') file: any) {
        try {
            const result = excelToJson({
                source: file.buffer,
                header: {
                    rows: 1
                },
                columnToKey: {
                    A: 'Creator Name',
                    B: 'Creator Email',
                    C: 'Total Pending Amount',
                    D: 'Program'
                }
            });

            // console.warn(result['JULY 2022 BATCH']);
            console.warn(result['JAN 2023 BATCH']);

            for (let entry of result['JAN 2023 BATCH']) {
                const user: User = await userRepository.findOne({ email: entry['Creator Email'] }).lean();
                if (user) {
                    console.warn('USER ==>', user._id);

                    await paymentRequestRepository.update(
                        { user: user._id },
                        { $set: { deleted: true } },
                        { multi: true },
                    );

                    const program: Program = await programRepository.findOne({ title: entry['Program'], university }).lean();
                    const paymentGateway: PaymentGateway = await paymentGatewayRepository.findOne({ paymentType: PaymentGatewayTypes.CC_AVENUE, university }).lean();

                    await paymentRequestRepository.create({
                        currency: 'INR',
                        dueDate: moment().endOf('month').toDate(),
                        initialPayment: 0,
                        moduleId: Types.ObjectId('61cdb4ef3a3f79003c70a93b'),
                        paidAmount: 0,
                        paymentGateway: paymentGateway._id,
                        program: program._id,
                        requestedAmount: entry['Total Pending Amount'],
                        totalAmount: entry['Total Pending Amount'],
                        type: PaymentRequestType.PROGRAM,
                        university,
                        user: user._id,
                    });
                }
            }

            console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

            return res.status(201).send({ message: 'Added module ids' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Get('/scripts/remove-duplicate-payment-requests/:university([0-9a-f]{24})')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async removeDuplicatePaymentRequests(@Req() req: any, @Res() res: any, @Param('university') university: string) {
        try {
            const userIds = await paymentRequestRepository.distinct('user', { university });
            for (let user of userIds) {
                const paymentRequests: PaymentRequest[] = await paymentRequestRepository.find({ user }).sort({ createdAt: -1 }).lean();

                const requests = {};
                const requestIdsToDelete = [];
                for (let paymentRequest of paymentRequests) {
                    const { _id, requestedAmount } = paymentRequest;
                    if (requestedAmount in requests) {
                        requestIdsToDelete.push(_id);
                    } else {
                        requests[requestedAmount] = _id;
                    }
                }

                if (requestIdsToDelete.length > 0) {
                    await paymentRequestRepository.update(
                        { _id: { $in: requestIdsToDelete } },
                        { $set: { deleted: true } },
                        { multi: true },
                    );
                }
            }

            console.warn('===== ===== ===== ===== DONE ===== ===== ===== =====');

            return res.status(201).send({ message: 'Added module ids' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }
}
