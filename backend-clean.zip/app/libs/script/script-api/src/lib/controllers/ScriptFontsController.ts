import { existsSync, mkdirSync, unlinkSync } from 'fs';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { FontsDownloader } from '../services/FontsDownloader';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';

@JsonController()
export class ScriptFontsController {
  @Post('/scripts/fonts/download')
  @Validate([
    {
      field: 'directory',
      validation: [{ value: 'notEmpty', message: 'directory is required' }]
    },
    {
      field: 'fonts',
      validation: [{ value: 'notEmpty', message: 'URL is required' }]
    }
  ])
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async downloadFonts(@Req() req: any, @Res() res: any) {
    try {
      const { directory, fonts } = req.body;

      if (existsSync(process.env.TEMP_DIR + directory)) {
        unlinkSync(process.env.TEMP_DIR + directory);
      } else {
        mkdirSync(process.env.TEMP_DIR + directory);
      }

      for (let woff of fonts) {
        const woff2URL = woff.replace(/woff/gm, 'woff2');
        const woff2Downloader = new FontsDownloader(woff2URL, directory);
        await woff2Downloader.download();

        const ttfURL = woff.replace(/woff2/gm, 'ttf');
        const ttfDownloader = new FontsDownloader(ttfURL, directory);
        await ttfDownloader.download();
      }

      return res.status(200).send({ message: 'Downloaded.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ message: error.message });
    }
  }
}
