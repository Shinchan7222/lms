import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { VideoSessionContentTypes } from '@edorer/track-video-session-data';
import { VideoSessionTypes, videoSessionRepository } from '@edorer/video-session-data';
import { webinarContentRepository } from '@edorer/track-webinar-data';
import { webinarRepository } from '@edorer/webinar-data';

@JsonController()
export class ScriptWebinarController {

    @Post('/scripts/fix-webinar-contents')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async fixWebinarContents(@Req() req: any, @Res() res: any) {
        try {
            const webinarContents = await webinarContentRepository.find({ contentType: VideoSessionContentTypes.MEDIA }).lean();
            for (let webinarContent of webinarContents) {
                await webinarContentRepository.update(
                    { _id: webinarContent._id },
                    { $set: { content: webinarContent.url } },
                    { multi: false }
                );
            }

            return res.status(201).send({ message: 'Fixed webinar contents' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }

    @Post('/scripts/add-video-session-to-webinar')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addVideoSessionToWebinar(@Req() req: any, @Res() res: any) {
        try {
            const webinars = await webinarRepository
                .find({
                        endDateTime: { $exists: true },
                        startDateTime: { $exists: true },
                        videoSession: { $exists: false }
                    }
                )
                .lean();
            for (let webinar of webinars) {
                const videoSession = await videoSessionRepository.create({
                    createdAt: webinar.createdAt,
                    duration: webinar.duration,
                    endDateTime: webinar.endDateTime,
                    owner: webinar.owner,
                    participants: webinar.participants,
                    sessionType: VideoSessionTypes.WEBINAR,
                    speakers: webinar.speakers,
                    startDateTime: webinar.startDateTime,
                    status: webinar.status === 'completed' ? 'ended' : webinar.status,
                    university: webinar.university,
                    updatedAt: webinar.updatedAt
                });

                await webinarRepository.update(
                    { _id: webinar._id },
                    { $set: { videoSession: videoSession._id } },
                    { multi: false }
                );
            }

            return res.status(201).send({ message: 'Video Session added successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }
}
