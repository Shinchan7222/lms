import * as moment from 'moment-timezone';
import * as http from 'http';
import * as os from 'os';
import { CanExecuteScript } from '@edorer/script-data';
import { ConvertPPTToImages, FileUtils } from '@edorer/utils';
import { CustomSmsSender } from '@edorer/custom-sms-sender';
import { Downloader, S3University } from '@edorer/s3';
import { ExamEnrollment, examEnrollmentRepository } from '@edorer/exam-enrollment-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { createClient } from 'redis';
import { getIO } from '@edorer/pool-app';
import { Socket } from '@edorer/socket';
import { Get, JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Json2Excel, StringUtils } from '@edorer/utils';
import { Question, questionRepository, QuestionTypes } from '@edorer/question-data';
import { Types } from 'mongoose';
import { User, userRepository, UserTypes } from '@edorer/user-data';
import { applicantRepository } from '@edorer/applicant-data';
import { courseRepository } from '@edorer/course-data';
import { lectureRepository } from '@edorer/lecture-data';
import { programRepository } from '@edorer/program-data';
import { readFileSync } from 'fs';
import { reviewRequestRepository } from '@edorer/review-request-data';
import { roleRepository } from '@edorer/role-data';
import { tokenRepository } from '@edorer/token-data';
import { universityRepository, universityConfigurationRepository } from '@edorer/university-data';
import { v4 as uuidV4 } from 'uuid';

function getLocalIp(): string {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                return iface.address;
            }
        }
    }
    return '127.0.0.1';
}

function checkNetworkAccess(): Promise<boolean> {
    return new Promise((resolve) => {
        const req = http.get('http://clients3.google.com/generate_204', (res) => {
            resolve(res.statusCode === 204);
            res.resume();
        });
        req.setTimeout(3000, () => {
            req.destroy();
            resolve(false);
        });
        req.on('error', () => resolve(false));
    });
}

@JsonController()
export class ScriptController {

    @Get('/scripts/health-check')
    async healthCheck(@Req() req: any, @Res() res: any) {

        const localIp = getLocalIp();
        const hasNetwork = await checkNetworkAccess();

        console.log(`[health-check] local IP: ${localIp} | network access: ${hasNetwork}`);
        await userRepository.findOne({});

        return res.status(200).send({ message: 'good', localIp, hasNetwork });
    }

    @Get('/scripts/socket-debug')
    async socketDebug(@Req() req: any, @Res() res: any) {
        const io = getIO();
        if (!io) {
            return res.status(200).send({ error: 'IO not initialized' });
        }

        const adapter = io.sockets.adapter;
        const totalConnected = io.sockets.sockets.size;
        const allRooms: any = {};

        adapter.rooms.forEach((sockets, roomName) => {
            if (!roomName.startsWith('videoSession:') && !roomName.startsWith('user:') && !roomName.startsWith('exam:')) return;
            allRooms[roomName] = {
                count: sockets.size,
                socketIds: Array.from(sockets).slice(0, 5) // first 5 IDs
            };
        });

        const videoSessionRooms = Object.keys(allRooms).filter(r => r.startsWith('videoSession:'));

        return res.status(200).send({
            totalConnected,
            totalRooms: adapter.rooms.size,
            videoSessionRooms: videoSessionRooms.length,
            rooms: allRooms,
            adapterType: adapter.constructor.name,
            pid: process.pid
        });
    }

    @Get('/scripts/socket-test/:room')
    async socketTest(@Req() req: any, @Res() res: any) {
        const io = getIO();
        if (!io) return res.status(500).send({ error: 'IO not initialized' });

        const room = 'videoSession:' + req.params.room;
        const event = `videoSession_content_added_${req.params.room}`;
        const results: any = { room, event, pid: process.pid, totalSockets: io.sockets.sockets.size, tests: [] };

        // Test 1: Normal io.to(room).emit
        try {
            const encrypted = Socket.encrypt({ content: 'TEST1_ROOM_' + Date.now(), contentType: 'message' });
            io.to(room).emit(event, encrypted);
            results.tests.push({ method: 'io.to(room).emit', status: 'ok' });
        } catch (e: any) {
            results.tests.push({ method: 'io.to(room).emit', error: e.message });
        }

        // Test 2: Direct emit to each socket in the room by ID
        try {
            const adapter = io.sockets.adapter;
            const allRoomKeys = Array.from(adapter.rooms.keys());
            const matchingRooms = allRoomKeys.filter(r => r.includes('videoSession'));
            results.debug = { lookingFor: room, allVideoRooms: matchingRooms, totalRooms: allRoomKeys.length };

            const roomSockets = adapter.rooms.get(room);
            if (roomSockets) {
                for (const socketId of roomSockets) {
                    const s = io.sockets.sockets.get(socketId);
                    if (s) {
                        const encrypted = Socket.encrypt({ content: 'TEST2_DIRECT_' + Date.now(), contentType: 'message' });
                        s.emit(event, encrypted);
                        results.tests.push({ method: 'direct s.emit', socketId, connected: s.connected });
                    } else {
                        results.tests.push({ method: 'direct s.emit', socketId, error: 'socket gone from map' });
                    }
                }
            } else {
                results.tests.push({ method: 'direct s.emit', error: 'room not in adapter' });
            }
        } catch (e: any) {
            results.tests.push({ method: 'direct s.emit', error: e.message });
        }

        // Test 3: Broadcast to ALL sockets
        try {
            const encrypted = Socket.encrypt({ content: 'TEST3_BROADCAST_' + Date.now(), contentType: 'message' });
            io.emit(event, encrypted);
            results.tests.push({ method: 'io.emit (all)', sockets: io.sockets.sockets.size });
        } catch (e: any) {
            results.tests.push({ method: 'io.emit (all)', error: e.message });
        }

        return res.status(200).send(results);
    }

    @Get('/scripts/redis-debug')
    async redisDebug(@Req() req: any, @Res() res: any) {
        const results: any = {
            env: {
                REDIS_HOST: process.env.REDIS_HOST || '(not set, defaults to localhost)',
                REDIS_PASSWORD: process.env.REDIS_PASSWORD ? '***set***' : '(not set)',
            },
            connection: {},
            pubsub: {},
            socketAdapter: {}
        };

        // 1. Test basic Redis connectivity
        const redisUrl = process.env.REDIS_PASSWORD
            ? `redis://:${process.env.REDIS_PASSWORD}@${process.env.REDIS_HOST || 'localhost'}:6379`
            : `redis://${process.env.REDIS_HOST || 'localhost'}:6379`;

        let testClient: any = null;
        try {
            testClient = createClient({ url: redisUrl });
            testClient.on('error', () => {});

            const connectStart = Date.now();
            await Promise.race([
                testClient.connect(),
                new Promise((_, reject) => setTimeout(() => reject(new Error('connect timeout 5s')), 5000))
            ]);
            results.connection.status = 'connected';
            results.connection.latencyMs = Date.now() - connectStart;
            results.connection.url = redisUrl.replace(/:[^:@]*@/, ':***@');

            // 2. Test PING
            const pingStart = Date.now();
            const pong = await testClient.ping();
            results.connection.ping = pong;
            results.connection.pingMs = Date.now() - pingStart;

            // 3. Test SET/GET
            const testKey = '__socket_debug_' + Date.now();
            await testClient.set(testKey, 'ok', { EX: 10 });
            const val = await testClient.get(testKey);
            await testClient.del(testKey);
            results.connection.setGet = val === 'ok' ? 'ok' : 'FAILED: got ' + val;

            // 4. Test PUB/SUB (the mechanism Socket.IO Redis adapter uses)
            try {
                const subClient = testClient.duplicate();
                await subClient.connect();

                let received = false;
                const channel = '__socket_debug_pubsub_' + Date.now();

                await subClient.subscribe(channel, (message) => {
                    if (message === 'test_message') received = true;
                });

                // Small delay for subscription to register
                await new Promise(r => setTimeout(r, 200));

                await testClient.publish(channel, 'test_message');

                // Wait for message
                await new Promise(r => setTimeout(r, 500));

                await subClient.unsubscribe(channel);
                await subClient.disconnect();

                results.pubsub.status = received ? 'ok' : 'FAILED: message not received';
                results.pubsub.channel = channel;
            } catch (e: any) {
                results.pubsub.status = 'error';
                results.pubsub.error = e.message;
            }

            // 5. Redis INFO
            try {
                const info = await testClient.info('server');
                const versionMatch = info.match(/redis_version:(\S+)/);
                const uptimeMatch = info.match(/uptime_in_seconds:(\d+)/);
                const clientsInfo = await testClient.info('clients');
                const connectedMatch = clientsInfo.match(/connected_clients:(\d+)/);

                results.connection.redisVersion = versionMatch ? versionMatch[1] : 'unknown';
                results.connection.uptimeSeconds = uptimeMatch ? parseInt(uptimeMatch[1]) : 'unknown';
                results.connection.connectedClients = connectedMatch ? parseInt(connectedMatch[1]) : 'unknown';
            } catch (e: any) {
                results.connection.info = 'could not fetch: ' + e.message;
            }

        } catch (e: any) {
            results.connection.status = 'FAILED';
            results.connection.error = e.message;
        } finally {
            if (testClient) {
                try { await testClient.disconnect(); } catch (_) {}
            }
        }

        // 6. Check Socket.IO adapter state
        try {
            const io = getIO();
            if (io) {
                const adapter = io.sockets.adapter;
                results.socketAdapter.type = adapter.constructor.name;
                results.socketAdapter.totalRooms = adapter.rooms.size;
                results.socketAdapter.totalSockets = io.sockets.sockets.size;

                // Check if adapter has pubClient/subClient (Redis adapter)
                if ((adapter as any).pubClient) {
                    results.socketAdapter.pubClientReady = (adapter as any).pubClient.isReady || false;
                    results.socketAdapter.subClientReady = (adapter as any).subClient?.isReady || false;
                } else {
                    results.socketAdapter.note = 'No Redis pub/sub clients on adapter — using in-memory adapter';
                }
            } else {
                results.socketAdapter.status = 'IO not initialized';
            }
        } catch (e: any) {
            results.socketAdapter.error = e.message;
        }

        return res.status(200).send(results);
    }

    // @Get('/scripts/test-notif')
    // async testNotif(@Req() req: any, @Res() res: any) {
    //     await paymentRepository.create({
    //         "deleted" : false,
    //         "username" : "amineorion@gmail.com",
    //         "data" : {
    //             "txnid" : "899226bd5d106c20f9d75b85a9bd9ad0",
    //             "firstname" : "Ruhi Kapoor",
    //             "email" : "getepe6502@teasya.com",
    //             "phone" : "123456789",
    //             "key" : "0657AAEZDS",
    //             "mode" : "UPI",
    //             "unmappedstatus" : "NA",
    //             "cardCategory" : "NA",
    //             "addedon" : "2022-07-12 05:47:34",
    //             "payment_source" : "Easebuzz",
    //             "PG_TYPE" : "NA",
    //             "bank_ref_num" : "53033916956",
    //             "bankcode" : "NA",
    //             "error" : "APPROVED OR COMPLETED SUCCESSFULLY",
    //             "error_Message" : "APPROVED OR COMPLETED SUCCESSFULLY",
    //             "name_on_card" : "NA",
    //             "upi_va" : "9355213321@paytm",
    //             "cardnum" : "NA",
    //             "issuing_bank" : "NA",
    //             "easepayid" : "E2207129YQJ75W",
    //             "amount" : "1.0",
    //             "net_amount_debit" : "1.0",
    //             "cash_back_percentage" : "50.0",
    //             "deduction_percentage" : "0.0",
    //             "merchant_logo" : "NA",
    //             "surl" : "https://pay.easebuzz.in/webservice/success_url",
    //             "furl" : "https://pay.easebuzz.in/webservice/success_url",
    //             "productinfo" : "Introduction to Google Classroom",
    //             "udf10" : "",
    //             "udf9" : "",
    //             "udf8" : "",
    //             "udf7" : "",
    //             "udf6" : "",
    //             "udf5" : "",
    //             "udf4" : "",
    //             "udf3" : "",
    //             "udf2" : "",
    //             "udf1" : "",
    //             "card_type" : "UPI",
    //             "hash" : "66f15d40e9f7b5d991c0eb7390999b70d3fb1a8e1ada934fd3fdcb88f09fcf1fd3a1e8f3b1b76a6a065824bbbbfff30a48c37faf37fabe865ad7a964a32a5933",
    //             "status" : "success",
    //             "bank_name" : "NA"
    //         },
    //         "reason" : "Introduction to Google Classroom",
    //         "no" : "899226bd5d106c20f9d75b85a9bd9ad0",
    //         "amount" : 1,
    //         "status" : "success",
    //         "owner" : ("62a1d54a9f6b50d2ea8b58d7"),
    //         "paymentGateway" : ("6023ce8a3f09d941f2dfe091"),
    //         "university" : ("5ffda431be794b82dd8d1281")
    //     });
    // }

    @Get('/scripts/add-tokens')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addTokens(@Req() req: any, @Res() res: any) {
        let users = await userRepository.find({ token: { $exists: false } });
        for (let user of users) {
            if (!user.token) {
                user.token = uuidV4();
                await user.save();
            }
        }
        return res.send({ message: 'ok' });
    }

    @Get('/scripts/migrate')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async migrate(@Req() req: any, @Res() res: any) {
        const users = await userRepository.find({ classes: { $exists: true }, type: 'student' });
        for (let user of users) {
            let oldClasses = user.classes;

            if (user.classes.length > 0) {
                oldClasses.push(...user.classes);
            }

            if (oldClasses.length > 0) {
                await userRepository.update({ _id: user._id }, { $set: { classes: oldClasses } }, { multi: false });
            }
        }
        return res.send({ message: 'ok' });
    }

    // @Get('/scripts/fill-event')
    // @UseBefore(CanExecuteScript)
    // async fillEvent(@Req() req: any, @Res() res: any) {
    //     let applicants = await applicantRepository.find().select('_id').sort({createdAt: -1}).lean();
    //     for (let applicant of applicants) {
    //         let event = await eventRepository.findOne({'data.applicant': applicant._id}).select('_id date').sort({
    //             date: -1,
    //             createdAt: -1
    //         }).lean();
    //         if (event) {
    //             await applicantRepository.update({_id: applicant._id},
    //                 {$set: {latestEvent: event._id, latestEventAt: event.date}}, {multi: false});
    //         }
    //     }
    // }

    // @Get('/scripts/add-secret')
    // @UseBefore(CanExecuteScript)
    // async addSecret(@Req() req: any, @Res() res: any) {
    //     let users = await userRepository.find({useTwoFactorAuth: true});
    //     for (let user of users) {
    //         user.secret = otplib.authenticator.generateSecret();
    //         await user.save();
    //     }
    //     return res.send({message: 'ok'});
    // }
    //
    // @Get('/scripts/update-numbers')
    // @UseBefore(CanExecuteScript)
    // async updateNumbers(@Req() req: any, @Res() res: any) {
    //     let jobs = await jobRepository.find();
    //     for (let job of jobs) {
    //         job.numberOfActiveCandidates = await applicantRepository.count({job: job._id});
    //         await job.save();
    //     }
    //     return res.send({message: 'ok'});
    // }
    //
    // @Get('/scripts/stop-watch')
    // @UseBefore(IsAuthenticated)
    // @UseBefore(CanExecuteScript)
    // async stopWatch(@Req() req: any, @Res() res: any) {
    //     let googleCalendar = new GoogleCalendar(req.user);
    //     await googleCalendar.init();
    //     let meetings = await meetingRepository.find({owner: req.user._id});
    //     for (let meeting of meetings) {
    //         await googleCalendar.stopWatch(meeting.googleCalendarId);
    //     }
    //     return res.send({message: 'ok'});
    // }
    //
    // @Get('/scripts/update-lowercase')
    // @UseBefore(CanExecuteScript)
    // async updateLowercase(@Req() req: any, @Res() res: any) {
    //     let applicants = await applicantRepository.find();
    //     for (let applicant of applicants) {
    //         applicant.lowername = applicant.name.toLowerCase();
    //         applicant.loweremail = applicant.email.toLowerCase();
    //         await applicant.save();
    //     }
    //     return res.send({message: 'ok'});
    // }

    // @Get('/scripts/schedule')
    // @UseBefore(CanExecuteScript)
    // @UseAfter(FinishRequest)
    // @UseBefore(StartRequest)
    // async schedule(@Req() req: any, @Res() res: any) {
    // tslint:disable-next-line:max-line-length
    //     let users = await userRepository.find({ email: ['santosh.pakhare@mitwpu.edu.in', 'sai.ojha@mitwpu.edu.in', 'samrat.dev@mitwpu.edu.in'] });
    //     let applicants = await applicantRepository.find({ createdAt: { $gte: moment('2020-06-08T20:00:00+01:00') } });
    //     let i = 0;
    //     let time = 0;
    //     for (let applicant of applicants) {
    //         if (moment('2020-06-09T09:00:00+05:30').add(time, 'm').diff(moment('2020-06-09T17:00:00+05:30')) === 0) {
    //             time += 16 * 60;
    //         }
    //         if (moment('2020-06-09T09:00:00+05:30').add(time, 'm').diff(moment('2020-06-10T17:00:00+05:30')) === 0) {
    //             time += 16 * 60;
    //         }
    //         if (moment('2020-06-09T09:00:00+05:30').add(time, 'm').diff(moment('2020-06-11T17:00:00+05:30')) === 0) {
    //             time += 16 * 60;
    //         }
    //         if (moment('2020-06-09T09:00:00+05:30').add(time, 'm').diff(moment('2020-06-09T13:00:00+05:30')) === 0) {
    //             time += 60;
    //         }
    //         if (moment('2020-06-09T09:00:00+05:30').add(time, 'm').diff(moment('2020-06-10T13:00:00+05:30')) === 0) {
    //             time += 60;
    //         }
    //         if (moment('2020-06-09T09:00:00+05:30').add(time, 'm').diff(moment('2020-06-11T13:00:00+05:30')) === 0) {
    //             time += 60;
    //         }
    //         if (moment('2020-06-09T09:00:00+05:30').add(time, 'm').diff(moment('2020-06-12T13:00:00+05:30')) === 0) {
    //             time += 60;
    //         }
    //         let user = users[i];
    //         let event = await eventRepository.create({
    //             date: moment('2020-06-09T09:00:00+05:30').add(time, 'm'),
    //             type: 'Video Interview',
    //             data: {
    //                 applicant: applicant._id
    //             },
    //             note: '',
    //             status: 'accepted',
    //             owner: user._id,
    //             university: user.university
    //         });
    //         const token = (new Token({ id: event._id })).generate();
    //         await eventRepository.update({ _id: event._id }, { $set: { acceptToken: token } });
    //         let mailer = new InviteToMeeting(event._id);
    //         mailer.send().then(() => {
    //         });
    //         i += 1;
    //         if (i >= users.length) {
    //             i = 0;
    //             time += 12;
    //         }
    //     }
    // }

    // @Get('/scripts/custom-schedule')
    // @UseBefore(CanExecuteScript)
    // @UseAfter(FinishRequest)
    // @UseBefore(StartRequest)
    // async customSchedule(@Req() req: any, @Res() res: any) {
    //     let users = await userRepository.find({ _id: ['5ed80b4b8632d5ddf05b8a51', '5ed80b608632d5ddf05b8e54'] });
    // tslint:disable-next-line:max-line-length
    //     let applicants = await applicantRepository.find({ _id: ['5ed80b9405524c26d4bd9520', '5ed80baa05524c26d4bd9521', '5ed80bb705524c26d4bd9522', '5ed80bc505524c26d4bd9523'] });
    //     let i = 0;
    //     let time = 15;
    //     for (let applicant of applicants) {
    //         let user = users[i];
    //         let event = await eventRepository.create({
    //             date: moment().add(time, 'm'),
    //             type: 'Video Interview',
    //             data: {
    //                 applicant: applicant._id
    //             },
    //             note: '',
    //             status: 'accepted',
    //             owner: user._id,
    //             university: user.university
    //         });
    //         const token = (new Token({ id: event._id })).generate();
    //         await eventRepository.update({ _id: event._id }, { $set: { acceptToken: token } });
    //         let mailer = new InviteToMeeting(event._id);
    //         mailer.send().then(() => {
    //         });
    //         i += 1;
    //         if (i >= users.length) {
    //             i = 0;
    //             time += 15;
    //         }
    //     }
    // }

    // @Post('/scripts/send-mail')
    // async mailer(
    //     @Req() req: any,
    //     @Res() res: any
    // ) {
    //     try {
    //         let certificate = new CourseCertificateManager(req.user, '6085edff7835b3607b32b179');
    //
    //         await certificate.sendCertificate();
    //
    //         return res.send({message: 'ok'});
    //     } catch (error: any) {
    //         console.error(error);
    //         return res.status(400).send({error: error.message});
    //     }
    // }

    @Post('/scripts/send-sms')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async smsSender(@Req() req: any, @Res() res: any) {
        try {
            const course = await courseRepository.findOne({ _id: '6085edff7835b3607b32b179' }).lean();
            const university = await universityRepository.findOne({ _id: course.university }).lean();
            const student = await userRepository.findOne({ _id: '608c44344fdb39304b71d491' }).lean();

            const customSmsSender = new CustomSmsSender({
                ...student,
                course
            }, student, university.defaultInvoice.invoice, university);
            await customSmsSender.send();

            return res.send({ message: 'ok' });

        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/get-applicants')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async getApplicants(@Req() req: any, @Res() res: any) {
        try {
            const applicants = await applicantRepository.find({
                latestEventAt: {
                    $gte: moment().add(1, 'day').startOf('day'),
                    $lte: moment().add(1, 'day').endOf('day')
                }
            }).select('email name phone testTitle latestEvent latestEventAt')
                .populate({
                    path: 'latestEvent',
                    select: 'owner',
                    populate: {
                        path: 'owner',
                        select: 'name'
                    }
                }).sort({ latestEventAt: 1 })
                .lean();

            const items = [];

            if (applicants.length > 0) {
                for (let applicant of applicants) {
                    const item = {
                        'Applicant Name': applicant.name || '',
                        'Applicant Email': applicant.email || '',
                        'Applicant Phone': applicant.phone || '',
                        'Cluster': applicant.testTitle || '',
                        'Interview Date': moment(applicant.latestEventAt).tz('Asia/Kolkata').format('LLL'),
                        'Interviewer': applicant.latestEvent.owner.name || ''
                    };

                    items.push(item);
                }
            }

            let converter = new Json2Excel(items);
            const reportPath = await converter.convert();
            const buffer = readFileSync(reportPath);
            res.writeHead(200, {
                'Content-Type': 'application/vnd.ms-excel',
                'Content-disposition': `attachment;attachment; applicants.xlsx`,
                'Content-Length': buffer.length
            });
            return res.end(buffer);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Post('/scripts/add-applicants')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addApplicants(@Req() req: any, @Res() res: any) {
        try {
            const { applicants } = req.body;

            for (let applicant of applicants) {
                await applicantRepository.create(applicant);
            }

            return res.status(201).send({ message: 'Applicants added successfully!' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/replace-program-fees-with-price')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async replaceProgramFeesWithPrice(@Req() req: any, @Res() res: any) {
        try {
            const programs = await programRepository.find({ fees: { $exists: true } }).lean();

            for (let program of programs) {
                const price = +program.fees;
                await programRepository.update(
                    { _id: program._id },
                    { $set: { price } },
                    { multi: false }
                );
            }

            return res.status(201).send({ message: 'Fees replaced successfully!' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/add-requested-to-for-review-requests')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async requestedTo(@Req() req: any, @Res() res: any) {
        try {
            const reviewRequests = await reviewRequestRepository.find({}).lean();

            for (let reviewRequest of reviewRequests) {
                const requestedTo = reviewRequest.raisedTo;
                const requestedBy = reviewRequest.raisedBy;

                await reviewRequestRepository.update(
                    { _id: reviewRequest._id },
                    { $set: { requestedTo, requestedBy } },
                    { multi: false }
                );
            }

            return res.status(201).send({ message: 'Added successfully!' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/change-token-used-type-to-number')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async changeTokenType(@Req() req: any, @Res() res: any) {
        try {
            const unUsedTokens = await tokenRepository.find({ used: { $eq: 'false' } }).lean();

            await tokenRepository.update(
                { _id: { $in: unUsedTokens.map(token => token._id) } },
                { $set: { used: 0 } },
                { multi: true }
            );

            const usedTokens = await tokenRepository.find({ used: { $eq: 'true' } }).lean();

            await tokenRepository.update(
                { _id: { $in: usedTokens.map(token => token._id) } },
                { $set: { used: 1 } },
                { multi: true }
            );

            return res.status(201).send({ message: 'Tokens updated successfully!' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/students')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async students(@Req() req: any, @Res() res: any) {
        try {
            const condition = { type: UserTypes.STUDENT, university: Types.ObjectId('61d28e1a940446002a51f59b') };
            const users: User[] = await userRepository.find(condition).populate({
                path: 'classes',
                select: 'name'
            }).lean();

            const students = [];

            for (let user of users) {
                const classes = [];
                if (user.classes && user.classes.length > 0) {
                    classes.push(...user.classes.map(c => c.name));
                }

                const data: any = {
                    Name: StringUtils.capitalize(user.name),
                    Email: StringUtils.lowercase(user.email),
                    Classes: classes.join(', ')
                };

                students.push(data);
            }

            const converter = new Json2Excel(students);
            const filePath = await converter.convert();
            const buffer = readFileSync(filePath);
            req.downloadFile = filePath;
            res.setHeader('Content-Type', 'application/vnd.ms-excel');
            res.writeHead(200, {
                'Content-Type': 'application/vnd.ms-excel',
                'Content-disposition': 'attachment;attachment; filename = Students.xlsx',
                'Content-Length': buffer.length
            });
            return res.end(buffer);

        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/fix-role-domains')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async fixRoleDomains(@Req() req: any, @Res() res: any) {
        try {
            const condition = { allDomains: { $exists: true }, 'domains.allSelected': { $exists: false } };
            const roles = await roleRepository.find(condition).lean();

            for (let role of roles) {
                const { allDomains, domains } = role;
                let selected = [];
                if (Array.isArray(domains)) {
                    selected = domains;
                }

                await roleRepository.update(
                    { _id: role._id },
                    { $set: { allDomains: undefined, domains: undefined } },
                    { multi: false }
                );

                await roleRepository.update(
                    { _id: role._id },
                    { $set: { domains: { allSelected: allDomains, exceptions: [], hasException: false, selected } } },
                    { multi: false }
                );
            }

            return res.status(201).send({ message: 'Roles updated successfully' });

        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/add-exam-enrollment-university')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addExamEnrollmentUniversity(@Req() req: any, @Res() res: any) {
        try {
            const condition = { exam: { $exists: true }, university: { $exists: false } };
            const populate = { path: 'exam', select: 'university' };
            const examEnrollments: ExamEnrollment[] = await examEnrollmentRepository.find(condition).populate(populate).lean();

            for (let examEnrollment of examEnrollments) {
                if (examEnrollment.exam && examEnrollment.exam.university) {
                    await examEnrollmentRepository.update(
                        { _id: examEnrollment._id },
                        { $set: { university: examEnrollment.exam.university } },
                        { multi: false }
                    );
                }
            }

            return res.status(201).send({ message: 'Enrollments updated successfully' });

        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/add-visible-to-question-templates')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addVisibleToQuestionTemplate(@Req() req: any, @Res() res: any) {
        try {
            const questions: Question[] = await questionRepository
                .find({ templates: { $exists: true }, type: QuestionTypes.PROGRAMMING })
                .lean();

            for (let question of questions) {
                const templates = [];

                for (let template of question.templates) {
                    templates.push({ ...template, isVisible: true });
                }

                await questionRepository.update(
                    { _id: question._id },
                    { $set: { templates } },
                    { multi: false }
                );
            }

            return res.status(201).send({ message: 'Question Templates updated successfully' });

        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Get('/scripts/fix-ppt')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async fixPPT(@Req() req: any, @Res() res: any) {
        try {
            let lectures = await lectureRepository.find({
                pages: {
                    $elemMatch: {
                        assetUrl: { $exists: true, $regex: '.*google.*' },
                        contentType: 'document',
                        html: { $exists: false }
                    }
                }
            });
            for (let lecture of lectures) {
                for (let page of lecture.pages) {
                    // tslint:disable-next-line:max-line-length
                    page.html = '<div class=\'pdf-container\' style=\'width: 100%; height: 100%\'><iframe allowfullscreen src=\'' + page.assetUrl + '\' style=\'width: 100%; height: 100%\'></iframe></div>';
                }
                await lecture.save();
            }
            return res.status(201).send({ message: 'Done' });

        } catch
        (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    //
    // @Get('/scripts/lectures/create-videos')
    // async createVideo(@Req() req: any, @Res() res: any) {
    //     try {
    //         let lectures = await lectureRepository.find({
    //             pages: {
    //                 $elemMatch: {
    //                     contentType: 'video',
    //                     video: {$regex: '.*lmsassets.*'}
    //                 }
    //             }
    //         }).sort({createdAt: 1});
    //         let config = await universityConfigurationRepository.findOne({university: ("5ffda431be794b82dd8d1281")});
    //         let s3 = new S3University(config);
    //         for (let lecture of lectures) {
    //             if (!lecture.course) {
    //                 let chapter = await chapterRepository.findOne({lectures: lecture._id});
    //                 let course = await courseRepository.findOne({chapters: chapter._id});
    //                 if (!course) {
    //                     continue;
    //                 }
    //                 lecture.course = course._id;
    //                 await lectureRepository.update({_id: lecture._id}, {$set: {course: lecture.course}}, {multi: false})
    //             }
    //             if (lecture.course) {
    //                 for (let page of lecture.pages) {
    //                     try {
    //                         if (page.contentType === 'video') {
    //                             let downloader = new Downloader(page.video);
    //                             let videoPath = await downloader.download();
    // tslint:disable-next-line:max-line-length
    //                             let url = await s3.upload(videoPath, uuidV4() + '-' + videoPath.split('/').pop(), config.buckets.LMS_COURSE_VIDEOS);
    //                             await videoUploaderRepository.create({
    //                                 url,
    //                                 isDashed: false,
    //                                 isWatermarked: false,
    //                                 course: lecture.course,
    //                                 lecture: lecture._id,
    //                                 owner: lecture.owner,
    //                                 university: config.university
    //                             });
    //                             page.video = url;
    //                             page.assetUrl = url;
    //                         }
    //                     } catch (e) {
    //                         console.error(e);
    //                     }
    //                     await lectureRepository.update({_id: lecture._id}, {$set: {pages: lecture.pages}}, {multi: false})
    //                 }
    //             }
    //         }
    //         return res.send({message: 'done'});
    //     } catch (error: any) {
    //         console.error(error);
    //         return res.status(400).send({error: error.message});
    //     }
    // }

    @Get('/scripts/convert-pptx-to-images')
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async convertPptxToImages(@Req() req: any, @Res() res: any) {
        try {
            // Find all lectures with pptx pages that have no images
            const lectures = await lectureRepository.find({
                'pages.contentType': 'document',
                'pages.storedURI': { $exists: true, $regex: '\\.pptx?' }
            }).lean();

            const universityConfig = await universityConfigurationRepository.findOne().lean();
            if (!universityConfig) {
                return res.status(400).send({ error: 'No university config found' });
            }

            const s3 = new S3University(universityConfig);
            let converted = 0;
            let skipped = 0;
            let failed = 0;
            const errors = [];

            for (const lecture of lectures) {
                if (!lecture.pages || lecture.pages.length === 0) continue;

                let lectureUpdated = false;

                for (const page of lecture.pages) {
                    if (!page.storedURI || page.storedURI.indexOf('.ppt') === -1) continue;
                    if (page.images && page.images.length > 0) {
                        skipped++;
                        continue;
                    }

                    try {
                        console.log(`[convert-pptx] Processing: ${page.storedURI}`);

                        const downloader = new Downloader(page.storedURI, s3);
                        const path = await downloader.download();

                        if (!path) {
                            failed++;
                            errors.push({ uri: page.storedURI, error: 'Download returned null' });
                            continue;
                        }

                        const file = {
                            buffer: FileUtils.readFile(path),
                            originalname: downloader.filename || path.split('/').pop()
                        };

                        const converter = new ConvertPPTToImages(file, universityConfig);
                        page.images = await converter.convert();

                        FileUtils.removeFile(path);

                        if (page.images && page.images.length > 0) {
                            converted++;
                            lectureUpdated = true;
                            console.log(`[convert-pptx] OK: ${page.storedURI} -> ${page.images.length} images`);
                        } else {
                            failed++;
                            errors.push({ uri: page.storedURI, error: 'Conversion produced 0 images' });
                        }
                    } catch (error: any) {
                        failed++;
                        errors.push({ uri: page.storedURI, error: error.message });
                        console.error(`[convert-pptx] FAIL: ${page.storedURI}`, error.message);
                    }
                }

                if (lectureUpdated) {
                    await lectureRepository.update(
                        { _id: lecture._id },
                        { $set: { pages: lecture.pages, converted: true } },
                        { multi: false }
                    );
                }
            }

            return res.status(200).send({
                message: 'Done',
                total: lectures.length,
                converted,
                skipped,
                failed,
                errors: errors.slice(0, 20)
            });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
