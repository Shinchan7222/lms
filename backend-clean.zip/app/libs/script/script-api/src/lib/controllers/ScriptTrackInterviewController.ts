import { CanExecuteScript } from '@edorer/script-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { trackInterviewRepository } from '@edorer/track-interview-data';
import { User, userRepository, UserTypes } from '@edorer/user-data';

@JsonController()
export class ScriptTrackInterviewController {

    @Get('/scripts/add-interviewers-to-model')
    @UseBefore(CanExecuteScript)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addInterviewersToModel(@Req() req: any, @Res() res: any) {
        try {
            const trackInterviews = await trackInterviewRepository
                .find({ interviewer: { $exists: true }, university: { $exists: true } })
                .lean();

            for (let trackInterview of trackInterviews) {
                const universityOwner: User = await userRepository
                    .findOne({ type: UserTypes.UNIVERSITY_OWNER, university: trackInterview.university })
                    .lean();

                await trackInterviewRepository.update(
                    { _id: trackInterview._id },
                    { $set: { interviewers: [universityOwner._id, trackInterview.interviewer] } },
                    { multi: false },
                );
            }

            return res.status(200).send({ message: 'Added successfully' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ message: error.message });
        }
    }
}
