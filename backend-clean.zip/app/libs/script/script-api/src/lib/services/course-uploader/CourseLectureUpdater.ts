import { Workbook } from 'exceljs';
import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { videoTempRepository } from '@edorer/video-uploader-data';
import { universityConfigurationRepository } from '@edorer/university-data';
import { Types } from 'mongoose';
import { CourseStructureFixerService } from './CourseStructureFixerService';

interface ExcelRow {
    'Course Name': string;
    'Program Name'?: string;
    'Unit Name': string;
    'Topic Name': string;
    'Video Link': string;
    'Faculty Name for videos'?: string;
    'Unit PDF Links'?: string;
}

interface GroupedData {
    courseName: string;
    programName?: string;
    unitName: string;
    topicName: string;
    videoLinks: string[];
    facultyName?: string;
}

interface CourseGroup {
    courseName: string;
    programName?: string;
    units: Map<string, UnitGroup>;
}

interface UnitGroup {
    unitName: string;
    topics: Map<string, TopicGroup>;
}

interface TopicGroup {
    topicName: string;
    videoUrls: string[];
}

export class CourseLectureUpdater {
    private readonly excelFile: any;
    private readonly universityId: string;
    private readonly ownerId: string = '692ab73c5426270099610321'; // From existing code
    private readonly domainId: string = '692aaf11c0d6c0620af3790a'; // From existing code
    private workbook: Workbook | null = null;
    private unitPdfMap: Map<string, string> = new Map(); // courseName|unitName -> pdfLink

    constructor(excelFile: any, universityId: string) {
        this.excelFile = excelFile;
        this.universityId = universityId;
    }

    /**
     * Main process method to update course lectures
     */
    async process(): Promise<{ success: boolean; courseIds: string[]; errors: string[] }> {
        const errors: string[] = [];
        const courseIds: string[] = [];

        try {
            // Parse Excel file (First sheet only)
            const rows = await this.parseExcel();

            // Group data by Course -> Unit -> Topic
            const courseGroups = this.groupByCourseUnitTopic(rows);

            // Process each course
            for (const [courseName, courseGroup] of courseGroups) {
                try {
                    const courseId = await this.updateCourseLectures(courseGroup);
                    courseIds.push(courseId);
                    console.log(`Successfully processed course: ${courseName} (ID: ${courseId})`);

                    const fixerService = new CourseStructureFixerService(this.universityId);
                    const course = await courseRepository.findOne({ _id: courseId });
                    if (course) {
                        await fixerService.processCourse(course);
                    }

                } catch (error: any) {
                    const errorMsg = `Error processing course ${courseName}: ${error.message}`;
                    errors.push(errorMsg);
                    console.error(errorMsg, error);
                }
            }

            if (courseIds.length === 0) {
                if (errors.length > 0) {
                    return { success: false, courseIds: [], errors };
                }
                throw new Error('No courses were processed');
            }

            return { success: true, courseIds, errors };
        } catch (error: any) {
            errors.push(`Failed to process Excel file: ${error.message}`);
            return { success: false, courseIds: [], errors };
        }
    }

    /**
     * Parse Excel file and extract rows from the first worksheet
     */
    private async parseExcel(): Promise<ExcelRow[]> {
        this.workbook = new Workbook();
        await this.workbook.xlsx.load(this.excelFile.buffer);

        const worksheet = this.workbook.getWorksheet(1); // Get the first worksheet
        if (!worksheet) {
            throw new Error('Excel file is empty or invalid');
        }

        const rows: ExcelRow[] = [];
        let headers: { [key: string]: number } = {};
        let headerRowFound = false;

        // Process each row
        worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
            // First row should be headers
            if (rowNumber === 1) {
                row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
                    const headerValue = cell.value?.toString() || '';
                    headers[headerValue] = colNumber;
                });
                headerRowFound = true;

                // Validate required columns
                const requiredColumns = ['Course Name', 'Unit Name', 'Topic Name', 'Video Link'];
                for (const col of requiredColumns) {
                    if (!(col in headers)) {
                        throw new Error(`Missing required column: ${col}`);
                    }
                }
                return;
            }

            if (!headerRowFound) {
                return;
            }

            // Extract row data
            const rowData: ExcelRow = {
                'Course Name': '',
                'Program Name': undefined,
                'Unit Name': '',
                'Topic Name': '',
                'Video Link': '',
                'Faculty Name for videos': undefined,
                'Unit PDF Links': undefined
            };

            // Get cell values by header name
            for (const [headerName, colNumber] of Object.entries(headers)) {
                const cell = row.getCell(colNumber);
                let cellValue = '';

                // Check if cell has a hyperlink
                const hyperlink = cell.hyperlink as any;
                if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
                    cellValue = hyperlink.target;
                } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
                    const formula = (cell.value as any).formula;
                    const urlMatch = formula?.match(/=HYPERLINK\("([^"]+)"/i);
                    if (urlMatch && urlMatch[1]) {
                        cellValue = urlMatch[1];
                    } else {
                        if (cell.value && (cell.value as any).hyperlink) {
                            cellValue = (cell.value as any).hyperlink;
                        } else {
                            cellValue = cell.value?.toString() || '';
                        }
                    }
                } else {
                    if (cell.value && (cell.value as any).hyperlink) {
                        cellValue = (cell.value as any).hyperlink;
                    } else {
                        cellValue = cell.value?.toString() || '';
                    }
                }

                if (headerName in rowData) {
                    (rowData as any)[headerName] = cellValue;
                }
            }

            // Only add row if it has required data
            if (rowData['Course Name'] || rowData['Unit Name'] || rowData['Topic Name']) {
                rows.push(rowData);

                // Store unit PDF link if present
                if (rowData['Unit PDF Links'] && rowData['Unit PDF Links'].trim() && rowData['Course Name'] && rowData['Unit Name']) {
                    const key = `${rowData['Course Name'].trim()}|${rowData['Unit Name'].trim()}`;
                    this.unitPdfMap.set(key, rowData['Unit PDF Links'].trim());
                }
            }
        });

        if (rows.length === 0) {
            throw new Error('No data found in Excel file');
        }

        return rows;
    }

    /**
     * Group rows by Course -> Unit -> Topic
     */
    private groupByCourseUnitTopic(rows: ExcelRow[]): Map<string, CourseGroup> {
        const courseMap = new Map<string, CourseGroup>();

        for (const row of rows) {
            const courseName = row['Course Name'];
            const unitName = row['Unit Name'];
            const topicName = row['Topic Name'];

            if (!courseName || !unitName || !topicName) {
                continue;
            }
            console.log(courseName);
            if (courseName !== 'Financial Management') {
                continue;
            }

            // Get or create course group
            if (!courseMap.has(courseName)) {
                courseMap.set(courseName, {
                    courseName,
                    programName: row['Program Name'],
                    units: new Map()
                });
            }

            const courseGroup = courseMap.get(courseName)!;

            // Get or create unit group
            if (!courseGroup.units.has(unitName)) {
                courseGroup.units.set(unitName, {
                    unitName,
                    topics: new Map()
                });
            }

            const unitGroup = courseGroup.units.get(unitName)!;

            // Get or create topic group
            if (!unitGroup.topics.has(topicName)) {
                unitGroup.topics.set(topicName, {
                    topicName,
                    videoUrls: []
                });
            }

            const topicGroup = unitGroup.topics.get(topicName)!;

            // Add video link if present
            if (row['Video Link'] && row['Video Link'].trim()) {
                topicGroup.videoUrls.push(row['Video Link'].trim());
            }
        }

        return courseMap;
    }

    /**
     * Update course by ensuring chapters and lectures exist
     */
    /**
     * Update course by ensuring chapters and lectures exist
     */
    async updateCourseLectures(courseGroup: CourseGroup): Promise<string> {
        // Fetch videos from videoTemp for all topics
        const videoMap = await this.fetchVideosFromVideoTemp(courseGroup);

        // Get course
        const course = await this.findCourse(courseGroup);



        if (!course) {
            throw new Error(`Course not found: ${courseGroup.courseName}`);
        }

        // Create lectures in existing chapters
        const chapterIds: Types.ObjectId[] = [];

        let unitIndex = 1;
        for (const [unitName, unitGroup] of courseGroup.units) {
            const chapterTitle = `Module ${unitIndex} - ${unitName}`;

            // Find existing chapter only

            // Find or create chapter
            const { chapter, isNew } = await this.createChapter(course._id, chapterTitle);

            if (isNew) {
                chapterIds.push(chapter._id);
            }

            const lectureIds: Types.ObjectId[] = [];

            const unitPdfKey = `${courseGroup.courseName}|${unitName}`;
            const unitPdfLink = this.unitPdfMap.get(unitPdfKey);

            // Logic to calculate Unit Index for lectures within this chapter
            // "Unit X" numbering logic: 
            // 1. Special types (Assignment, Quiz, Question) do NOT get "Unit X".
            // 2. Regular lectures get "Unit X".
            // 3. "Unit X" increments only when the "base name" changes.

            let currentLectureUnitIndex = 0;
            let lastBaseName = '';
            let isFirstTopic = true;

            for (const [topicName, topicGroup] of unitGroup.topics) {
                const videoUrls = videoMap.get(`${courseGroup.courseName}|${unitName}|${topicName}`) || [];

                let finalVideoUrls = videoUrls;
                if (finalVideoUrls.length === 0 && topicGroup.videoUrls.length > 0) {
                    finalVideoUrls = topicGroup.videoUrls;
                }

                if (finalVideoUrls.length === 0) {
                    console.warn(`No videos found for ${courseGroup.courseName} - ${unitName} - ${topicName}`);
                    continue;
                }

                // --- Naming Logic Start ---
                const isSpecial = this.isSpecialType(topicName);
                let lectureTitle = topicName;

                if (!isSpecial) {
                    // It's a regular lecture, so it gets "Unit X" prefix.
                    // Determine if we need to increment the index.
                    // Clean suffix logic similar to FixerService

                    // The topicName acts as the "suffix" here compared to Fixer logic 
                    // (because Fixer parses "Unit X - Suffix", here we are building it).
                    // So we treat topicName as the content to analyze for baseName.

                    let cleanName = topicName.trim();
                    // Remove any existing "Unit X" prefix if the user put it in Excel (unlikely but safe)
                    cleanName = cleanName.replace(/^(\*?)\s*Unit\s+(\d+)([-:])\s*/i, '');

                    const baseNameMatch = cleanName.match(/^(.*?)(\s+\d+)?$/);
                    const baseName = baseNameMatch ? baseNameMatch[1].trim().toLowerCase() : cleanName.toLowerCase();

                    if (baseName !== lastBaseName) {
                        currentLectureUnitIndex++;
                        lastBaseName = baseName;
                    }

                    lectureTitle = `Unit ${currentLectureUnitIndex} - ${topicName}`;
                }
                // --- Naming Logic End ---

                // Always create new lecture, even if it exists
                const lecture = await this.createLecture(course._id, lectureTitle, finalVideoUrls, (isFirstTopic && unitPdfLink) ? unitPdfLink : null);
                lectureIds.push(lecture._id);

                isFirstTopic = false;
            }

            if (lectureIds.length > 0) {
                for (const lectureId of lectureIds) {
                    await chapterRepository.findOneAndUpdate(
                        { _id: chapter._id },
                        { $addToSet: { lectures: lectureId } },
                        { multi: false }
                    );
                }
            }
            unitIndex++;
        }

        // Link chapters to course (redundant if they exist, but harmless)
        for (const chapterId of chapterIds) {
            await courseRepository.findOneAndUpdate(
                { _id: course._id },
                { $addToSet: { chapters: chapterId } },
                { multi: false }
            );
        }

        return course._id.toString();
    }

    private isSpecialType(title: string): boolean {
        const cleanTitle = title.trim();
        if (cleanTitle.match(/^Assignment/i)) return true;
        if (cleanTitle.match(/^Quiz/i)) return true;
        if (cleanTitle.match(/^Question/i)) return true;
        return false;
    }

    private async fetchVideosFromVideoTemp(courseGroup: CourseGroup): Promise<Map<string, string[]>> {
        const videoMap = new Map<string, string[]>();

        for (const [unitName, unitGroup] of courseGroup.units) {
            for (const [topicName, topicGroup] of unitGroup.topics) {
                const key = `${courseGroup.courseName}|${unitName}|${topicName}`;

                const videoTemp = await videoTempRepository.findOne({
                    courseName: courseGroup.courseName.trim(),
                    unitName: unitName.trim(),
                    topicName: topicName.trim()
                }).lean();

                if (videoTemp && videoTemp.url) {
                    videoMap.set(key, [videoTemp.url]);
                } else {
                    videoMap.set(key, []);
                }
            }
        }

        return videoMap;
    }

    private async findCourse(courseGroup: CourseGroup): Promise<any> {

        // Format course title
        let courseTitle: string = `${courseGroup.programName} - ${courseGroup.courseName}`;

        const existingCourse = await courseRepository.findOne({
            title: courseTitle,
            university: this.universityId,
            deleted: { $ne: true }
        }).lean();

        return existingCourse;
    }

    private async findChapter(courseId: Types.ObjectId, title: string): Promise<any> {
        const existingChapter = await chapterRepository.findOne({
            course: courseId,
            title: title
        }).lean();

        return existingChapter;
    }

    private async createLecture(courseId: Types.ObjectId, topicName: string, videoUrls: string[], pdfUrl: string | null = null): Promise<any> {
        // Check if lecture already exists for this course with the same title
        const existingLecture = await lectureRepository.findOne({
            course: courseId,
            title: topicName
        }).lean();

        if (existingLecture) {
            return existingLecture;
        }

        const pages: any[] = [];

        const videoPages = videoUrls.map((videoUrl, index) => ({
            title: index === 0 ? 'Video' : `Video ${index + 1}`,
            contentType: 'video',
            video: videoUrl,
            assetUrl: videoUrl,
            time: 1800
        }));

        pages.push(...videoPages);

        const lecture = await lectureRepository.create({
            course: courseId,
            owner: this.ownerId,
            title: topicName,
            pages: pages
        });

        return lecture;
    }

    private async createChapter(courseId: Types.ObjectId, unitName: string): Promise<{ chapter: any; isNew: boolean }> {
        // Check if chapter already exists for this course with the same title
        const existingChapter = await chapterRepository.findOne({
            course: courseId,
            title: unitName
        }).lean();

        if (existingChapter) {
            return { chapter: existingChapter, isNew: false };
        }

        // Create new chapter if not found
        const chapter = await chapterRepository.create({
            course: courseId,
            owner: this.ownerId,
            title: unitName,
            lectures: []
        });

        return { chapter, isNew: true };
    }
}
