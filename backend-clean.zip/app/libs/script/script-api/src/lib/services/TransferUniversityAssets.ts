import { University, universityRepository } from '@edorer/university-data';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { mailer } from '@edorer/mailer';
import { UniversityConfiguration } from '@edorer/university-data';

export class TransferUniversityAssets {
  private readonly universities: University[] = [];
  private readonly universityConfig: UniversityConfiguration;
  private readonly results: {
    success: number;
    failed: number;
    urls: { original: string; new: string }[];
  };

  private readonly BATCH_SIZE = 10;
  private readonly MAX_RETRIES = 3;

  constructor(universities: University[] = [], universityConfig: UniversityConfiguration) {
    this.universities = universities;
    this.universityConfig = universityConfig;
    this.results = {
      success: 0,
      failed: 0,
      urls: []
    };
  }

  private isValidUrl(url: string | undefined): boolean {
    if (!url) return false;
    try {
      new URL(url);
      return url.includes('amazonaws.com') || url.includes('s3-ap-south-1.amazonaws.com') || url.includes('s3.ap-south-1.amazonaws.com');
    } catch {
      return false;
    }
  }

  private async processUrl(url: string | undefined, bucketName: any, retries = 0): Promise<string | undefined> {
    let downloadedUrl: string | undefined;

    try {
      if (!this.isValidUrl(url)) return undefined;

      // Check if this URL has already been processed
      const existingResult = this.results.urls.find((result) => result.original === url);
      if (existingResult) {
        return existingResult.new;
      }

      const downloader = new Downloader(url);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      const s3 = new S3University(this.universityConfig, true);
      const filename = url.split('/').pop() || `file-${Date.now()}`;
      const uploadedUrl = await s3.uploadBuffer(fileContent, filename, bucketName);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      this.results.success++;
      this.results.urls.push({ original: url, new: uploadedUrl });

      return uploadedUrl;
    } catch (error) {
      console.error(`Error processing URL ${url}:`, error);
      if (retries < this.MAX_RETRIES) {
        console.warn(`Retry ${retries + 1} for asset ${url}`);
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retries + 1)));
        return this.processUrl(url, bucketName, retries + 1);
      }
      console.error(`Failed to process asset after ${this.MAX_RETRIES} retries:`, error);
      this.results.failed++;
      return undefined;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch (error) {
          console.error('Failed to cleanup temporary file:', error);
        }
      }
    }
  }

  private async processAsset(university: University): Promise<void> {
    try {
      console.log(`Processing university: ${university.name} (${university._id})`);

      const updatedAsset: Partial<University> = {};
      let assetsTransferred = false;

      // Process all image assets
      const assetFields = [
        { field: 'logo', bucket: this.universityConfig.buckets.ASSETS },
        { field: 'loginImage', bucket: this.universityConfig.buckets.ASSETS },
        { field: 'whiteLogo', bucket: this.universityConfig.buckets.ASSETS },
        { field: 'favicon', bucket: this.universityConfig.buckets.ASSETS },
        { field: 'smallLogo', bucket: this.universityConfig.buckets.ASSETS },
        { field: 'url', bucket: this.universityConfig.buckets.LMS_COURSE_VIDEOS }
      ];

      for (const { field, bucket } of assetFields) {
        if (university[field]) {
          const newUrl = await this.processUrl(university[field], bucket);

          if (newUrl) {
            updatedAsset[field] = newUrl;
            updatedAsset[`previous${field.charAt(0).toUpperCase() + field.slice(1)}`] = university[field];
            console.log(`✅ Transferred ${field} for university ${university.name}`);
            assetsTransferred = true;
          }
        }
      }

      if (assetsTransferred) {
        await universityRepository.update({ _id: university._id }, { $set: updatedAsset });
        console.log(`✅ University ${university.name} updated successfully`);
      } else {
        console.log(`⚠️ No assets transferred for university: ${university.name}`);
      }
    } catch (error) {
      console.error(`❌ Error processing university ${university._id}:`, error);
      this.results.failed++;
    }
  }

  private async processBatch(batch: University[]) {
    await Promise.all(batch.map((university) => this.processAsset(university)));
  }

  public async transfer() {
    if (this.universities.length === 0) {
      console.log('No universities to process');
      return;
    }

    console.log(`Starting transfer for ${this.universities.length} universities...`);

    for (let i = 0; i < this.universities.length; i += this.BATCH_SIZE) {
      const batch = this.universities.slice(i, i + this.BATCH_SIZE);
      try {
        console.log(`Processing batch ${Math.floor(i / this.BATCH_SIZE) + 1}/${Math.ceil(this.universities.length / this.BATCH_SIZE)}`);
        await this.processBatch(batch);
      } catch (error) {
        console.error(`Error processing batch starting at index ${i}:`, error);
      }
    }

    console.log('Transfer summary:');
    console.log(`✅ Total successful transfers: ${this.results.success}`);
    console.log(`❌ Total failed transfers: ${this.results.failed}`);

    await this.sendMail();
  }

  private async sendMail() {
    try {
      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';

      // Create a more detailed email with results
      const successfulTransfers = this.results.success;
      const failedTransfers = this.results.failed;
      const totalUniversities = this.universities.length;

      mailOptions.html = `
        <h2>University Assets Transfer Complete</h2>
        <p>Total universities processed: ${totalUniversities}</p>
        <p>Successful asset transfers: ${successfulTransfers}</p>
        <p>Failed asset transfers: ${failedTransfers}</p>
        <br/>
        ${failedTransfers > 0 ? '<p style="color: red;">⚠️ Some assets failed to transfer. Please check the logs for details.</p>' : ''}
        <br/>
        <p>Best regards,</p>
        <p><em>This is an automated message, please do not reply directly to this email.</em></p>
      `;
      mailOptions.subject = `University Assets Transfer Complete - ${successfulTransfers} succeeded, ${failedTransfers} failed`;
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();
      await mailer.send(mailOptions);
      console.log('Transfer report email sent successfully');
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }
}
