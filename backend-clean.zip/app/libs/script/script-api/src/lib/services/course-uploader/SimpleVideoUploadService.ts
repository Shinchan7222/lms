import { Workbook } from 'exceljs';
import { videoTempRepository } from '@edorer/video-uploader-data';
import { universityConfigurationRepository } from '@edorer/university-data';
import { S3University, Downloader } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { GoogleDriveDownloader } from './GoogleDriveDownloader';
import { v4 as uuidV4 } from 'uuid';
import moment = require('moment');
// NEW IMPORTS
import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { Types } from 'mongoose';

interface ExcelRow {
    'Course Name': string;
    'Program Name'?: string;
    'Unit Name': string;
    'Topic Name': string;
    'Video Link': string;
    'Faculty Name for videos'?: string;
    'Semester'?: string;
}

interface GroupedData {
    courseName: string;
    programName?: string;
    unitName: string;
    topicName: string;
    videoLinks: string[];
    facultyName?: string;
    semester?: string;
}

const pLimit = require('p-limit');

export class SimpleVideoUploadService {
    private readonly excelFile: any;
    private readonly universityId: string;
    private universityConfig: any;
    private googleDriveDownloader: GoogleDriveDownloader | null = null;

    constructor(excelFile: any, universityId: string) {
        this.excelFile = excelFile;
        this.universityId = universityId;
    }

    async process(): Promise<{ success: number; errors: string[]; duplicates: number }> {
        const errors: string[] = [];
        let successCount = 0;
        let duplicatesCount = 0;

        try {
            // Get university config
            this.universityConfig = await universityConfigurationRepository.findOne({
                university: this.universityId
            }).lean();

            if (!this.universityConfig) {
                throw new Error('University configuration not found');
            }

            // Initialize Google Drive downloader
            this.initializeGoogleDriveDownloader();

            // Parse Excel file
            const rows = await this.parseExcel();

            // Group by Topic Name (same topic = multiple videos)
            const groupedData = this.groupByTopic(rows);

            // Limit concurrency to 4
            const limit = pLimit(4);

            const processPromises = groupedData.map(group => {
                return limit(async () => {
                    try {
                        // Check for duplicates
                        const existing = await videoTempRepository.findOne({
                            courseName: group.courseName,
                            unitName: group.unitName,
                            topicName: group.topicName,
                            university: new Types.ObjectId(this.universityId)
                        });

                        if (existing && moment(existing.createdAt).isBefore(moment().subtract(1, 'day'))) {
                            existing.topicName = existing.topicName + '--';
                            await existing.save();
                        }

                        if (existing && existing.url) {
                            duplicatesCount++;
                            console.log(`Skipping duplicate download/upload. Updating course content: ${group.courseName} - ${group.unitName} - ${group.topicName}`);
                            await this.updateCourseContent(group, existing.url);
                            return;
                        }

                        // Process the group (download -> upload)
                        await this.processGroup(group);
                        successCount++;
                    } catch (error: any) {
                        const errorMsg = `Error processing ${group.courseName} - ${group.unitName} - ${group.topicName}: ${error.message}`;
                        errors.push(errorMsg);
                        console.error(errorMsg, error);
                    }
                });
            });

            // Wait for all promises to complete
            await Promise.all(processPromises);

            return { success: successCount, errors, duplicates: duplicatesCount };

        } catch (error: any) {
            throw new Error(`Failed to process Excel file: ${error.message}`);
        }
    }

    private initializeGoogleDriveDownloader(): void {
        const clientId = this.universityConfig?.advanced?.googleClientId;
        const clientSecret = this.universityConfig?.advanced?.googleClientSecret;

        this.googleDriveDownloader = new GoogleDriveDownloader(
            undefined, // tokenPath
            clientId,
            clientSecret
        );
    }

    private async processGroup(group: GroupedData): Promise<void> {
        const s3 = new S3University(this.universityConfig, true);
        let finalUrl: string;

        if (group.videoLinks.length === 0) {
            throw new Error('No video links found');
        }

        // Use the first video link
        const videoUrl = group.videoLinks[0];
        const downloadedPath = `/tmp/${uuidV4()}-${videoUrl.split('/').pop() || 'video.mp4'}`;
        let actualDownloadedPath: string | undefined;

        try {
            if (!this.googleDriveDownloader) {
                throw new Error('Google Drive downloader not initialized');
            }

            // Download
            console.log(`Downloading video for ${group.topicName}...`);
            actualDownloadedPath = await this.googleDriveDownloader.downloadFile(videoUrl, downloadedPath);

            // Upload to S3
            console.log(`Uploading video for ${group.topicName}...`);
            const filename = `${uuidV4()}-simple.mp4`;
            const uploadedUrl = await s3.upload(
                actualDownloadedPath, // Use the path returned by downloader (which may have extension added)
                filename,
                this.universityConfig.buckets.LMS_COURSE_VIDEOS
            );

            if (!uploadedUrl) {
                throw new Error('Upload to S3 failed');
            }

            finalUrl = uploadedUrl;
            console.log(`Uploaded to: ${finalUrl}`);

            // Save to DB
            await videoTempRepository.create({
                courseName: group.courseName,
                unitName: group.unitName,
                topicName: group.topicName,
                url: finalUrl,
                originalUrl: group.videoLinks.join(','),
                university: new Types.ObjectId(this.universityId)
            });

            // Update Course Content (Course -> Chapter -> Lecture)
            await this.updateCourseContent(group, finalUrl);

        } finally {
            // Cleanup
            if (actualDownloadedPath && FileUtils.fileExists(actualDownloadedPath)) {
                try {
                    FileUtils.removeFile(actualDownloadedPath);
                } catch (e) {
                    console.error('Failed to cleanup file:', actualDownloadedPath, e);
                }
            } else if (FileUtils.fileExists(downloadedPath)) {
                try {
                    FileUtils.removeFile(downloadedPath);
                } catch (e) {
                    console.error('Failed to cleanup file:', downloadedPath, e);
                }
            }
        }
    }

    private async parseExcel(): Promise<ExcelRow[]> {
        const workbook = new Workbook();
        await workbook.xlsx.load(this.excelFile.buffer);

        const worksheet = workbook.getWorksheet(1);
        if (!worksheet) {
            throw new Error('Excel file is empty or invalid');
        }

        const rows: ExcelRow[] = [];
        let headers: { [key: string]: number } = {};
        let headerRowFound = false;

        worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
            if (rowNumber === 1) {
                row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
                    const headerValue = cell.value?.toString() || '';
                    headers[headerValue] = colNumber;
                });
                headerRowFound = true;

                // Validate required columns
                const requiredColumns = ['Course Name', 'Unit Name', 'Topic Name', 'Video Link'];
                for (const col of requiredColumns) {
                    if (!(col in headers)) {
                        throw new Error(`Missing required column: ${col}`);
                    }
                }
                return;
            }

            if (!headerRowFound) return;

            const rowData: ExcelRow = {
                'Course Name': '',
                'Program Name': undefined,
                'Unit Name': '',
                'Topic Name': '',
                'Video Link': '',
                'Faculty Name for videos': undefined,
                'Semester': undefined
            };

            for (const [headerName, colNumber] of Object.entries(headers)) {
                const cell = row.getCell(colNumber);
                let cellValue = '';

                // Handle hyperlinks
                const hyperlink = cell.hyperlink as any;
                if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
                    cellValue = hyperlink.target;
                } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
                    // Formula hyperlink extraction if needed
                    const val = cell.value as any;
                    if (val.result && typeof val.result === 'string') cellValue = val.result;
                } else {
                    if (cell.value && (cell.value as any).hyperlink) {
                        cellValue = (cell.value as any).hyperlink;
                    } else {
                        cellValue = cell.value?.toString() || '';
                    }
                }

                if (headerName in rowData) {
                    (rowData as any)[headerName] = cellValue;
                }
            }

            if (rowData['Course Name'] || rowData['Unit Name'] || rowData['Topic Name']) {
                rows.push(rowData);
            }
        });

        if (rows.length === 0) {
            throw new Error('No data found in Excel file');
        }

        return rows;
    }

    private groupByTopic(rows: ExcelRow[]): GroupedData[] {
        const groupedMap = new Map<string, GroupedData>();

        for (const row of rows) {
            const key = `${row['Course Name']}|${row['Program Name'] || ''}|${row['Unit Name']}|${row['Topic Name']}`;

            if (!groupedMap.has(key)) {
                groupedMap.set(key, {
                    courseName: row['Course Name'],
                    programName: row['Program Name'],
                    unitName: row['Unit Name'],
                    topicName: row['Topic Name'],
                    videoLinks: [],
                    facultyName: row['Faculty Name for videos'],
                    semester: row['Semester']
                });
            }

            const group = groupedMap.get(key)!;
            if (row['Video Link'] && row['Video Link'].trim()) {
                group.videoLinks.push(row['Video Link'].trim());
            }
        }

        return Array.from(groupedMap.values());
    }

    private async updateCourseContent(group: GroupedData, videoUrl: string): Promise<void> {
        // 1. Find Course
        let courseTitle = group.courseName;
        courseTitle = `${group.programName} - ${group.courseName}`;


        const course = await courseRepository.findOne({
            title: courseTitle,
            university: this.universityId,
            deleted: { $ne: true }
        });

        if (!course) {
            console.warn(`Course not found: ${courseTitle}. Skipping update for topic ${group.topicName}`);
            return;
        }

        // 2. Find Chapter (Unit)
        // Fetch all chapters to match by name (checking if title contains unitName)
        const chapters = await chapterRepository.find({
            course: course._id
        });

        let chapter = chapters.find(c => c.title.toLowerCase().includes(group.unitName.toLowerCase()));

        if (!chapter) {
            // Create Chapter
            console.log(`Creating new chapter for unit: ${group.unitName}`);
            const count = chapters.length;
            // Use "UNIT X - Name" convention if possible, or just append
            const newTitle = `UNIT ${count + 1} - ${group.unitName}`;

            chapter = await chapterRepository.create({
                course: course._id,
                owner: course.owner,
                title: newTitle,
                lectures: []
            });

            // Add to Course
            await courseRepository.findOneAndUpdate(
                { _id: course._id },
                { $addToSet: { chapters: chapter._id } },
                { multi: false }
            );
        }

        // 3. Find Lecture (Topic)
        // Fetch lectures in the chapter
        const lectures = await lectureRepository.find({
            _id: { $in: chapter.lectures }
        });

        let lecture = lectures.find(l => l.title.toLowerCase().includes(group.topicName.toLowerCase()));

        if (lecture) {
            // Update existing lecture - REPLACE existing video(s)
            console.log(`Replacing video(s) in existing lecture: ${lecture.title}`);

            if (!lecture.pages) lecture.pages = [];

            // Remove existing video pages to ensure clean replacement
            lecture.pages = lecture.pages.filter((p: any) => p.contentType !== 'video');

            lecture.pages.push({
                title: 'Video',
                contentType: 'video',
                video: videoUrl,
                assetUrl: videoUrl,
                time: 1800 // Default 30 mins
            });

            // Update lecture title to start with *
            if (!lecture.title.startsWith('*')) {
                lecture.title = `*${lecture.title}`;
            }

            await lectureRepository.findOneAndUpdate(
                { _id: lecture._id },
                {
                    $set: {
                        pages: lecture.pages,
                        title: lecture.title
                    }
                },
                { multi: false }
            );

        } else {
            // Create new Lecture with * in title
            console.log(`Creating new lecture for topic: ${group.topicName}`);
            const lecturesCount = lectures.length;
            const newLectureTitle = `*TOPIC ${lecturesCount + 1} - ${group.topicName}`;

            lecture = await lectureRepository.create({
                course: course._id,
                owner: course.owner,
                title: newLectureTitle,
                pages: [{
                    title: 'Video',
                    contentType: 'video',
                    video: videoUrl,
                    assetUrl: videoUrl,
                    time: 1800
                }]
            });

            // Add to Chapter
            await chapterRepository.findOneAndUpdate(
                { _id: chapter._id },
                { $addToSet: { lectures: lecture._id } },
                { multi: false }
            );
        }
    }
}
