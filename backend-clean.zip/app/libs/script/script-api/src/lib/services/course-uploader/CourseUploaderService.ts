import { Workbook } from 'exceljs';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { programRepository } from '@edorer/program-data';
import { universityConfigurationRepository } from '@edorer/university-data';
import { v4 as uuidV4 } from 'uuid';

interface ExcelRow {
  'Course Name': string;
  'Program Name'?: string;
  'Unit Name': string;
  'Topic Name': string;
  'Video Link': string;
  'Unit PDF Links'?: string;
}

interface GroupedData {
  courseName: string;
  programName?: string;
  unitName: string;
  topicName: string;
  videoLinks: string[];
}

export class CourseUploaderService {
  private readonly excelFile: any;
  private readonly universityId: string;
  private universityConfig: any;

  constructor(excelFile: any, universityId: string) {
    this.excelFile = excelFile;
    this.universityId = universityId;
  }

  async process(): Promise<{ success: number; errors: string[] }> {
    const errors: string[] = [];
    let successCount = 0;

    try {
      // Parse Excel file
      const rows = await this.parseExcel();
      
      // Group by Topic Name (same topic = append videos)
      const groupedData = this.groupByTopic(rows);

      // Get university config
      this.universityConfig = await universityConfigurationRepository.findOne({ 
        university: this.universityId 
      }).lean();

      if (!this.universityConfig) {
        throw new Error('University configuration not found');
      }

      const s3 = new S3University(this.universityConfig, true);

      // Process each group
      for (const group of groupedData) {
        try {
          await this.processGroup(group, s3);
          successCount++;
        } catch (error: any) {
          const errorMsg = `Error processing ${group.courseName} - ${group.topicName}: ${error.message}`;
          errors.push(errorMsg);
          console.error(errorMsg, error);
        }
      }

      return { success: successCount, errors };
    } catch (error: any) {
      throw new Error(`Failed to process Excel file: ${error.message}`);
    }
  }

  private async parseExcel(): Promise<ExcelRow[]> {
    const workbook = new Workbook();
    await workbook.xlsx.load(this.excelFile.buffer);
    
    const worksheet = workbook.getWorksheet(1); // Get the first worksheet
    if (!worksheet) {
      throw new Error('Excel file is empty or invalid');
    }

    const rows: ExcelRow[] = [];
    let headers: { [key: string]: number } = {};
    let headerRowFound = false;

    // Process each row
    worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      // First row should be headers
      if (rowNumber === 1) {
        row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
          const headerValue = cell.value?.toString() || '';
          headers[headerValue] = colNumber;
        });
        headerRowFound = true;

    // Validate required columns
    const requiredColumns = ['Course Name', 'Unit Name', 'Topic Name', 'Video Link'];
    for (const col of requiredColumns) {
          if (!(col in headers)) {
        throw new Error(`Missing required column: ${col}`);
          }
        }
        return;
      }

      if (!headerRowFound) {
        return;
      }

      // Extract row data
      const rowData: ExcelRow = {
        'Course Name': '',
        'Program Name': undefined,
        'Unit Name': '',
        'Topic Name': '',
        'Video Link': '',
        'Unit PDF Links': undefined
      };

      // Get cell values by header name
      for (const [headerName, colNumber] of Object.entries(headers)) {
        const cell = row.getCell(colNumber);
        let cellValue = '';

        // Check if cell has a hyperlink (can be string or object with target property)
        const hyperlink = cell.hyperlink as any;
        if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
          cellValue = hyperlink.target;
        } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
          // Handle HYPERLINK formula: =HYPERLINK("url", "text")
          const formula = (cell.value as any).formula;
          const urlMatch = formula?.match(/=HYPERLINK\("([^"]+)"/i);
          if (urlMatch && urlMatch[1]) {
            cellValue = urlMatch[1];
          } else {
            cellValue = cell.value?.toString() || '';
          }
        } else {
          cellValue = cell.value?.toString() || '';
        }

        if (headerName in rowData) {
          (rowData as any)[headerName] = cellValue;
        }
      }

      // Only add row if it has required data
      if (rowData['Course Name'] || rowData['Unit Name'] || rowData['Topic Name']) {
        rows.push(rowData);
      }
    });

    if (rows.length === 0) {
      throw new Error('No data found in Excel file');
    }

    return rows;
  }

  private groupByTopic(rows: ExcelRow[]): GroupedData[] {
    const groupedMap = new Map<string, GroupedData>();

    for (const row of rows) {
      const key = `${row['Course Name']}|${row['Program Name'] || ''}|${row['Unit Name']}|${row['Topic Name']}`;
      
      if (!groupedMap.has(key)) {
        groupedMap.set(key, {
          courseName: row['Course Name'],
          programName: row['Program Name'],
          unitName: row['Unit Name'],
          topicName: row['Topic Name'],
          videoLinks: []
        });
      }

      const group = groupedMap.get(key)!;
      if (row['Video Link'] && row['Video Link'].trim()) {
        group.videoLinks.push(row['Video Link'].trim());
      }
    }

    return Array.from(groupedMap.values());
  }

  private async processGroup(group: GroupedData, s3: S3University): Promise<void> {
    // Find course by title
    let courses = await courseRepository.find({ 
      title: {$regex: group.programName ? new RegExp(`^.*${group.programName} - ${group.courseName}.*$`, 'i') : new RegExp(`^.*${group.courseName}.*$`, 'i')},
      university: this.universityId
    }).lean();

    if (courses.length === 0) {
      throw new Error(`Course not found: ${group.courseName}`);
    }

    // If more than 1 course, filter by program name
    if (courses.length > 1 && group.programName) {
      const program = await programRepository.findOne({ 
        title: group.programName 
      }).lean();

      if (program) {
        // Find courses that belong to this program
        const programCourseIds = [];
        for (const curriculum of program.curriculum || []) {
          for (const yearData of curriculum.yearData || []) {
            for (const entry of yearData.data || []) {
              if (entry.course) {
                programCourseIds.push(entry.course.toString());
              }
            }
          }
        }

        courses = courses.filter(c => 
          programCourseIds.includes(c._id.toString())
        );
      }

      if (courses.length === 0) {
        throw new Error(`Course not found in program: ${group.courseName} - ${group.programName}`);
      }

      if (courses.length > 1) {
        throw new Error(`Multiple courses found: ${group.courseName} - ${group.programName}. Please be more specific.`);
      }
    }

    const course = courses[0];

    // Find chapter by Unit Name
    const chapter = await chapterRepository.findOne({
      course: course._id,
      title: { $regex: new RegExp(`^.*${group.unitName}.*$`, 'i')}
    }).lean();

    if (!chapter) {
      throw new Error(`Chapter not found: ${group.unitName} in course ${group.courseName}`);
    }

    if (!chapter.lectures || chapter.lectures.length === 0) {
      throw new Error(`Chapter ${group.unitName} has no lectures`);
    }

    // Find lecture by Topic Name within the chapter
    const lecture = await lectureRepository.findOne({
      _id: { $in: chapter.lectures },
      title: { $regex: new RegExp(`^.*${group.topicName}.*$`, 'i') }
    });

    // if (!lecture) {
    //   throw new Error(`Lecture not found: ${group.topicName} in chapter ${group.unitName}`);
    // }

    // Download and upload videos
    const uploadedVideoUrls: string[] = [];
    
    for (const videoLink of group.videoLinks) {
      try {
        const uploadedUrl = await this.downloadAndUploadVideo(videoLink, s3);
        if (uploadedUrl) {
          uploadedVideoUrls.push(uploadedUrl);
        }
      } catch (error: any) {
        console.error(`Failed to process video ${videoLink}:`, error);
        // Continue with other videos even if one fails
      }
    }

    if (uploadedVideoUrls.length === 0) {
      throw new Error(`No videos were successfully uploaded for ${group.topicName}`);
    }

    // Create video pages and add them at the beginning
    const newPages = uploadedVideoUrls.map((videoUrl, index) => ({
      title: index === 0 ? 'Video' : `Video ${index + 1}`,
      contentType: 'video',
      video: videoUrl,
      assetUrl: videoUrl,
      time: 0
    }));
    console.log(newPages);

    // lecture.pages = [...newPages, ...(lecture.pages || [])];
    
    // await lecture.save();
  }

  private async downloadAndUploadVideo(videoUrl: string, s3: S3University): Promise<string | null> {
    let downloadedPath: string | undefined;

    try {
      // Download video
      const downloader = new Downloader(videoUrl);
      downloadedPath = await downloader.download();

      if (!downloadedPath || !FileUtils.fileExists(downloadedPath)) {
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedPath);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedPath);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      // Generate filename
      const originalFilename = videoUrl.split('/').pop() || 'video';
      const filename = `${uuidV4()}-${originalFilename}`;

      // Upload to S3
      const uploadedUrl = await s3.uploadBuffer(
        fileContent,
        filename,
        this.universityConfig.buckets.LMS_COURSE_VIDEOS
      );

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      return uploadedUrl;
    } catch (error: any) {
      console.error(`Error processing video ${videoUrl}:`, error);
      return null;
    } finally {
      // Cleanup downloaded file
      if (downloadedPath && FileUtils.fileExists(downloadedPath)) {
        try {
          FileUtils.removeFile(downloadedPath);
        } catch (error) {
          console.error('Failed to cleanup temporary file:', error);
        }
      }
    }
  }
}
