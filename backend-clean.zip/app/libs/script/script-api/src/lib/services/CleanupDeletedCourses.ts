import { Chapter, chapterRepository } from '@edorer/chapter-data';
import { Course, courseRepository } from '@edorer/course-data';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { S3University } from '@edorer/s3';
import { UniversityConfiguration, universityConfigurationRepository } from '@edorer/university-data';
import * as os from 'os';

export class CleanupDeletedCourses {
  private readonly MAX_CONCURRENT_TASKS = os.cpus().length;
  private readonly universityId: string;
  private activePromises: Set<Promise<void>> = new Set();

  private courses: Course[] = [];
  private chapters: Chapter[] = [];
  private lectures: Lecture[] = [];
  private universityConfig: UniversityConfiguration;

  constructor(universityId: string) {
    this.universityId = universityId;
  }

  async cleanup() {
    await this.getUniversityConfig();
    await this.findCourses();
    await this.fetchChapters();
    await this.fetchLectures();
    await this.deleteMaterials();
  }

  private async getUniversityConfig() {
    const universityConfig = await universityConfigurationRepository.findOne({ university: this.universityId }).lean();
    if (!universityConfig) throw new Error('University configuration not found');

    this.universityConfig = universityConfig;
  }

  private async findCourses() {
    this.courses = await courseRepository.findWithDeleted({ deleted: true }).select('chapters').lean(true);
  }

  private async fetchChapters() {
    const courseIds = this.courses.map((c) => c._id);
    this.chapters = await chapterRepository
      .find({ course: { $in: courseIds } })
      .select('lectures')
      .lean(true);
  }

  private async addToQueue(task: () => Promise<void>): Promise<void> {
    while (this.activePromises.size >= this.MAX_CONCURRENT_TASKS) {
      await Promise.race(this.activePromises);
    }

    const promise = task().finally(() => {
      this.activePromises.delete(promise);
    });

    this.activePromises.add(promise);
    return promise;
  }

  private async fetchLectures() {
    const lectureIds = this.chapters.flatMap((c) => c.lectures);
    this.lectures = await lectureRepository
      .find({
        _id: { $in: lectureIds },
        $or: [
          { 'pages.assetUrl': { $regex: 'https://storage.googleapis.com' } },
          { 'pages.images': { $regex: 'https://storage.googleapis.com' } },
          { 'pages.video': { $regex: 'https://storage.googleapis.com' } }
        ],
        'pages.contentType': { $in: ['document', 'video'] }
      })
      .select('pages')
      .lean(true);
  }

  private async deleteMaterials() {
    const assets = this.lectures
      .flatMap((l) => l.pages)
      .map((o) => o.assetUrl)
      .filter(Boolean);

    const images = this.lectures.flatMap((l) => l.pages).flatMap((o) => o.images || []);

    const videos = this.lectures
      .flatMap((l) => l.pages)
      .map((o) => o.video)
      .filter(Boolean);

    const urls = [...new Set([...assets, ...images, ...videos])];

    if (urls.length === 0) return;

    const s3 = new S3University(this.universityConfig, true);

    const deletePromises = urls.map((url) =>
      this.addToQueue(async () => {
        await s3.delete(url);
      })
    );

    await Promise.allSettled(deletePromises);

    await Promise.allSettled(this.activePromises);
  }
}
