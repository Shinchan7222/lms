import get, { AxiosResponse } from 'axios';
import { createWriteStream } from 'fs';
import { v4 as uuidV4 } from 'uuid';
import { parse } from 'url';
const url = require('url');
const path = require('path');

export class FontsDownloader {
  ext: string;

  private directory: string;

  private filePath: string;

  public fileName: string;

  private readonly url: string;

  constructor(url: string, directory?: string) {
    this.directory = directory;
    this.url = url;
  }

  public async download() {
    if (!this.ext) {
      this.ext = this.url.split('.').pop();
    }

    const parsedUrl = new URL(this.url);

    this.fileName = path.basename(parsedUrl.pathname);
    this.filePath = `${process.env.TEMP_DIR}${this.directory}/${this.fileName}`;

    try {
      await this.get();
      return this.filePath;
    } catch (e) {
      console.error(e);
      console.error('ERROR in ' + this.url);
      return null;
    }
  }

  private get() {
    return new Promise((resolve, reject) => {
      const writer = createWriteStream(this.filePath);
      get(this.url, {
        responseType: 'stream',
        headers: {
          Origin: 'https://www.fontfabric.com',
          Referer: 'https://www.colophon-foundry.org/'
        }
      })
        .then((response: AxiosResponse<any>) => {
          response.data.pipe(writer);
          let error = null;
          writer.on('error', (err) => {
            error = err;
            writer.close();
            reject(err);
          });
          writer.on('close', () => {
            if (!error) {
              resolve(true);
            }
          });
        })
        .catch((e) => {
          reject(e);
        });
    });
  }
}
