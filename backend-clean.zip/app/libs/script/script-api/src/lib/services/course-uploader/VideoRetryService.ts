import { videoToUploadRepository } from '@edorer/script-data';
import { videoTempRepository } from '@edorer/video-uploader-data';

export class VideoRetryService {

    async retryFastCompletions(): Promise<{ processed: number, updated: number, errors: string[] }> {
        const errors: string[] = [];
        let processed = 0;
        let updated = 0;

        try {
            // 1. Fetch completed tasks since 2026-01-22
            const tasks = await videoToUploadRepository.find({
                status: 'done',
                createdAt: { $gte: new Date('2026-01-22') }
            }).lean();

            console.log(`[VideoRetryService] Found ${tasks.length} completed tasks since 2026-01-22`);

            for (const task of tasks) {
                processed++;

                // 2. Check duration
                if (!task.startedAt || !task.completedAt) {
                    continue;
                }

                const duration = new Date(task.completedAt).getTime() - new Date(task.startedAt).getTime();

                // If duration is less than 1 minute (60000 ms)
                if (duration < 60000) {
                    try {
                        // 3. Check for existing VideoTemp
                        const existingTemp = await videoTempRepository.findOne({
                            courseName: task.courseName,
                            unitName: task.unitName,
                            topicName: task.topicName
                        });

                        if (existingTemp) {
                            console.log(`[VideoRetryService] Found fast completion with existing VideoTemp: ${task.courseName} - ${task.topicName} (Duration: ${duration}ms)`);

                            // 4. Update task
                            existingTemp.topicName = `${task.topicName} --`;
                            await existingTemp.save();
                            
                            await videoToUploadRepository.update(
                                { _id: task._id },
                                {
                                    $set: {
                                        status: 'pending'
                                    },
                                    $unset: {
                                        startedAt: 1,
                                        completedAt: 1,
                                        errorMessage: 1
                                    }
                                },
                                { multi: false }
                            );

                            updated++;
                        }
                    } catch (err: any) {
                        const msg = `Error processing task ${task._id}: ${err.message}`;
                        console.error(msg);
                        errors.push(msg);
                    }
                }
            }

            return { processed, updated, errors };
        } catch (error: any) {
            throw new Error(`Failed to retry fast completions: ${error.message}`);
        }
    }
}
