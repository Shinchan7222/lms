import { Chapter, chapterRepository } from '@edorer/chapter-data';
import { Course, courseRepository } from '@edorer/course-data';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { S3University } from '@edorer/s3';
import { UniversityConfiguration, universityConfigurationRepository } from '@edorer/university-data';

export class CleanupDeletedCourses {
  private readonly limit: number;
  private readonly universityId: string;

  private courses: Course[] = [];
  private chapters: Chapter[] = [];
  private lectures: Lecture[] = [];
  private universityConfig: UniversityConfiguration;

  constructor(limit: number, universityId: string) {
    this.limit = limit;
    this.universityId = universityId;
  }

  async cleanup() {
    await this.getUniversityConfig();
    await this.findCourses();
    await this.deleteMaterials();
  }

  private async getUniversityConfig() {
    const universityConfig = await universityConfigurationRepository.findOne({ university: this.universityId }).lean();
    if (!universityConfig) throw new Error('University configuration not found');

    this.universityConfig = universityConfig;
  }

  private async findCourses() {
    this.courses = await courseRepository.findWithDeleted({ deleted: true }).limit(this.limit).select('chapters').lean(true);
  }

  private async deleteMaterials() {
    const assets = this.lectures
      .flatMap((l) => l.pages)
      .map((o) => o.assetUrl)
      .filter(Boolean);

    const images = this.lectures.flatMap((l) => l.pages).flatMap((o) => o.images || []);

    const videos = this.lectures
      .flatMap((l) => l.pages)
      .map((o) => o.video)
      .filter(Boolean);

    const urls = [...new Set([...assets, ...images, ...videos])];

    if (urls.length === 0) return;

    const s3 = new S3University(this.universityConfig, true);

    const [first] = urls;

    await s3.delete(first);

    // await Promise.allSettled(urls.map((url) => s3.delete(url)));
  }
}
