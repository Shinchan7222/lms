import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { universityConfigurationRepository } from '@edorer/university-data';
import { videoTempRepository } from '@edorer/video-uploader-data';
import { v4 as uuidV4 } from 'uuid';
import { RemotionVideoProcessor } from './RemotionVideoProcessor';
import { parallelProcessor } from './ParallelProcessor';
import { GoogleDriveDownloader } from './GoogleDriveDownloader';
import { videoToUploadRepository, VideoToUpload } from '@edorer/script-data';
import { RemotionOldVideoProcessor } from './RemotionOldVideoProcessor';
const fs = require('fs');
const exec = require('child_process').exec;
const util = require('util');
const execPromise = util.promisify(exec);
const path = require('path');

interface GroupedData {
  courseName: string;
  programName?: string;
  unitName: string;
  topicName: string;
  videoLinks: string[];
  facultyName?: string;
  semester?: string;
}

export class VideoToUploadProcessor {
  private readonly universityId: string;
  private readonly maxConcurrentVideos: number;
  private universityConfig: any;
  private googleDriveDownloader: GoogleDriveDownloader | null = null;
  private readonly tokenPath?: string;

  constructor(universityId: string, maxConcurrentVideos: number = 6, tokenPath?: string) {
    this.universityId = universityId;
    this.maxConcurrentVideos = maxConcurrentVideos;
    this.tokenPath = tokenPath;
  }

  /**
   * Initialize Google Drive downloader with university config credentials
   */
  private initializeGoogleDriveDownloader(): void {
    if (this.googleDriveDownloader) {
      return; // Already initialized
    }

    const clientId = this.universityConfig?.advanced?.googleClientId;
    const clientSecret = this.universityConfig?.advanced?.googleClientSecret;

    this.googleDriveDownloader = new GoogleDriveDownloader(
      this.tokenPath,
      clientId,
      clientSecret
    );
  }

  /**
   * Process a single VideoToUpload entry
   */
  async processVideoToUpload(videoToUpload: VideoToUpload | any): Promise<void> {
    try {
      // Get university ID from videoToUpload if not set in constructor
      const universityId = this.universityId || videoToUpload.university?.toString() || videoToUpload.university;

      if (!universityId) {
        throw new Error('University ID not found');
      }

      // Get university config (use the extracted universityId)
      if (!this.universityConfig || this.universityId !== universityId) {
        this.universityConfig = await universityConfigurationRepository.findOne({
          university: universityId
        }).lean();

        if (!this.universityConfig) {
          throw new Error('University configuration not found');
        }
      }

      // Initialize Google Drive downloader with credentials
      this.initializeGoogleDriveDownloader();

      const s3 = new S3University(this.universityConfig, true);

      // Convert VideoToUpload to GroupedData format
      const group: GroupedData = {
        courseName: videoToUpload.courseName,
        programName: videoToUpload.programName,
        unitName: videoToUpload.unitName,
        topicName: videoToUpload.topicName,
        videoLinks: videoToUpload.videoLinks,
        facultyName: videoToUpload.facultyName,
        semester: videoToUpload.semester
      };

      // Process the group
      await this.processGroup(group, s3);
    } catch (error: any) {
      // Update status to error and error message in the database
      await videoToUploadRepository.update(
        { _id: videoToUpload._id },
        {
          $set: {
            status: 'error',
            errorMessage: error.message,
            updatedAt: new Date()
          },
          $unset: {
            startedAt: 1
          }
        },
        { multi: false }
      );
      throw error;
    }
  }

  private async processGroup(group: GroupedData, s3: S3University): Promise<void> {
    const videoLinks = group.videoLinks;

    // Check if videos already exist before processing
    const allVideosExist = await this.checkAllVideosExist(group);
    if (allVideosExist) {
      console.log(`All videos already exist in videoTemp for ${group.courseName} - ${group.unitName} - ${group.topicName}, skipping`);
      return;
    }

    // If there's only one video, process it as before
    if (videoLinks.length === 1) {
      try {
        await this.downloadAndUploadVideo(videoLinks[0], s3, group);
      } catch (error: any) {
        throw new Error(`Error processing video for ${group.topicName}: ${error.message}`);
      }
      return;
    }

    // If there are multiple videos, concatenate them before processing with remotion
    let downloadedPaths: string[] = [];
    let concatenatedVideoPath: string | undefined;
    let unzippedDir: string | undefined;

    try {
      // Download all videos first - PARALLEL (6 at a time)
      console.log(`Downloading ${videoLinks.length} videos for topic: ${group.topicName} (parallel, max 6)`);
      const downloadTasks = videoLinks.map(videoLink => () => this.downloadVideo(videoLink));
      const downloadResults = await parallelProcessor.processInParallel(downloadTasks);

      for (const result of downloadResults) {
        if (result.success && result.result) {
          downloadedPaths.push(result.result.path);
        } else {
          console.error(`Failed to download video:`, result.error);
          throw new Error(`Failed to download one or more videos: ${result.error}`);
        }
      }

      if (downloadedPaths.length === 0) {
        throw new Error(`No videos were successfully downloaded for ${group.topicName}`);
      }

      // Concatenate videos using ffmpeg
      console.log(`Concatenating ${downloadedPaths.length} videos for topic: ${group.topicName}`);
      concatenatedVideoPath = await this.concatenateVideos(downloadedPaths);

      // Process the concatenated video with remotion processor
      const remotionDir = process.env.REMOTION_DIR || '/home/amine/test/remotion-video-app'; // Remotion directory path
      const processor = new RemotionOldVideoProcessor(remotionDir, this.universityConfig, s3);
      const uploadedUrl = await processor.processVideo(concatenatedVideoPath, group);

      console.log(`Successfully uploaded concatenated video: ${uploadedUrl}`);
    } catch (error: any) {
      console.error(`Error processing video group ${group.topicName}:`, error);
      throw error;
    } finally {
      // Cleanup downloaded files
      for (const path of downloadedPaths) {
        if (FileUtils.fileExists(path)) {
          try {
            FileUtils.removeFile(path);
          } catch (error) {
            console.error('Failed to cleanup downloaded file:', error);
          }
        }
      }

      // Cleanup concatenated video
      if (concatenatedVideoPath && FileUtils.fileExists(concatenatedVideoPath)) {
        try {
          FileUtils.removeFile(concatenatedVideoPath);
        } catch (error) {
          console.error('Failed to cleanup concatenated video:', error);
        }
      }
    }
  }

  private async downloadVideo(videoUrl: string): Promise<{ path: string }> {
    if (!this.googleDriveDownloader) {
      throw new Error('Google Drive downloader not initialized');
    }
    const downloadedPath = `/tmp/${uuidV4()}-${videoUrl.split('/').pop() || 'video'}.mp4`;
    try {
      await this.googleDriveDownloader.downloadFile(videoUrl, downloadedPath);
    } catch (error: any) {
      console.error(`Error downloading video ${videoUrl}:`, error);
      throw error;
    }
    return { path: downloadedPath };
  }



  private async checkAllVideosExist(group: GroupedData): Promise<boolean> {
    try {
      const existing = await videoTempRepository.findOne({
        courseName: group.courseName,
        unitName: group.unitName,
        topicName: group.topicName,
        university: this.universityId
      }).lean();

      if (existing && existing.url) {
        console.log(`Video already exists in videoTemp for ${group.courseName} - ${group.unitName} - ${group.topicName}`);
        return true;
      }

      return false;
    } catch (error: any) {
      console.error(`Error checking videoTemps for group ${group.courseName} - ${group.unitName} - ${group.topicName}:`, error);
      return false;
    }
  }

  private async downloadAndUploadVideo(videoUrl: string, s3: S3University, group: GroupedData) {
    let downloadedPath: string | undefined;

    try {
      // Check if video already exists in videoTemp by courseName, unitName, topicName
      const existing = await videoTempRepository.findOne({
        courseName: group.courseName,
        unitName: group.unitName,
        topicName: group.topicName,
        university: this.universityId
      }).lean();

      if (existing && existing.url) {
        console.log(`Skipping download and processing for ${group.courseName} - ${group.unitName} - ${group.topicName}, using existing URL: ${existing.url}`);
        return existing.url;
      }

      // Download video
      const { path } = await this.downloadVideo(videoUrl);
      downloadedPath = path;

      // Process with remotion
      const remotionDir = process.env.REMOTION_DIR || '/home/amine/test/remotion-video-app';
      const processor = new RemotionVideoProcessor(remotionDir, this.universityConfig, s3, this.universityId);
      const uploadedUrl = await processor.processVideo(downloadedPath, group);

      console.log(`Successfully uploaded video: ${uploadedUrl}`);
      return uploadedUrl;
    } catch (error: any) {
      console.error(`Error processing video ${videoUrl}:`, error);
      throw error;
    } finally {
      // Cleanup downloaded file
      if (downloadedPath && FileUtils.fileExists(downloadedPath)) {
        try {
          FileUtils.removeFile(downloadedPath);
        } catch (error) {
          console.error('Failed to cleanup downloaded file:', error);
        }
      }
    }
  }

  private async concatenateVideos(videoPaths: string[]): Promise<string> {
    const outputPath = `/tmp/concatenated-${uuidV4()}.mp4`;

    try {
      // Validate all video files exist
      for (const path of videoPaths) {
        if (!FileUtils.fileExists(path)) {
          throw new Error(`Video file not found: ${path}`);
        }
      }

      const numVideos = videoPaths.length;
      console.log(`[CONCAT] Concatenating ${numVideos} videos...`);

      // Build input arguments
      const inputArgs = videoPaths.map(path => `-i "${path}"`).join(' ');

      // Build filter_complex: scale, pad, set SAR, fps, and format each video and audio stream
      const filterParts: string[] = [];

      // Process each video: scale to 1920x1080, pad, set SAR, and fps=30
      for (let i = 0; i < numVideos; i++) {
        filterParts.push(
          `[${i}:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[v${i}]`
        );
      }

      // Process each audio: format to 48kHz stereo
      for (let i = 0; i < numVideos; i++) {
        filterParts.push(
          `[${i}:a]aformat=sample_rates=48000:channel_layouts=stereo[a${i}]`
        );
      }

      // Concatenate all video and audio streams
      const concatInputs: string[] = [];
      for (let i = 0; i < numVideos; i++) {
        concatInputs.push(`[v${i}][a${i}]`);
      }
      filterParts.push(
        `${concatInputs.join('')}concat=n=${numVideos}:v=1:a=1[v][a]`
      );

      const filterComplex = filterParts.join(';');

      // Build FFmpeg command with filter_complex
      const command = `ffmpeg ${inputArgs} ` +
        `-filter_complex "${filterComplex}" ` +
        `-map "[v]" -map "[a]" ` +
        `-c:v libx264 -preset ultrafast -crf 23 ` +
        `-c:a aac -b:a 192k ` +
        `-movflags +faststart ` +
        `"${outputPath}"`;

      console.log(`[CONCAT] Running FFmpeg command (filter_complex with scaling and padding)...`);
      console.log(`[CONCAT] Command: ${command.substring(0, 300)}...`);

      const startTime = Date.now();
      const { stdout, stderr } = await execPromise(command, {
        maxBuffer: 1024 * 1024 * 100, // 100MB buffer
        timeout: 600000, // 10 minutes timeout
      });
      const duration = ((Date.now() - startTime) / 1000).toFixed(2);
      console.log(`[CONCAT] Concatenation completed in ${duration} seconds`);

      if (stdout) {
        console.log(`[CONCAT] Concatenation output: ${stdout}`);
      }
      if (stderr) {
        // FFmpeg outputs progress to stderr, so log it
        console.log(`[CONCAT] Concatenation stderr: ${stderr.substring(0, 500)}`);
      }

      // Small delay to ensure file is fully written
      await new Promise(resolve => setTimeout(resolve, 500));

      if (!FileUtils.fileExists(outputPath)) {
        throw new Error(`Concatenated video not found at ${outputPath}`);
      }

      // Check file size to ensure it's not empty
      const stats = fs.statSync(outputPath);
      if (stats.size === 0) {
        throw new Error(`Concatenated video is empty (0 bytes)`);
      }

      console.log(`[CONCAT] Successfully concatenated ${numVideos} videos`);
      console.log(`[CONCAT] Output path: ${outputPath}`);
      console.log(`[CONCAT] File size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);

      return outputPath;
    } catch (error: any) {
      console.error(`[CONCAT] Error occurred during concatenation:`, error);
      throw new Error(`Failed to concatenate videos: ${error.message}`);
    }
  }
}

