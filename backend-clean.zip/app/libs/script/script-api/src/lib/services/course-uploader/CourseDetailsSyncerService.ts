import { courseRepository } from '@edorer/course-data';
import { lectureRepository } from '@edorer/lecture-data';
import axios from 'axios';

export class CourseDetailsSyncerService {
    private readonly universityId: string;

    constructor(universityId: string) {
        this.universityId = universityId;
    }

    async process(): Promise<{ success: number; errors: number; totalProcessed: number; results: any[] }> {
        try {
            // 1. Find all courses for this university
            const courses = await courseRepository
                .find({
                    university: this.universityId,
                    deleted: { $ne: true }
                })
                .select('_id title chapters')
                .lean();

            if (!courses || courses.length === 0) {
                return { success: 0, errors: 0, totalProcessed: 0, results: [] };
            }

            console.log(`Found ${courses.length} courses to sync.`);

            // Process in batches to avoid overwhelming the external API or DB
            const batchSize = 1;
            const allResults: any[] = [];
            let successCount = 0;
            let errorCount = 0;

            for (let i = 0; i < courses.length; i += batchSize) {
                const batch = courses.slice(i, i + batchSize);
                const batchPromises = batch.map(course => this.syncCourseSyllabus(course));

                const batchResults = await Promise.all(batchPromises);

                batchResults.forEach((result: any) => {
                    allResults.push(result);
                    if (result.success) {
                        successCount++;
                    } else {
                        errorCount++;
                    }
                });
            }

            return {
                success: successCount,
                errors: errorCount,
                totalProcessed: courses.length,
                results: allResults
            };

        } catch (error: any) {
            console.error('Error in CourseDetailsSyncerService:', error);
            throw error;
        }
    }

    private async syncCourseSyllabus(course: any): Promise<{ courseId: string; success: boolean; message?: string; error?: string }> {
        try {
            // 2. Find Syllabus Lecture
            // We look for lectures in this course that match possible syllabus titles
            const lectures = await lectureRepository.find({
                course: course._id,
                deleted: { $ne: true },
                title: 'Syllabus'
            }).lean();

            let syllabusLecture = lectures[0];

            // If multiple found, just pick the first one
            if (lectures.length > 1) {
                syllabusLecture = lectures[0];
            }

            if (!syllabusLecture) {
                return { courseId: course._id, success: false, message: 'No syllabus lecture found' };
            }

            // 3. Extract PDF URL
            let pdfUrl: string | undefined;

            // Check pages if they exist
            if (syllabusLecture.pages && syllabusLecture.pages.length > 0) {
                // Look for a page that might contain the document
                // 1. Page with title 'Course Criteria' or 'Syllabus'
                // 2. First page with assetUrl
                const page = syllabusLecture.pages.find((p: any) =>
                    (p.title === 'Course Criteria' || p.title === 'Syllabus') && p.assetUrl
                ) || syllabusLecture.pages.find((p: any) => p.assetUrl);

                if (page) {
                    pdfUrl = page.assetUrl;
                }
            }

            // Fallback: check if the lecture itself has some property (unlikely based on schema, but good to check if pages failed)
            // Modify this if Lecture schema stores URL directly, but usually it's in pages.

            if (!pdfUrl) {
                return { courseId: course._id, success: false, message: 'Syllabus found but no PDF URL in pages' };
            }

            // 4. Send to External API
            await this.sendToExternalApi(course._id.toString(), pdfUrl);

            return { courseId: course._id, success: true, message: 'Synced successfully' };

        } catch (error: any) {
            // console.error(`Failed to sync course ${course._id}:`, error.message);
            return { courseId: course._id, success: false, error: error.message };
        }
    }

    private async sendToExternalApi(courseId: string, pdfUrl: string): Promise<void> {
        const data = JSON.stringify({
            courseId: courseId,
            pdfUrl: pdfUrl
        });

        const config = {
            method: 'post' as any,
            maxBodyLength: Infinity,
            url: 'https://api-ai.edorer.com/api/course-details',
            headers: {
                'AuthorizationToken': 'fda221uh3u2h313320-db34-11eb-89cb-c365057a3241',
                'Content-Type': 'application/json'
            },
            data: data
        };

        try {
            const response = await axios.request(config);
            // console.log(JSON.stringify(response.data));
        } catch (error) {
            // console.log(error);
            throw error; // Re-throw to be caught by the caller
        }
    }
}
