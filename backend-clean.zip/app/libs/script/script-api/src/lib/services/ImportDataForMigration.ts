import { ExamProctor, ExamTimeMode, examRepository } from '@edorer/exam-data';
import { FileUtils } from '@edorer/utils';
import { MigrationUtils } from './MigrationUtils';
import { Open } from 'unzipper';
import { TrackExamReviewStatus, TrackExamWritingOption, trackExamRepository } from '@edorer/track-exam-data';
import { University } from '@edorer/university-data';
import { User, UserTypes, userRepository } from '@edorer/user-data';
import { categoryRepository } from '@edorer/category-data';
import { domainRepository } from '@edorer/domain-data';
import { questionRepository } from '@edorer/question-data';
import { subjectRepository } from '@edorer/subject-data';
import { writeFileSync } from 'fs';

export class ImportDataForMigration {
  private admin: User;

  private university: University;

  private readonly email: string;

  private readonly rootDir: string;

  private readonly zipFile: any;

  private examIds: string[] = [];

  constructor(email: string, rootDir: string, zipFile: any) {
    this.email = email;
    this.rootDir = rootDir;
    this.zipFile = zipFile;
  }

  async import() {
    try {
      await this.unzipFolder();

      await this.fetchAdmin();
      await this.importTeachers();
      await this.importStudents();
      await this.importExams();
      await this.importCategories('meazr-');
      await this.importSubjects('meazr-');
      await this.importDomains('meazr-');
      await this.importQuestions('meazr-');
      await this.importReportUsers('meazr-');

      // await this.importFlows();
      // await this.importCategories('flow-meazr-');
      // await this.importSubjects('flow-meazr-');
      // await this.importDomains('flow-meazr-');
      // await this.importQuestions('flow-meazr-');
      // await this.importReportUsers('flow-meazr-');

      await this.importTracks();
      await this.fixFlowReportMeazrs();
    } catch (error: any) {
      console.error(error);
      throw new Error(error);
    }
  }

  private async unzipFolder() {
    const directory = await Open.buffer(this.zipFile.buffer);
    const jsonFiles = directory.files.filter((filePath) => filePath.path.includes('.json'));
    for (let jsonFile of jsonFiles) {
      try {
        const courseStructureFileBuffer = await jsonFile.buffer();
        const fileName = jsonFile.path.split('/').pop();
        writeFileSync(this.rootDir + '/' + fileName, courseStructureFileBuffer);
      } catch (error: any) {
        console.warn('fileName ==> ', jsonFile);
        console.error(error);
      }
    }
  }

  private async fetchAdmin() {
    this.admin = await userRepository.findOne({ email: this.email }).populate({ path: 'university', select: '_id' }).select('_id university').lean();

    if (!this.admin) {
      throw new Error('Admin not found');
    }

    this.university = this.admin.university;

    console.warn(this.university.url, this.university._id);
  }

  private async importTeachers() {
    if (FileUtils.fileExists(this.rootDir + '/meazr-teachers.json')) {
      const path = this.rootDir + '/meazr-teachers.json';

      const items = await FileUtils.readLargeData(path);
      const ids = items.map((item) => item._id);
      await MigrationUtils.deleteData('teachers', ids, this.university._id, userRepository);

      const teachers = [];

      for (let item of items) {
        const { _id, avatar, email, location, mobileNumber, name, token, useTwoFactorAuth } = item;
        const user = await MigrationUtils.userWithEmailAndName(email, MigrationUtils.sanitizeName(name), this.university._id);
        const teacher = {
          _id,
          ...user,
          avatar,
          location: location || 'India',
          passwordManuallyChanged: true,
          phone: mobileNumber || '',
          token,
          type: UserTypes.TEACHER,
          useTwoFactorAuth
        };

        teachers.push(teacher);
      }

      await MigrationUtils.updateData('teachers', teachers, userRepository);
    }
  }

  private async importStudents() {
    if (FileUtils.fileExists(this.rootDir + '/meazr-students.json')) {
      const path = this.rootDir + '/meazr-students.json';

      const items = await FileUtils.readLargeData(path);
      const ids = items.map((item) => item._id);
      await MigrationUtils.deleteData('students', ids, this.university._id, userRepository);

      const students = [];

      for (let item of items) {
        const { _id, avatar, email, location, mobileNumber, name, token, useTwoFactorAuth } = item;
        const user = await MigrationUtils.userWithEmailAndName(email, MigrationUtils.sanitizeName(name), this.university._id);
        const student = {
          _id,
          ...user,
          avatar,
          location: location || 'India',
          passwordManuallyChanged: false,
          phone: mobileNumber || '',
          token,
          useTwoFactorAuth
        };

        students.push(student);
      }

      await MigrationUtils.updateData('students', students, userRepository);
    }
  }

  private async importCategories(fileName: string) {
    const path = this.rootDir + '/' + fileName + 'categories.json';
    if (FileUtils.fileExists(path)) {
      const items = await FileUtils.readLargeData(path);
      const ids = items.map((item) => item._id);
      await MigrationUtils.deleteData(fileName + 'categories', ids, this.university._id, categoryRepository);

      const categories = [];

      for (let item of items) {
        const category = {
          _id: item._id,
          name: item.name,
          university: this.university._id
        };

        categories.push(category);
      }

      await MigrationUtils.writeData(fileName + 'categories', categories, categoryRepository);
    }
  }

  private async importSubjects(fileName: string) {
    const path = this.rootDir + '/' + fileName + 'subjects.json';
    if (FileUtils.fileExists(path)) {
      const items = await FileUtils.readLargeData(path);
      const ids = items.map((item) => item._id);
      await MigrationUtils.deleteData(fileName + 'subjects', ids, this.university._id, subjectRepository);

      const subjects = [];

      for (let item of items) {
        const subject = {
          _id: item._id,
          name: item.name,
          university: this.university._id
        };

        subjects.push(subject);
      }

      await MigrationUtils.writeData(fileName + 'subjects', subjects, subjectRepository);
    }
  }

  private async importDomains(fileName: string) {
    const file = this.rootDir + '/' + fileName + 'domains.json';
    if (FileUtils.fileExists(file)) {
      const items = await FileUtils.readLargeData(file);
      const ids = items.map((item) => item._id);
      await MigrationUtils.deleteData(fileName + 'domains', ids, this.university._id, domainRepository);

      const domains = [];

      for (let item of items) {
        const domain = {
          _id: item._id,
          name: item.name,
          university: this.university._id
        };

        domains.push(domain);
      }

      await MigrationUtils.writeData(fileName + 'domains', domains, domainRepository);
    }
  }

  private async importQuestions(fileName: string) {
    const file = this.rootDir + '/' + fileName + 'questions.json';
    if (FileUtils.fileExists(file)) {
      const items = await FileUtils.readLargeData(file);
      const ids = items.map((item) => item._id);
      await MigrationUtils.deleteData(fileName + 'questions', ids, this.university._id, questionRepository);

      const questions = [];

      for (let item of items) {
        const {
          _id,
          allowedLanguages,
          answers,
          category,
          content,
          difficultyLevel,
          maxTime: time = 60,
          maxWords,
          owner,
          points,
          randomizeOptions = false,
          type
        } = item;

        const question = {
          _id,
          allowedLanguages,
          alternatives: [],
          category,
          content,
          difficulty: MigrationUtils.formatDifficulty(difficultyLevel),
          isCaseInsensitive: false,
          lecture: null,
          options: MigrationUtils.formatAnswers(type, answers),
          owner,
          points,
          postCode: '',
          preCode: '',
          randomizeOptions,
          time,
          type: MigrationUtils.formatType(type),
          university: this.university._id,
          wordCount: { enabled: maxWords && maxWords > 10, limit: maxWords || 50 }
        };
        question.content = item.content;
        question.owner = this.admin._id;

        questions.push(question);
      }

      await MigrationUtils.writeData(fileName + 'questions', questions, questionRepository);
    }
  }

  private async importExams() {
    if (FileUtils.fileExists(this.rootDir + '/meazrs.json')) {
      const path = this.rootDir + '/meazrs.json';

      const items = await FileUtils.readLargeData(path);
      const ids = items.map((item) => item._id);
      this.examIds.push(...ids);
      await MigrationUtils.deleteData('exams', ids, this.university._id, examRepository);

      const exams = [];

      for (let item of items) {
        const {
          _id,
          accessibility,
          description,
          fetch,
          groupQuestions,
          instruction,
          navigation,
          noisePopupEnabled = false,
          noisePopupDBFrequency = 10,
          noisePopupFrequency = 10,
          owner,
          price,
          shuffleQuestions = false,
          shuffleType,
          skill,
          timing,
          title,
          totalMarks = { value: 1 },
          totalTime = { value: 0 },
          shields
        } = item;

        const formattedQuestions = MigrationUtils.sanitizeQuestions(groupQuestions);
        await questionRepository.update({ _id: { $in: formattedQuestions } }, { exam: _id }, { multi: true });

        const exam = {
          _id,
          applicants: [],
          autoScheduler: { enabled: false },
          browserLock: {
            enabled: MigrationUtils.shieldValue(shields.lockAndTrack),
            debar: {
              enabled: shields.lockAndTrack && shields.lockAndTrack.deBarEnabled ? shields.lockAndTrack.deBarEnabled : false,
              // tslint:disable-next-line:max-line-length
              maxDeviation: shields.lockAndTrack && shields.lockAndTrack.maxDeviation ? shields.lockAndTrack.maxDeviation : 10,
              maxViolation: shields.lockAndTrack && shields.lockAndTrack.maxViolation ? shields.lockAndTrack.maxViolation : 10
            }
          },
          commonAccessEnabled: false,
          completionMail: { enabled: false },
          createdAt: new Date(),
          description: description || title,
          deviceRestriction: null,
          domain: skill ? skill : null,
          dynamicForm: null,
          editors: [],
          enableAnswerInPaper: false,
          fetch: await MigrationUtils.formatFetch(fetch, this.university._id),
          impersonationCheck: {
            enabled: false,
            automatic: false,
            manual: false
          },
          instruction: instruction || title,
          monitoring: {
            enabled: MigrationUtils.shieldValue(shields.vidProctor),
            liveChat: false,
            liveExamControl: false,
            type: MigrationUtils.formatMonitorType(shields.vidProctor),
            debar: shields.vidProctor && shields.vidProctor.deBarEnabled ? shields.vidProctor.deBarEnabled : false,
            primary: { device: true, person: true },
            noise: {
              enabled: noisePopupEnabled,
              decibel: noisePopupDBFrequency,
              seconds: noisePopupFrequency
            },
            secondary: { enabled: MigrationUtils.shieldValue(shields.doubleProctor) }
          },
          navigation: {
            enabled: true,
            categoryLabel: navigation.categoryLabel,
            categoryNavigation: navigation.categoryNavigator,
            pointsLabel: navigation.pointsLabel,
            questionNavigation: navigation.questionNavigator,
            questionPositionLabel: navigation.questionLabel,
            showNegativePoints: navigation.negativePoints
          },
          owner,
          paymentGateway: null,
          preRequisiteEnabled: false,
          price: price || 0,
          priceEnabled: !!(price && price > 0),
          questions: formattedQuestions,
          randomisation: {
            enabled: shuffleQuestions,
            type: MigrationUtils.formatRandomisation(shuffleType)
          },
          secure: accessibility !== 'Public',
          students: [],
          subDomain: null,
          timeMode: timing && timing === 'Stand Alone Time' ? ExamTimeMode.STAND_ALONE_TIME : ExamTimeMode.EXAMINATION_TIME,
          title,
          totalMarks: totalMarks && totalMarks.value ? totalMarks.value : 0,
          totalTime: totalTime && totalTime.value ? totalTime.value : 0,
          university: this.university._id
        };

        exams.push(exam);
      }

      await MigrationUtils.writeData('exams', exams, examRepository);
    }
  }

  private async importTracks() {
    const files = FileUtils.directoryFiles(this.rootDir);
    const sanitizedFiles = files.filter((file) => file.includes('meazr-tracks') && !file.includes('._'));

    for (let file of sanitizedFiles) {
      const path = this.rootDir + '/' + file;
      console.warn(path);

      if (FileUtils.fileExists(path)) {
        const items = await FileUtils.readLargeData(path);

        const ids = items.map((item) => item._id);
        await MigrationUtils.deleteData('trackExams', ids, this.university._id, trackExamRepository);

        const trackExams = [];

        for (let item of items) {
          const {
            _id,
            answers,
            endsAt,
            finishedAt: endedAt,
            groupQuestions,
            progress,
            measure: percentage,
            meazr: exam,
            reviews = [],
            score,
            startsAt: startedAt,
            status,
            totalTime,
            user,
            email,
            name
          } = item;

          const trackExam = {
            _id,
            answers: MigrationUtils.formatTrackAnswers(answers),
            chat: null,
            endedAt,
            endsAt,
            exam,
            email,
            name,
            impersonationVerified: true,
            leaveReasons: [],
            mode: MigrationUtils.formatTrackMode(progress),
            optionRandomiseSteps: [],
            percentage,
            questions: MigrationUtils.sanitizeQuestions(groupQuestions),
            reviewStatus: reviews.length > 0 ? TrackExamReviewStatus.REVIEWED : TrackExamReviewStatus.NOT_REQUESTED,
            score,
            selectedAlternatives: [],
            startedAt,
            status: MigrationUtils.formatTrackStatus(status),
            tagged: [],
            totalTime: totalTime.value,
            university: this.university._id,
            user: user ? user : null,
            writingOption: TrackExamWritingOption.EDITOR
          };

          trackExams.push(trackExam);
        }

        await MigrationUtils.writeData('trackExams', trackExams, trackExamRepository);
      }
    }
  }

  private async importFlows() {
    if (FileUtils.fileExists(this.rootDir + '/flows.json')) {
      const path = this.rootDir + '/flows.json';
      const items = await FileUtils.readLargeData(path);
      const ids = items.map((item) => item._id.toString());
      this.examIds.push(...ids);

      const examsFound = await examRepository
        .find({ _id: { $in: ids } })
        .select('_id')
        .lean();
      const examFoundIds = examsFound.map((item) => item._id.toString());

      const examsToBeAdded = [];
      for (let item of items) {
        if (examFoundIds.indexOf(item._id.toString()) === -1) {
          examsToBeAdded.push(item);
        }
      }

      const exams = [];

      for (let item of examsToBeAdded) {
        const {
          _id,
          accessibility,
          description,
          editors = [],
          fetch,
          groupQuestions,
          instruction,
          navigation,
          noisePopupEnabled = false,
          noisePopupDBFrequency = 10,
          noisePopupFrequency = 10,
          owner,
          price,
          shuffleQuestions = false,
          shuffleType,
          skill,
          timing,
          title,
          totalMarks = { auto: true, value: 1 },
          totalTime = { value: 0 },
          shields
        } = item;

        const formattedQuestions = MigrationUtils.sanitizeQuestions(groupQuestions);
        await questionRepository.update({ _id: { $in: formattedQuestions } }, { exam: _id }, { multi: true });

        const exam = {
          _id,
          applicants: [],
          autoCalculatePoint: totalMarks && totalMarks.auto ? totalMarks.auto : false,
          autoScheduler: { enabled: false },
          browserLock: {
            enabled: shields && shields.lockAndTrack ? MigrationUtils.shieldValue(shields.lockAndTrack) : false,
            debar: {
              // tslint:disable-next-line:max-line-length
              enabled: shields && shields.lockAndTrack && shields.lockAndTrack.deBarEnabled ? shields.lockAndTrack.deBarEnabled : false,
              // tslint:disable-next-line:max-line-length
              maxDeviation: shields && shields.lockAndTrack && shields.lockAndTrack.maxDeviation ? shields.lockAndTrack.maxDeviation : 10,
              // tslint:disable-next-line:max-line-length
              maxViolation: shields && shields.lockAndTrack && shields.lockAndTrack.maxViolation ? shields.lockAndTrack.maxViolation : 10
            }
          },
          commonAccessEnabled: false,
          completionMail: { enabled: false },
          createdAt: new Date(),
          description: description || title,
          deviceRestriction: null,
          domain: skill ? skill : null,
          dynamicForm: null,
          editors,
          enableAnswerInPaper: false,
          fetch: await MigrationUtils.formatFetch(fetch, this.university._id),
          impersonationCheck: {
            enabled: false,
            automatic: false,
            manual: false
          },
          instruction: instruction || title,
          monitoring: {
            deviceSelectionEnabled: true,
            enabled: shields && shields.vidProctor ? MigrationUtils.shieldValue(shields.vidProctor) : false,
            liveChat: false,
            liveExamControl: false,
            // tslint:disable-next-line:max-line-length
            type: shields && shields.vidProctor ? MigrationUtils.formatMonitorType(shields.vidProctor) : ExamProctor.VIDEO_PROCTOR,
            debar: shields && shields.vidProctor && shields.vidProctor.deBarEnabled ? shields.vidProctor.deBarEnabled : false,
            primary: { device: true, person: true },
            noise: {
              enabled: noisePopupEnabled,
              decibel: noisePopupDBFrequency,
              seconds: noisePopupFrequency
            },
            secondary: { enabled: shields && shields.doubleProctor ? MigrationUtils.shieldValue(shields.doubleProctor) : false }
          },
          navigation: {
            enabled: true,
            categoryLabel: navigation && navigation.categoryLabel ? navigation.categoryLabel : false,
            categoryNavigation: navigation && navigation.categoryNavigator ? navigation.categoryNavigator : false,
            pointsLabel: navigation && navigation.pointsLabel ? navigation.pointsLabel : false,
            questionNavigation: navigation && navigation.questionNavigator ? navigation.questionNavigator : false,
            questionPositionLabel: navigation && navigation.questionLabel ? navigation.questionLabel : false,
            showNegativePoints: navigation && navigation.negativePoints ? navigation.negativePoints : false
          },
          owner,
          paymentGateway: null,
          preRequisiteEnabled: false,
          price: price || 0,
          priceEnabled: !!(price && price > 0),
          questions: formattedQuestions,
          randomisation: {
            enabled: shuffleQuestions,
            type: MigrationUtils.formatRandomisation(shuffleType)
          },
          secure: accessibility && accessibility !== 'Public',
          students: [],
          subDomain: null,
          timeMode: timing && timing === 'Stand Alone Time' ? ExamTimeMode.STAND_ALONE_TIME : ExamTimeMode.EXAMINATION_TIME,
          title,
          totalMarks: totalMarks && totalMarks.value ? totalMarks.value : 0,
          totalTime: totalTime && totalTime.value ? totalTime.value : 0,
          university: this.university
        };

        exams.push(exam);
      }

      await MigrationUtils.writeData('flows', exams, examRepository);
    }
  }

  private async importReportUsers(fileName: string) {
    const file = this.rootDir + '/' + fileName + 'report-users.json';
    if (FileUtils.fileExists(file)) {
      const items = await FileUtils.readLargeData(file);
      const ids = items.map((item) => item._id);
      await MigrationUtils.deleteData('students', ids, this.university._id, userRepository);

      const reportUsers = [];

      for (let item of items) {
        const { _id, avatar, email, location, mobileNumber, name, token, useTwoFactorAuth } = item;
        const user = await MigrationUtils.userWithEmailAndName(email, MigrationUtils.sanitizeName(name), this.university._id);
        const reportUser = {
          _id,
          ...user,
          avatar,
          location: location || 'India',
          passwordManuallyChanged: false,
          phone: mobileNumber || '',
          token,
          useTwoFactorAuth
        };

        reportUsers.push(reportUser);
      }

      await MigrationUtils.updateUser(fileName + 'report-users', reportUsers, userRepository);
    }
  }

  private async fixFlowReportMeazrs() {
    const file = this.rootDir + '/flowIds.json';
    if (FileUtils.fileExists(file)) {
      const items = await FileUtils.readLargeData(file);
      for (let item of items) {
        await trackExamRepository.update({ exam: { $in: item.meazrs } }, { exam: item._id }, { multi: true });
      }
    }
  }
}
