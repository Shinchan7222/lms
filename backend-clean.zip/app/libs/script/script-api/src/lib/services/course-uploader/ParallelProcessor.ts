/**
 * Parallel processor for FFmpeg, download, and upload operations
 * Limits concurrent operations to 6 at a time
 */
export class ParallelProcessor {
  private activeTasks: Set<Promise<any>> = new Set();
  private readonly maxConcurrent: number = 1;

  /**
   * Process tasks in parallel with a limit of maxConcurrent
   */
  async processInParallel<T>(
    tasks: Array<() => Promise<T>>
  ): Promise<Array<{ success: boolean; result?: T; error?: any }>> {
    const results: Array<{ success: boolean; result?: T; error?: any }> = [];
    const taskQueue = [...tasks];
    const activePromises: Set<Promise<void>> = new Set();

    // Process tasks in batches
    while (taskQueue.length > 0 || activePromises.size > 0) {
      // Start new tasks up to the limit
      while (activePromises.size < this.maxConcurrent && taskQueue.length > 0) {
        const task = taskQueue.shift();
        if (task) {
          const taskPromise = this.executeTask(task, results);
          activePromises.add(taskPromise);

          taskPromise.finally(() => {
            activePromises.delete(taskPromise);
          });
        }
      }

      // Wait for at least one task to complete before starting new ones
      if (activePromises.size > 0) {
        await Promise.race(Array.from(activePromises));
      }
    }

    return results;
  }

  private async executeTask<T>(
    task: () => Promise<T>,
    results: Array<{ success: boolean; result?: T; error?: any }>
  ): Promise<void> {
    try {
      const result = await task();
      results.push({ success: true, result });
    } catch (error) {
      results.push({ success: false, error });
    }
  }

  /**
   * Wait for all active tasks to complete
   */
  async waitForAll(): Promise<void> {
    if (this.activeTasks.size > 0) {
      await Promise.all(Array.from(this.activeTasks));
    }
  }

  /**
   * Process a single task with concurrency limit
   */
  async processTask<T>(task: () => Promise<T>): Promise<T> {
    // Wait if we're at the limit
    while (this.activeTasks.size >= this.maxConcurrent) {
      await Promise.race(Array.from(this.activeTasks));
    }

    const taskPromise = task();
    this.activeTasks.add(taskPromise);

    try {
      const result = await taskPromise;
      return result;
    } finally {
      this.activeTasks.delete(taskPromise);
    }
  }

  getActiveTaskCount(): number {
    return this.activeTasks.size;
  }
}

// Singleton instance for parallel processing
export const parallelProcessor = new ParallelProcessor();

