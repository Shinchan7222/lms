import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { CourseStructureReorganizerService } from './CourseStructureReorganizerService';

export class DuplicateChapterMergerService {
    private readonly universityId: string;
    private reorganizer: CourseStructureReorganizerService;

    constructor(universityId: string) {
        this.universityId = universityId;
        this.reorganizer = new CourseStructureReorganizerService(universityId);
    }

    async process(): Promise<{
        message: string;
        totalCoursesProcessed: number;
        totalChaptersMerged: number;
        changes: string[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let totalCoursesProcessed = 0;
            let totalChaptersMerged = 0;
            const changes: string[] = [];

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                // Fetch all chapters (including deleted ones? No, we only care about active ones mostly, but let's stick to active)
                // Actually, duplicate check logic looked at `course.chapters` ids.
                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                if (chapters.length === 0) continue;

                // Group by normalized name
                const groupedChapters = new Map<string, any[]>();

                for (const chapter of chapters) {
                    let name = chapter.title || '';
                    const match = name.match(/^Module\s+\d+\s+-\s+(.*)$/i);
                    let normalized = match ? match[1].trim() : name.trim();

                    if (!groupedChapters.has(normalized)) {
                        groupedChapters.set(normalized, []);
                    }
                    groupedChapters.get(normalized)?.push(chapter);
                }

                let courseModified = false;

                for (const [normalizedName, group] of groupedChapters.entries()) {
                    if (group.length > 1) {
                        // MERGE
                        // 1. Master is the first one
                        const masterChapter = group[0];
                        const others = group.slice(1);

                        // 2. Collect unique lectures
                        const masterLectureIds = new Set(masterChapter.lectures.map((id: any) => id.toString()));

                        for (const other of others) {
                            if (other.lectures && other.lectures.length > 0) {
                                for (const lectureId of other.lectures) {
                                    if (!masterLectureIds.has(lectureId.toString())) {
                                        masterChapter.lectures.push(lectureId);
                                        masterLectureIds.add(lectureId.toString());
                                    }
                                }
                            }
                            // Delete other chapter
                            other.deleted = true; // Soft delete or hard? Usually soft delete in this system
                            await other.save();

                            // Remove from course.chapters array
                            const idx = course.chapters.findIndex((cId: any) => cId.toString() === other._id.toString());
                            if (idx > -1) {
                                course.chapters.splice(idx, 1);
                            }
                        }

                        // 3. Save Master Chapter
                        await masterChapter.save();
                        changes.push(`[Course: ${course.title}] Merged ${others.length} duplicate(s) into "${masterChapter.title}"`);
                        totalChaptersMerged += others.length;
                        courseModified = true;

                        // 4. Reorder Lectures in Master Chapter
                        // Use the reorganizer logic to rename "Topic {i} - ..." -> "Unit {i} - ..."
                        // We need the reorganizer service public method
                        const lecturesChanged = await this.reorganizer.processLectures(masterChapter, course.title, masterChapter.title);
                        if (lecturesChanged) {
                            await masterChapter.save();
                            changes.push(`[Course: ${course.title}] Reordered lectures in "${masterChapter.title}"`);
                        }
                    }
                }

                if (courseModified) {
                    await course.save();
                    totalCoursesProcessed++;
                }
            }

            return {
                message: 'Duplicate chapter merge completed',
                totalCoursesProcessed,
                totalChaptersMerged,
                changes
            };

        } catch (error: any) {
            console.error('Error merging duplicate chapters:', error);
            return {
                message: 'Error merging duplicate chapters',
                totalCoursesProcessed: 0,
                totalChaptersMerged: 0,
                changes: [],
                error: error.message
            };
        }
    }
}
