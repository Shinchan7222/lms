import { Workbook } from 'exceljs';
import { videoTempRepository } from '@edorer/video-uploader-data';

interface ExcelRow {
    'Course Name': string;
    'Program Name'?: string;
    'Unit Name': string;
    'Topic Name': string;
    'Video Link': string;
}

interface CourseGroup {
    courseName: string;
    programName?: string;
    units: Map<string, UnitGroup>;
}

interface UnitGroup {
    unitName: string;
    topics: Map<string, TopicGroup>;
}

interface TopicGroup {
    topicName: string;
    videoUrls: string[];
}

interface MissingTopic {
    unitName: string;
    topicName: string;
}

interface CourseDetail {
    courseName: string;
    totalTopics: number;
    missingVideos: number;
    missingTopics: MissingTopic[];
}

interface CheckResult {
    success: boolean;
    totalCourses: number;
    totalTopics: number;
    totalMissingVideos: number;
    courseDetails: CourseDetail[];
}

export class CourseChecker {
    private readonly excelFile: any;
    private readonly tabName: string;

    constructor(excelFile: any, tabName: string) {
        this.excelFile = excelFile;
        this.tabName = tabName;
    }

    /**
     * Main process method to check for missing videos
     */
    async process(): Promise<CheckResult> {
        try {
            // Parse Excel file
            const rows = await this.parseExcel();

            // Group data by Course -> Unit -> Topic
            const courseGroups = this.groupByCourseUnitTopic(rows);

            // Check for missing videos
            const result = await this.checkMissingVideos(courseGroups);

            return result;
        } catch (error: any) {
            throw new Error(`Failed to process Excel file: ${error.message}`);
        }
    }

    /**
     * Parse Excel file and extract rows
     */
    private async parseExcel(): Promise<ExcelRow[]> {
        const workbook = new Workbook();
        await workbook.xlsx.load(this.excelFile.buffer);

        // Log all worksheets in the Excel file
        const worksheetNames = workbook.worksheets.map(ws => ws.name);
        console.log('Available worksheets in Excel file:', worksheetNames);

        const worksheet = workbook.getWorksheet(1); // Get the first worksheet
        if (!worksheet) {
            throw new Error('Excel file is empty or invalid');
        }

        const rows: ExcelRow[] = [];
        let headers: { [key: string]: number } = {};
        let headerRowFound = false;

        // Process each row
        worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
            // First row should be headers
            if (rowNumber === 1) {
                row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
                    const headerValue = cell.value?.toString() || '';
                    headers[headerValue] = colNumber;
                });
                headerRowFound = true;

                // Validate required columns
                const requiredColumns = ['Course Name', 'Unit Name', 'Topic Name', 'Video Link'];
                for (const col of requiredColumns) {
                    if (!(col in headers)) {
                        throw new Error(`Missing required column: ${col}`);
                    }
                }
                return;
            }

            if (!headerRowFound) {
                return;
            }

            // Extract row data
            const rowData: ExcelRow = {
                'Course Name': '',
                'Program Name': undefined,
                'Unit Name': '',
                'Topic Name': '',
                'Video Link': ''
            };

            // Get cell values by header name
            for (const [headerName, colNumber] of Object.entries(headers)) {
                const cell = row.getCell(colNumber);
                let cellValue = '';

                // Check if cell has a hyperlink
                const hyperlink = cell.hyperlink as any;
                if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
                    cellValue = hyperlink.target;
                } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
                    const formula = (cell.value as any).formula;
                    const urlMatch = formula?.match(/=HYPERLINK\("([^"]+)"/i);
                    if (urlMatch && urlMatch[1]) {
                        cellValue = urlMatch[1];
                    } else {
                        if (cell.value && (cell.value as any).hyperlink) {
                            cellValue = (cell.value as any).hyperlink;
                        } else {
                            cellValue = cell.value?.toString() || '';
                        }
                    }
                } else {
                    if (cell.value && (cell.value as any).hyperlink) {
                        cellValue = (cell.value as any).hyperlink;
                    } else {
                        cellValue = cell.value?.toString() || '';
                    }
                }

                if (headerName in rowData) {
                    (rowData as any)[headerName] = cellValue;
                }
            }

            // Only add row if it has required data
            if (rowData['Course Name'] || rowData['Unit Name'] || rowData['Topic Name']) {
                rows.push(rowData);
            }
        });

        if (rows.length === 0) {
            throw new Error('No data found in Excel file');
        }

        return rows;
    }

    /**
     * Group rows by Course -> Unit -> Topic
     */
    private groupByCourseUnitTopic(rows: ExcelRow[]): Map<string, CourseGroup> {
        const courseMap = new Map<string, CourseGroup>();

        for (const row of rows) {
            const courseName = row['Course Name'];
            const unitName = row['Unit Name'];
            const topicName = row['Topic Name'];

            if (!courseName || !unitName || !topicName) {
                continue;
            }

            // Get or create course group
            if (!courseMap.has(courseName)) {
                courseMap.set(courseName, {
                    courseName,
                    programName: row['Program Name'],
                    units: new Map()
                });
            }

            const courseGroup = courseMap.get(courseName)!;

            // Get or create unit group
            if (!courseGroup.units.has(unitName)) {
                courseGroup.units.set(unitName, {
                    unitName,
                    topics: new Map()
                });
            }

            const unitGroup = courseGroup.units.get(unitName)!;

            // Get or create topic group
            if (!unitGroup.topics.has(topicName)) {
                unitGroup.topics.set(topicName, {
                    topicName,
                    videoUrls: []
                });
            }

            const topicGroup = unitGroup.topics.get(topicName)!;

            // Add video link if present
            if (row['Video Link'] && row['Video Link'].trim()) {
                topicGroup.videoUrls.push(row['Video Link'].trim());
            }
        }

        return courseMap;
    }

    /**
     * Check for missing videos in the database
     */
    private async checkMissingVideos(courseGroups: Map<string, CourseGroup>): Promise<CheckResult> {
        const courseDetails: CourseDetail[] = [];
        let totalTopics = 0;
        let totalMissingVideos = 0;

        for (const [courseName, courseGroup] of courseGroups) {
            const missingTopics: MissingTopic[] = [];
            let courseTopicCount = 0;

            for (const [unitName, unitGroup] of courseGroup.units) {
                for (const [topicName, topicGroup] of unitGroup.topics) {
                    courseTopicCount++;
                    totalTopics++;

                    // Check if video exists in videoTemp
                    const videoTemp = await videoTempRepository.findOne({
                        courseName: courseGroup.courseName.trim(),
                        unitName: unitName.trim(),
                        topicName: topicName.trim()
                    }).lean();

                    // If no video found in database, add to missing list
                    if (!videoTemp || !videoTemp.url) {
                        missingTopics.push({
                            unitName,
                            topicName
                        });
                        totalMissingVideos++;
                    }
                }
            }

            courseDetails.push({
                courseName,
                totalTopics: courseTopicCount,
                missingVideos: missingTopics.length,
                missingTopics
            });
        }

        return {
            success: true,
            totalCourses: courseGroups.size,
            totalTopics,
            totalMissingVideos,
            courseDetails
        };
    }
}
