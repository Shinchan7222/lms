import { Workbook } from 'exceljs';
import { videoToUploadRepository, VideoToUpload } from '@edorer/script-data';
import { Types } from 'mongoose';

interface ExcelRow {
  'Course Name': string;
  'Program Name'?: string;
  'Unit Name': string;
  'Topic Name': string;
  'Video Link': string;
  'Faculty Name for videos'?: string;
  'Semester'?: string;
}

interface GroupedData {
  courseName: string;
  programName?: string;
  unitName: string;
  topicName: string;
  videoLinks: string[];
  facultyName?: string;
  semester?: string;
}

export class VideoToUploadExcelParser {
  private readonly excelFile: any;
  private readonly universityId: string;

  constructor(excelFile: any, universityId: string) {
    this.excelFile = excelFile;
    this.universityId = universityId;
  }

  async parseAndStore(): Promise<{ success: number; errors: string[]; duplicates: number }> {
    const errors: string[] = [];
    let successCount = 0;
    let duplicatesCount = 0;

    try {
      // Parse Excel file
      const rows = await this.parseExcel();

      // Group by Topic Name (same topic = append videos)
      const groupedData = this.groupByTopic(rows);

      // Store each group in the database with duplicate checking
      for (const group of groupedData) {
        try {
          // Check for duplicates based on courseName, unitName, topicName, and university
          const existing = await videoToUploadRepository.findOne({
            courseName: group.courseName,
            unitName: group.unitName,
            topicName: group.topicName,
            university: new Types.ObjectId(this.universityId)
          }).lean();

          if (existing) {
            // If exists, remove it and create a new one
            await videoToUploadRepository.delete({ _id: existing._id });
          }

          // Create new VideoToUpload entry with status 'pending'
          await videoToUploadRepository.create({
            courseName: group.courseName.trim(),
            programName: group.programName.trim(),
            unitName: group.unitName.trim(),
            topicName: group.topicName.trim(),
            videoLinks: group.videoLinks,
            facultyName: group.facultyName.trim(),
            semester: group.semester,
            university: new Types.ObjectId(this.universityId),
            status: 'pending'
          });

          successCount++;
        } catch (error: any) {
          const errorMsg = `Error storing ${group.courseName} - ${group.unitName} - ${group.topicName}: ${error.message}`;
          errors.push(errorMsg);
          console.error(errorMsg, error);
        }
      }

      return { success: successCount, errors, duplicates: duplicatesCount };
    } catch (error: any) {
      throw new Error(`Failed to parse and store Excel file: ${error.message}`);
    }
  }

  private async parseExcel(): Promise<ExcelRow[]> {
    const workbook = new Workbook();
    await workbook.xlsx.load(this.excelFile.buffer);

    const worksheet = workbook.getWorksheet(1); // Get the first worksheet
    if (!worksheet) {
      throw new Error('Excel file is empty or invalid');
    }

    const rows: ExcelRow[] = [];
    let headers: { [key: string]: number } = {};
    let headerRowFound = false;

    // Process each row
    worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      // First row should be headers
      if (rowNumber === 1) {
        row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
          const headerValue = cell.value?.toString() || '';
          headers[headerValue] = colNumber;
        });
        headerRowFound = true;

        // Validate required columns
        const requiredColumns = ['Course Name', 'Unit Name', 'Topic Name', 'Video Link'];
        for (const col of requiredColumns) {
          if (!(col in headers)) {
            throw new Error(`Missing required column: ${col}`);
          }
        }
        return;
      }

      if (!headerRowFound) {
        return;
      }

      // Extract row data
      const rowData: ExcelRow = {
        'Course Name': '',
        'Program Name': undefined,
        'Unit Name': '',
        'Topic Name': '',
        'Video Link': '',
        'Faculty Name for videos': undefined,
        'Semester': undefined
      };

      // Get cell values by header name
      for (const [headerName, colNumber] of Object.entries(headers)) {
        const cell = row.getCell(colNumber);
        let cellValue = '';

        // Check if cell has a hyperlink (can be string or object with target property)
        const hyperlink = cell.hyperlink as any;
        if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
          cellValue = hyperlink.target;
        } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
          const formula = (cell.value as any).formula;
          const urlMatch = formula?.match(/=HYPERLINK\("([^"]+)"/i);
          if (urlMatch && urlMatch[1]) {
            cellValue = urlMatch[1];
          } else {
            if (cell.value && (cell.value as any).hyperlink) {
              cellValue = (cell.value as any).hyperlink;
            } else {
              cellValue = cell.value?.toString() || '';
            }
          }
        } else {
          if (cell.value && (cell.value as any).hyperlink) {
            cellValue = (cell.value as any).hyperlink;
          } else {
            cellValue = cell.value?.toString() || '';
          }
        }

        if (headerName in rowData) {
          (rowData as any)[headerName] = cellValue;
        }
      }

      // Only add row if it has required data
      if (rowData['Course Name'] || rowData['Unit Name'] || rowData['Topic Name']) {
        rows.push(rowData);
      }
    });

    if (rows.length === 0) {
      throw new Error('No data found in Excel file');
    }

    return rows;
  }

  private groupByTopic(rows: ExcelRow[]): GroupedData[] {
    const groupedMap = new Map<string, GroupedData>();

    for (const row of rows) {
      const key = `${row['Course Name']}|${row['Program Name'] || ''}|${row['Unit Name']}|${row['Topic Name']}`;

      if (!groupedMap.has(key)) {
        groupedMap.set(key, {
          courseName: row['Course Name'],
          programName: row['Program Name'],
          unitName: row['Unit Name'],
          topicName: row['Topic Name'],
          videoLinks: [],
          facultyName: row['Faculty Name for videos'],
          semester: row['Semester']
        });
      }

      const group = groupedMap.get(key)!;
      if (row['Video Link'] && row['Video Link'].trim()) {
        group.videoLinks.push(row['Video Link'].trim());
      }
    }

    return Array.from(groupedMap.values());
  }
}

