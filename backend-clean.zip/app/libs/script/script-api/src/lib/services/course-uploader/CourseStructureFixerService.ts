import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';

export class CourseStructureFixerService {
    private readonly universityId: string;
    private changes: string[] = [];

    constructor(universityId: string) {
        this.universityId = universityId;
    }

    async process(): Promise<{ success: boolean; count: number; changes: string[]; error?: string }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let processedCount = 0;

            for (const course of courses) {
                await this.processCourse(course);
                processedCount++;
            }

            return { success: true, count: processedCount, changes: this.changes };
        } catch (error: any) {
            console.error('Error fixing course structure:', error);
            return { success: false, count: 0, changes: [], error: error.message };
        }
    }

    public async processCourse(course: any) {
        const chapters = await chapterRepository.find({
            course: course._id,
        });

        if (!chapters || chapters.length === 0) return;

        for (const chapter of chapters) {
            await this.processLectures(chapter, course.title, chapter.title);
        }
    }

    private async processLectures(chapter: any, courseTitle: string, chapterTitle: string): Promise<boolean> {
        if (!chapter.lectures || chapter.lectures.length === 0) return false;

        const lectures = await lectureRepository.find({
            _id: { $in: chapter.lectures }
        });

        const unitLectures: any[] = [];
        const otherLectures: any[] = [];

        for (const lecture of lectures) {
            const title = lecture.title || '';
            const unitMatch = title.trim().match(/^(\*?)\s*Unit\s+(\d+)(.*)$/i);

            if (unitMatch) {
                unitLectures.push({
                    lecture,
                    star: unitMatch[1] || '',
                    number: parseInt(unitMatch[2], 10),
                    suffix: unitMatch[3] || '',
                    originalTitle: title
                });
            } else {
                otherLectures.push(lecture);
            }
        }

        // Sort by CURRENT Unit number
        unitLectures.sort((a, b) => a.number - b.number);

        // Group and Re-index
        let currentUnitIndex = 0;
        let lastBaseName = '';

        let isLectureChanged = false;

        for (const item of unitLectures) {
            let cleanSuffix = item.suffix.trim();
            cleanSuffix = cleanSuffix.replace(/^[-:]\s*/, '');

            const baseNameMatch = cleanSuffix.match(/^(.*?)(\s+\d+)?$/);
            const baseName = baseNameMatch ? baseNameMatch[1].trim().toLowerCase() : cleanSuffix.toLowerCase();

            if (baseName !== lastBaseName) {
                currentUnitIndex++;
                lastBaseName = baseName;
            }

            const newTitle = `${item.star}Unit ${currentUnitIndex}${item.suffix}`;

            if (item.lecture.title !== newTitle) {
                this.changes.push(`[Course: ${courseTitle} | Chapter: ${chapterTitle}]\n  Old Lecture: "${item.originalTitle}"\n  New Lecture: "${newTitle}"`);
                item.lecture.title = newTitle;
                await item.lecture.save();
                isLectureChanged = true;
            }
        }

        // Re-assemble lectures for sorting check
        const processedUnitLectures = unitLectures.map(u => u.lecture);

        // Sort Others
        otherLectures.sort((a, b) => {
            const getPriority = (t: string) => {
                const title = t.trim();
                if (title.match(/^Assignment/i)) return 100;
                if (title.match(/^Quiz/i)) return 101;
                if (title.match(/^Question/i)) return 102;
                return 0;
            };

            const pA = getPriority(a.title);
            const pB = getPriority(b.title);

            if (pA !== pB) return pA - pB;
            return 0;
        });

        const finalLectures = [...processedUnitLectures, ...otherLectures];

        const originalIdOrder = chapter.lectures.map((id: any) => id.toString()).join(',');
        const newIdOrder = finalLectures.map(l => l._id.toString()).join(',');

        if (originalIdOrder !== newIdOrder) {
            chapter.lectures = finalLectures.map(l => l._id);
            await chapter.save();
            // this.changes.push(`[Course: ${courseTitle} | Chapter: ${chapterTitle}] Reordered lectures`);
        } else if (isLectureChanged) {
            // Changes already logged above
            // this.changes.push(`[Course: ${courseTitle} | Chapter: ${chapterTitle}] Saved renamed lectures`);
        }

        return true;
    }
}
