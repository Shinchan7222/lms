import { FileUtils } from '@edorer/utils';
import { S3University } from '@edorer/s3';
import { v4 as uuidV4 } from 'uuid';
import { videoTempRepository } from '@edorer/video-uploader-data';
import { Types } from 'mongoose';
import { remotionQueue } from './RemotionQueue';
const fs = require('fs');
const exec = require('child_process').exec;
const util = require('util');
const execPromise = util.promisify(exec);
const path = require('path');
const copyFileSync = require('fs').copyFileSync;

interface GroupedData {
  courseName: string;
  programName?: string;
  unitName: string;
  topicName: string;
  videoLinks: string[];
  facultyName?: string;
  semester?: string;
}

export class RemotionVideoProcessor {
  private readonly remotionDir: string;
  private readonly universityConfig: any;
  private readonly s3: S3University;
  private tempDir: string;

  private readonly universityId: string;

  constructor(remotionDir: string, universityConfig: any, s3: S3University, universityId: string) {
    this.remotionDir = remotionDir;
    this.universityConfig = universityConfig;
    this.s3 = s3;
    this.universityId = universityId;
    this.tempDir = `/tmp/remotion-processor-${uuidV4()}`;
  }

  /**
   * Main processing function that orchestrates all steps
   * Remotion processing is queued, FFmpeg and upload operations are parallel
   */
  async processVideo(
    mainVideoPath: string,
    group: GroupedData
  ): Promise<string> {
    let introVideoPath: string | undefined;
    let mainVideoWithOverlaysPath: string | undefined;
    let outroVideoPath: string | undefined;
    let finalVideoPath: string | undefined;

    try {
      // Create temp directory
      FileUtils.createDirectory(this.tempDir);

      // Step 1: Process intro in remotion - QUEUED (sequential)
      console.log('Step 1: Processing intro with Remotion (queued)...');
      // introVideoPath = await remotionQueue.enqueue(() =>
      //   this.processIntroWithRemotion(group)
      // );
      introVideoPath = '/home/amine/mewar.mp4';

      // // Trim intro video to 5 seconds
      // if (FileUtils.fileExists(introVideoPath)) {
      //   console.log('Trimming intro video to 5 seconds...');
      //   introVideoPath = await this.trimVideo(introVideoPath, 0, 5);
      // }

      // Step 2: Add teacher name and logo in a single FFmpeg pass to avoid re-encoding twice - PARALLEL
      console.log('Step 2: Adding teacher name and logo to main video in single pass (parallel)...');
      mainVideoWithOverlaysPath = await this.addTeacherNameAndLogoWithFfmpeg(
        mainVideoPath,
        '',
        `https://storage.googleapis.com/mewaruniversity-important/81e253b9-5fc7-4615-86dc-7d813ab5c9e6-39fc45bb-de2a-4a86-8e6c-fb8f9ccf7332-whatsapp-image-2026-01-04-at-17.43.44.jpg`
      );

      // Step 3: Get outro video path from remotion assets
      outroVideoPath = '/home/amine/mewar.mp4';

      // Step 4: Append intro + main + outro together - PARALLEL
      console.log('Step 3: Appending videos together (parallel)...');
      console.log(`[VIDEO PATH] Before append - Intro: ${introVideoPath}`);
      console.log(`[VIDEO PATH] Before append - Main: ${mainVideoWithOverlaysPath}`);
      console.log(`[VIDEO PATH] Before append - Outro: ${outroVideoPath || 'N/A'}`);
      finalVideoPath = await this.appendVideos(
        introVideoPath,
        mainVideoWithOverlaysPath,
        outroVideoPath
      );

      // Step 5: Upload final video - PARALLEL
      console.log('Step 4: Uploading final video (parallel)...');
      const uploadedUrl = await this.uploadVideo(finalVideoPath, group);

      // Log all video paths for debugging
      console.log('\n========== ALL VIDEO PATHS ==========');
      console.log(`[VIDEO PATH] Temp Directory: ${this.tempDir}`);
      console.log(`[VIDEO PATH] Intro Video: ${introVideoPath}`);
      console.log(`[VIDEO PATH] Main Video with Overlays: ${mainVideoWithOverlaysPath}`);
      console.log(`[VIDEO PATH] Outro Video: ${outroVideoPath || 'N/A'}`);
      console.log(`[VIDEO PATH] Final Concatenated Video: ${finalVideoPath}`);
      console.log(`[VIDEO PATH] Uploaded URL: ${uploadedUrl}`);
      console.log('=====================================\n');

      return uploadedUrl;
    } catch (error: any) {
      console.error('Error processing video:', error);
      throw error;
    } finally {
      // Cleanup temp files
      this.cleanup();
    }
  }

  /**
   * Process FFmpeg operations (teacher name + logo) - can be called in parallel
   * Now uses a single FFmpeg pass to avoid re-encoding twice
   */
  async processFfmpegOperations(
    mainVideoPath: string,
    teacherName: string,
    logoUrl: string
  ): Promise<string> {
    try {
      // Add teacher name and logo in a single pass
      return await this.addTeacherNameAndLogoWithFfmpeg(
        mainVideoPath,
        '',
        `https://storage.googleapis.com/mewaruniversity-important/81e253b9-5fc7-4615-86dc-7d813ab5c9e6-39fc45bb-de2a-4a86-8e6c-fb8f9ccf7332-whatsapp-image-2026-01-04-at-17.43.44.jpg`
      );
    } catch (error: any) {
      console.error('Error in FFmpeg operations:', error);
      throw error;
    }
  }


  /**
   * Process only the intro video using Remotion
   */
  private async processIntroWithRemotion(group: GroupedData): Promise<string> {
    try {
      // Ensure remotion directory exists
      if (!FileUtils.fileExists(this.remotionDir)) {
        throw new Error(`Remotion directory not found at ${this.remotionDir}`);
      }

      // Ensure assets directory exists
      const assetsDir = `${this.remotionDir}/assets`;
      FileUtils.createDirectory(assetsDir);

      // Prepare command parameters (escape quotes in values to prevent shell injection)
      const courseName = (group.courseName || '').replace(/"/g, '\\"');
      const unitName = (group.unitName || '').replace(/"/g, '\\"');
      const topicName = (group.topicName || '').replace(/"/g, '\\"');
      const semester = (group.semester || '').replace(/"/g, '\\"');

      // Build the node command - only process intro
      const introOutputPath = `${this.tempDir}/intro_video.mp4`;
      const command = `cd "${this.remotionDir}" && node render.mjs ` +
        `--intro ./assets/intro.mp4 ` +
        `--logo ./assets/logo.png ` +
        `--title "${courseName}" ` +
        `--subtitle "${unitName}" ` +
        `--topic "${topicName}" ` +
        `--semester "${semester}" ` +
        `--output "${introOutputPath}"`;

      console.log(`Running intro processing command: ${command}`);

      // Execute the command
      const { stdout, stderr } = await execPromise(command, {
        maxBuffer: 1024 * 1024 * 100, // 100MB buffer
      });

      if (stdout) {
        console.log(`Intro processing output: ${stdout}`);
      }
      if (stderr) {
        console.error(`Intro processing stderr: ${stderr}`);
      }

      if (!FileUtils.fileExists(introOutputPath)) {
        throw new Error(`Intro video not found at ${introOutputPath}`);
      }

      console.log('Intro video processed successfully');
      console.log(`[VIDEO PATH] Intro video: ${introOutputPath}`);
      return introOutputPath;
    } catch (error: any) {
      console.error('Error processing intro with remotion:', error);
      throw error;
    }
  }

  /**
   * Add teacher name and logo in a single FFmpeg pass to avoid re-encoding twice
   * Uses ultrafast preset and copies audio to minimize processing time
   */
  async addTeacherNameAndLogoWithFfmpeg(
    videoPath: string,
    teacherName: string,
    logoUrl: string = `https://storage.googleapis.com/mewaruniversity-important/81e253b9-5fc7-4615-86dc-7d813ab5c9e6-39fc45bb-de2a-4a86-8e6c-fb8f9ccf7332-whatsapp-image-2026-01-04-at-17.43.44.jpg`
  ): Promise<string> {
    const hasTeacherName = false;
    const hasLogo = logoUrl && logoUrl.trim() !== '';

    // If neither teacher name nor logo, return original video
    if (!hasTeacherName && !hasLogo) {
      console.log('No teacher name or logo provided, skipping overlay...');
      return videoPath;
    }

    const outputPath = `${this.tempDir}/main_with_overlays_${uuidV4()}.mp4`;
    let logoPath: string | undefined;

    try {
      // Prepare logo if needed
      if (hasLogo) {
        logoPath = `${this.tempDir}/logo_${uuidV4()}.png`;

        // Download logo if it's a URL
        if (logoUrl.startsWith('http://') || logoUrl.startsWith('https://')) {
          const axios = require('axios');
          const response = await axios.get(logoUrl, {
            responseType: 'arraybuffer',
          });
          fs.writeFileSync(logoPath, response.data);
        } else {
          // Assume it's a local path
          if (FileUtils.fileExists(logoUrl)) {
            copyFileSync(logoUrl, logoPath);
          } else {
            throw new Error(`Logo file not found at ${logoUrl}`);
          }
        }
      }

      // Build filter_complex based on what we need to add
      let filterComplex = '';
      let inputArgs = `-ss 20 -i "${videoPath}"`;

      // Helper function to escape text for FFmpeg
      const escapeText = (text: string): string => {
        return text
          .replace(/\\/g, '\\\\')
          .replace(/:/g, '\\:')
          .replace(/'/g, "\\'")
          .replace(/"/g, '\\"')
          .replace(/\[/g, '\\[')
          .replace(/\]/g, '\\]');
      };

      if (hasLogo && hasTeacherName) {
        // Both logo and teacher name
        // Combine teacher name with university text for seamless black box
        const combinedText = `${teacherName.trim()}`;
        const escapedCombinedText = escapeText(combinedText);

        // Logo: positioned at top-right corner, keep logo as-is (no background, no rounded corners)
        // Teacher name + university: positioned at bottom-left (x=20, y=H-th-20), white text on black background
        // Logo processing: scale logo to 250px and overlay directly
        filterComplex = `[0:v]drawtext=text='${escapedCombinedText}':fontcolor=white:fontsize=30:x=20:y=H-th-20:box=1:boxcolor=black@1.0:boxborderw=8[with_text];` +
          `[1:v]scale=280:-1[logo_scaled];` +
          `[with_text][logo_scaled]overlay=W-w-20:20[v]`;
        inputArgs = `-ss 20 -i "${videoPath}" -i "${logoPath}"`;
      } else if (hasLogo) {
        // Only logo - position at top-right, keep logo as-is (no background, no rounded corners)
        // Logo processing: scale logo to 250px and overlay directly
        filterComplex = `[1:v]scale=280:-1[logo_scaled];` +
          `[0:v][logo_scaled]overlay=W-w-20:20[v]`;
        inputArgs = `-ss 20 -i "${videoPath}" -i "${logoPath}"`;
      } else if (hasTeacherName) {
        // Only teacher name - positioned at bottom-left (x=20, y=H-th-20), black background, white text
        // Append ", Silver Oak University" after teacher name
        const combinedText = `${teacherName}`;
        const escapedCombinedText = escapeText(combinedText);

        filterComplex = `drawtext=text='${escapedCombinedText}':fontcolor=white:fontsize=30:x=20:y=H-th-20:box=1:boxcolor=black@1.0:boxborderw=8[v]`;
      }

      // Build FFmpeg command using the specified format
      // Note: Video must be re-encoded when adding overlays
      // - Using ultrafast preset for speed
      // - Audio encoding with aac at 192k bitrate
      // - Explicit stream mapping to process only what's needed
      // - Using efficient pixel format and encoding settings
      const command = `ffmpeg ${inputArgs} ` +
        `-filter_complex "${filterComplex}" ` +
        `-map "[v]" -map 0:a? ` +
        `-c:v libx264 -preset ultrafast -crf 18 -pix_fmt yuv420p ` +
        `-c:a aac -b:a 192k -shortest -avoid_negative_ts make_zero ` +
        `-movflags +faststart "${outputPath}"`;

      console.log(`Adding overlays (teacher: ${hasTeacherName}, logo: ${hasLogo})...`);

      const { stdout, stderr } = await execPromise(command, {
        maxBuffer: 1024 * 1024 * 100,
      });

      if (stdout) {
        console.log(`Overlay output: ${stdout}`);
      }
      if (stderr) {
        console.log(`Overlay stderr: ${stderr}`);
      }

      if (!FileUtils.fileExists(outputPath)) {
        throw new Error(`Video with overlays not found at ${outputPath}`);
      }

      // Cleanup downloaded logo
      // COMMENTED OUT: Keep logo for debugging
      // if (logoPath && FileUtils.fileExists(logoPath)) {
      //   FileUtils.removeFile(logoPath);
      // }

      console.log('Overlays added successfully');
      console.log(`[VIDEO PATH] Main video with overlays: ${outputPath}`);
      return outputPath;
    } catch (error: any) {
      console.error('Error adding overlays:', error);
      // Cleanup on error
      // COMMENTED OUT: Keep logo for debugging
      // if (logoPath && FileUtils.fileExists(logoPath)) {
      //   try {
      //     FileUtils.removeFile(logoPath);
      //   } catch {}
      // }
      throw error;
    }
  }





  /**
   * Get outro video path from remotion assets
   */
  private async getOutroVideoPath(): Promise<string | undefined> {
    const outroSourcePath = `${this.remotionDir}/assets/ending.mp4`;
    const outroPath = `${this.tempDir}/outro_video.mp4`;

    try {
      // Check if outro exists in remotion assets
      if (FileUtils.fileExists(outroSourcePath)) {
        // Copy outro to temp directory
        copyFileSync(outroSourcePath, outroPath);
        console.log('Outro video found and copied');
        console.log(`[VIDEO PATH] Outro video: ${outroPath}`);
        return outroPath;
      }

      // If outro doesn't exist, we can skip it
      console.log('Outro video not found in assets, will skip in concatenation');
      return undefined;
    } catch (error: any) {
      console.error('Error getting outro video:', error);
      // Don't throw, just skip outro if there's an error
      return undefined;
    }
  }

  /**
   * Append intro, main, and outro videos together
   * Public method for parallel processing
   * Uses filter_complex with scaling, padding, and audio formatting
   */
  async appendVideos(
    introPath: string,
    mainPath: string,
    outroPath?: string
  ): Promise<string> {
    const outputPath = `${this.tempDir}/final_video_${uuidV4()}.mp4`;

    try {
      // Create list of videos to concatenate
      // When outro exists, order is: outro - intro - main - outro
      const videoList: string[] = [];

      // Add outro at the beginning if it exists
      // if (outroPath && FileUtils.fileExists(outroPath)) {
      //   videoList.push(outroPath);
      //   console.log(`[APPEND] Found outro video (beginning): ${outroPath}`);
      // }

      if (introPath && FileUtils.fileExists(introPath)) {
        videoList.push(introPath);
        console.log(`[APPEND] Found intro video: ${introPath}`);
      } else {
        console.log(`[APPEND] Intro video not found or invalid: ${introPath}`);
      }
      if (mainPath && FileUtils.fileExists(mainPath)) {
        videoList.push(mainPath);
        console.log(`[APPEND] Found main video: ${mainPath}`);
      } else {
        console.log(`[APPEND] Main video not found or invalid: ${mainPath}`);
      }

      // Add outro at the end if it exists
      if (outroPath && FileUtils.fileExists(outroPath)) {
        videoList.push(outroPath);
        console.log(`[APPEND] Found outro video (ending): ${outroPath}`);
      } else {
        console.log(`[APPEND] Outro video not found or invalid: ${outroPath || 'N/A'}`);
      }

      if (videoList.length === 0) {
        throw new Error('No videos to concatenate');
      }

      const numVideos = videoList.length;
      console.log(`[APPEND] Concatenating ${numVideos} videos...`);

      // Build input arguments
      const inputArgs = videoList.map(path => `-i "${path}"`).join(' ');

      // Build filter_complex: scale, pad, set SAR, fps, and format each video and audio stream
      const filterParts: string[] = [];

      // Process each video: scale to 1920x1080, pad, set SAR, and fps=30
      for (let i = 0; i < numVideos; i++) {
        filterParts.push(
          `[${i}:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[v${i}]`
        );
      }

      // Process each audio: format to 48kHz stereo
      for (let i = 0; i < numVideos; i++) {
        filterParts.push(
          `[${i}:a]aformat=sample_rates=48000:channel_layouts=stereo[a${i}]`
        );
      }

      // Concatenate all video and audio streams
      const concatInputs: string[] = [];
      for (let i = 0; i < numVideos; i++) {
        concatInputs.push(`[v${i}][a${i}]`);
      }
      filterParts.push(
        `${concatInputs.join('')}concat=n=${numVideos}:v=1:a=1[v][a]`
      );

      const filterComplex = filterParts.join(';');

      // Build FFmpeg command with filter_complex
      const command = `ffmpeg ${inputArgs} ` +
        `-filter_complex "${filterComplex}" ` +
        `-map "[v]" -map "[a]" ` +
        `-c:v libx264 -preset ultrafast -crf 23 ` +
        `-c:a aac -b:a 192k ` +
        `-movflags +faststart ` +
        `"${outputPath}"`;

      console.log(`[APPEND] Running FFmpeg command (filter_complex with scaling and padding)...`);
      console.log(`[APPEND] Command: ${command.substring(0, 300)}...`);

      const startTime = Date.now();
      const { stdout, stderr } = await execPromise(command, {
        maxBuffer: 1024 * 1024 * 100,
        timeout: 600000, // 10 minutes timeout
      });
      const duration = ((Date.now() - startTime) / 1000).toFixed(2);
      console.log(`[APPEND] Concatenation completed in ${duration} seconds`);

      if (stdout) {
        console.log(`[APPEND] Concatenation output: ${stdout}`);
      }
      if (stderr) {
        // FFmpeg outputs progress to stderr, so log it
        console.log(`[APPEND] Concatenation stderr: ${stderr.substring(0, 500)}`);
      }

      // Small delay to ensure file is fully written
      await new Promise(resolve => setTimeout(resolve, 500));

      if (!FileUtils.fileExists(outputPath)) {
        throw new Error(`Concatenated video not found at ${outputPath}`);
      }

      // Check file size to ensure it's not empty
      const stats = fs.statSync(outputPath);
      if (stats.size === 0) {
        throw new Error(`Concatenated video is empty (0 bytes)`);
      }

      console.log(`[APPEND] Successfully concatenated ${numVideos} videos`);
      console.log(`[VIDEO PATH] Final concatenated video: ${outputPath}`);
      console.log(`[VIDEO PATH] File size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);
      console.log(`[VIDEO PATH] All input videos:`);
      videoList.forEach((path, index) => {
        const fileStats = fs.statSync(path);
        console.log(`  ${index + 1}. ${path} (${(fileStats.size / 1024 / 1024).toFixed(2)} MB)`);
      });
      return outputPath;
    } catch (error: any) {
      console.error(`[APPEND] Error occurred during concatenation:`, error);
      console.log(`[VIDEO PATH] Error occurred, but keeping files for debugging:`);
      if (introPath) console.log(`  - Intro: ${introPath}`);
      if (mainPath) console.log(`  - Main: ${mainPath}`);
      if (outroPath) console.log(`  - Outro: ${outroPath}`);
      console.log(`  - Output path: ${outputPath}`);
      throw new Error(`Failed to concatenate videos: ${error.message}`);
    }
  }

  /**
   * Upload the final video to S3
   * Public method for parallel processing
   */
  async uploadVideo(
    videoPath: string,
    group: GroupedData
  ): Promise<string> {
    try {
      const filename = `${uuidV4()}-final.mp4`;
      const uploadedUrl = await this.s3.upload(
        videoPath,
        filename,
        this.universityConfig.buckets.LMS_COURSE_VIDEOS
      );

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      // Save to videoTemp with all details
      await videoTempRepository.create({
        courseName: group.courseName,
        unitName: group.unitName,
        topicName: group.topicName,
        url: uploadedUrl,
        originalUrl: group.videoLinks.join(','),
        university: new Types.ObjectId(this.universityId)
      });

      console.log(`Successfully uploaded video: ${uploadedUrl}`);
      return uploadedUrl;
    } catch (error: any) {
      console.error('Error uploading video:', error);
      throw error;
    }
  }

  /**
   * Cleanup temporary files and directories
   */
  private cleanup(): void {
    try {
      // COMMENTED OUT: Keep all videos for debugging
      // if (FileUtils.fileExists(this.tempDir)) {
      //   FileUtils.removeDirectory(this.tempDir);
      //   console.log('Cleaned up temporary files');
      // }
      console.log(`[VIDEO PATH] Temp directory (NOT CLEANED UP): ${this.tempDir}`);
      console.log(`[VIDEO PATH] All videos are preserved in: ${this.tempDir}`);
    } catch (error) {
      console.error('Failed to cleanup temporary files:', error);
    }
  }

  /**
   * Trim a video to a specific duration
   */
  async trimVideo(filePath: string, start: number, duration: number): Promise<string> {
    const outputPath = `${this.tempDir}/trimmed_${uuidV4()}.mp4`;

    try {
      // ffmpeg -ss [start] -i [input] -t [duration] -c:v libx264 -c:a aac [output]
      // Using re-encoding to ensure stability, fast preset
      const command = `ffmpeg -ss ${start} -i "${filePath}" -t ${duration} ` +
        `-c:v libx264 -preset ultrafast -crf 23 ` +
        `-c:a aac -b:a 192k ` +
        `"${outputPath}"`;

      console.log(`Trimming video: ${command}`);

      await execPromise(command, {
        maxBuffer: 1024 * 1024 * 100,
      });

      if (!FileUtils.fileExists(outputPath)) {
        throw new Error(`Trimmed video not found at ${outputPath}`);
      }

      return outputPath;
    } catch (error: any) {
      console.error('Error trimming video:', error);
      throw error;
    }
  }
}

