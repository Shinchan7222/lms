const util = require('util');
const exec = util.promisify(require('child_process').exec);

import { existsSync, readFileSync, writeFileSync } from 'fs';
import { mailer } from '@edorer/mailer';
import { University } from '@edorer/university-data';
import { v4 as uuidv4 } from 'uuid';

export class AwsDocumentsRestorer {
  private readonly batch: number;
  private readonly instance: number;
  private readonly urls: string[];
  private readonly university: University;

  private setUrls: Set<string> = new Set();

  constructor(batch: number = 50, instance: number = 8, urls: string[], university: University) {
    this.batch = batch;
    this.instance = instance;
    this.urls = urls;
    this.university = university;

    this.urls.forEach((url) => {
      this.addUrl(url);
    });
  }

  async restore() {
    await this.restoreDocuments();
  }

  private isValidUrl(url: string): boolean {
    try {
      new URL(url);

      return url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private addUrl(url: string): void {
    if (!this.isValidUrl(url)) return;
    if (this.setUrls.has(url)) return;

    this.setUrls.add(url);
  }

  private async restoreDocuments() {
    let restored = 0;
    let skipped = 0;
    let failed = 0;
    let alreadyInProgress = 0;

    const urls = Array.from(this.setUrls);

    const BATCH_SIZE = this.batch;
    const CONCURRENT_BATCHES = this.instance;
    const BATCH_DELAY_MS = 1000;

    const progressFile = process.env.TEMP_DIR + uuidv4() + '-restore-progress.json';
    let processedUrls = new Set();

    try {
      if (existsSync(progressFile)) {
        const data = JSON.parse(readFileSync(progressFile, 'utf8'));
        processedUrls = new Set(data.processedUrls || []);
        alreadyInProgress = data.alreadyInProgress || 0;
        failed = data.failed || 0;
        restored = data.restored || 0;
        skipped = data.skipped || 0;
      }
    } catch {}

    const urlsToProcess = urls.filter((url) => !processedUrls.has(url));

    for (let i = 0; i < urlsToProcess.length; i += BATCH_SIZE * CONCURRENT_BATCHES) {
      const batchPromises = [];

      for (let j = 0; j < CONCURRENT_BATCHES; j++) {
        const startIdx = i + j * BATCH_SIZE;
        if (startIdx >= urlsToProcess.length) continue;

        const batch = urlsToProcess.slice(startIdx, startIdx + BATCH_SIZE);
        batchPromises.push(this.processBatch(batch));
      }

      try {
        const batchResults = await Promise.all(batchPromises);

        for (const result of batchResults.flat()) {
          processedUrls.add(result.url);

          if (result.success) {
            if (result.alreadyInProgress) {
              alreadyInProgress++;
            } else {
              restored++;
            }
          } else {
            if (result.skipped) {
              skipped++;
            } else {
              failed++;
            }
          }
        }

        const progress = {
          alreadyInProgress,
          failed,
          lastUpdated: new Date().toISOString(),
          processedUrls: Array.from(processedUrls),
          restored,
          skipped
        };

        writeFileSync(progressFile, JSON.stringify(progress, null, 2));

        if (i + BATCH_SIZE * CONCURRENT_BATCHES < urlsToProcess.length) {
          await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY_MS));
        }
      } catch {}
    }

    await this.sendMail(restored, alreadyInProgress, skipped, failed);
  }

  private async processBatch(urls: string[]): Promise<
    Array<{
      alreadyInProgress?: boolean;
      key?: string;
      reason?: string;
      skipped?: boolean;
      success: boolean;
      url: string;
    }>
  > {
    return Promise.all(
      urls.map(async (url, index) => {
        if (!this.isValidUrl(url)) {
          return { success: false, url, skipped: true, reason: 'Invalid URL' };
        }

        const urlObj = new URL(url);
        const paths = urlObj.pathname.split('/').filter(Boolean);

        let key = '';
        if (paths.length === 1) {
          key = paths[0];
        } else if (paths.length === 2) {
          key = paths[1];
        } else {
          paths.splice(0, 1);
          key = paths.join('/');
        }

        if (!key) {
          return { success: false, url, skipped: true, reason: 'Could not extract key from URL' };
        }

        try {
          const escapedKey = key.replace(/'/g, "'\\''");

          const decodedKey = decodeURIComponent(escapedKey);

          let bucketName = url.split('/')[3];

          const command = `aws s3api restore-object \
          --bucket ${bucketName} \
          --key '${decodedKey}' \
          --restore-request '{"Days":7,"GlacierJobParameters":{"Tier":"Standard"}}' \
          --profile parul`;

          console.log(command);

          const { stderr } = await exec(command);

          if (stderr && !stderr.includes('RestoreAlreadyInProgress')) {
            return { success: false, url, key, reason: stderr.trim() };
          }

          const isAlreadyInProgress = stderr && stderr.includes('RestoreAlreadyInProgress');

          return {
            success: true,
            url,
            key,
            alreadyInProgress: isAlreadyInProgress
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : '';
          if (errorMessage.includes('RestoreAlreadyInProgress')) {
            return {
              success: true,
              url,
              key,
              alreadyInProgress: true
            };
          }

          let reason = error instanceof Error ? error.message : 'Unknown error';
          if (errorMessage.includes('NoSuchKey')) {
            reason = 'File not found in S3';
          } else if (errorMessage.includes('AccessDenied')) {
            reason = 'Access denied - check AWS credentials';
          }

          return { success: false, url, key, reason };
        }
      })
    );
  }

  private async sendMail(restored: number, alreadyInProgress: number, skipped: number, failed: number) {
    const mailOptions: any = {};
    mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
    mailOptions.html = `
      <h4>Restoration complete!</h4>
      <ul>
        <li><strong>Restored:</strong> ${restored}</li>
        <li><strong>Failed:</strong> ${failed}</li>
        <li><strong>In progress:</strong> ${alreadyInProgress}</li>
        <li><strong>Skipped:</strong> ${skipped}</li>
        <li><strong>Total:</strong> ${this.setUrls.size}</li>
      </ul>
      
      </br></br></br></br>
      <p>Best regards,</p>
      <p><em>This is an automated message, please do not reply directly to this email.</em></p>
    `;
    mailOptions.subject = `Restoration complete of ${this.university.url}`;
    mailOptions.to = 'abdul@edorer.com';

    mailer.init();

    await mailer.send(mailOptions);
  }
}
