import { ExamProctor, ExamTimeMode, examRepository } from '@edorer/exam-data';
import { FileUtils } from '@edorer/utils';
import { MigrationUtils } from './MigrationUtils';
import { Open } from 'unzipper';
import { UserTypes, userRepository } from '@edorer/user-data';
import { categoryRepository } from '@edorer/category-data';
import { classRepository } from '@edorer/class-data';
import { domainRepository } from '@edorer/domain-data';
import { hash } from 'bcryptjs';
import { questionRepository } from '@edorer/question-data';
import { subjectRepository } from '@edorer/subject-data';
import { writeFileSync } from 'fs';

export class ImportParulDataForMigration {
  private university = '5ffda431be794b82dd8d1281';

  private readonly rootDir: string;

  private readonly zipFile: any;

  constructor(rootDir: string, zipFile: any) {
    this.rootDir = rootDir;
    this.zipFile = zipFile;
  }

  async import() {
    try {
      await this.unzipFolder();

      if (FileUtils.fileExists(this.rootDir + '/admins.json')) {
        await this.importAdmins();
      }

      if (FileUtils.fileExists(this.rootDir + '/users.json')) {
        await this.importUsers();
      }

      if (FileUtils.fileExists(this.rootDir + '/categories.json')) {
        await this.importCategories();
      }

      if (FileUtils.fileExists(this.rootDir + '/subjects.json')) {
        await this.importSubjects();
      }

      if (FileUtils.fileExists(this.rootDir + '/domains.json')) {
        await this.importDomains();
      }

      if (FileUtils.fileExists(this.rootDir + '/classes.json')) {
        await this.importClasses();
      }

      if (FileUtils.fileExists(this.rootDir + '/questions.json')) {
        await this.importQuestions();
      }

      if (FileUtils.fileExists(this.rootDir + '/meazrs.json')) {
        await this.importExams();
      }

      if (FileUtils.fileExists(this.rootDir + '/flows.json')) {
        await this.importFlows();
      }
    } catch (error: any) {
      console.error(error);
      throw new Error(error);
    }
  }

  private async unzipFolder() {
    const directory = await Open.buffer(this.zipFile.buffer);
    const jsonFiles = directory.files.filter((filePath) => filePath.path.includes('.json'));
    for (let jsonFile of jsonFiles) {
      const courseStructureFileBuffer = await jsonFile.buffer();
      const fileName = jsonFile.path.split('/').pop();
      writeFileSync(this.rootDir + '/' + fileName, courseStructureFileBuffer);
    }
  }

  private async importAdmins() {
    const path = this.rootDir + '/admins.json';
    const items = await FileUtils.readLargeData(path);

    for (let item of items) {
      const {
        avatar,
        course,
        email,
        fullname,
        groups: classes,
        institute,
        isBanned: isSuspended,
        isPhoneVerified,
        location,
        mobileNumber,
        name,
        onboardingDone: isOnBoardingDone,
        organization,
        program,
        role,
        specialization,
        token,
        username,
        useTwoFactorAuth
      } = item;

      await userRepository.findOneAndUpdate(
        { email },
        {
          avatar,
          classes,
          courses: [course],
          deleted: false,
          email,
          forcedAvatarUpload: MigrationUtils.formatUserType(role) !== UserTypes.STUDENT,
          institute,
          isActive: true,
          isEdorer: false,
          isEmailVerified: true,
          isOnBoardingDone,
          isPhoneVerified,
          isRevoked: false,
          isSuspended,
          location: location || 'India',
          name: MigrationUtils.formatUserName(name, fullname, username),
          organization,
          password: await hash('123456', 10),
          passwordManuallyChanged: MigrationUtils.formatUserType(role) !== UserTypes.STUDENT,
          phone: mobileNumber || '',
          program,
          role: '62c6d0c82a52e189aca0034a',
          specialization,
          token,
          type: MigrationUtils.formatUserType(role),
          university: this.university,
          useTwoFactorAuth
        },
        { multi: false, new: true, upsert: true }
      );
    }
  }

  private async importUsers() {
    const path = this.rootDir + '/users.json';
    const items = await FileUtils.readLargeData(path);

    const emailMap = {};
    for (let item of items) {
      const email = item.email.toString().toLowerCase();

      if (email in emailMap) {
        const count = emailMap[email] + 1;
        emailMap[email] = count;
        item.email = 'copy-' + count + '-' + email;
      } else {
        emailMap[email] = 0;
      }
    }

    const emails = items.map((item) => item.email);
    const oldUsersWithEmails = await userRepository
      .find({ email: { $in: emails } })
      .select('email')
      .lean();
    const oldUserEmails = oldUsersWithEmails.map((item) => item.email.toString().toLowerCase());

    const usersFilteredByEmails = [];
    for (let item of items) {
      if (oldUserEmails.indexOf(item.email.toString().toLowerCase()) === -1) {
        usersFilteredByEmails.push(item);
      }
    }
    console.warn(usersFilteredByEmails.length);

    const userIds = items.map((item) => item._id.toString());
    const oldUsersWithIds = await userRepository
      .find({ _id: { $in: userIds } })
      .select('_id')
      .lean();
    const oldUserIds = oldUsersWithIds.map((item) => item._id.toString());

    const usersToBeAdded = [];
    for (let item of usersFilteredByEmails) {
      if (oldUserIds.indexOf(item._id.toString()) === -1) {
        usersToBeAdded.push(item);
      }
    }
    console.warn(usersToBeAdded.length);

    const users = [];

    for (let item of usersToBeAdded) {
      const {
        _id,
        avatar,
        course,
        email,
        fullname,
        groups: classes,
        institute,
        isBanned: isSuspended,
        isPhoneVerified,
        location,
        mobileNumber,
        name,
        onboardingDone: isOnBoardingDone,
        organization,
        program,
        role,
        specialization,
        token,
        username,
        useTwoFactorAuth
      } = item;

      const user = {
        _id,
        avatar,
        classes,
        courses: [course],
        deleted: false,
        email,
        forcedAvatarUpload: MigrationUtils.formatUserType(role) !== UserTypes.STUDENT,
        institute,
        isActive: true,
        isEdorer: false,
        isEmailVerified: true,
        isOnBoardingDone,
        isPhoneVerified,
        isRevoked: false,
        isSuspended,
        location: location || 'India',
        name: MigrationUtils.formatUserName(name, fullname, username),
        organization,
        password: await hash('123456', 10),
        passwordManuallyChanged: MigrationUtils.formatUserType(role) !== UserTypes.STUDENT,
        phone: mobileNumber || '',
        program,
        specialization,
        token,
        type: MigrationUtils.formatUserType(role),
        university: this.university,
        useTwoFactorAuth
      };

      users.push(user);
    }

    await MigrationUtils.writeData('users', users, userRepository);
  }

  private async importCategories() {
    const path = this.rootDir + '/categories.json';
    const items = await FileUtils.readLargeData(path);
    const categoryIds = items.map((item) => item._id);
    const oldCategoriesWithIds = await categoryRepository
      .find({ _id: { $in: categoryIds } })
      .select('_id')
      .lean();
    const oldCategoryIds = oldCategoriesWithIds.map((item) => item._id.toString());

    console.warn('categories'.toUpperCase(), items.length);

    const categories = [];

    for (let item of items) {
      if (oldCategoryIds.indexOf(item._id.toString()) === -1) {
        const category = {
          _id: item._id,
          name: item && item.name ? item.name : 'without name',
          university: this.university
        };

        categories.push(category);
      }
    }

    await MigrationUtils.writeData('categories', categories, categoryRepository);
  }

  private async importSubjects() {
    const path = this.rootDir + '/subjects.json';
    const items = await FileUtils.readLargeData(path);
    const subjectIds = items.map((item) => item._id);
    const oldSubjectsWithIds = await subjectRepository
      .find({ _id: { $in: subjectIds } })
      .select('_id')
      .lean();
    const oldSubjectIds = oldSubjectsWithIds.map((item) => item._id.toString());

    const subjects = [];

    for (let item of items) {
      if (oldSubjectIds.indexOf(item._id.toString()) === -1) {
        const subject = {
          _id: item._id,
          name: item && item.name ? item.name : 'without name',
          university: this.university
        };

        subjects.push(subject);
      }
    }

    await MigrationUtils.writeData('subjects', subjects, subjectRepository);
  }

  private async importDomains() {
    const path = this.rootDir + '/domains.json';
    const items = await FileUtils.readLargeData(path);
    const domainIds = items.map((item) => item._id);
    const oldDomainsWithIds = await domainRepository
      .find({ _id: { $in: domainIds } })
      .select('_id')
      .lean();
    const oldDomainIds = oldDomainsWithIds.map((item) => item._id.toString());

    console.warn('domains'.toUpperCase(), items.length);

    const domains = [];

    for (let item of items) {
      if (oldDomainIds.indexOf(item._id.toString()) === -1) {
        const domain = {
          _id: item._id,
          name: item && item.name ? item.name : 'without name',
          university: this.university
        };

        if (!item.name) {
          console.warn(JSON.stringify(item));
        }

        domains.push(domain);
      }
    }

    await MigrationUtils.writeData('domains', domains, domainRepository);
  }

  private async importClasses() {
    const path = this.rootDir + '/classes.json';
    const items = await FileUtils.readLargeData(path);
    const classIds = items.map((item) => item._id);
    const oldClassesWithIds = await classRepository
      .find({ _id: { $in: classIds } })
      .select('_id')
      .lean();
    const oldClassIds = oldClassesWithIds.map((item) => item._id.toString());

    console.warn('classes'.toUpperCase(), items.length);

    const classes = [];

    for (let item of items) {
      if (oldClassIds.indexOf(item._id.toString()) === -1) {
        const classData = {
          _id: item._id,
          name: item && item.name ? item.name : 'without name',
          university: this.university
        };

        classes.push(classData);
      }
    }

    await MigrationUtils.writeData('classes', classes, classRepository);
  }

  private async importQuestions() {
    const path = this.rootDir + '/questions.json';
    const items = await FileUtils.readLargeData(path);
    const ids = items.map((item) => item._id);
    await MigrationUtils.deleteData('questions', ids, this.university, questionRepository);

    const questions = [];

    for (let item of items) {
      const {
        _id,
        allowedLanguages,
        answers,
        category,
        content,
        difficultyLevel,
        maxTime: time = 60,
        maxWords,
        owner,
        points,
        randomizeOptions = false,
        type
      } = item;

      const question = {
        _id,
        allowedLanguages,
        alternatives: [],
        category,
        content,
        difficulty: MigrationUtils.formatDifficulty(difficultyLevel),
        isCaseInsensitive: false,
        isMigrated: true,
        lecture: null,
        options: MigrationUtils.formatAnswers(type, answers),
        owner,
        points,
        randomizeOptions,
        time,
        type: MigrationUtils.formatType(type),
        university: this.university,
        wordCount: { enabled: maxWords && maxWords > 10, limit: maxWords || 50 }
      };
      question.content = item.content;
      question.owner = owner;

      questions.push(question);
    }

    await MigrationUtils.writeData('questions', questions, questionRepository);
  }

  private async importExams() {
    const path = this.rootDir + '/meazrs.json';
    const items = await FileUtils.readLargeData(path);
    const ids = items.map((item) => item._id.toString());

    console.warn('EXAM IDS', ids.length);

    const examsFound = await examRepository
      .find({ _id: { $in: ids } })
      .select('_id')
      .lean();
    const examFoundIds = examsFound.map((item) => item._id.toString());
    console.warn('EXAM FOUND IDS', examFoundIds.length);

    const examsToBeAdded = [];
    for (let item of items) {
      if (examFoundIds.indexOf(item._id.toString()) === -1) {
        examsToBeAdded.push(item);
      }
    }
    console.warn('EXAMS TO BE ADDED', examsToBeAdded.length);

    const exams = [];

    for (let item of examsToBeAdded) {
      const {
        _id,
        accessibility,
        description,
        editors = [],
        fetch,
        groupQuestions,
        instruction,
        navigation,
        noisePopupEnabled = false,
        noisePopupDBFrequency = 10,
        noisePopupFrequency = 10,
        owner,
        price,
        shuffleQuestions = false,
        shuffleType,
        skill,
        timing,
        title,
        totalMarks = { auto: true, value: 1 },
        totalTime = { value: 0 },
        shields
      } = item;

      const formattedQuestions = MigrationUtils.sanitizeQuestions(groupQuestions);
      await questionRepository.update({ _id: { $in: formattedQuestions } }, { exam: _id }, { multi: true });

      const exam = {
        _id,
        applicants: [],
        autoCalculatePoint: totalMarks && totalMarks.auto ? totalMarks.auto : false,
        autoScheduler: { enabled: false },
        browserLock: {
          enabled: shields && shields.lockAndTrack ? MigrationUtils.shieldValue(shields.lockAndTrack) : false,
          debar: {
            // tslint:disable-next-line:max-line-length
            enabled: shields && shields.lockAndTrack && shields.lockAndTrack.deBarEnabled ? shields.lockAndTrack.deBarEnabled : false,
            // tslint:disable-next-line:max-line-length
            maxDeviation: shields && shields.lockAndTrack && shields.lockAndTrack.maxDeviation ? shields.lockAndTrack.maxDeviation : 10,
            // tslint:disable-next-line:max-line-length
            maxViolation: shields && shields.lockAndTrack && shields.lockAndTrack.maxViolation ? shields.lockAndTrack.maxViolation : 10
          }
        },
        commonAccessEnabled: false,
        completionMail: { enabled: false },
        createdAt: new Date(),
        description: description || title,
        deviceRestriction: null,
        domain: skill ? skill : null,
        dynamicForm: null,
        editors,
        enableAnswerInPaper: false,
        fetch: await MigrationUtils.formatFetch(fetch, this.university),
        impersonationCheck: {
          enabled: false,
          automatic: false,
          manual: false
        },
        instruction: instruction || title,
        monitoring: {
          deviceSelectionEnabled: true,
          enabled: shields && shields.vidProctor ? MigrationUtils.shieldValue(shields.vidProctor) : false,
          liveChat: false,
          liveExamControl: false,
          type: shields && shields.vidProctor ? MigrationUtils.formatMonitorType(shields.vidProctor) : ExamProctor.VIDEO_PROCTOR,
          debar: shields && shields.vidProctor && shields.vidProctor.deBarEnabled ? shields.vidProctor.deBarEnabled : false,
          primary: { device: true, person: true },
          noise: {
            enabled: noisePopupEnabled,
            decibel: noisePopupDBFrequency,
            seconds: noisePopupFrequency
          },
          secondary: { enabled: shields && shields.doubleProctor ? MigrationUtils.shieldValue(shields.doubleProctor) : false }
        },
        navigation: {
          enabled: true,
          categoryLabel: navigation && navigation.categoryLabel ? navigation.categoryLabel : false,
          categoryNavigation: navigation && navigation.categoryNavigator ? navigation.categoryNavigator : false,
          pointsLabel: navigation && navigation.pointsLabel ? navigation.pointsLabel : false,
          questionNavigation: navigation && navigation.questionNavigator ? navigation.questionNavigator : false,
          questionPositionLabel: navigation && navigation.questionLabel ? navigation.questionLabel : false,
          showNegativePoints: navigation && navigation.negativePoints ? navigation.negativePoints : false
        },
        owner,
        paymentGateway: null,
        preRequisiteEnabled: false,
        price: price || 0,
        priceEnabled: !!(price && price > 0),
        questions: formattedQuestions,
        randomisation: {
          enabled: shuffleQuestions,
          type: MigrationUtils.formatRandomisation(shuffleType)
        },
        secure: accessibility && accessibility !== 'Public',
        students: [],
        subDomain: null,
        timeMode: timing && timing === 'Stand Alone Time' ? ExamTimeMode.STAND_ALONE_TIME : ExamTimeMode.EXAMINATION_TIME,
        title,
        totalMarks: totalMarks && totalMarks.value ? totalMarks.value : 0,
        totalTime: totalTime && totalTime.value ? totalTime.value : 0,
        university: this.university
      };

      exams.push(exam);
    }

    await MigrationUtils.writeData('exams', exams, examRepository);
  }

  private async importFlows() {
    const path = this.rootDir + '/flows.json';
    const items = await FileUtils.readLargeData(path);
    const ids = items.map((item) => item._id.toString());

    console.warn('FLOW IDS', ids.length);

    const examsFound = await examRepository
      .find({ _id: { $in: ids } })
      .select('_id')
      .lean();
    const examFoundIds = examsFound.map((item) => item._id.toString());
    console.warn('FLOW FOUND IDS', examFoundIds.length);

    const examsToBeAdded = [];
    for (let item of items) {
      if (examFoundIds.indexOf(item._id.toString()) === -1) {
        examsToBeAdded.push(item);
      }
    }
    console.warn('FLOWS TO BE ADDED', examsToBeAdded.length);

    const exams = [];

    for (let item of examsToBeAdded) {
      const {
        _id,
        accessibility,
        description,
        editors = [],
        fetch,
        groupQuestions,
        instruction,
        navigation,
        noisePopupEnabled = false,
        noisePopupDBFrequency = 10,
        noisePopupFrequency = 10,
        owner,
        price,
        shuffleQuestions = false,
        shuffleType,
        skill,
        timing,
        title,
        totalMarks = { auto: true, value: 1 },
        totalTime = { value: 0 },
        shields
      } = item;

      const formattedQuestions = MigrationUtils.sanitizeQuestions(groupQuestions);
      await questionRepository.update({ _id: { $in: formattedQuestions } }, { exam: _id }, { multi: true });

      const exam = {
        _id,
        applicants: [],
        autoCalculatePoint: totalMarks && totalMarks.auto ? totalMarks.auto : false,
        autoScheduler: { enabled: false },
        browserLock: {
          enabled: shields && shields.lockAndTrack ? MigrationUtils.shieldValue(shields.lockAndTrack) : false,
          debar: {
            // tslint:disable-next-line:max-line-length
            enabled: shields && shields.lockAndTrack && shields.lockAndTrack.deBarEnabled ? shields.lockAndTrack.deBarEnabled : false,
            // tslint:disable-next-line:max-line-length
            maxDeviation: shields && shields.lockAndTrack && shields.lockAndTrack.maxDeviation ? shields.lockAndTrack.maxDeviation : 10,
            // tslint:disable-next-line:max-line-length
            maxViolation: shields && shields.lockAndTrack && shields.lockAndTrack.maxViolation ? shields.lockAndTrack.maxViolation : 10
          }
        },
        commonAccessEnabled: false,
        completionMail: { enabled: false },
        createdAt: new Date(),
        description: description || title,
        deviceRestriction: null,
        domain: skill ? skill : null,
        dynamicForm: null,
        editors,
        enableAnswerInPaper: false,
        fetch: await MigrationUtils.formatFetch(fetch, this.university),
        impersonationCheck: {
          enabled: false,
          automatic: false,
          manual: false
        },
        instruction: instruction || title,
        monitoring: {
          deviceSelectionEnabled: true,
          enabled: shields && shields.vidProctor ? MigrationUtils.shieldValue(shields.vidProctor) : false,
          liveChat: false,
          liveExamControl: false,
          type: shields && shields.vidProctor ? MigrationUtils.formatMonitorType(shields.vidProctor) : ExamProctor.VIDEO_PROCTOR,
          debar: shields && shields.vidProctor && shields.vidProctor.deBarEnabled ? shields.vidProctor.deBarEnabled : false,
          primary: { device: true, person: true },
          noise: {
            enabled: noisePopupEnabled,
            decibel: noisePopupDBFrequency,
            seconds: noisePopupFrequency
          },
          secondary: { enabled: shields && shields.doubleProctor ? MigrationUtils.shieldValue(shields.doubleProctor) : false }
        },
        navigation: {
          enabled: true,
          categoryLabel: navigation && navigation.categoryLabel ? navigation.categoryLabel : false,
          categoryNavigation: navigation && navigation.categoryNavigator ? navigation.categoryNavigator : false,
          pointsLabel: navigation && navigation.pointsLabel ? navigation.pointsLabel : false,
          questionNavigation: navigation && navigation.questionNavigator ? navigation.questionNavigator : false,
          questionPositionLabel: navigation && navigation.questionLabel ? navigation.questionLabel : false,
          showNegativePoints: navigation && navigation.negativePoints ? navigation.negativePoints : false
        },
        owner,
        paymentGateway: null,
        preRequisiteEnabled: false,
        price: price || 0,
        priceEnabled: !!(price && price > 0),
        questions: formattedQuestions,
        randomisation: {
          enabled: shuffleQuestions,
          type: MigrationUtils.formatRandomisation(shuffleType)
        },
        secure: accessibility && accessibility !== 'Public',
        students: [],
        subDomain: null,
        timeMode: timing && timing === 'Stand Alone Time' ? ExamTimeMode.STAND_ALONE_TIME : ExamTimeMode.EXAMINATION_TIME,
        title,
        totalMarks: totalMarks && totalMarks.value ? totalMarks.value : 0,
        totalTime: totalTime && totalTime.value ? totalTime.value : 0,
        university: this.university
      };

      exams.push(exam);
    }

    await MigrationUtils.writeData('flows', exams, examRepository);
  }
}
