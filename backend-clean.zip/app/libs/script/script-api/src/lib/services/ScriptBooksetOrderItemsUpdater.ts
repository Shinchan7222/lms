import { BooksetTrack, booksetTrackRepository } from '@edorer/bookset-track-data';
import { BookSetOrderCanceller } from '@edorer/bookset-track-api';
import { BookSetReorderer } from '@edorer/bookset-track-api';
import { University } from '@edorer/university-data';
import moment = require('moment');

interface UpdateResult {
  failed: Array<{ orderId: string; reason: string; trackId: string }>;
  processed: number;
  skipped: number;
  updated: number;
}

export class ScriptBooksetOrderItemsUpdater {
  private tracks: BooksetTrack[] = [];

  private readonly university: University;

  constructor(university: University) {
    this.university = university;
  }

  async update(): Promise<UpdateResult> {
    await this.fetchTracks();

    const result: UpdateResult = {
      failed: [],
      processed: this.tracks.length,
      skipped: 0,
      updated: 0
    };

    for (const track of this.tracks) {
      try {
        const canceller = new BookSetOrderCanceller([String(track._id)], this.university);
        await canceller.cancel();

        const reorderer = new BookSetReorderer(String(track._id), this.university);
        await reorderer.create();

        result.updated++;
      } catch (error: any) {
        result.failed.push({
          orderId: String(track.orderId || ''),
          reason: error?.message || 'Could not update order item',
          trackId: String(track._id)
        });
      }
    }

    return result;
  }

  private async fetchTracks() {
    this.tracks = await booksetTrackRepository
      .find({
        bookset: { $in: ['69bb9578797f240014de1a0b', '69bb95d98b39f6000d35e027', '69bb9645797f240014de2163', '69bb96cb1bd9870022e1a0c1'] },
        createdAt: { $gte: moment().subtract(1, 'month').startOf('month').toDate(), $lte: moment().subtract(1, 'month').endOf('month').toDate() },
        status: 'NEW',
        orderId: { $exists: true, $ne: '' },
        university: this.university._id
      })
      .limit(5)
      .sort({ createdAt: -1 })
      .lean();
  }
}
