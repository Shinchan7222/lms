import { Assets, assetsRepository } from '@edorer/assets-data';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { mailer } from '@edorer/mailer';
import { UniversityConfiguration } from '@edorer/university-data';

export class TransferAssets {
  private readonly assets: Assets[] = [];
  private readonly universityConfig: UniversityConfiguration;

  private readonly BATCH_SIZE = 10;
  private readonly MAX_RETRIES = 3;

  constructor(assets: Assets[] = [], universityConfig: UniversityConfiguration) {
    this.assets = assets;
    this.universityConfig = universityConfig;
  }

  private isValidUrl(url: string | undefined): boolean {
    if (!url) return false;
    try {
      new URL(url);

      return url.startsWith('https://minio.paruluniversity.ac.in') || url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private async processUrl(url: string | undefined, retries = 0): Promise<string | undefined> {
    let downloadedUrl: string | undefined;

    try {
      if (!this.isValidUrl(url)) return undefined;

      const downloader = new Downloader(url);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      const s3 = new S3University(this.universityConfig, true);
      const uploadedUrl = await s3.uploadBuffer(fileContent, url.split('/').pop(), this.universityConfig.buckets.LMS_COURSE_VIDEOS);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      return uploadedUrl;
    } catch (error) {
      console.error(error);
      if (retries < this.MAX_RETRIES) {
        console.warn(`Retry ${retries + 1} for asset ${url}`);
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retries + 1)));
        return this.processUrl(url, retries + 1);
      }
      console.error(`Failed to process asset after ${this.MAX_RETRIES} retries:`, error);
      return undefined;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch (error) {
          console.error('Failed to cleanup temporary file:', error);
        }
      }
    }
  }

  private async processAsset(asset: Assets): Promise<void> {
    try {
      const newIntro = await this.processUrl(asset.url, this.universityConfig.buckets.LMS_COURSE_VIDEOS);

      const updatedAsset: Partial<Assets> = { isAssetsShifted: true };

      if (newIntro) {
        updatedAsset.url = newIntro;
        updatedAsset.previousUrl = asset.url;
      }

      await assetsRepository.update({ _id: asset._id }, { $set: { ...updatedAsset } });
    } catch (error) {
      console.error(`Error processing asset ${asset._id}:`, error);
    }
  }

  private async processBatch(batch: Assets[]) {
    await Promise.all(batch.map((asset) => this.processAsset(asset)));
  }

  public async transfer() {
    if (this.assets.length === 0) return;

    for (let i = 0; i < this.assets.length; i += this.BATCH_SIZE) {
      const batch = this.assets.slice(i, i + this.BATCH_SIZE);
      try {
        await this.processBatch(batch);
      } catch (error) {
        console.error(`Error processing batch starting at index ${i}:`, error);
      }
    }

    await this.sendMail();
  }

  private async sendMail() {
    try {
      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
      mailOptions.html = `
        <h4>Assets transferred!</h4>
        </br></br></br></br>
        <p>Best regards,</p>
        <p><em>This is an automated message, please do not reply directly to this email.</em></p>
      `;
      mailOptions.subject = `Restoration complete`;
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();

      await mailer.send(mailOptions);
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }
}
