import { Workbook } from 'exceljs';
import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { Types } from 'mongoose';

interface ExcelRow {
    'Course Name': string;
    'Program Name'?: string;
    'Unit Name': string;
    'Topic Name': string;
    'Video Link': string;
}

interface RemovedLecture {
    chapterTitle: string;
    lectureTitle: string;
    lectureId: string;
}

interface CourseDetail {
    courseName: string;
    courseId: string;
    chaptersProcessed: number;
    lecturesRemoved: number;
    removedLectures: RemovedLecture[];
}

interface RemovalResult {
    success: boolean;
    totalCoursesProcessed: number;
    totalChaptersProcessed: number;
    totalLecturesRemoved: number;
    courseDetails: CourseDetail[];
}

export class DuplicateRemover {
    private readonly excelFile: any;
    private readonly universityId: string;
    private readonly tabName: string;

    constructor(excelFile: any, universityId: string, tabName: string) {
        this.excelFile = excelFile;
        this.universityId = universityId;
        this.tabName = tabName;
    }

    /**
     * Main process method to remove duplicate lectures
     */
    async process(): Promise<RemovalResult> {
        try {
            // Parse Excel file to get course data with program names
            const courseData = await this.parseExcel();

            // Find courses in database
            const courses = await this.findCoursesFromExcel(courseData);

            // Remove duplicates from each course
            const result = await this.removeDuplicateLectures(courses);

            return result;
        } catch (error: any) {
            throw new Error(`Failed to process Excel file: ${error.message}`);
        }
    }

    /**
     * Parse Excel file and extract course data with program names
     */
    private async parseExcel(): Promise<Map<string, string | undefined>> {
        const workbook = new Workbook();
        await workbook.xlsx.load(this.excelFile.buffer);

        const worksheet = workbook.getWorksheet(1);
        if (!worksheet) {
            throw new Error('Excel file is empty or invalid');
        }

        const courseData = new Map<string, string | undefined>();
        let headers: { [key: string]: number } = {};
        let headerRowFound = false;

        worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
            if (rowNumber === 1) {
                row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
                    const headerValue = cell.value?.toString() || '';
                    headers[headerValue] = colNumber;
                });
                headerRowFound = true;

                // Validate required columns
                const requiredColumns = ['Course Name'];
                for (const col of requiredColumns) {
                    if (!(col in headers)) {
                        throw new Error(`Missing required column: ${col}`);
                    }
                }
                return;
            }

            if (!headerRowFound) {
                return;
            }

            // Extract course name and program name
            const courseNameCell = row.getCell(headers['Course Name']);
            const courseName = courseNameCell.value?.toString() || '';

            let programName: string | undefined;
            if (headers['Program Name']) {
                const programNameCell = row.getCell(headers['Program Name']);
                programName = programNameCell.value?.toString();
            }

            if (courseName && courseName.trim()) {
                courseData.set(courseName.trim(), programName?.trim());
            }
        });

        if (courseData.size === 0) {
            throw new Error('No course names found in Excel file');
        }

        return courseData;
    }

    /**
     * Find courses in database based on Excel course data
     */
    private async findCoursesFromExcel(courseData: Map<string, string | undefined>): Promise<any[]> {
        const courses: any[] = [];

        for (const [courseName, programName] of courseData) {
            // Format course title based on program name
            let courseTitle: string;
            if (programName && programName.toUpperCase() === 'MBA') {
                courseTitle = `MBA_${courseName}`;
            } else if (programName) {
                courseTitle = `${programName} - ${courseName}`;
            } else {
                courseTitle = courseName;
            }

            // Try to find course with the formatted title
            const course = await courseRepository.findOne({
                title: courseTitle,
                university: this.universityId,
                deleted: { $ne: true }
            }).lean();

            if (course) {
                courses.push(course);
                console.log(`Found course: ${course.title} (ID: ${course._id})`);
            } else {
                console.warn(`Course not found: ${courseTitle}`);
            }
        }

        if (courses.length === 0) {
            throw new Error('No matching courses found in database');
        }

        return courses;
    }

    /**
     * Remove duplicate lectures from all courses
     */
    private async removeDuplicateLectures(courses: any[]): Promise<RemovalResult> {
        const courseDetails: CourseDetail[] = [];
        let totalChaptersProcessed = 0;
        let totalLecturesRemoved = 0;

        for (const course of courses) {
            const removedLectures: RemovedLecture[] = [];
            let chaptersProcessed = 0;

            // Get all chapters for this course
            const chapters = await chapterRepository.find({
                course: course._id,
                deleted: { $ne: true }
            }).lean();

            for (const chapter of chapters) {
                if (!chapter.lectures || chapter.lectures.length === 0) {
                    continue;
                }

                chaptersProcessed++;
                totalChaptersProcessed++;

                // Get all lectures for this chapter
                const lectures = await lectureRepository.find({
                    _id: { $in: chapter.lectures },
                    deleted: { $ne: true }
                }).lean();

                // Find duplicates
                const duplicatesToRemove = this.findDuplicatesInChapter(lectures);

                if (duplicatesToRemove.length > 0) {
                    // Remove duplicates from chapter's lectures array
                    const lectureIdsToKeep = chapter.lectures.filter(
                        (lectureId: any) => !duplicatesToRemove.some(dup => dup._id.toString() === lectureId.toString())
                    );

                    await chapterRepository.findOneAndUpdate(
                        { _id: chapter._id },
                        { $set: { lectures: lectureIdsToKeep } },
                        { multi: false }
                    );

                    // Delete duplicate lecture documents
                    for (const duplicate of duplicatesToRemove) {
                        await lectureRepository.findOneAndUpdate(
                            { _id: duplicate._id },
                            { $set: { deleted: true } },
                            { multi: false }
                        );
                    }

                    // Record removed lectures
                    for (const duplicate of duplicatesToRemove) {
                        removedLectures.push({
                            chapterTitle: chapter.title,
                            lectureTitle: duplicate.title,
                            lectureId: duplicate._id.toString()
                        });
                        totalLecturesRemoved++;
                    }

                    console.log(`Removed ${duplicatesToRemove.length} duplicate(s) from chapter "${chapter.title}" in course "${course.title}"`);
                }

                // Reorder lectures: Assignment should be second-to-last, Question should be last
                const remainingLectures = lectures.filter(
                    (lecture: any) => !duplicatesToRemove.some(dup => dup._id.toString() === lecture._id.toString())
                );

                const reorderedLectureIds = this.reorderLectures(remainingLectures);

                // Update chapter with reordered lectures if order changed
                if (reorderedLectureIds.length > 0) {
                    await chapterRepository.findOneAndUpdate(
                        { _id: chapter._id },
                        { $set: { lectures: reorderedLectureIds } },
                        { multi: false }
                    );
                    console.log(`Reordered lectures in chapter "${chapter.title}"`);
                }
            }

            courseDetails.push({
                courseName: course.title,
                courseId: course._id.toString(),
                chaptersProcessed,
                lecturesRemoved: removedLectures.length,
                removedLectures
            });
        }

        return {
            success: true,
            totalCoursesProcessed: courses.length,
            totalChaptersProcessed,
            totalLecturesRemoved,
            courseDetails
        };
    }

    /**
   * Find duplicate lectures within a chapter
   * Returns array of lectures to remove (keeps lecture with highest TOPIC number)
   */
    private findDuplicatesInChapter(lectures: any[]): any[] {
        const duplicatesToRemove: any[] = [];
        const titleGroups = new Map<string, any[]>();

        // Group lectures by normalized title
        for (const lecture of lectures) {
            const title = lecture.title.trim();
            const normalizedTitle = this.normalizeLectureTitle(title);

            if (!titleGroups.has(normalizedTitle)) {
                titleGroups.set(normalizedTitle, []);
            }
            titleGroups.get(normalizedTitle)!.push(lecture);
        }

        // For each group with duplicates, keep the one with highest TOPIC number
        for (const [normalizedTitle, group] of titleGroups) {
            if (group.length > 1) {
                // Sort by TOPIC number (descending), so highest number is first
                group.sort((a, b) => {
                    const topicNumA = this.extractTopicNumber(a.title);
                    const topicNumB = this.extractTopicNumber(b.title);
                    return topicNumB - topicNumA; // Descending order
                });

                // Keep the first one (highest TOPIC number), remove the rest
                const toKeep = group[0];
                const toRemove = group.slice(1);

                for (const lecture of toRemove) {
                    duplicatesToRemove.push(lecture);
                    console.log(`  Found duplicate: "${lecture.title}" (ID: ${lecture._id}) - will keep "${toKeep.title}" instead`);
                }
            }
        }

        return duplicatesToRemove;
    }

    /**
     * Extract TOPIC number from lecture title
     * Returns 0 if no TOPIC number found
     */
    private extractTopicNumber(title: string): number {
        const match = title.match(/^TOPIC\s+(\d+)/i);
        return match ? parseInt(match[1], 10) : 0;
    }

    /**
     * Reorder lectures so Assignment is second-to-last and Question is last
     * Returns array of lecture IDs in the correct order
     */
    private reorderLectures(lectures: any[]): any[] {
        if (lectures.length === 0) {
            return [];
        }

        // Separate lectures into categories
        const regularLectures: any[] = [];
        const assignmentLectures: any[] = [];
        const questionLectures: any[] = [];

        for (const lecture of lectures) {
            const normalizedTitle = lecture.title.trim().toLowerCase();

            if (normalizedTitle.includes('assignment')) {
                assignmentLectures.push(lecture);
            } else if (normalizedTitle.includes('question')) {
                questionLectures.push(lecture);
            } else {
                regularLectures.push(lecture);
            }
        }

        // Build final order: regular lectures, then Assignment, then Question
        const orderedLectures: any[] = [
            ...regularLectures,
            ...assignmentLectures,
            ...questionLectures
        ];

        // Return array of lecture IDs in the new order
        return orderedLectures.map(lecture => lecture._id);
    }

    /**
     * Normalize lecture title for comparison
     * Removes "TOPIC X - " prefix and trims whitespace
     */
    private normalizeLectureTitle(title: string): string {
        // Remove "TOPIC X - " prefix (where X is a number)
        const withoutTopicPrefix = title.replace(/^TOPIC\s+\d+\s*-\s*/i, '');

        // Trim and convert to lowercase for case-insensitive comparison
        return withoutTopicPrefix.trim().toLowerCase();
    }
}
