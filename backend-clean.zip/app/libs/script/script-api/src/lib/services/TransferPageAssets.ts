import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { mailer } from '@edorer/mailer';
import { Page, pageRepository } from '@edorer/page-builder-data';
import { UniversityConfiguration } from '@edorer/university-data';

export class TransferPageAssets {
  private readonly pages: Page[] = [];
  private readonly universityConfig: UniversityConfiguration;
  private readonly results: {
    success: number;
    failed: number;
    urls: { original: string; new: string }[];
  };

  private readonly BATCH_SIZE = 10;
  private readonly MAX_RETRIES = 3;

  constructor(pages: Page[] = [], universityConfig: UniversityConfiguration) {
    this.pages = pages;
    this.universityConfig = universityConfig;
    this.results = {
      success: 0,
      failed: 0,
      urls: []
    };
  }

  private isValidUrl(url: string | undefined): boolean {
    if (!url) return false;
    try {
      new URL(url);
      return url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private async processUrl(url: string | undefined, bucketName: any, retries = 0): Promise<string | undefined> {
    let downloadedUrl: string | undefined;

    try {
      if (!this.isValidUrl(url)) return undefined;

      // Check if this URL has already been processed
      const existingResult = this.results.urls.find((result) => result.original === url);
      if (existingResult) {
        return existingResult.new;
      }

      const downloader = new Downloader(url);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      const s3 = new S3University(this.universityConfig, true);
      const filename = url.split('/').pop() || `file-${Date.now()}`;
      const uploadedUrl = await s3.uploadBuffer(fileContent, filename, bucketName);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      this.results.success++;
      this.results.urls.push({ original: url, new: uploadedUrl });

      return uploadedUrl;
    } catch (error) {
      console.error(`Error processing URL ${url}:`, error);
      if (retries < this.MAX_RETRIES) {
        console.warn(`Retry ${retries + 1} for asset ${url}`);
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retries + 1)));
        return this.processUrl(url, bucketName, retries + 1);
      }
      console.error(`Failed to process asset after ${this.MAX_RETRIES} retries:`, error);
      this.results.failed++;
      return undefined;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch (error) {
          console.error('Failed to cleanup temporary file:', error);
        }
      }
    }
  }

  private async processPage(page: Page): Promise<void> {
    try {
      const updates: any = { isAssetsShifted: true };
      let assetsTransferred = false;

      // Process page contents for embedded assets
      if (page.contents && Array.isArray(page.contents)) {
        const updatedContents = await this.processPageContents(page.contents);
        if (updatedContents) {
          updates.contents = updatedContents;
          assetsTransferred = true;
        }
      }

      // Only update if any assets were transferred
      if (assetsTransferred) {
        await pageRepository.update({ _id: page._id }, { $set: updates });
        console.log(`✅ Successfully processed page: ${page._id} (${page.title})`);
      } else {
        console.log(`⚠️ No valid assets found for page: ${page._id} (${page.title})`);
      }
    } catch (error) {
      console.error(`❌ Error processing page ${page._id}:`, error);
    }
  }

  private async processPageContents(contents: Array<any>): Promise<Array<any> | undefined> {
    try {
      const updatedContents = [...contents];
      let contentModified = false;

      for (let i = 0; i < updatedContents.length; i++) {
        const content = updatedContents[i];

        // Process preview in each content item
        if (content.preview) {
          const newPreview = await this.processUrl(content.preview, this.universityConfig.buckets.ASSETS);
          if (newPreview) {
            content.previousPreview = content.preview;
            content.preview = newPreview;
            contentModified = true;
          }
        }

        // Process content details
        if (content.details) {
          // Handle section image in details
          if (content.details.sectionImage) {
            const newImage = await this.processUrl(content.details.sectionImage, this.universityConfig.buckets.ASSETS);
            if (newImage) {
              content.details.previousSectionImage = content.details.sectionImage;
              content.details.sectionImage = newImage;
              contentModified = true;
            }
          }

          // Handle section images array in details
          if (content.details.sectionImages && Array.isArray(content.details.sectionImages)) {
            const updatedImages = [];
            let imagesModified = false;

            for (let j = 0; j < content.details.sectionImages.length; j++) {
              const imageUrl = content.details.sectionImages[j];
              const newImageUrl = await this.processUrl(imageUrl, this.universityConfig.buckets.ASSETS);

              if (newImageUrl) {
                updatedImages.push(newImageUrl);
                imagesModified = true;
              } else {
                updatedImages.push(imageUrl);
              }
            }

            if (imagesModified) {
              content.details.previousSectionImages = [...content.details.sectionImages];
              content.details.sectionImages = updatedImages;
              contentModified = true;
            }
          }

          // Handle section title that might contain HTML with embedded images
          if (content.details.sectionTitle) {
            const { text: newText, modified } = await this.processHtmlContent(content.details.sectionTitle, this.universityConfig.buckets.ASSETS);

            if (modified) {
              content.details.previousSectionTitle = content.details.sectionTitle;
              content.details.sectionTitle = newText;
              contentModified = true;
            }
          }

          // Handle section description that might contain HTML with embedded images
          if (content.details.sectionDescription) {
            const { text: newText, modified } = await this.processHtmlContent(
              content.details.sectionDescription,
              this.universityConfig.buckets.ASSETS
            );

            if (modified) {
              content.details.previousSectionDescription = content.details.sectionDescription;
              content.details.sectionDescription = newText;
              contentModified = true;
            }
          }

          // Process cards in section cards
          if (content.details.sectionCards && Array.isArray(content.details.sectionCards)) {
            for (let j = 0; j < content.details.sectionCards.length; j++) {
              const card = content.details.sectionCards[j];

              // Process icon in card
              if (card.icon) {
                const newIcon = await this.processUrl(card.icon, this.universityConfig.buckets.ASSETS);
                if (newIcon) {
                  card.previousIcon = card.icon;
                  card.icon = newIcon;
                  contentModified = true;
                }
              }

              // Process title that might contain HTML with embedded images
              if (card.title) {
                const { text: newText, modified } = await this.processHtmlContent(card.title, this.universityConfig.buckets.ASSETS);

                if (modified) {
                  card.previousTitle = card.title;
                  card.title = newText;
                  contentModified = true;
                }
              }

              // Process description that might contain HTML with embedded images
              if (card.description) {
                const { text: newText, modified } = await this.processHtmlContent(card.description, this.universityConfig.buckets.ASSETS);

                if (modified) {
                  card.previousDescription = card.description;
                  card.description = newText;
                  contentModified = true;
                }
              }

              // Process caption that might contain HTML with embedded images
              if (card.caption) {
                const { text: newText, modified } = await this.processHtmlContent(card.caption, this.universityConfig.buckets.ASSETS);

                if (modified) {
                  card.previousCaption = card.caption;
                  card.caption = newText;
                  contentModified = true;
                }
              }

              // Process nested content in cards
              if (card.content) {
                // Handle content URL
                if (card.content.url) {
                  const newUrl = await this.processUrl(card.content.url, this.universityConfig.buckets.ASSETS);
                  if (newUrl) {
                    card.content.previousUrl = card.content.url;
                    card.content.url = newUrl;
                    contentModified = true;
                  }
                }

                // Handle content details that might contain HTML
                if (card.content.details) {
                  const { text: newText, modified } = await this.processHtmlContent(card.content.details, this.universityConfig.buckets.ASSETS);

                  if (modified) {
                    card.content.previousDetails = card.content.details;
                    card.content.details = newText;
                    contentModified = true;
                  }
                }
              }

              // Process nested contents array in cards
              if (card.contents && Array.isArray(card.contents)) {
                for (let k = 0; k < card.contents.length; k++) {
                  const contentItem = card.contents[k];

                  // Process text that might contain HTML
                  if (contentItem.text) {
                    const { text: newText, modified } = await this.processHtmlContent(contentItem.text, this.universityConfig.buckets.ASSETS);

                    if (modified) {
                      contentItem.previousText = contentItem.text;
                      contentItem.text = newText;
                      contentModified = true;
                    }
                  }
                }
              }
            }
          }

          // Process sections in styles with backgrounds
          if (content.details.sectionStyle && typeof content.details.sectionStyle === 'string') {
            const { text: newStyle, modified } = await this.processStyleBackground(
              content.details.sectionStyle,
              this.universityConfig.buckets.ASSETS
            );

            if (modified) {
              content.details.previousSectionStyle = content.details.sectionStyle;
              content.details.sectionStyle = newStyle;
              contentModified = true;
            }
          }
        }

        updatedContents[i] = content;
      }

      return contentModified ? updatedContents : undefined;
    } catch (error) {
      console.error('Error processing page contents:', error);
      return undefined;
    }
  }

  private async processHtmlContent(htmlText: string, bucketName: string): Promise<{ text: string; modified: boolean }> {
    if (!htmlText) return { text: htmlText, modified: false };

    try {
      let modified = false;
      let newText = htmlText;

      // Find all img src attributes
      const imgRegex = /<img[^>]+src="([^"]+)"[^>]*>/g;
      let match;

      while ((match = imgRegex.exec(htmlText)) !== null) {
        const originalUrl = match[1];
        if (this.isValidUrl(originalUrl)) {
          const newUrl = await this.processUrl(originalUrl, bucketName);
          if (newUrl) {
            newText = newText.replace(new RegExp(originalUrl.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g'), newUrl);
            modified = true;
          }
        }
      }

      return { text: newText, modified };
    } catch (error) {
      console.error('Error processing HTML content:', error);
      return { text: htmlText, modified: false };
    }
  }

  private async processStyleBackground(styleText: string, bucketName: string): Promise<{ text: string; modified: boolean }> {
    if (!styleText) return { text: styleText, modified: false };

    try {
      let modified = false;
      let newStyle = styleText;

      // Find background-image URL if exists
      const bgRegex = /background-image:\s*url\(['"]([^'"]+)['"]\)/g;
      let match;

      while ((match = bgRegex.exec(styleText)) !== null) {
        const originalUrl = match[1];
        if (this.isValidUrl(originalUrl)) {
          const newUrl = await this.processUrl(originalUrl, bucketName);
          if (newUrl) {
            newStyle = newStyle.replace(new RegExp(originalUrl.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g'), newUrl);
            modified = true;
          }
        }
      }

      return { text: newStyle, modified };
    } catch (error) {
      console.error('Error processing style background:', error);
      return { text: styleText, modified: false };
    }
  }

  private async processBatch(batch: Page[]) {
    await Promise.all(batch.map((page) => this.processPage(page)));
  }

  public async transfer() {
    if (this.pages.length === 0) {
      console.log('No pages to process.');
      return;
    }

    console.log(`Starting asset transfer for ${this.pages.length} pages...`);

    for (let i = 0; i < this.pages.length; i += this.BATCH_SIZE) {
      const batch = this.pages.slice(i, i + this.BATCH_SIZE);
      try {
        console.log(`Processing batch ${i / this.BATCH_SIZE + 1}/${Math.ceil(this.pages.length / this.BATCH_SIZE)}`);
        await this.processBatch(batch);
      } catch (error) {
        console.error(`Error processing batch starting at index ${i}:`, error);
      }
    }

    console.log('Transfer summary:');
    console.log(`✅ Total successful transfers: ${this.results.success}`);
    console.log(`❌ Total failed transfers: ${this.results.failed}`);

    await this.sendMail();
  }

  private async sendMail() {
    try {
      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';

      // Create a more detailed email with results
      const successfulTransfers = this.results.success;
      const failedTransfers = this.results.failed;
      const totalPages = this.pages.length;

      mailOptions.html = `
        <h2>Page Assets Transfer Complete</h2>
        <p>Total pages processed: ${totalPages}</p>
        <p>Successful transfers: ${successfulTransfers}</p>
        <p>Failed transfers: ${failedTransfers}</p>
        <br/>
        ${failedTransfers > 0 ? '<p style="color: red;">⚠️ Some assets failed to transfer. Please check the logs for details.</p>' : ''}
        <br/>
        <p>Best regards,</p>
        <p><em>This is an automated message, please do not reply directly to this email.</em></p>
      `;
      mailOptions.subject = `Page Assets Transfer Complete - ${successfulTransfers} succeeded, ${failedTransfers} failed`;
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();
      await mailer.send(mailOptions);
      console.log('Transfer report email sent successfully');
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }
}
