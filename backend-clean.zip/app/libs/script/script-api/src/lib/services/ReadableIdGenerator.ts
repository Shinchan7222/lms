import { DateUtils, numberUtils } from '@edorer/utils';
import { Question } from '@edorer/question-data';

export class ReadableIdGenerator {

    static generate(question: Question) {

        const date = new Date();

        const typePrefix = question.type.substr(0, 2);
        const difficultyLevelPrefix = question.difficulty.substr(0, 1);
        const categoryNamePrefix = question.category.name.substr(0, 2);
        const fullDate = date.getFullYear() + '' + DateUtils.formatMonth(date.getMonth()) + '' + DateUtils.formatDay(date.getDate());

        const questionId = (typePrefix + difficultyLevelPrefix + categoryNamePrefix + fullDate).toUpperCase();

        return questionId + numberUtils.pad(1, 4);
    }
}
