import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { CourseStructureReorganizerService } from './CourseStructureReorganizerService';

export class LectureReorderingService {
    private readonly universityId: string;
    private changes: string[] = [];
    private reorganizer: CourseStructureReorganizerService;

    constructor(universityId: string) {
        this.universityId = universityId;
        this.reorganizer = new CourseStructureReorganizerService(universityId);
    }

    async check(): Promise<{
        message: string;
        totalMisorderedChapters: number;
        details: any[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let totalMisorderedChapters = 0;
            const details: any[] = [];

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length <= 1) continue;

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    // Create a map for quick lookup
                    const lectureMap = new Map(lectures.map(l => [l._id.toString(), l]));

                    // Reconstruct current order objects
                    const currentOrderedLectures = [];
                    for (const id of chapter.lectures) {
                        const l = lectureMap.get(id.toString());
                        if (l) currentOrderedLectures.push(l);
                    }

                    // Determine correct order
                    const sortedLectures = [...currentOrderedLectures];
                    this.sortLectures(sortedLectures);

                    // Check if different
                    const currentIds = currentOrderedLectures.map(l => l._id.toString()).join(',');
                    const sortedIds = sortedLectures.map(l => l._id.toString()).join(',');

                    if (currentIds !== sortedIds) {
                        totalMisorderedChapters++;
                        details.push({
                            courseTitle: course.title,
                            chapterTitle: chapter.title,
                            currentOrder: currentOrderedLectures.map(l => l.title),
                            expectedOrder: sortedLectures.map(l => l.title)
                        });
                    }
                }
            }

            return {
                message: 'Lecture reorder check completed',
                totalMisorderedChapters,
                details: details.slice(0, 50) // Limit details size
            };

        } catch (error: any) {
            console.error('Error checking lecture order:', error);
            return {
                message: 'Error checking lecture order',
                totalMisorderedChapters: 0,
                details: [],
                error: error.message
            };
        }
    }

    async process(): Promise<{
        message: string;
        totalChaptersReordered: number;
        changes: string[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let totalChaptersReordered = 0;
            this.changes = [];

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                let courseModified = false;

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length <= 1) continue;

                    // Rename TOPIC -> Unit and re-index first
                    const lecturesRenamed = await this.reorganizer.processLectures(chapter, course.title, chapter.title);
                    if (lecturesRenamed) {
                        this.changes.push(`[Course: ${course.title} | Chapter: ${chapter.title}] Renamed/Re-indexed TOPIC/Unit lectures`);
                        courseModified = true;
                    }

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    const lectureMap = new Map(lectures.map(l => [l._id.toString(), l]));
                    const currentOrderedLectures = [];
                    for (const id of chapter.lectures) {
                        const l = lectureMap.get(id.toString());
                        if (l) currentOrderedLectures.push(l);
                    }

                    const sortedLectures = [...currentOrderedLectures];
                    this.sortLectures(sortedLectures);

                    const currentIds = currentOrderedLectures.map(l => l._id.toString()).join(',');
                    const sortedIds = sortedLectures.map(l => l._id.toString()).join(',');

                    if (currentIds !== sortedIds) {
                        chapter.lectures = sortedLectures.map(l => l._id);
                        await chapter.save();
                        this.changes.push(`[Course: ${course.title} | Chapter: ${chapter.title}] Reordered lectures`);
                        totalChaptersReordered++;
                    }
                }
            }

            return {
                message: 'Lecture reordering completed',
                totalChaptersReordered,
                changes: this.changes
            };

        } catch (error: any) {
            console.error('Error reordering lectures:', error);
            return {
                message: 'Error reordering lectures',
                totalChaptersReordered: 0,
                changes: [],
                error: error.message
            };
        }
    }

    private sortLectures(lectures: any[]) {
        lectures.sort((a, b) => {
            const titleA = a.title || '';
            const titleB = b.title || '';

            // 1. Units (First)
            const unitMatchA = titleA.match(/Unit\s*(\d+)/i);
            const unitMatchB = titleB.match(/Unit\s*(\d+)/i);

            if (unitMatchA && unitMatchB) {
                return parseInt(unitMatchA[1]) - parseInt(unitMatchB[1]);
            }
            if (unitMatchA) return -1;
            if (unitMatchB) return 1;

            // 2. E - Book (Second)
            if (titleA.toLowerCase().includes('e - book')) return -1;
            if (titleB.toLowerCase().includes('e - book')) return 1;
            if (titleA.toLowerCase().includes('e-book')) return -1;
            if (titleB.toLowerCase().includes('e-book')) return 1;

            // 3. Quiz / Question (Third)
            const quizItems = ['quiz', 'question'];
            const isQuizA = quizItems.some(i => titleA.toLowerCase().includes(i));
            const isQuizB = quizItems.some(i => titleB.toLowerCase().includes(i));

            if (isQuizA && !isQuizB) return -1;
            if (!isQuizA && isQuizB) return 1;

            // 4. Assignment (Last)
            if (titleA.toLowerCase().includes('assignment')) return 1;
            if (titleB.toLowerCase().includes('assignment')) return -1;

            return 0;
        });
    }
}
