import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { mailer } from '@edorer/mailer';
import { Question, questionRepository } from '@edorer/question-data';
import { UniversityConfiguration } from '@edorer/university-data';

export class TransferQuestionAssets {
  private readonly questions: Question[] = [];
  private readonly universityConfig: UniversityConfiguration;

  private readonly BATCH_SIZE = 10;
  private readonly MAX_RETRIES = 3;

  constructor(questions: Question[] = [], universityConfig: UniversityConfiguration) {
    this.questions = questions;
    this.universityConfig = universityConfig;
  }

  private isValidUrl(url: string | undefined): boolean {
    if (!url) return false;
    try {
      new URL(url);

      return url.startsWith('https://minio.paruluniversity.ac.in') || url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private extractAbsoluteImageUrls(content: string): string[] {
    const matches = content.match(/src="(https:\/\/[^"]+)"/g);
    return matches ? matches.map((match) => match.replace('src="', '').replace('"', '')) : [];
  }

  private async processAsset(url: string, retries = 0): Promise<string | undefined> {
    let downloadedUrl: string | undefined;

    try {
      if (!this.isValidUrl(url)) return undefined;

      const downloader = new Downloader(url);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      const s3 = new S3University(this.universityConfig, true);
      const uploadedUrl = await s3.uploadBuffer(fileContent, url.split('/').pop(), this.universityConfig.buckets.LMS_COURSE_VIDEOS);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      return uploadedUrl;
    } catch (error) {
      console.error(`Error processing image URL (${url}): ${error}`);
      if (retries < this.MAX_RETRIES) {
        console.warn(`Retry ${retries + 1} for image ${url}`);
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retries + 1)));
        return this.processAsset(url, retries + 1);
      }
      return undefined;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch (error) {
          console.error('Failed to cleanup temporary file:', error);
        }
      }
    }
  }

  private async processQuestion(question: Question): Promise<void> {
    try {
      let updatedContent = question.content;
      const imageUrls = this.extractAbsoluteImageUrls(question.content);

      if (imageUrls.length > 0) {
        for (const imageUrl of imageUrls) {
          const uploadedUrl = await this.processAsset(imageUrl);
          if (uploadedUrl) {
            updatedContent = updatedContent.replace(imageUrl, uploadedUrl);
          }
        }
      }

      if (updatedContent !== question.content) {
        await questionRepository.update(
          { _id: question._id },
          { $set: { content: updatedContent, isAssetsShifted: true, previousContent: question.content } }
        );
      }
    } catch (error) {
      console.error(`Error processing question ${question._id}:`, error);
    }
  }

  private async processBatch(batch: Question[]) {
    await Promise.all(batch.map((question) => this.processQuestion(question)));
  }

  public async transfer() {
    if (this.questions.length === 0) return;

    for (let i = 0; i < this.questions.length; i += this.BATCH_SIZE) {
      const batch = this.questions.slice(i, i + this.BATCH_SIZE);
      await this.processBatch(batch);
    }

    await this.sendMail();
  }

  private async sendMail() {
    try {
      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
      mailOptions.html = `
          <h4>Question assets transferred!</h4>
          </br></br></br></br>
          <p>Best regards,</p>
          <p><em>This is an automated message, please do not reply directly to this email.</em></p>
        `;
      mailOptions.subject = `Restoration complete`;
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();

      await mailer.send(mailOptions);
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }
}
