import ShortUniqueId from 'short-unique-id';
import { ExamProctor, ExamRandomisationTypes } from '@edorer/exam-data';
import { QuestionDifficulty, QuestionTypes } from '@edorer/question-data';
import { StringUtils } from '@edorer/utils';
import { TrackExamMode, TrackExamStatus } from '@edorer/track-exam-data';
import { UserTypes, userRepository } from '@edorer/user-data';
import { categoryRepository } from '@edorer/category-data';
import { existsSync } from 'fs';
import { hash } from 'bcryptjs';
import { v4 as uuidV4 } from 'uuid';

export class MigrationUtils {

    static checkFile(file: string) {
        if (!existsSync(file)) {
            throw new Error(file.toUpperCase() + ' does not exist');
        }
    }

    static sanitizeQuestions(groupQuestions: any) {
        let questions = [];

        for (let groupQuestion of groupQuestions) {
            questions.push(...groupQuestion.questions);
        }

        return questions.map(question => question._id);
    }

    static sanitizeName(name: { first?: string, middle?: string, last?: string }) {
        if (!name) {
            return '';
        }

        const names = Object.values(name);

        return names.join(' ');
    }

    static async deleteData(collection: string, ids: string[], universityId: string, repository: any) {
        try {
            if (ids.length > 0) {
                await repository.deleteMany({ _id: { $in: ids } });
            }
            console.warn('DELETED ' + collection.toUpperCase());
        } catch (error: any) {
            console.error(collection.toUpperCase());
            console.error(error.message);
            // throw new Error('Could not insert data');
        }
    }

    static async writeData(collection: string, items: any, repository: any) {
        try {
            console.warn(collection.toUpperCase(), 'ADDED', items.length);
            if (items.length > 0) {
                await repository.insertMany(items);
            }
            console.warn('WRITTEN ' + collection.toUpperCase());
        } catch (error: any) {
            console.error(collection.toUpperCase());
            console.error(error.message);
        }
    }

    static async updateData(collection: string, items: any, repository: any) {
        try {
            if (items.length > 0) {
                for (let item of items) {
                    await repository.findOneAndUpdate(
                        { _id: item._id },
                        { ...item },
                        { multi: false, upsert: true }
                    );
                }
            }
            console.warn('UPDATED ' + collection.toUpperCase());
        } catch (error: any) {
            console.error(collection.toUpperCase());
            console.error(error.message);
            throw new Error('Could not update data');
        }
    }

    static async updateUser(collection: string, items: any, repository: any) {
        if (items.length > 0) {
            for (let item of items) {
                const { _id, email, ...itemsToUpdate } = item;
                try {
                    await repository.findOneAndUpdate(
                        { $or: [{ _id }, { email }] },
                        { ...itemsToUpdate },
                        { multi: false, upsert: true }
                    );
                } catch (error: any) {
                    console.error(collection.toUpperCase());
                    console.error(error.message);
                }

                console.warn('UPDATED ' + collection.toUpperCase());
            }
        }
    }

    static formatRandomisation(shuffleType: string) {
        if (!shuffleType) {
            return ExamRandomisationTypes.EVERYTHING;
        }

        switch (shuffleType) {
            case 'Category': {
                return ExamRandomisationTypes.CATEGORIES;
            }
            case 'Question': {
                return ExamRandomisationTypes.QUESTIONS;
            }
            case 'QuestionAndCategory': {
                return ExamRandomisationTypes.CATEGORIES_AND_QUESTIONS;
            }

            default: {
                return ExamRandomisationTypes.EVERYTHING;
            }
        }
    }

    static async formatFetch(fetch: { [key: string]: { smart: number, brilliant: number, genius: number } }, universityId: string) {
        if (fetch === null || fetch === undefined || Object.keys(fetch).length < 1) {
            return {};
        }

        const keys = Object.keys(fetch);
        const values = Object.values(fetch);

        const formattedFetch: { [key: string]: { easy: number, medium: number, hard: number } } = {};

        for (let index = 0; index < keys.length; index++) {
            const key = keys[index];
            const fetchValue = values[index];

            const category = await categoryRepository.findOneAndUpdate(
                { name: key, university: universityId },
                { name: key, university: universityId },
                { multi: false, new: true, upsert: true }
            );

            formattedFetch[category._id] = { easy: fetchValue.smart, medium: fetchValue.brilliant, hard: fetchValue.genius };
        }

        return formattedFetch;
    }

    static shieldValue(shield: any) {
        if (!shield) {
            return false;
        }

        if (!shield.enabled) {
            return false;
        }

        return shield.enabled.value;
    }

    static formatMonitorType(shield: any) {
        if (!shield) {
            return ExamProctor.WIZARD;
        }

        if (!shield.type) {
            return ExamProctor.WIZARD;
        }

        return shield.type === 'Live' ? ExamProctor.LIVE_PROCTOR : ExamProctor.WIZARD;
    }

    static formatDifficulty(difficulty: string): QuestionDifficulty {
        switch (StringUtils.lowercase(difficulty).trim()) {
            case 'medium':
            case 'brilliant': {
                return QuestionDifficulty.MEDIUM;
            }

            case 'hard':
            case 'genius': {
                return QuestionDifficulty.HARD;
            }

            default: {
                return QuestionDifficulty.EASY;
            }
        }
    }

    static formatType(type: string): QuestionTypes {
        switch (type) {
            case 'Video Response': {
                return QuestionTypes.VIDEO;
            }

            case 'Single Choice':
            case 'Trivia Single Choice': {
                return QuestionTypes.SINGLE_SELECT;
            }

            case 'Subjective':
            case 'Submission': {
                return QuestionTypes.FREE_ANSWER;
            }

            case 'Sorting': {
                return QuestionTypes.ORDERING;
            }

            case 'Problem Solving': {
                return QuestionTypes.PROGRAMMING;
            }

            case 'Multiple Choice': {
                return QuestionTypes.MULTIPLE_SELECT;
            }

            case 'Match the Following': {
                return QuestionTypes.MATCHING;
            }

            case 'Fill in the Blank': {
                return QuestionTypes.FILL_IN_THE_BLANKS;
            }

            case 'Linear Scale': {
                return QuestionTypes.LIKERT_SCALE;
            }

            default: {
                return QuestionTypes.FREE_ANSWER;
            }
        }
    }

    static formatAnswers(type: string, answers: any[]): any[] {
        const options = [];

        for (let answer of answers) {
            const {
                content = '', explanation = '', isHugeTestCaseInput: isInputHuge = false,
                isHugeTestCaseOutput: isOutputHuge = false, testCaseInput: input = '',
                isCorrect = false, testCaseOutput: output = '', isVisible: visible = false
            } = answer;

            const answerContent = this.formatAnswerContent(type, content);

            const option = {
                content: answerContent, explanation, input,
                isCorrect, isInputHuge, isOutputHuge,
                output, visible
            };

            options.push(option);
        }

        return options;
    }

    static formatAnswerContent(type: string, content: any) {
        const questionType = this.formatType(type);

        switch (questionType) {
            case QuestionTypes.FILL_IN_THE_BLANKS: {
                return Array.isArray(content) ? content : [content];
            }

            default: {
                return Array.isArray(content) ? content.join(' ') : content;
            }
        }
    }

    static formatTrackMode(progress: string) {
        switch (progress) {
            case 'Setup': {
                return TrackExamMode.SETUP;
            }

            default: {
                return TrackExamMode.QUESTION;
            }
        }
    }

    static formatTrackStatus(progress: string) {
        switch (progress) {
            case 'Ongoing': {
                return TrackExamStatus.IN_PROGRESS;
            }

            case 'Abandoned': {
                return TrackExamStatus.ABANDONED;
            }

            default: {
                return TrackExamStatus.ENDED;
            }
        }
    }

    static formatTrackAnswers(trackAnswers: any[]) {
        const answers = [];

        for (let trackAnswer of trackAnswers) {
            if (trackAnswer) {
                const {
                    attachements: diagrams = [], content, createdAt = new Date(),
                    points: point = 0, question: questionId = null, verdict = {},
                    visibleEvaluations, hiddenEvaluations
                } = trackAnswer;

                let answerContent = [];
                if (content !== null) {
                    if (content && content.value) {
                        answerContent = Array.isArray(content.value) ? content.value.map(v => String(v)) : [content.value.toString()];
                    } else if (content && content.url) {
                        answerContent = [content.url];
                    } else {
                        if (Array.isArray(content)) {
                            const isBoolean = content.every(con => typeof con === 'boolean');
                            if (isBoolean) {
                                answerContent = [String(content.findIndex(a => a))];
                            } else {
                                answerContent = content.map(v => String(v));
                            }
                        } else if (typeof content === 'object' && content.files && content.files.length) {
                            answerContent = content.files.map(file => file.content);
                        } else {
                            answerContent = [String(content)];
                        }
                    }
                }

                if (content === 0 || content === '0') {
                    answerContent = ['0'];
                }

                if (!content || (content && Array.isArray(content) && content.length === 0)) {
                    answerContent = ['0'];
                }

                const answer: any = {
                    answer: answerContent,
                    compiledResult: {
                        visibleEvaluations: this.formatEvaluations(visibleEvaluations),
                        hiddenEvaluations: this.formatEvaluations(hiddenEvaluations),
                        verdictDetails: verdict
                    },
                    createdAt,
                    diagrams,
                    isCorrect: point > 0,
                    point,
                    questionId
                };

                if (content && content.url) {
                    answer.attachments = [{ createdAt: new Date(), url: content.url }];
                }

                answers.push(answer);
            }
        }

        return answers;
    }

    static async createUserWithEmail(email = null, name = null, universityId: string) {
        let userId: string;
        const user = await this.userWithEmailAndName(email, name, universityId);

        const existingUser = await userRepository.findOne({ email: user.email }).lean();
        if (existingUser) {
            userId = existingUser._id;
        } else {
            const userWithEmail = await userRepository.create(user);
            userId = userWithEmail._id;
        }

        return userId;
    }

    static async createUserWithID(userId: string, email = null, name = null, universityId: string) {
        const existingUser = await userRepository.count({ _id: userId });
        if (existingUser > 0) {
            return userId;
        } else {
            const user = await this.userWithEmailAndName(email, name, universityId);
            const userWithEmail = await userRepository.create({ _id: userId, ...user });
            return userWithEmail._id;
        }
    }

    static async userWithEmailAndName(email = null, name = null, universityId: string) {
        if (email === null) {
            const shortUniqueId = new ShortUniqueId();
            shortUniqueId.setDictionary('alpha_lower');
            const shortId = shortUniqueId.randomUUID(6);

            email = shortId + '@edorer.com';
        }

        if (name === null) {
            name = 'no-name';
        }

        return {
            avatar: '',
            createdAt: new Date(),
            deleted: false,
            email,
            forcedAvatarUpload: true,
            isActive: true,
            isEdorer: false,
            isEmailVerified: true,
            isOnBoardingDone: true,
            isPhoneVerified: true,
            isRevoked: false,
            isSuspended: false,
            location: 'India',
            name,
            password: await hash('123456', 10),
            passwordManuallyChanged: true,
            phone: '',
            token: uuidV4(),
            type: UserTypes.STUDENT,
            university: universityId,
            useTwoFactorAuth: false
        };
    }

    static formatUserType(type: string): UserTypes {
        switch (type) {
            case 'manager': {
                return UserTypes.UNIVERSITY_MEMBER;
            }

            case 'meaZrmatician':
            case 'meaZrer': {
                return UserTypes.TEACHER;
            }

            case 'meaZree': {
                return UserTypes.STUDENT;
            }

            default: {
                return UserTypes.UNIVERSITY_MEMBER;
            }
        }
    }

    static formatUserName(name: { first: string, last: string, middle: string }, fullName: string = null, userName: string = null): string {
        if (name && Object.keys(name).length > 0) {
            return Object.values(name).join(' ');
        }

        if (fullName) {
            return fullName;
        }

        if (userName) {
            return userName;
        }

        return 'No name';
    }

    static formatEvaluations(evaluations) {
        const ev = [];

        for (let evaluation of evaluations) {
            const {
                isHugeTestCaseInput: isInputHuge = false, isHugeTestCaseOutput: isOutputHuge = false,
                testCaseInput: input = '', isCorrect = false, testCaseOutput: output = '', isVisible: visible = false
            } = evaluation;

            ev.push({
                input,
                isCorrect,
                isInputHuge,
                isOutputHuge,
                output,
                visible
            });
        }

        return ev;
    }
}
