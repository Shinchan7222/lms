import { createHash } from 'crypto';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { mailer } from '@edorer/mailer';
import { ProgramResult, programResultRepository } from '@edorer/program-result-data';
import { University, UniversityConfiguration } from '@edorer/university-data';

export class TransferProgramResults {
  private readonly programResults: ProgramResult[] = [];
  private readonly university: University;
  private readonly universityConfig: UniversityConfiguration;
  private readonly MAX_RETRIES = 3;
  private readonly MAX_CONCURRENT_TASKS = Math.max(4, Math.floor(require('os').cpus().length * 0.75));

  private activePromises = new Set<Promise<void>>();
  private stats = {
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0
  };
  private deniedUrls: { encodedUrl?: string; url: string; programResultId: string }[] = [];

  constructor(programResults: ProgramResult[] = [], university: University, universityConfig: UniversityConfiguration) {
    this.programResults = programResults;
    this.university = university;
    this.universityConfig = universityConfig;
  }

  private async addToQueue(task: () => Promise<void>): Promise<void> {
    while (this.activePromises.size >= this.MAX_CONCURRENT_TASKS) {
      await Promise.race(this.activePromises);
    }

    const promise = task().finally(() => {
      this.activePromises.delete(promise);
    });

    this.activePromises.add(promise);
    return promise;
  }

  private isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private generateSafeFileName(originalName: string): string {
    const ext = originalName.split('.').pop() || '';
    const hash = createHash('md5').update(originalName).digest('hex').slice(0, 8);
    // Take only first 12 chars of the name to keep it short
    const safeName = originalName
      .split('.')[0]
      .replace(/[^a-zA-Z0-9]/g, '-') // Replace non-alphanumeric chars with dash
      .replace(/-+/g, '-') // Replace multiple dashes with single dash
      .slice(0, 12)
      .trim();
    return `${safeName}-${hash}.${ext}`;
  }

  private async downloadAndUploadUrl(url: string, bucketName: any, programResultId: string): Promise<string | null> {
    let downloadedUrl: string | undefined;
    try {
      const filename = url.split('/').pop();
      const encodedFilename = encodeURIComponent(filename);

      const encodedUrl = url.replace(filename, encodedFilename);

      const downloader = new Downloader(encodedUrl);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        this.deniedUrls.push({ encodedUrl, url, programResultId });
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        this.deniedUrls.push({ encodedUrl, url, programResultId });
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        this.deniedUrls.push({ encodedUrl, url, programResultId });
        throw new Error('Failed to read file content');
      }

      const originalFileName = url.split('/').pop() || '';
      const safeFileName = this.generateSafeFileName(originalFileName);

      const s3 = new S3University(this.universityConfig, true);
      const uploadedUrl = await s3.uploadBuffer(fileContent, safeFileName, bucketName);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      return uploadedUrl;
    } catch {
      this.deniedUrls.push({ url, programResultId });
      return null;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch {}
      }
    }
  }

  private async processWorkWithRetry(programResult: ProgramResult, retryCount = 0): Promise<void> {
    let downloadedDocUrl: string | undefined;
    let downloadedVideoUrl: string | undefined;

    try {
      if (programResult.dmc && this.isValidUrl(programResult.dmc)) {
        const uploadedUrl = await this.downloadAndUploadUrl(
          programResult.dmc,
          this.universityConfig.buckets.LMS_COURSE_VIDEOS,
          programResult._id.toString()
        );

        if (uploadedUrl) {
          const originalDoc = programResult.dmc;
          programResult.dmc = uploadedUrl;

          await programResultRepository.update(
            { _id: programResult._id },
            {
              $set: {
                dmc: uploadedUrl,
                previousDmc: originalDoc,
                isShifted: true
              }
            }
          );
          this.stats.successful++;
        }
      }

      this.stats.processed++;
    } catch (error) {
      if (retryCount < this.MAX_RETRIES) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retryCount + 1)));
        return this.processWorkWithRetry(programResult, retryCount + 1);
      }
      this.stats.failed++;
      this.stats.processed++;
    } finally {
      if (downloadedDocUrl && FileUtils.fileExists(downloadedDocUrl)) {
        try {
          FileUtils.removeFile(downloadedDocUrl);
        } catch {}
      }
      if (downloadedVideoUrl && FileUtils.fileExists(downloadedVideoUrl)) {
        try {
          FileUtils.removeFile(downloadedVideoUrl);
        } catch {}
      }
    }
  }

  public async transfer() {
    if (this.programResults.length === 0) {
      return;
    }

    console.log('MAX_CONCURRENT_TASKS ==>', this.MAX_CONCURRENT_TASKS);
    console.log('programResults ==>', this.programResults.length);

    const documents = this.programResults.map((programResult) => programResult.dmc).filter((url) => this.isValidUrl(url));
    const allUrls = [...documents];

    // Calculate total items to process
    this.stats.total = this.programResults.length;

    // Process all programResults maintaining max concurrent tasks
    for (const programResult of this.programResults) {
      await this.addToQueue(() => this.processWorkWithRetry(programResult));
    }

    // Wait for any remaining tasks to complete
    await Promise.all(this.activePromises);

    await this.sendMail();
  }

  private async sendMail() {
    try {
      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';

      const deniedUrlsHtml = `
        <div style="margin: 20px 0;">
          <h5>Denied Access URLs:</h5>
          ${
            this.deniedUrls.length > 0
              ? `
            <h6>Documents (${this.deniedUrls.length}):</h6>
            <ul>
              ${this.deniedUrls.map((item) => `<li>Work ID: ${item.programResultId} - URL: ${item.url}</li>`).join('')}
            </ul>
          `
              : ''
          }
        </div>
      `;

      mailOptions.html = `
          <h4>Program results transferred for ${this.university.url}!</h4>
          <div style="margin: 20px 0;">
            <h5>Transfer Statistics:</h5>
            <ul>
              <li>Total Works: ${this.stats.total}</li>
              <li>Successfully Processed: ${this.stats.successful}</li>
              <li>Failed: ${this.stats.failed}</li>
              <li>Success Rate: ${((this.stats.successful / this.stats.total) * 100).toFixed(2)}%</li>
              <li>Denied URLs: ${this.deniedUrls.length}</li>
            </ul>
          </div>
          ${this.deniedUrls.length > 0 ? deniedUrlsHtml : '<p>No access denied URLs found.</p>'}
          </br></br>
          <p>Best regards,</p>
          <p><em>This is an automated message, please do not reply directly to this email.</em></p>
        `;
      mailOptions.subject = `Program results transfer complete - Success Rate: ${((this.stats.successful / this.stats.total) * 100).toFixed(2)}% - ${
        this.deniedUrls.length
      } Denied URLs`;
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();
      await mailer.send(mailOptions);
    } catch {}
  }
}
