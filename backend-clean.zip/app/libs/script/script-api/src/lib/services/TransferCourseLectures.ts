import { AwsDocumentsRestorer } from './AwsDocumentsRestorer';
import { createHash } from 'crypto';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { mailer } from '@edorer/mailer';
import { University, UniversityConfiguration } from '@edorer/university-data';

interface ProcessingStats {
  total: number;
  processed: number;
  successful: number;
  failed: number;
  skipped: number;
}

export class TransferCourseLectures {
  private readonly lectures: Lecture[] = [];
  private readonly restore: boolean = true;
  private readonly university: University;
  private readonly universityConfig: UniversityConfiguration;
  private readonly MAX_RETRIES = 3;
  private readonly MAX_CONCURRENT_TASKS = Math.max(4, Math.floor(require('os').cpus().length * 0.75));

  private stats: ProcessingStats = {
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0,
    skipped: 0
  };

  private activePromises = new Set<Promise<void>>();

  constructor(lectures: Lecture[] = [], university: University, universityConfig: UniversityConfiguration, restore = true) {
    this.lectures = lectures;
    this.restore = restore;
    this.university = university;
    this.universityConfig = universityConfig;
  }

  private isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private generateSafeFileName(originalName: string): string {
    const ext = originalName.split('.').pop() || '';
    const hash = createHash('md5').update(originalName).digest('hex').slice(0, 8);
    const safeName = originalName
      .split('.')[0]
      .replace(/[^a-zA-Z0-9]/g, '-')
      .replace(/-+/g, '-')
      .slice(0, 12)
      .trim();

    return `${safeName}-${hash}.${ext}`;
  }

  private async downloadAndUploadUrl(url: string, bucketName: any): Promise<string | null> {
    let downloadedUrl: string | undefined;

    try {
      const filename = url.split('/').pop();
      const encodedFilename = encodeURIComponent(filename);
      const encodedUrl = url.replace(filename, encodedFilename);

      const downloader = new Downloader(encodedUrl);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      const originalFileName = url.split('/').pop() || '';
      const safeFileName = this.generateSafeFileName(originalFileName);

      const s3 = new S3University(this.universityConfig, true);
      const uploadedUrl = await s3.uploadBuffer(fileContent, safeFileName, bucketName);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      return uploadedUrl;
    } catch {
      return null;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch {}
      }
    }
  }

  private async processImagesWithRetry(page: any, lecture: Lecture, retryCount = 0): Promise<void> {
    try {
      if (!page.images || !Array.isArray(page.images) || page.images.length === 0) {
        return;
      }

      const uploadedImages: string[] = [];
      const originalImages: string[] = [...page.images];

      for (const imageUrl of originalImages) {
        if (this.isValidUrl(imageUrl)) {
          const uploadedUrl = await this.downloadAndUploadUrl(imageUrl, this.universityConfig.buckets.LMS_COURSE_VIDEOS);

          if (uploadedUrl) {
            uploadedImages.push(uploadedUrl);
          } else {
            uploadedImages.push(imageUrl);
          }
        } else {
          uploadedImages.push(imageUrl);
        }
      }

      if (JSON.stringify(originalImages) !== JSON.stringify(uploadedImages)) {
        page.images = uploadedImages;
        page.previousImages = originalImages;

        await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages, isShifted: true } });
      }
    } catch (error) {
      if (retryCount < this.MAX_RETRIES) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retryCount + 1)));
        return this.processImagesWithRetry(page, lecture, retryCount + 1);
      }
    }
  }

  private async processPageWithRetry(page: any, lecture: Lecture, retryCount = 0): Promise<void> {
    try {
      let url: string | undefined;
      let url2: string | undefined;

      if (page.contentType === 'document' && page.assetUrl) {
        url = page.assetUrl;
        url2 = page.storedURI;
      } else if (page.contentType === 'video' && page.video) {
        url = page.video;
      }

      if (!url || !this.isValidUrl(url)) {
        if (page.contentType === 'document' && page.video) {
          page.video = null;
          await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages, isShifted: true } });
        }

        await this.processImagesWithRetry(page, lecture);
        return;
      }

      const uploadedUrl = await this.downloadAndUploadUrl(url, this.universityConfig.buckets.LMS_COURSE_VIDEOS);
      if (!uploadedUrl) {
        throw new Error('Failed to process main asset');
      }

      page.assetUrl = uploadedUrl;
      page.previousUrl = url;

      if (url2) {
        const uploadedUrl2 = await this.downloadAndUploadUrl(url2, this.universityConfig.buckets.LMS_COURSE_VIDEOS);
        if (uploadedUrl2) {
          page.storedURI = uploadedUrl2;
        }
      }

      if (page.contentType === 'video') {
        page.video = uploadedUrl;
      }

      await this.processImagesWithRetry(page, lecture);
      await lectureRepository.update({ _id: lecture._id }, { $set: { pages: lecture.pages, isShifted: true } });

      this.stats.successful++;
      this.stats.processed++;
    } catch (error) {
      if (retryCount < this.MAX_RETRIES) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retryCount + 1)));
        return this.processPageWithRetry(page, lecture, retryCount + 1);
      }

      this.stats.failed++;
      this.stats.processed++;

      try {
        await this.processImagesWithRetry(page, lecture);
      } catch {}
    }
  }

  private async addToQueue(task: () => Promise<void>): Promise<void> {
    while (this.activePromises.size >= this.MAX_CONCURRENT_TASKS) {
      await Promise.allSettled(this.activePromises);
    }

    const promise = task().finally(() => {
      this.activePromises.delete(promise);
    });

    this.activePromises.add(promise);
    return promise;
  }

  public async transfer() {
    if (this.lectures.length === 0) return;

    if (this.restore) {
      const urlSet = new Set<string>();

      this.lectures.forEach((lecture) => {
        lecture.pages?.forEach((page) => {
          if (page.assetUrl && this.isValidUrl(page.assetUrl)) urlSet.add(page.assetUrl);
          if (page.video && this.isValidUrl(page.video)) urlSet.add(page.video);

          page.images?.forEach((img) => {
            if (this.isValidUrl(img)) urlSet.add(img);
          });
        });
      });

      const allUrls = Array.from(urlSet);

      const restorer = new AwsDocumentsRestorer(20, 4, allUrls, this.university);
      await restorer.restore();
    }

    // Calculate total pages
    this.stats.total = this.lectures.reduce((acc, lecture) => acc + (lecture.pages?.length || 0), 0);

    // Process all lectures maintaining max concurrent tasks
    for (const lecture of this.lectures) {
      if (!lecture?.pages?.length) {
        this.stats.skipped++;
        continue;
      }

      for (const page of lecture.pages) {
        await this.addToQueue(() => this.processPageWithRetry(page, lecture));
      }
    }

    // Wait for any remaining tasks to complete
    await Promise.all(this.activePromises);

    await this.sendMail();
  }

  private async sendMail() {
    try {
      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
      mailOptions.html = `
          <h4>Course lectures transferred for ${this.university.url}!</h4>
          <div style="margin: 20px 0;">
            <h5>Transfer Statistics:</h5>
            <ul>
              <li>Total Pages: ${this.stats.total}</li>
              <li>Successfully Processed: ${this.stats.successful}</li>
              <li>Failed: ${this.stats.failed}</li>
              <li>Skipped: ${this.stats.skipped}</li>
              <li>Success Rate: ${((this.stats.successful / this.stats.total) * 100).toFixed(2)}%</li>
            </ul>
          </div>
          </br></br>
          <p>Best regards,</p>
          <p><em>This is an automated message, please do not reply directly to this email.</em></p>
        `;
      mailOptions.subject = `Course lectures transfer completed for ${this.university.name} - Success Rate: ${(
        (this.stats.successful / this.stats.total) *
        100
      ).toFixed(2)}%`;
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();
      await mailer.send(mailOptions);
    } catch {}
  }
}
