import { Workbook } from 'exceljs';
import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { programRepository } from '@edorer/program-data';
import { Types } from 'mongoose';

interface ConsistencyExcelRow {
    'Course Name': string;
    'Program Name'?: string;
    'Module Number': number;
    'Module Name': string;
    'Unit Name': string;
    'Video Link'?: string;
}

interface Validationresult {
    row: number;
    status: 'valid' | 'invalid';
    message: string;
    details?: any;
}

export class CourseConsistencyCheckerService {
    private readonly excelFile: any;
    private readonly universityId: string;

    constructor(excelFile: any, universityId: string) {
        this.excelFile = excelFile;
        this.universityId = universityId;
    }

    async verify(): Promise<{ success: boolean; results: Validationresult[] }> {
        const rows = await this.parseExcel();
        const results: Validationresult[] = [];
        let allValid = true;

        // Group by Course
        const coursesMap = this.groupByCourse(rows);

        for (const [courseKey, courseRows] of coursesMap) {
            const firstRow = courseRows[0];
            const courseName = firstRow['Course Name'];
            const programName = firstRow['Program Name'];

            try {
                // 1. Verify Course Exists
                const course = await this.findCourse(courseName, programName);
                if (!course) {
                    this.addResult(results, -1, 'invalid', `Course not found: ${courseName} ${programName ? `(${programName})` : ''}`);
                    allValid = false;
                    continue;
                }

                // Group by Module (Chapter)
                const modulesMap = this.groupByModule(courseRows);

                // Sort modules by number to check order
                const sortedModuleNumbers = Array.from(modulesMap.keys()).sort((a, b) => a - b);

                // Check Module Order sequence (optional strictness: must start at 1? must be sequential? assuming sequential for now)
                for (let i = 0; i < sortedModuleNumbers.length; i++) {
                    if (sortedModuleNumbers[i] !== i + 1) {
                        this.addResult(results, -1, 'invalid', `Course ${courseName}: Missing Module ${i + 1} (Found ${sortedModuleNumbers[i]})`);
                        allValid = false;
                    }
                }

                for (const moduleNumber of sortedModuleNumbers) {
                    const moduleRows = modulesMap.get(moduleNumber)!;
                    const firstModuleRow = moduleRows[0];
                    const moduleName = firstModuleRow['Module Name'];

                    // 2. Verify Chapter (Module)
                    // "Inside chapter have Module {i}"
                    // We need to find a chapter that matches the Module Name AND contains "Module {i}" in its title? 
                    // Or just find the chapter by name and Verify it contains "Module {i}"?
                    // The prompt says: "check all courses / chapters / lectures exists and right order and have video or no. make sure that inside lectures have Unit {i} and chapter have Module {i}"

                    const chapter = await chapterRepository.findOne({
                        course: course._id,
                        title: { $regex: new RegExp(moduleName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') } // Escape regex chars in name
                    }).lean();

                    if (!chapter) {
                        this.addResult(results, moduleRows[0]['row'], 'invalid', `Chapter not found: "${moduleName}" in Course: "${courseName}"`);
                        allValid = false;
                        continue;
                    }

                    // Verify Chapter Title format "Module {i}"
                    const moduleRegex = new RegExp(`Module\\s*${moduleNumber}`, 'i');
                    if (!moduleRegex.test(chapter.title)) {
                        this.addResult(results, moduleRows[0]['row'], 'invalid', `Chapter title "${chapter.title}" does not contain "Module ${moduleNumber}"`);
                        allValid = false;
                    }

                    // Group by Unit (Lecture) - assuming order in excel is order of units? Or use Unit Name?
                    // The prompt says "Unit {i}". Does the excel have "Unit Number"? 
                    // The User provided image shows "Unit Name" column. It does NOT show "Unit Number" column explicitly in the first screenshot, wait.
                    // Screenshot 1: Course Name | Module Number | Module Name | Unit Name.
                    // Module Number is explicit. Unit Number is NOT in the screenshot headers.
                    // However, user says "make sure that inside lectures have Unit {i}".
                    // Maybe I need to infer i from the order in the excel? Or check if the lecture title contains *any* "Unit {digits}"?
                    // "right order" implies I should check the sequence in DB matches sequence in Excel?
                    // Let's assume the order in Excel is the intended order.

                    if (!chapter.lectures || chapter.lectures.length === 0) {
                        this.addResult(results, moduleRows[0]['row'], 'invalid', `Chapter "${moduleName}" has no lectures in DB`);
                        allValid = false;
                        continue;
                    }

                    // Fetch all lectures for this chapter
                    const dbLectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    }).lean();

                    // We need to match Excel rows to DB lectures. 
                    // Match by name
                    for (let i = 0; i < moduleRows.length; i++) {
                        const row = moduleRows[i];
                        const unitName = row['Unit Name'];
                        const expectedUnitNumber = i + 1; // Inferring unit number from order in Excel module block

                        const lecture = dbLectures.find(l => l.title.trim().toLowerCase().includes(unitName.trim().toLowerCase())); // Loose match? or exact? Strict first.

                        if (!lecture) {
                            this.addResult(results, (row as any).row, 'invalid', `Lecture (Unit) not found: "${unitName}" in Chapter: "${moduleName}"`);
                            allValid = false;
                            continue;
                        }

                        // Verify Lecture Title format "Unit {i}"
                        // "Unit sometimes have * at the beginning" -> "*Unit 1" or "* Unit 1"
                        // Regex: ^\*?\s*Unit\s*{i} ? or contains Unit {i}?
                        // Prompt: "inside lectures have Unit {i} ... Unit sometimes have * at the beginning"
                        const unitRegex = new RegExp(`\\*?\\s*Unit\\s*${expectedUnitNumber}`, 'i');
                        if (!unitRegex.test(lecture.title)) {
                            this.addResult(results, (row as any).row, 'invalid', `Lecture title "${lecture.title}" does not contain "Unit ${expectedUnitNumber}" (Expected for "${unitName}")`);
                            allValid = false;
                        }

                        // Check Video
                        // "have video or no" - The excel has "Video Link"? Or check if DB has video?
                        // Prompt: "check ... have video or no". 
                        // If Excel has video link, DB should have video? Or just reporting?
                        // If I look at the user request: "check all courses / chapters / lectures exists and right order and have video or no."
                        // This sounds like a validation report.
                        // I will check if the lecture has a video content type page.

                        const hasVideo = lecture.pages && lecture.pages.some((p: any) => p.contentType === 'video' || (p.type === 'video')); // Adjust based on schema
                        if (!hasVideo) {
                            this.addResult(results, (row as any).row, 'invalid', `Lecture "${lecture.title}" is missing video in DB`);
                            allValid = false;
                        }

                        // this.addResult(results, (row as any).row, 'valid', `Verified "${unitName}" (Module ${moduleNumber}, Unit ${expectedUnitNumber})`);
                    }
                }

            } catch (error: any) {
                this.addResult(results, -1, 'invalid', `System Error checking course ${courseName}: ${error.message}`);
                allValid = false;
            }
        }

        return { success: allValid, results };
    }

    async process(): Promise<{ success: boolean; results: Validationresult[] }> {
        const rows = await this.parseExcel();
        const results: Validationresult[] = [];
        let allValid = true;

        const coursesMap = this.groupByCourse(rows);

        for (const [courseKey, courseRows] of coursesMap) {
            const firstRow = courseRows[0];
            const courseName = firstRow['Course Name'];
            const programName = firstRow['Program Name'];

            try {
                // 1. Verify/Get Course
                let course = await this.findCourse(courseName, programName);
                if (!course) {
                    this.addResult(results, -1, 'invalid', `Course not found: ${courseName} ${programName ? `(${programName})` : ''}`);
                    allValid = false;
                    continue;
                }

                const modulesMap = this.groupByModule(courseRows);
                const sortedModuleNumbers = Array.from(modulesMap.keys()).sort((a, b) => a - b);

                // Track chapters to ensure order later
                // We'll iterate the EXCEL modules and ensure they exist/created in order

                for (const moduleNumber of sortedModuleNumbers) {
                    const moduleRows = modulesMap.get(moduleNumber)!;
                    const firstModuleRow = moduleRows[0];
                    const moduleNameRaw = firstModuleRow['Module Name'];
                    const moduleNameFull = `Module ${moduleNumber} - ${moduleNameRaw}`;

                    // 2. Find or Create Chapter
                    let chapter = await chapterRepository.findOne({
                        course: course._id,
                        title: { $regex: new RegExp(moduleNameRaw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') }
                    });

                    if (!chapter) {
                        // Check if maybe it exists with the "Module X" name already
                        chapter = await chapterRepository.findOne({
                            course: course._id,
                            title: { $regex: new RegExp(`Module\\s*${moduleNumber}`, 'i') }
                        });
                    }

                    if (!chapter) {
                        // Create
                        chapter = await chapterRepository.create({
                            title: moduleNameFull,
                            course: course._id,
                            university: course.university,
                            owner: course.owner,
                            lectures: [],
                            order: moduleNumber // Assuming order field exists or we rely on reorder later
                        });
                        this.addResult(results, moduleRows[0].row, 'valid', `Created Chapter: "${moduleNameFull}"`);
                    } else {
                        // Check/Fix Name
                        const moduleRegex = new RegExp(`Module\\s*${moduleNumber}`, 'i');
                        if (!moduleRegex.test(chapter.title)) {
                            this.addResult(results, moduleRows[0].row, 'valid', `Renamed Chapter from "${chapter.title}" to: "${moduleNameFull}"`);
                            chapter.title = moduleNameFull; // Enforce naming
                            await chapter.save();
                        }
                    }

                    // 3. Process Lectures (Units)
                    for (let i = 0; i < moduleRows.length; i++) {
                        const row = moduleRows[i];
                        const unitNameRaw = row['Unit Name'].replace(/^\*\s*/, ''); // Remove leading *
                        const expectedUnitNumber = i + 1;
                        const unitNameFull = `Unit ${expectedUnitNumber} - ${unitNameRaw}`;

                        let lecture = null;

                        if (chapter.lectures && chapter.lectures.length > 0) {
                            // Find in existing lectures
                            const dbLectures = await lectureRepository.find({
                                _id: { $in: chapter.lectures }
                            });

                            lecture = dbLectures.find(l =>
                                l.title.trim().toLowerCase().includes(unitNameRaw.trim().toLowerCase()) ||
                                l.title.trim().toLowerCase().includes(unitNameFull.trim().toLowerCase())
                            );
                        }

                        if (!lecture) {
                            // Create
                            lecture = await lectureRepository.create({
                                title: unitNameFull,
                                chapter: chapter._id,
                                university: course.university,
                                pages: [],
                                owner: course.owner,
                                order: expectedUnitNumber
                            });

                            // Add to chapter
                            chapter.lectures = chapter.lectures || [];
                            chapter.lectures.push(lecture._id);
                            await chapter.save();

                            this.addResult(results, row.row, 'valid', `Created Lecture: "${unitNameFull}"`);
                        } else {
                            // Check/Fix Name
                            const unitRegex = new RegExp(`Unit\\s*${expectedUnitNumber}`, 'i');
                            if (!unitRegex.test(lecture.title)) {
                                this.addResult(results, row.row, 'valid', `Renamed Lecture from "${lecture.title}" to: "${unitNameFull}"`);
                                lecture.title = unitNameFull;
                                await lecture.save();
                            }
                        }
                    }

                    // Reorder Lectures in Chapter
                    await this.reorderLectures(chapter);
                }

                // Reorder Chapters in Course
                await this.reorderChapters(course);

            } catch (error: any) {
                this.addResult(results, -1, 'invalid', `Error processing course ${courseName}: ${error.message}`);
                allValid = false;
            }
        }

        return { success: allValid, results };
    }

    private async reorderChapters(course: any) {
        const chapters = await chapterRepository.find({ course: course._id });

        const sortedChapters = chapters.sort((a, b) => {
            const titleA = a.title.toLowerCase();
            const titleB = b.title.toLowerCase();

            // Helper to get priority
            // 0: Introduction, Syllabus
            // 1: Modules
            // 2: Rest
            const getPriority = (t: string, match: RegExpMatchArray | null) => {
                if (t.includes('introduction') || t.includes('syllabus')) return 0;
                if (match) return 1;
                return 2;
            };

            const moduleMatchA = titleA.match(/Module\s*(\d+)/i);
            const moduleMatchB = titleB.match(/Module\s*(\d+)/i);

            const pA = getPriority(titleA, moduleMatchA);
            const pB = getPriority(titleB, moduleMatchB);

            if (pA !== pB) return pA - pB;

            // Same priority handling
            if (pA === 0) {
                if (titleA.includes('introduction') && !titleB.includes('introduction')) return -1;
                if (!titleA.includes('introduction') && titleB.includes('introduction')) return 1;
                return 0;
            }

            if (pA === 1 && moduleMatchA && moduleMatchB) {
                return parseInt(moduleMatchA[1]) - parseInt(moduleMatchB[1]);
            }

            return 0;
        });

        // Update Course chapters array
        course.chapters = sortedChapters.map(c => c._id);
        await course.save(); // Assuming course repository save or mongoose document save

        // Also update 'order' field on chapters if used
        for (let i = 0; i < sortedChapters.length; i++) {
            await chapterRepository.update({ _id: sortedChapters[i]._id }, { order: i + 1 });
        }
    }

    private async reorderLectures(chapter: any) {
        if (!chapter.lectures || chapter.lectures.length === 0) return;

        const lectures = await lectureRepository.find({ _id: { $in: chapter.lectures } });

        const sortedLectures = lectures.sort((a, b) => {
            const titleA = a.title.toLowerCase();
            const titleB = b.title.toLowerCase();

            // 1. Units (First)
            const unitMatchA = a.title.match(/Unit\s*(\d+)/i);
            const unitMatchB = b.title.match(/Unit\s*(\d+)/i);

            if (unitMatchA && unitMatchB) {
                return parseInt(unitMatchA[1]) - parseInt(unitMatchB[1]);
            }
            if (unitMatchA) return -1;
            if (unitMatchB) return 1;

            // 2. E - Book (Second)
            if (titleA.includes('e - book')) return -1;
            if (titleA.includes('e-book')) return -1;
            if (titleB.includes('e - book')) return 1;
            if (titleB.includes('e-book')) return 1;

            // 3. Quiz / Question (Third)
            const quizItems = ['quiz', 'question'];
            const isQuizA = quizItems.some(i => titleA.includes(i));
            const isQuizB = quizItems.some(i => titleB.includes(i));

            if (isQuizA && !isQuizB) return -1;
            if (!isQuizA && isQuizB) return 1;

            // 4. Assignment (Last)
            if (titleA.includes('assignment')) return 1;
            if (titleB.includes('assignment')) return -1;

            return 0;
        });

        chapter.lectures = sortedLectures.map(l => l._id);
        await chapter.save();

        // Update order field
        for (let i = 0; i < sortedLectures.length; i++) {
            await lectureRepository.update({ _id: sortedLectures[i]._id }, { order: i + 1 });
        }
    }

    // Placeholder for the second endpoint logic - "depend class" ??
    // "it will hav endepend class. where first endpoint... second endpoint..."
    // User might mean dependency injection or valid class structure. 
    // For the second endpoint (upload), I'll implement a stub that calls verify first then would proceed.
    // Wait, if content already exists (we are checking existence), what is "upload" doing?
    // Maybe "upload this xmls" means *using* the excel to fix/update? or just verify?
    // "create 2 endpoints that i will upload this xmls... first endpoint, it will check... make sure..."
    // Maybe second endpoint is just "Ok, now upload the videos" where missing?
    // I will check `CourseUploaderService` again. It uploads videos.
    // So likely Endpoint 1 = Verify, Endpoint 2 = Execute Upload (using logic similar to CourseUploaderService but maybe strictly following this new structure?)
    // For now I will expose the verify method.

    private addResult(results: Validationresult[], row: number, status: 'valid' | 'invalid', message: string) {
        results.push({
            row,
            status,
            message
        });
    }

    private groupByCourse(rows: any[]) {
        const map = new Map<string, any[]>();
        rows.forEach(row => {
            const key = row['Course Name'] + '|' + (row['Program Name'] || '');
            if (!map.has(key)) map.set(key, []);
            map.get(key)!.push(row);
        });
        return map;
    }

    private groupByModule(rows: any[]) {
        const map = new Map<number, any[]>();
        rows.forEach(row => {
            const num = row['Module Number'];
            if (!map.has(num)) map.set(num, []);
            map.get(num)!.push(row);
        });
        return map;
    }

    private async findCourse(courseName: string, programName?: string) {
        let query: any = {
            title: { $regex: new RegExp(courseName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') },
            university: this.universityId
        };

        if (programName) {
            // Logic from CourseUploaderService to filter by program
            // For now, simple find
            // query['programTitle'] = programName; // Not reliable if program title isn't stored on course
        }

        // Try finding exact or regex
        const courses = await courseRepository.find(query);
        if (courses.length === 0) return null;
        return courses[0]; // simplistic selection
    }

    private async parseExcel(): Promise<any[]> {
        const workbook = new Workbook();
        await workbook.xlsx.load(this.excelFile.buffer);

        const worksheet = workbook.getWorksheet(1);
        if (!worksheet) throw new Error('Excel file is empty');

        const rows: any[] = [];
        let headers: { [key: string]: number } = {};
        let headerRowFound = false;

        worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
            if (rowNumber === 1 || !headerRowFound) {
                // Try to detect header row
                const values = (row.values as any[]).slice(1).map(v => v?.toString());
                if (values.includes('Course Name') && values.includes('Module Number')) {
                    row.eachCell((cell, colNumber) => {
                        headers[cell.value?.toString() || ''] = colNumber;
                    });
                    headerRowFound = true;
                    return;
                }
            }

            if (headerRowFound) {
                const rowData: any = { row: rowNumber };
                for (const [key, col] of Object.entries(headers)) {
                    let val = row.getCell(col).value;
                    // Handle hyperlink objects
                    if (val && typeof val === 'object' && (val as any).text) {
                        val = (val as any).text;
                    } else if (val && typeof val === 'object' && (val as any).hyperlink) {
                        // if it's a hyperlink object but we want the displayed text for names?
                        // Usually value is the text.
                        // valid for strings
                    }
                    rowData[key] = val?.toString().trim();
                }
                if (rowData['Course Name']) rows.push(rowData);
            }
        });
        return rows;
    }
}
