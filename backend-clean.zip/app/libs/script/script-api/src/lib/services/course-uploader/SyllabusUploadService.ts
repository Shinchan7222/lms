import { S3University } from '@edorer/s3';
import { universityConfigurationRepository } from '@edorer/university-data';
import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { v4 as uuidV4 } from 'uuid';
import * as fs from 'fs';
import * as path from 'path';

export class SyllabusUploadService {
    private readonly file: any;
    private readonly universityId: string;
    private universityConfig: any;

    constructor(file: any, universityId: string) {
        this.file = file;
        this.universityId = universityId;
    }

    async renameLectures(): Promise<{ success: boolean; count: number; error?: string }> {
        try {
            // 1. Find all courses for this university
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: { $ne: true }
            }).select('_id');

            const courseIds = courses.map(c => c._id);

            // 2. Find lectures with title "Syllabus Document" in these courses
            const lectures = await lectureRepository.find({
                course: { $in: courseIds },
                title: 'Syllabus Document',
                deleted: { $ne: true }
            });

            console.log(`Found ${lectures.length} lectures to rename.`);

            let count = 0;
            for (const lecture of lectures) {
                let updated = false;

                // Update Lecture Title
                lecture.title = 'Course Criteria';
                updated = true;

                // Update Page Title
                if (lecture.pages && lecture.pages.length > 0) {
                    lecture.pages.forEach((page: any) => {
                        if (page.title === 'Syllabus') {
                            page.title = 'Course Criteria';
                        }
                    });
                }

                await lectureRepository.findOneAndUpdate(
                    { _id: lecture._id },
                    {
                        $set: {
                            title: lecture.title,
                            pages: lecture.pages
                        }
                    },
                    { multi: false }
                );
                count++;
            }

            return { success: true, count };

        } catch (error: any) {
            console.error('Error renaming lectures:', error);
            return { success: false, count: 0, error: error.message };
        }
    }

    async removeSyllabusChapters(): Promise<{ success: boolean; count: number; error?: string }> {
        try {
            console.log('Starting cleanup of Syllabus chapters...');

            // 1. Find all courses
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: { $ne: true }
            }).select('_id chapters');

            const courseIds = courses.map(c => c._id);

            // 2. Find Syllabus chapters to remove
            const chaptersToRemove = await chapterRepository.find({
                course: { $in: courseIds },
                title: 'Syllabus',
                deleted: { $ne: true }
            });

            console.log(`Found ${chaptersToRemove.length} Syllabus chapters to remove.`);

            let count = 0;
            for (const chapter of chaptersToRemove) {
                // Remove lectures
                if (chapter.lectures && chapter.lectures.length > 0) {
                    await lectureRepository.deleteMany({
                        _id: { $in: chapter.lectures }
                    });
                }

                // Remove Chapter from Course
                await courseRepository.findOneAndUpdate(
                    { _id: chapter.course },
                    { $pull: { chapters: chapter._id } },
                    { multi: false }
                );

                // Delete Chapter
                await chapterRepository.deleteMany({ _id: chapter._id });

                count++;
            }

            console.log(`Successfully removed ${count} Syllabus chapters.`);
            return { success: true, count };

        } catch (error: any) {
            console.error('Error removing Syllabus chapters:', error);
            return { success: false, count: 0, error: error.message };
        }
    }

    async removeDuplicateLectures(): Promise<{ success: boolean; count: number; error?: string }> {
        try {
            console.log('Starting cleanup of duplicate Course Criteria lectures...');

            // 1. Find all courses for this university
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: { $ne: true }
            }).select('_id');
            const courseIds = courses.map(c => c._id);

            // 2. Find Syllabus chapters
            const chapters = await chapterRepository.find({
                course: { $in: courseIds },
                title: { $in: ['Syllabus', 'Introduction'] },
                deleted: { $ne: true }
            });

            console.log(`Found ${chapters.length} Syllabus chapters. Checking for duplicates...`);

            let removedCount = 0;

            for (const chapter of chapters) {
                if (!chapter.lectures || chapter.lectures.length === 0) continue;

                // Fetch lectures for this chapter
                const lectures = await lectureRepository.find({
                    _id: { $in: chapter.lectures },
                    deleted: { $ne: true }
                });

                // Filter for "Course Criteria"
                // Also check for "Syllabus Document" just in case they weren't renamed, 
                // but user specifically asked for "Course Criteria".
                const criteriaLectures = lectures.filter(l =>
                    l.title === 'Course Criteria'
                );

                if (criteriaLectures.length > 1) {
                    console.log(`Chapter ${chapter._id} has ${criteriaLectures.length} criteria lectures. Keeping the last one.`);

                    // Assuming the order in 'lectures' array or _id roughly correlates to creation, 
                    // but better to just keep the last one in the list we fetched (or sort by _id generation time if needed).
                    // MongoDB ObjectIds are time-ordered. Let's sort by _id to be safe.
                    // criteriaLectures.sort((a, b) => a._id.toString().localeCompare(b._id.toString())); // Basic sort

                    // Actually, let's keep the one that is last in the finding order is usually insertion order if not modified.
                    // But safe bet: Keep the last one created.

                    const sorted = criteriaLectures.sort((a: any, b: any) => {
                        // creation time from ObjectId
                        return parseInt(a._id.toString().substring(0, 8), 16) - parseInt(b._id.toString().substring(0, 8), 16);
                    });

                    // Keep the last one (newest)
                    const toKeep = sorted[sorted.length - 1];
                    const toRemove = sorted.slice(0, sorted.length - 1);

                    for (const lectureToRemove of toRemove) {
                        // Delete lecture
                        await lectureRepository.deleteMany({ _id: lectureToRemove._id });

                        // Remove from Chapter
                        await chapterRepository.findOneAndUpdate(
                            { _id: chapter._id },
                            { $pull: { lectures: lectureToRemove._id } },
                            { multi: false }
                        );

                        removedCount++;
                    }
                }
            }

            console.log(`Successfully removed ${removedCount} duplicate lectures.`);
            return { success: true, count: removedCount };

        } catch (error: any) {
            console.error('Error removing duplicate lectures:', error);
            return { success: false, count: 0, error: error.message };
        }
    }

    async reorderSyllabusChapters(): Promise<{ success: boolean; count: number; error?: string }> {
        try {
            console.log('Starting reordering of Syllabus chapters...');

            // 1. Find all courses for this university
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: { $ne: true }
            }).select('_id chapters');

            console.log(`Checking ${courses.length} courses for reordering...`);

            let reorderedCount = 0;

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                // 2. Find Syllabus/Introduction chapter ID
                // Fetch all chapters for this course
                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters },
                    deleted: { $ne: true }
                }).select('_id title');

                const syllabusChapter = chapters.find(c =>
                    c.title && (c.title.toLowerCase() === 'syllabus' || c.title.toLowerCase() === 'introduction')
                );

                if (syllabusChapter) {
                    const syllabusId = syllabusChapter._id.toString();
                    const currentChapters = course.chapters.map((id: any) => id.toString());
                    const currentIndex = currentChapters.indexOf(syllabusId);

                    if (currentIndex > 0) { // If it exists and is NOT first
                        console.log(`Reordering course ${course._id}: Syllabus (index ${currentIndex}) -> 0`);

                        // Move to front
                        currentChapters.splice(currentIndex, 1);
                        currentChapters.unshift(syllabusId);

                        // Update Course
                        await courseRepository.findOneAndUpdate(
                            { _id: course._id },
                            { $set: { chapters: currentChapters } },
                            { multi: false }
                        );
                        reorderedCount++;
                    }
                }
            }

            console.log(`Successfully reordered ${reorderedCount} courses.`);
            return { success: true, count: reorderedCount };

        } catch (error: any) {
            console.error('Error reordering Syllabus chapters:', error);
            return { success: false, count: 0, error: error.message };
        }
    }

    async process(): Promise<{ success: boolean; url?: string; error?: string }> {
        try {
            // 1. Get university config
            this.universityConfig = await universityConfigurationRepository.findOne({
                university: this.universityId
            }).lean();

            if (!this.universityConfig) {
                throw new Error('University configuration not found');
            }

            // 2. Upload to S3
            const s3 = new S3University(this.universityConfig, true);
            const extension = this.file.originalname ? path.extname(this.file.originalname) : '.pdf';
            const filename = `${uuidV4()}-syllabus${extension}`;

            // We need to write the buffer to a temp file for S3 upload if it's a buffer
            // Assuming 'file' has a buffer property and originalname
            const tempPath = `/tmp/${filename}`;
            fs.writeFileSync(tempPath, this.file.buffer);

            let uploadedUrl: string;
            try {
                uploadedUrl = await s3.upload(
                    tempPath,
                    filename,
                    this.universityConfig.buckets.LMS_COURSE_VIDEOS // Using the same bucket for safely
                );
            } finally {
                // Cleanup temp file
                if (fs.existsSync(tempPath)) {
                    fs.unlinkSync(tempPath);
                }
            }

            if (!uploadedUrl) {
                throw new Error('Failed to upload file to S3');
            }

            console.log(`Uploaded syllabus to: ${uploadedUrl}`);

            // 3. Update All Courses
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: { $ne: true }
            }).select('_id owner intro');

            console.log(`Found ${courses.length} courses to update.`);

            let successCount = 0;
            for (const course of courses) {
                try {
                    await this.updateCourseWithSyllabus(course, uploadedUrl);
                    successCount++;
                } catch (err: any) {
                    console.error(`Failed to update course ${course._id}:`, err);
                }
            }

            return { success: true, url: uploadedUrl };

        } catch (error: any) {
            console.error('Error in SyllabusUploadService:', error);
            return { success: false, error: error.message };
        }
    }

    private async updateCourseWithSyllabus(course: any, documentUrl: string): Promise<void> {

        // 2. Find or Create "Syllabus" Chapter
        const chapters = await chapterRepository.find({
            course: course._id
        });

        let chapter = chapters.find(c => c.title.toLowerCase() === 'syllabus' || c.title.toLowerCase() === 'introduction');

        if (!chapter) {
            console.log('Creating new Syllabus chapter');
            // If we are creating a Syllabus chapter, we might want it to be the FIRST chapter.
            // But we can't easily reorder everything here without more logic.
            // For now, we append it.

            chapter = await chapterRepository.create({
                course: course._id,
                owner: course.owner,
                title: 'Syllabus',
                lectures: []
            });

            // Add to Course
            // We use unshift to put it at the beginning of the chapters array if possible, 
            // but $addToSet doesn't support position. $push with $position: 0 does.
            // However, to be safe and consistent with other scripts, let's just add it.
            // If the user wants it first, we might need to handle that specifically.
            // Standard approach:
            await courseRepository.findOneAndUpdate(
                { _id: course._id },
                { $addToSet: { chapters: chapter._id } },
                { multi: false }
            );
        }

        // 3. Create "Course Criteria" Lecture
        console.log('Creating new Course Criteria lecture');
        const lecture = await lectureRepository.create({
            course: course._id,
            owner: course.owner,
            title: 'Course Criteria',
            pages: [{
                title: 'Course Criteria',
                contentType: 'document',
                assetUrl: documentUrl,
                time: 300 // 5 mins
            }]
        });

        // 4. Add Lecture to Chapter
        await chapterRepository.findOneAndUpdate(
            { _id: chapter._id },
            { $addToSet: { lectures: lecture._id } },
            { multi: false }
        );

        // 5. Update Course Intro (optional but good practice for syllabus)
        // Only if it doesn't have one
        if (!course.intro) {
            await courseRepository.findOneAndUpdate(
                { _id: course._id },
                { $set: { intro: documentUrl } },
                { multi: false }
            );
        }
    }
}
