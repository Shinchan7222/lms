import { TaskStatus as TaskStatusModel, taskStatusRepository, TaskStatusType } from '@edorer/script-data';

export type TaskStatus = 'in_progress' | 'done';

export interface TaskRecord {
  id: string; // Format: "Course - Unit - Topic"
  status: TaskStatus;
  topicName: string;
  unitName: string;
  courseName: string;
  programName?: string;
  createdAt?: string;
  updatedAt?: string;
  startedAt?: string;
  completedAt?: string;
}

export class TaskStatusManager {
  private readonly STALE_TASK_HOURS = 3;

  constructor(statusFilePath?: string) {
    // statusFilePath parameter kept for backward compatibility but no longer used
  }

  /**
   * Clean up tasks that have been in_progress for more than 3 hours
   * This method is called automatically on every fetch operation
   */
  private async cleanupStaleTasks(): Promise<void> {
    const threeHoursAgo = new Date();
    threeHoursAgo.setHours(threeHoursAgo.getHours() - this.STALE_TASK_HOURS);

    // Delete tasks that are in_progress and started more than 3 hours ago
    // Use startedAt if available, otherwise fall back to updatedAt
    await taskStatusRepository.deleteMany(
      {
        status: 'in_progress',
        $or: [
          { startedAt: { $lt: threeHoursAgo } },
          { startedAt: { $exists: false }, updatedAt: { $lt: threeHoursAgo } }
        ]
      }
    );
  }

  /**
   * Generate task ID in format: "Course - Unit - Topic"
   */
  generateTaskId(courseName: string, unitName: string, topicName: string): string {
    return `${courseName} - ${unitName} - ${topicName}`;
  }

  /**
   * Check if a task should be skipped (already done or in progress)
   * Returns false if task doesn't exist (can be processed)
   */
  async shouldSkipTask(taskId: string): Promise<boolean> {
    await this.cleanupStaleTasks();
    const task = await taskStatusRepository.findOne({ id: taskId }).lean();
    // Only skip if task exists and is done or in_progress
    // If task doesn't exist, return false (don't skip, can be processed)
    if (!task) {
      return false;
    }
    return task.status === 'done' || task.status === 'in_progress';
  }

  /**
   * Get task status
   */
  async getTaskStatus(taskId: string): Promise<TaskStatus | null> {
    await this.cleanupStaleTasks();
    const task = await taskStatusRepository.findOne({ id: taskId }).lean();
    return task?.status || null;
  }

  /**
   * Reserve a task (mark as in_progress)
   * Returns true if successfully reserved, false if already exists with different status
   */
  async reserveTask(
    courseName: string,
    unitName: string,
    topicName: string,
    programName?: string
  ): Promise<boolean> {
    await this.cleanupStaleTasks();
    const taskId = this.generateTaskId(courseName, unitName, topicName);

    const existingTask = await taskStatusRepository.findOne({ id: taskId }).lean();

    if (existingTask) {
      // If already done, don't reserve
      if (existingTask.status === 'done') {
        return false;
      }
      // If already in progress, don't reserve again
      if (existingTask.status === 'in_progress') {
        return false;
      }
      // Should not happen, but update to in_progress if somehow status is invalid
      await taskStatusRepository.update(
        { id: taskId },
        {
          $set: {
            status: 'in_progress',
            startedAt: new Date(),
            updatedAt: new Date()
          }
        },
        { multi: false }
      );
    } else {
      // Create new task as in_progress using atomic operation
      try {
        const newTask = new TaskStatusModel({
          id: taskId,
          status: 'in_progress',
          topicName,
          unitName,
          courseName,
          programName,
          startedAt: new Date()
        });
        await newTask.save();
      } catch (error: any) {
        // If task was created by another process between check and create, check status
        if (error.code === 11000) { // Duplicate key error
          const task = await taskStatusRepository.findOne({ id: taskId }).lean();
          if (task && (task.status === 'done' || task.status === 'in_progress')) {
            return false;
          }
        }
        throw error;
      }
    }

    return true;
  }

  /**
   * Mark a task as done
   */
  async markTaskDone(taskId: string): Promise<void> {
    await taskStatusRepository.update(
      { id: taskId },
      {
        $set: {
          status: 'done',
          completedAt: new Date(),
          updatedAt: new Date()
        }
      },
      { multi: false }
    );
  }

  /**
   * Remove a task from the database (useful when error occurs and task should be retried)
   */
  async removeTask(taskId: string): Promise<void> {
    await taskStatusRepository.delete({ id: taskId });
  }

  /**
   * Get all tasks with a specific status
   */
  async getTasksByStatus(status: TaskStatus): Promise<TaskRecord[]> {
    await this.cleanupStaleTasks();
    const tasks = await taskStatusRepository.find({ status }).lean();
    return tasks.map(task => this.mapTaskToRecord(task));
  }

  /**
   * Get all tasks
   */
  async getAllTasks(): Promise<TaskRecord[]> {
    await this.cleanupStaleTasks();
    const tasks = await taskStatusRepository.find({}).lean();
    return tasks.map(task => this.mapTaskToRecord(task));
  }

  /**
   * Map database task to TaskRecord interface
   */
  private mapTaskToRecord(task: any): TaskRecord {
    return {
      id: task.id,
      status: task.status,
      topicName: task.topicName,
      unitName: task.unitName,
      courseName: task.courseName,
      programName: task.programName,
      createdAt: task.createdAt ? task.createdAt.toISOString() : undefined,
      updatedAt: task.updatedAt ? task.updatedAt.toISOString() : undefined,
      startedAt: task.startedAt ? task.startedAt.toISOString() : undefined,
      completedAt: task.completedAt ? task.completedAt.toISOString() : undefined
    };
  }

  /**
   * Initialize tasks from a list of groups (useful for initial setup)
   * Note: This method is kept for compatibility but doesn't create tasks anymore
   * Tasks are only created when they're actually being processed (in_progress)
   */
  async initializeTasks(groups: Array<{
    topicName: string;
    unitName: string;
    courseName: string;
    programName?: string;
  }>): Promise<void> {
    // No-op: Tasks are only created when they're actually being processed
    // This method is kept for compatibility but doesn't do anything
    return;
  }
}

