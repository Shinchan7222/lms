import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { CourseStructureReorganizerService } from './CourseStructureReorganizerService';

export class OrphanLectureMergerService {
    private readonly universityId: string;
    private changes: string[] = [];
    private reorganizer: CourseStructureReorganizerService;

    constructor(universityId: string) {
        this.universityId = universityId;
        this.reorganizer = new CourseStructureReorganizerService(universityId);
    }

    async check(): Promise<{
        message: string;
        totalOrphans: number;
        details: any[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let totalOrphans = 0;
            const details: any[] = [];

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length === 0) continue;

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    for (const lecture of lectures) {
                        if (this.isOrphan(lecture.title)) {
                            totalOrphans++;
                            details.push({
                                courseTitle: course.title,
                                chapterTitle: chapter.title,
                                lectureTitle: lecture.title,
                                lectureId: lecture._id
                            });
                        }
                    }
                }
            }

            return {
                message: 'Orphan lecture check completed',
                totalOrphans,
                details: details.slice(0, 50)
            };

        } catch (error: any) {
            console.error('Error checking orphans:', error);
            return {
                message: 'Error checking orphans',
                totalOrphans: 0,
                details: [],
                error: error.message
            };
        }
    }

    async process(): Promise<{
        message: string;
        totalOrphansMerged: number;
        changes: string[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let totalOrphansMerged = 0;
            this.changes = [];

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                let courseModified = false;

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length <= 1) continue;

                    // Rename TOPIC -> Unit and re-index first
                    const lecturesRenamed = await this.reorganizer.processLectures(chapter, course.title, chapter.title);
                    if (lecturesRenamed) {
                        this.changes.push(`[Course: ${course.title} | Chapter: ${chapter.title}] Renamed/Re-indexed TOPIC/Unit lectures`);
                        courseModified = true;
                    }

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    // Identify orphans and target
                    const orphans: any[] = [];
                    let targetUnit: any = null;

                    // Sort to find "Unit 1" or first Unit reliably?
                    // Usually we want to merge into the first valid Unit.

                    // Separate
                    for (const lecture of lectures) {
                        if (this.isOrphan(lecture.title)) {
                            orphans.push(lecture);
                        } else if (!targetUnit && this.isUnit(lecture.title)) {
                            targetUnit = lecture; // Pick the first Unit found as target. Ideally Unit 1.
                        }
                    }

                    // If no "Unit" found, try "Ebook" or just the first non-orphan?
                    // Requirement: "put the content inside the other lecture that have Unit 1"
                    // If no Unit 1, maybe wait? Or find *any* Unit.
                    // If multiple units, "Unit 1" is best.

                    if (!targetUnit) {
                        // Try to find any lecture that looks like a main container
                        targetUnit = lectures.find(l => this.isUnit(l.title));
                    }

                    if (orphans.length > 0 && targetUnit) {
                        let chapterModified = false;
                        for (const orphan of orphans) {
                            // Merge content
                            if (orphan.pages && orphan.pages.length > 0) {
                                if (!targetUnit.pages) targetUnit.pages = [];
                                targetUnit.pages.push(...orphan.pages);
                                await targetUnit.save();
                            }

                            // Delete orphan
                            orphan.deleted = true; // Soft delete
                            await orphan.save();

                            // Remove from chapter
                            const idx = chapter.lectures.findIndex((id: any) => id.toString() === orphan._id.toString());
                            if (idx > -1) {
                                chapter.lectures.splice(idx, 1);
                                chapterModified = true;
                            }

                            this.changes.push(`[Course: ${course.title} | Chapter: ${chapter.title}] Merged orphan "${orphan.title}" into "${targetUnit.title}"`);
                            totalOrphansMerged++;
                        }

                        if (chapterModified) {
                            await chapter.save();
                        }
                    }
                }
            }

            return {
                message: 'Orphan lecture merge completed',
                totalOrphansMerged,
                changes: this.changes
            };

        } catch (error: any) {
            console.error('Error merging orphans:', error);
            return {
                message: 'Error merging orphans',
                totalOrphansMerged: 0,
                changes: [],
                error: error.message
            };
        }
    }

    private isOrphan(title: string): boolean {
        const t = title.trim();
        // Not a Unit, not Ebook, not Assignment, not Quiz, not Question
        if (t.match(/^Unit/i)) return false;
        if (t.match(/^\*?\s*Unit/i)) return false; // Covers * Unit
        if (t.match(/^E(\s*-?\s*)?Book/i)) return false;
        if (t.match(/^Assignment/i)) return false;
        if (t.match(/^Quiz/i)) return false;
        if (t.match(/^Question/i)) return false;
        if (t.match(/^Introduction/i)) return false; // Usually separate
        if (t.match(/^Syllabus/i)) return false;
        if (t.match(/^Course\s+Introduction/i)) return false;
        if (t.match(/^Course\s+Criteria/i)) return false;

        // If it looks like just text e.g. "Organizational Structure and Design"
        return true;
    }

    private isUnit(title: string): boolean {
        return !!title.trim().match(/^\*?\s*Unit/i);
    }
}
