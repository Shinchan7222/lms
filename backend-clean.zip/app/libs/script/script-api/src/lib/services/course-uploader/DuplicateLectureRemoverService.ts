import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { CourseStructureReorganizerService } from './CourseStructureReorganizerService';

export class DuplicateLectureRemoverService {
    private readonly universityId: string;
    private reorganizer: CourseStructureReorganizerService;

    constructor(universityId: string) {
        this.universityId = universityId;
        this.reorganizer = new CourseStructureReorganizerService(universityId);
    }

    async process(): Promise<{
        message: string;
        totalLecturesRemoved: number;
        changes: string[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let totalLecturesRemoved = 0;
            const changes: string[] = [];

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length === 0) continue;

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    // Group by normalized name
                    const groupedLectures = new Map<string, any[]>();

                    for (const lecture of lectures) {
                        let name = lecture.title || '';
                        // Normalize: Remove "* Unit {i} - " or "Unit {i} - " prefix
                        const normalized = name.replace(/^(\*?)\s*Unit\s+\d+\s*[-:]?\s*/i, '').trim();

                        if (normalized === '') continue; // Skip empty normalized names? Or treat them as duplicates? 
                        // If empty, it means title was just "Unit 1" etc. Maybe safer to compare normalized.

                        if (!groupedLectures.has(normalized)) {
                            groupedLectures.set(normalized, []);
                        }
                        groupedLectures.get(normalized)?.push(lecture);
                    }

                    let chapterModified = false;

                    for (const [normalizedName, group] of groupedLectures.entries()) {
                        if (group.length > 1) {
                            // Sort by createdAt descending to keep the latest
                            // If createdAt is missing, use _id (timestamp embedded)
                            group.sort((a, b) => {
                                const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                                const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                                if (timeA !== timeB) return timeB - timeA;
                                return b._id.toString().localeCompare(a._id.toString());
                            });

                            const toKeep = group[0];
                            const toRemove = group.slice(1);

                            for (const lectureToRemove of toRemove) {
                                lectureToRemove.deleted = true;
                                await lectureToRemove.save();
                                changes.push(`[Course: ${course.title} | Chapter: ${chapter.title}] Removed duplicate lecture "${lectureToRemove.title}" (ID: ${lectureToRemove._id}), kept "${toKeep.title}" (ID: ${toKeep._id})`);

                                const idx = chapter.lectures.findIndex((id: any) => id.toString() === lectureToRemove._id.toString());
                                if (idx > -1) {
                                    chapter.lectures.splice(idx, 1);
                                }
                            }
                            totalLecturesRemoved += toRemove.length;
                            chapterModified = true;
                        }
                    }

                    if (chapterModified) {
                        await chapter.save();
                        // Re-index units
                        await this.reorganizer.processLectures(chapter, course.title, chapter.title);
                        await chapter.save(); // Save again after reordering
                    }
                }
            }

            return {
                message: 'Duplicate lecture removal completed',
                totalLecturesRemoved,
                changes
            };

        } catch (error: any) {
            console.error('Error removing duplicate lectures:', error);
            return {
                message: 'Error removing duplicate lectures',
                totalLecturesRemoved: 0,
                changes: [],
                error: error.message
            };
        }
    }
}
