import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';

export class CourseStructureReorganizerService {
    private readonly universityId: string;
    private changes: string[] = [];

    constructor(universityId: string) {
        this.universityId = universityId;
    }

    async process(): Promise<{ success: boolean; count: number; changes: string[]; error?: string }> {
        try {
            // 1. Fetch all courses for the university
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let processedCount = 0;

            for (const course of courses) {
                await this.processCourse(course);
                processedCount++;
            }

            return { success: true, count: processedCount, changes: this.changes };
        } catch (error: any) {
            console.error('Error reorganizing course structure:', error);
            return { success: false, count: 0, changes: [], error: error.message };
        }
    }

    private async processCourse(course: any) {
        // 2. Fetch all chapters for the course
        const chapters = await chapterRepository.find({
            course: course._id,
        });

        if (!chapters || chapters.length === 0) return;

        // 3. Rename Chapters: "Unit {i}" -> "Module {i}"
        const processedChapters = [];

        for (const chapter of chapters) {
            let title = chapter.title || '';
            const oldChapterName = title;
            let isChanged = false;

            const unitMatch = title.trim().match(/^UNIT\s+(\d+)(.*)$/i);

            if (unitMatch) {
                const number = unitMatch[1];
                const suffix = unitMatch[2] || '';
                const newTitle = `Module ${number}${suffix}`;
                this.changes.push(`[Course: ${course.title}]\n  Old Chapter: "${oldChapterName}"\n  New Chapter: "${newTitle}"`);
                title = newTitle;
                chapter.title = title;
                isChanged = true;
            }

            const lecturesChanged = await this.processLectures(chapter, course.title, oldChapterName);

            if (isChanged || lecturesChanged) {
                await chapter.save();
                if (!isChanged && lecturesChanged) {
                    this.changes.push(`[Course: ${course.title}]\n  Chapter: "${title}" (Lectures modified/reordered)`);
                }
            }

            processedChapters.push(chapter);
        }

        // 4. Reorder Chapters
        const originalOrder = processedChapters.map(c => c.title).join(', ');

        processedChapters.sort((a, b) => {
            const aMatch = a.title.match(/^Module\s+(\d+)$/i);
            const bMatch = b.title.match(/^Module\s+(\d+)$/i);

            if (aMatch && bMatch) {
                return parseInt(aMatch[1], 10) - parseInt(bMatch[1], 10);
            }
            if (aMatch) return -1;
            if (bMatch) return 1;
            return 0;
        });

        const newOrder = processedChapters.map(c => c.title).join(', ');
        if (originalOrder !== newOrder) {
            course.chapters = processedChapters.map(c => c._id);
            await course.save();
        }
    }

    public async processLectures(chapter: any, courseTitle: string, chapterTitle: string): Promise<boolean> {
        if (!chapter.lectures || chapter.lectures.length === 0) return false;

        const lectures = await lectureRepository.find({
            _id: { $in: chapter.lectures }
        });

        let isLectureChanged = false;

        // Identify and Sort Topic Lectures first to ensure correct sequence processing
        const topicLectures: any[] = [];
        const otherLectures: any[] = [];

        for (const lecture of lectures) {
            const title = lecture.title || '';
            // Capture star optionally
            const topicMatch = title.trim().match(/^(\*?)\s*TOPIC\s+(\d+)(.*)$/i);
            // Also match already renamed "Unit" lectures if we are re-running? 
            // Requirement implies we are working on "TOPIC" lectures. 
            // If they are already "Unit", we might need to be careful not to re-process if not desired, 
            // but user wants re-indexing so maybe we should process "Unit" too if they fit pattern?
            // user says "if lecture have TOPIC {i}". I will stick to TOPIC for now.

            if (topicMatch) {
                topicLectures.push({
                    lecture,
                    star: topicMatch[1] || '',
                    number: parseInt(topicMatch[2], 10),
                    suffix: topicMatch[3] || '',
                    originalTitle: title
                });
            } else {
                otherLectures.push(lecture);
            }
        }

        // Sort by original Topic number
        topicLectures.sort((a, b) => a.number - b.number);

        // Group and Re-index
        let currentUnitIndex = 0;
        let lastBaseName = '';

        for (const item of topicLectures) {
            // Determine Base Name: remove leading " - " or similar, and trailing numbers
            let cleanSuffix = item.suffix.trim();
            // Remove leading punctuation common in titles
            cleanSuffix = cleanSuffix.replace(/^[-:]\s*/, '');

            // Extract base name by removing trailing numbers
            // e.g. "Secant Method 1" -> "Secant Method"
            // "Introduction" -> "Introduction"
            const baseNameMatch = cleanSuffix.match(/^(.*?)(\s+\d+)?$/);
            const baseName = baseNameMatch ? baseNameMatch[1].trim().toLowerCase() : cleanSuffix.toLowerCase();

            if (baseName !== lastBaseName) {
                currentUnitIndex++;
                lastBaseName = baseName;
            }

            const newTitle = `${item.star}Unit ${currentUnitIndex}${item.suffix}`;

            if (item.lecture.title !== newTitle) {
                this.changes.push(`[Course: ${courseTitle} | Chapter: ${chapterTitle}]\n  Old Lecture: "${item.originalTitle}"\n  New Lecture: "${newTitle}"`);
                item.lecture.title = newTitle;
                await item.lecture.save();
                isLectureChanged = true;
            }
        }

        // Reassemble all lectures
        // internal topicLectures are just wrappers, get back lectures
        const processedTopicLectures = topicLectures.map(t => t.lecture);

        // Sort Other Lectures (Quiz, Assignment, Question)
        otherLectures.sort((a, b) => {
            const titleA = a.title.trim();
            const titleB = b.title.trim();

            const isQuizA = titleA.match(/^Quiz$/i);
            const isQuizB = titleB.match(/^Quiz$/i);
            const isQuestionA = titleA.match(/^Question$/i);
            const isQuestionB = titleB.match(/^Question$/i);
            const isAssignmentA = titleA.match(/^Assignment$/i);
            const isAssignmentB = titleB.match(/^Assignment$/i);

            // Order: Others -> ... -> Quiz -> Assignment -> Question?
            // User said: "Quiz should be in the end of chapter"
            // Previous req: "Assignment then Question in the end"
            // Let's put them at the very end in that order? 
            // "Quiz", then "Assignment", then "Question"? Or "Quiz" is last?
            // "Quiz should be in the end" -> usually implies last.
            // Let's assume order: ... -> Assignment -> Quiz -> Question (if any)
            // Or maybe just group them at the end.

            // Assign priorities:
            // Normal: 0
            // Quiz: 10
            // Assignment: 20
            // Question: 30

            // Wait, user screenshot shows: Unit 6, Unit 7, Quiz.
            // Requirement "Assignment then Question in the end".
            // If I have Quiz, Assignment, Question.
            // Maybe: Assignment -> Quiz -> Question? 
            // Let's prioritize:
            // 1. Assignment
            // 2. Quiz
            // 3. Question (User earlier said Assignment THEN Question).
            // User now mentions Quiz.
            // Let's stick to placing them at the end.

            const getPriority = (t: string) => {
                if (t.match(/^Assignment$/i)) return 100;
                if (t.match(/^Quiz$/i)) return 101;
                if (t.match(/^Question$/i)) return 102;
                return 0;
            };

            const pA = getPriority(titleA);
            const pB = getPriority(titleB);

            if (pA !== pB) return pA - pB;

            return 0; // Relative order for others
        });

        // Merge: Units then Others
        const finalLectures = [...processedTopicLectures, ...otherLectures];

        // Check if order changed
        const originalIdOrder = chapter.lectures.map((id: any) => id.toString()).join(',');
        const newIdOrder = finalLectures.map(l => l._id.toString()).join(',');

        if (originalIdOrder !== newIdOrder) {
            chapter.lectures = finalLectures.map(l => l._id);
            return true;
        }

        return isLectureChanged;
    }

    async organizeChapters(): Promise<{ success: boolean; count: number; changes: string[]; error?: string }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            let processedCount = 0;

            for (const course of courses) {
                await this.organizeCourseChapters(course);
                processedCount++;
            }

            return { success: true, count: processedCount, changes: this.changes };
        } catch (error: any) {
            console.error('Error organizing course chapters:', error);
            return { success: false, count: 0, changes: [], error: error.message };
        }
    }

    private async organizeCourseChapters(course: any) {
        if (!course.chapters || course.chapters.length === 0) return;

        const chapters = await chapterRepository.find({
            _id: { $in: course.chapters }
        });

        if (!chapters || chapters.length === 0) return;

        const introChapters: any[] = [];
        const contentChapters: any[] = [];
        const moduleChapters: any[] = [];
        const otherChapters: any[] = [];

        // 1. Categorize Chapters
        for (const chapter of chapters) {
            const title = chapter.title ? chapter.title.trim() : '';

            if (title.match(/^Introduction/i) || title.match(/^Syllabus/i)) {
                introChapters.push(chapter);
            } else if (title.match(/^Content/i)) {
                contentChapters.push(chapter);
            } else if (title.match(/^Module\s+\d+/i)) {
                moduleChapters.push(chapter);
            } else {
                otherChapters.push(chapter);
            }
        }

        // 2. Sort & Renumber Module Chapters
        // Sort by Module number
        moduleChapters.sort((a, b) => {
            const aMatch = a.title.match(/^Module\s+(\d+)/i);
            const bMatch = b.title.match(/^Module\s+(\d+)/i);
            const numA = aMatch ? parseInt(aMatch[1], 10) : 0;
            const numB = bMatch ? parseInt(bMatch[1], 10) : 0;
            return numA - numB;
        });

        // Resolve duplicates
        // We want to ensure strictly increasing numbers if duplicates exist.
        // e.g. Module 1, Module 1, Module 2 -> Module 1, Module 2, Module 3 ??
        // "if two module have same number, make the increase 1."
        // Interpreted as: if we encounter Module 1, and then another Module 1, the second becomes Module 2.
        // If there was already a Module 2, it might need to become Module 3, or stay Module 2 if we only fix the duplicate?
        // User said: "if two module have same number, make the increase 1."
        // Let's assume we want a sequence. But wait, modules might have suffixes "Module 1 - Intro".
        // If we rename, we change the number but keep suffix?
        // Let's try to just ensure uniqueness of the number part for the sorted list.

        let lastNum = 0;
        const usedNumbers = new Set<number>();

        for (const chapter of moduleChapters) {
            const title = chapter.title;
            const match = title.match(/^(Module\s+)(\d+)(.*)$/i);
            if (!match) continue; // Should not happen given regex above

            const prefix = match[1]; // "Module "
            let currentNum = parseInt(match[2], 10);
            const suffix = match[3] || '';

            // If this number is already used, or <= lastNum (implied order issue? No, sorting handles order. Duplicates is the issue)
            // Wait, if we have Module 1, Module 2. Sorted -> 1, 2. No conflict.
            // Module 1, Module 1. Sorted -> 1, 1.
            // First 1: OK.
            // Second 1: Duplicate! Change to 2.
            // But if we encounter Module 2 later?
            // "Module 1", "Module 1", "Module 2".
            // 1. "Module 1" -> used=1.
            // 2. "Module 1" -> used=1. Duplicate! Becomes 2. used=2.
            // 3. "Module 2" -> used=2. Duplicate! Becomes 3. used=3.
            // So essentially we are enforcing strictly increasing numbers for the sorted list if there's a collision.

            // Actually, we can just track `expectedNum`.
            // But gaps are probably allowed? e.g. Module 1, Module 3.
            // User: "if two module have same number, make the increase 1."
            // This implies: If currentNum <= lastNum (and not 0), then newNum = lastNum + 1.
            // NOT strictly resetting sequence (1,2,3...), but resolving conflicts.
            // Example: 1, 1, 5, 5 -> 1, 2, 5, 6.

            if (usedNumbers.has(currentNum)) {
                // Find next available number starting from currentNum + 1?
                // Or simply increment last stored number?
                // If we have 1, 1, 2.
                // 1 -> OK. Max=1.
                // 1 -> Conflict. Make it 2. Max=2.
                // 2 -> Conflict (with the new 2). Make it 3. Max=3.
                // Correct.

                // We need to keep track of ALL used numbers so far in this re-process?
                // No, "usedNumbers" is checking against what we have SEEN so far in the sorted list.
                // But we must also ensure we don't collide with FUTURE numbers if we increment?
                // The sort ensures we process in order.
                // If 1, 1, 2. We process 1. Then 1->2. Then 2->3.

                // What if 1, 1, 10.
                // 1 -> OK.
                // 1 -> 2.
                // 10 -> OK (2 < 10).

                // So the logic:
                // if (currentNum <= lastNum) {
                //      currentNum = lastNum + 1;
                // }
                // This would force compacting gaps?
                // 1, 5. last=1. current=5. 5 > 1. OK. last=5.
                // 1, 1, 5. last=1. current=1. 1<=1. new=2. last=2. next is 5.
                // This works for "if same number increase 1".
                // Does it force "Module 1, Module 2 ..." instead of "Module 1, Module 5"? No.

                // But wait, "if two module have same number".
                // My logic `if (currentNum <= lastNum)` captures same number AND out of order?
                // Sorted array. So currentNum is always >= prevNum.
                // So `currentNum === prevNum` is the duplicate case.

                // But what if: 1, 1, 2.
                // 1. last=1.
                // 1. == last. new=2. last=2.
                // 2. == last. new=3. last=3.
                // This seems correct.

                if (currentNum <= lastNum && lastNum !== 0) {
                    currentNum = lastNum + 1;
                }
            }

            usedNumbers.add(currentNum);
            lastNum = currentNum;

            const newTitle = `${prefix}${currentNum}${suffix}`;
            if (chapter.title !== newTitle) {
                this.changes.push(`[Course: ${course.title}]\n  Old Module: "${chapter.title}"\n  New Module: "${newTitle}"`);
                chapter.title = newTitle;
                await chapter.save();
            }
        }

        // 3. Construct Final List
        const finalOrder = [
            ...introChapters,
            ...moduleChapters,
            ...otherChapters,
            ...contentChapters
        ];

        // 4. Update Course
        const originalIdOrder = course.chapters.map((id: any) => id.toString()).join(',');
        const newIdOrder = finalOrder.map(c => c._id.toString()).join(',');

        if (originalIdOrder !== newIdOrder) {
            course.chapters = finalOrder.map((c: any) => c._id);
            await course.save();
            this.changes.push(`[Course: ${course.title}]\n  Updated Chapter Order`);
        }
    }
}
