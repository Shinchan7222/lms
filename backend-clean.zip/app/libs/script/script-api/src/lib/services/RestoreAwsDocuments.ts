const util = require('util');
const exec = util.promisify(require('child_process').exec);

import { assetsRepository } from '@edorer/assets-data';
import { classroomWorkRepository } from '@edorer/classroom-work-data';
import { courseRepository } from '@edorer/course-data';
import { examRepository } from '@edorer/exam-data';
import { existsSync, readFileSync, writeFileSync } from 'fs';
import { lectureRepository } from '@edorer/lecture-data';
import { mailer } from '@edorer/mailer';
import { programRepository } from '@edorer/program-data';
import { ProgramResult, programResultRepository } from '@edorer/program-result-data';
import { questionRepository } from '@edorer/question-data';
import { Types } from 'mongoose';
import { userDynamicDataRepository } from '@edorer/user-dynamic-data';
import { videoUploaderRepository } from '@edorer/video-uploader-data';

export class RestoreAwsDocuments {
  private readonly batch: number;
  private readonly instance: number;
  private readonly university: string;

  private setUrls: Set<string> = new Set();

  constructor(batch: number, instance: number, university: string) {
    this.batch = batch;
    this.instance = instance;
    this.university = university;
  }

  async restore() {
    // await this.fetchAssets();
    // await this.fetchClassroomWorks();
    // await this.fetchCourseAssets();
    // await this.fetchDynamicValues();
    // await this.fetchExams();
    // await this.fetchLectures();
    await this.fetchProgramResults();
    // await this.fetchPrograms();
    // await this.fetchVideos();

    console.log(`Found ${this.setUrls.size} URLs to restore`);

    await this.restoreDocuments();
  }

  private isValidUrl(url: string): boolean {
    try {
      new URL(url);

      // return (
      //   url.startsWith('https://s3-ap-south-1.amazonaws.com') ||
      //   url.startsWith('https://s3.ap-south-1.amazonaws.com') ||
      //   url.startsWith('https://s3.ap-southeast-1.amazonaws.com') ||
      //   url.startsWith('https://s3-ap-southeast-1.amazonaws.com')
      // );
      return url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private addUrl(url: string): void {
    if (!this.isValidUrl(url)) return;
    if (this.setUrls.has(url)) return;

    this.setUrls.add(url);
  }

  private async fetchAssets() {
    const assetsResult = await assetsRepository.aggregate([
      {
        $match: {
          url: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$url' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const assetUrls = assetsResult.map((item) => item.value).filter((asset) => this.isValidUrl(asset));

    for (let assetUrl of assetUrls) {
      this.addUrl(assetUrl);
    }
  }

  private async fetchClassroomWorks() {
    const documentsResult = await classroomWorkRepository.aggregate([
      {
        $match: {
          document: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$document' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const documentUrls = documentsResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let documentUrl of documentUrls) {
      this.addUrl(documentUrl);
    }

    const imagesResult = await classroomWorkRepository.aggregate([
      {
        $match: {
          images: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$images' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);
    console.log('imagesResult');
    console.log(imagesResult);
    const imageUrls = imagesResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let imageUrl of imageUrls) {
      this.addUrl(imageUrl);
    }

    const videosResult = await classroomWorkRepository.aggregate([
      {
        $match: {
          video: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$video' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const videoUrls = videosResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let videoUrl of videoUrls) {
      this.addUrl(videoUrl);
    }
  }

  private async fetchCourseAssets() {
    const galleriesResult = await courseRepository.aggregate([
      {
        $match: {
          galleries: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$galleries' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const galleryUrls = galleriesResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let galleryUrl of galleryUrls) {
      this.addUrl(galleryUrl);
    }

    const introsResult = await courseRepository.aggregate([
      {
        $match: {
          intro: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$intro' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const introUrls = introsResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let introUrl of introUrls) {
      this.addUrl(introUrl);
    }
  }

  private async fetchDynamicValues() {
    const assetsResult = await userDynamicDataRepository.aggregate([
      {
        $match: {
          data: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$data.value' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const assetUrls = assetsResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let assetUrl of assetUrls) {
      this.addUrl(assetUrl);
    }
  }

  private async fetchExams() {
    const examsResult = await examRepository.aggregate([
      {
        $match: { university: this.university }
      },
      { $group: { _id: '$_id' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const exams = examsResult.map((item) => item.value);

    const contentsResult = await questionRepository.aggregate([
      {
        $match: {
          content: { $regex: 'amazonaws.com' },
          exam: { $in: exams }
        }
      },
      { $group: { _id: '$content' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const contentUrls = contentsResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let contentUrl of contentUrls) {
      this.addUrl(contentUrl);
    }
  }

  private async fetchLectures() {
    const coursesResult = await courseRepository.aggregate([
      {
        $match: { university: Types.ObjectId(this.university) }
      },
      { $group: { _id: '$_id' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const courses = coursesResult.map((item) => item.value);

    const assetsResult = await lectureRepository.aggregate([
      {
        $match: {
          course: { $in: courses },
          'pages.assetUrl': { $regex: 'amazonaws.com' }
        }
      },
      { $unwind: '$pages' },
      { $group: { _id: '$pages.assetUrl' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const assetUrls = assetsResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let assetUrl of assetUrls) {
      this.addUrl(assetUrl);
    }

    const imagesResult = await lectureRepository.aggregate([
      {
        $match: {
          course: { $in: courses },
          'pages.images': { $regex: 'amazonaws.com' }
        }
      },
      { $unwind: '$pages' },
      { $group: { _id: '$pages.images' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const imageUrls = imagesResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let imageUrl of imageUrls) {
      this.addUrl(imageUrl);
    }

    const videosResult = await lectureRepository.aggregate([
      {
        $match: {
          course: { $in: courses },
          'pages.video': { $regex: 'amazonaws.com' }
        }
      },
      { $unwind: '$pages' },
      { $group: { _id: '$pages.video' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const videoUrls = videosResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let videoUrl of videoUrls) {
      this.addUrl(videoUrl);
    }
  }

  private async fetchPrograms() {
    const backgroundImagesResult = await programRepository.aggregate([
      {
        $match: {
          backgroundImage: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$backgroundImage' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const backgroundImageUrls = backgroundImagesResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let backgroundImageUrl of backgroundImageUrls) {
      this.addUrl(backgroundImageUrl);
    }

    const introsResult = await programRepository.aggregate([
      {
        $match: {
          intro: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$intro' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const introUrls = introsResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let introUrl of introUrls) {
      this.addUrl(introUrl);
    }

    const logosResult = await programRepository.aggregate([
      {
        $match: {
          logo: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$logo' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const logoUrls = logosResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let logoUrl of logoUrls) {
      this.addUrl(logoUrl);
    }
  }

  private async fetchProgramResults() {
    const programResult: ProgramResult[] = await programResultRepository
      .find({ dmc: { $regex: 'amazonaws.com' }, university: this.university })
      .lean();

    const assetUrls = programResult.map((item) => item.dmc).filter((url) => this.isValidUrl(url));
    for (let assetUrl of assetUrls) {
      this.addUrl(assetUrl);
    }
  }

  private async fetchVideos() {
    const videosResult = await videoUploaderRepository.aggregate([
      {
        $match: {
          url: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$url' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const urls = videosResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let url of urls) {
      this.addUrl(url);
    }

    const dashedVideosResult = await videoUploaderRepository.aggregate([
      {
        $match: {
          dashedUrl: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$dashedUrl' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const dashedVideoUrls = dashedVideosResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let dashedVideoUrl of dashedVideoUrls) {
      this.addUrl(dashedVideoUrl);
    }

    const watermarkedVideosResult = await videoUploaderRepository.aggregate([
      {
        $match: {
          watermarkedUrl: { $regex: 'amazonaws.com' }
        }
      },
      { $group: { _id: '$watermarkedUrl' } },
      { $project: { _id: 0, value: '$_id' } }
    ]);

    const watermarkedVideoUrls = watermarkedVideosResult.map((item) => item.value).filter((url) => this.isValidUrl(url));
    for (let watermarkedVideoUrl of watermarkedVideoUrls) {
      this.addUrl(watermarkedVideoUrl);
    }
  }

  private async restoreDocuments() {
    // Statistics tracking
    let restored = 0;
    let skipped = 0;
    let failed = 0;
    let alreadyInProgress = 0;

    const urls = Array.from(this.setUrls);

    // Process configuration
    const BATCH_SIZE = this.batch;
    const CONCURRENT_BATCHES = this.instance;
    const BATCH_DELAY_MS = 2000;

    // Resume support - store progress in a file
    const progressFile = process.env.TEMP_DIR + 'restore-progress.json';
    let processedUrls = new Set();

    try {
      if (existsSync(progressFile)) {
        const data = JSON.parse(readFileSync(progressFile, 'utf8'));
        processedUrls = new Set(data.processedUrls || []);
        alreadyInProgress = data.alreadyInProgress || 0;
        failed = data.failed || 0;
        restored = data.restored || 0;
        skipped = data.skipped || 0;

        console.log(`Resuming from previous run: ${processedUrls.size} already processed`);
      }
    } catch (error) {
      console.warn('Could not load progress file, starting fresh', error);
    }

    // Filter out already processed URLs
    const urlsToProcess = urls.filter((url) => !processedUrls.has(url));

    console.log(`Starting restoration of ${urlsToProcess.length} documents (${urls.length - urlsToProcess.length} already processed)`);
    console.log(`Processing in batches of ${BATCH_SIZE} with ${CONCURRENT_BATCHES} concurrent batches`);

    // Process URLs in batches
    for (let i = 0; i < urlsToProcess.length; i += BATCH_SIZE * CONCURRENT_BATCHES) {
      const batchPromises = [];

      for (let j = 0; j < CONCURRENT_BATCHES; j++) {
        const startIdx = i + j * BATCH_SIZE;
        if (startIdx >= urlsToProcess.length) continue;

        const batch = urlsToProcess.slice(startIdx, startIdx + BATCH_SIZE);
        batchPromises.push(this.processBatch(batch, j));
      }

      try {
        // Process batches concurrently
        const batchResults = await Promise.all(batchPromises);

        // Aggregate results
        for (const result of batchResults.flat()) {
          processedUrls.add(result.url);

          if (result.success) {
            if (result.alreadyInProgress) {
              alreadyInProgress++;
            } else {
              restored++;
            }
          } else {
            if (result.skipped) {
              skipped++;
            } else {
              console.log(result);
              console.log(`Failed to restore ${result.url}`, result.reason);
              failed++;
            }
          }
        }

        // Save progress periodically
        const progress = {
          alreadyInProgress,
          failed,
          lastUpdated: new Date().toISOString(),
          processedUrls: Array.from(processedUrls),
          restored,
          skipped
        };

        writeFileSync(progressFile, JSON.stringify(progress, null, 2));

        // Log progress
        const processed = restored + failed + skipped + alreadyInProgress;
        const total = urls.length;
        const percent = ((processed / total) * 100).toFixed(2);

        console.log(
          `Progress: ${processed}/${total} (${percent}%) processed | ` +
            `🟢 ${restored} restored | ` +
            `🔵 ${alreadyInProgress} in progress | ` +
            `🟡 ${skipped} skipped | ` +
            `🔴 ${failed} failed`
        );

        // Delay between batch groups to avoid rate limiting
        if (i + BATCH_SIZE * CONCURRENT_BATCHES < urlsToProcess.length) {
          console.log(`Sleeping for ${BATCH_DELAY_MS}ms before next batch group...`);
          await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY_MS));
        }
      } catch (error) {
        console.error(`Error processing batch group starting at index ${i}:`, error);
      }
    }

    await this.sendMail(restored, alreadyInProgress, skipped, failed);
  }

  private async processBatch(
    urls: string[],
    batchId: number
  ): Promise<
    Array<{
      alreadyInProgress?: boolean;
      key?: string;
      reason?: string;
      skipped?: boolean;
      success: boolean;
      url: string;
    }>
  > {
    return Promise.all(
      urls.map(async (url, index) => {
        if (!this.isValidUrl(url)) {
          return { success: false, url, skipped: true, reason: 'Invalid URL' };
        }

        // Extract the key (filename) from the URL
        // Handle both URL formats: s3.ap-south-1 and s3-ap-south-1
        const urlObj = new URL(url);
        const paths = urlObj.pathname.split('/').filter(Boolean);

        let key = '';
        if (paths.length === 1) {
          key = paths[0];
        } else if (paths.length === 2) {
          key = paths[1];
        } else {
          paths.splice(0, 1);
          key = paths.join('/');
        }

        if (!key) {
          return { success: false, url, skipped: true, reason: 'Could not extract key from URL' };
        }

        try {
          // Use shell escaping for the key to prevent command injection
          const escapedKey = key.replace(/'/g, "'\\''");
          // remove url encoding from the key
          const decodedKey = decodeURIComponent(escapedKey);

          console.log(`[Batch ${batchId}] Processing ${index + 1}/${urls.length}: ${key}`);
          let bucketName = url.split('/')[3];
          // Build the AWS CLI command
          const command = `aws s3api restore-object \
          --bucket ${bucketName} \
          --key '${decodedKey}' \
          --restore-request '{"Days":7,"GlacierJobParameters":{"Tier":"Standard"}}' \
          --profile parul`;

          console.log(command);

          // Execute the command
          const { stdout, stderr } = await exec(command);

          // Check for errors in stderr
          if (stderr && !stderr.includes('RestoreAlreadyInProgress')) {
            return { success: false, url, key, reason: stderr.trim() };
          }

          const isAlreadyInProgress = stderr && stderr.includes('RestoreAlreadyInProgress');

          return {
            success: true,
            url,
            key,
            alreadyInProgress: isAlreadyInProgress
          };
        } catch (error) {
          // Check if this is a "RestoreAlreadyInProgress" error, which is actually OK
          const errorMessage = error instanceof Error ? error.message : '';
          if (errorMessage.includes('RestoreAlreadyInProgress')) {
            return {
              success: true,
              url,
              key,
              alreadyInProgress: true
            };
          }

          // Check for other common AWS errors and provide better messaging
          let reason = error instanceof Error ? error.message : 'Unknown error';
          if (errorMessage.includes('NoSuchKey')) {
            reason = 'File not found in S3';
          } else if (errorMessage.includes('AccessDenied')) {
            reason = 'Access denied - check AWS credentials';
          }

          return { success: false, url, key, reason };
        }
      })
    );
  }

  private async sendMail(restored: number, alreadyInProgress: number, skipped: number, failed: number) {
    console.log(`\nRestoration complete!`);
    console.log(`🟢 ${restored} documents restored successfully`);
    console.log(`🔵 ${alreadyInProgress} documents already in progress`);
    console.log(`🟡 ${skipped} documents skipped`);
    console.log(`🔴 ${failed} documents failed`);

    const mailOptions: any = {};
    mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';
    mailOptions.html = `
      <h4>Restoration complete!</h4>
      <ul>
        <li><strong>Restored:</strong> ${restored}</li>
        <li><strong>Failed:</strong> ${failed}</li>
        <li><strong>In progress:</strong> ${alreadyInProgress}</li>
        <li><strong>Skipped:</strong> ${skipped}</li>
        <li><strong>Total:</strong> ${this.setUrls.size}</li>
      </ul>
      
      </br></br></br></br>
      <p>Best regards,</p>
      <p><em>This is an automated message, please do not reply directly to this email.</em></p>
    `;
    mailOptions.subject = `Restoration complete`;
    mailOptions.to = 'abdul@edorer.com';

    mailer.init();

    await mailer.send(mailOptions);
  }
}
