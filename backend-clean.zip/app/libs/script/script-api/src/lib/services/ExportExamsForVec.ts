import { Category, categoryRepository } from '@edorer/category-data';
import { Exam } from '@edorer/exam-data';
import { ExportQuestionsForVec } from './ExportQuestionsForVec';
import { Question, questionRepository } from '@edorer/question-data';
import { StringUtils } from '@edorer/utils';

export class ExportExamsForVec {

    private convertedExam: any = {};

    private categories: Category[] = [];

    private questions: Question[] = [];

    private readonly exam: Exam;

    private readonly owner: string;

    constructor(exam: Exam, owner: string) {
        this.exam = exam;
        this.owner = owner;
    }

    async convert() {
        await this.fetchQuestions();
        await this.fetchCategories();
        this.prepareExam();

        return this.convertedExam;
    }

    private async fetchQuestions() {
        const questions = await questionRepository.find({ _id: { $in: this.exam.questions } }).populate('category').lean();
        const exportQuestionsForVec = new ExportQuestionsForVec(this.owner, questions);
        this.questions = exportQuestionsForVec.convert();
    }

    private async fetchCategories() {
        const categoryIds = this.questions.map(question => question.category);
        const categories = await categoryRepository.find({ _id: { $in: categoryIds } }).lean();
        this.categories = categories.map(category => ({ ...category, owner: this.owner }));
    }

    private prepareExam() {
        const convertedExam: { [key: string]: Array<any> | boolean | number | object | string } = { ...this.exam, owner: this.owner };
        const groupQuestions = this.questions.map(question => ({ _id: question._id, questions: [question._id], owner: this.owner }));

        convertedExam.type = 'Hackz';
        convertedExam.categories = this.categories;
        convertedExam.questions = this.questions;
        convertedExam.groupQuestions = groupQuestions;
        convertedExam.slug = StringUtils.slug(this.exam.title.toLowerCase());

        this.convertedExam = convertedExam;
    }
}
