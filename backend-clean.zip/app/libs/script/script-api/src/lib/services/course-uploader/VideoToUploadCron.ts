import { videoToUploadRepository, VideoToUpload } from '@edorer/script-data';
import { VideoToUploadProcessor } from './VideoToUploadProcessor';

class VideoToUploadCron {
  private readonly STALE_TASK_HOURS = 3;

  IS_RUNNING = false;

  /**
   * Init method called by CronRegistry
   */
  async init() {
    // First reset stale tasks
    await this.resetStaleTasks();

    // Then process pending tasks
    await this.processPendingTasks();
  }

  /**
   * Process pending video upload tasks
   */
  private async processPendingTasks(): Promise<void> {
    // Find one pending task
    const pendingTask = await videoToUploadRepository.findOne({
      status: 'pending'
    }).sort({ createdAt: 1 }).lean();

    if (!pendingTask) {
      console.log('[VideoToUploadCron] No pending tasks found');
      return;
    }

    this.IS_RUNNING = true;

    // Mark as in_progress
    await videoToUploadRepository.update(
      { _id: pendingTask._id },
      {
        $set: {
          status: 'in_progress',
          startedAt: new Date(),
          updatedAt: new Date()
        }
      },
      { multi: false }
    );

    console.log(`[VideoToUploadCron] Processing task: ${pendingTask.courseName} - ${pendingTask.unitName} - ${pendingTask.topicName}`);

    // Process the task
    const universityId = pendingTask.university?.toString() || pendingTask.university;
    const processor = new VideoToUploadProcessor(
      universityId,
      6 // maxConcurrentVideos
    );

    try {
      await processor.processVideoToUpload(pendingTask);

      // Mark as done
      await videoToUploadRepository.update(
        { _id: pendingTask._id },
        {
          $set: {
            status: 'done',
            completedAt: new Date(),
            updatedAt: new Date()
          }
        },
        { multi: false }
      );

      console.log(`[VideoToUploadCron] Successfully processed task: ${pendingTask.courseName} - ${pendingTask.unitName} - ${pendingTask.topicName}`);
    } catch (error: any) {
      console.error(`[VideoToUploadCron] Error processing task:`, error);

      // Set status to error when error occurs
      await videoToUploadRepository.update(
        { _id: pendingTask._id },
        {
          $set: {
            status: 'error',
            errorMessage: error.message,
            updatedAt: new Date()
          },
          $unset: {
            startedAt: 1
          }
        },
        { multi: false }
      );
    }
    this.IS_RUNNING = false;
  }

  /**
   * Reset stale tasks (in_progress for more than 3 hours) back to pending
   */
  async resetStaleTasks(): Promise<number> {
    const staleThreshold = new Date();
    staleThreshold.setHours(staleThreshold.getHours() - this.STALE_TASK_HOURS);

    const result = await videoToUploadRepository.update(
      {
        status: 'in_progress',
        startedAt: { $lt: staleThreshold }
      },
      {
        $set: {
          status: 'pending',
          updatedAt: new Date()
        },
        $unset: {
          startedAt: 1,
          errorMessage: 1
        }
      },
      { multi: true }
    );

    const count = result.nModified || 0;
    if (count > 0) {
      console.log(`[VideoToUploadCron] Reset ${count} stale task(s) back to pending`);
    }

    return count;
  }
}

export const videoToUploadCron = new VideoToUploadCron();

