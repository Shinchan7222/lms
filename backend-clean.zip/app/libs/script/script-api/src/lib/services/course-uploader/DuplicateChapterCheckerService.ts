import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';

export class DuplicateChapterCheckerService {
    private readonly universityId: string;

    constructor(universityId: string) {
        this.universityId = universityId;
    }

    async process(): Promise<{
        message: string;
        totalCoursesWithDuplicates: number;
        totalDuplicatesFound: number;
        report: any[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            }).lean();

            const duplicatesReport = [];
            let totalDuplicates = 0;

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                }).lean();

                const nameCounts = new Map<string, number>();

                for (const chapter of chapters) {
                    let name = chapter.title || '';

                    // Normalize: Remove "Module {i} - " prefix
                    const match = name.match(/^Module\s+\d+\s+-\s+(.*)$/i);
                    let normalized = match ? match[1].trim() : name.trim();

                    if (nameCounts.has(normalized)) {
                        nameCounts.set(normalized, (nameCounts.get(normalized) || 0) + 1);
                    } else {
                        nameCounts.set(normalized, 1);
                    }
                }

                const courseDuplicates = [];
                for (const [name, count] of nameCounts.entries()) {
                    if (count > 1) {
                        courseDuplicates.push({
                            name: name,
                            count: count
                        });
                        totalDuplicates++;
                    }
                }

                if (courseDuplicates.length > 0) {
                    duplicatesReport.push({
                        courseId: course._id,
                        courseTitle: course.title,
                        duplicates: courseDuplicates
                    });
                }
            }

            return {
                message: 'Duplicate chapters check completed',
                totalCoursesWithDuplicates: duplicatesReport.length,
                totalDuplicatesFound: totalDuplicates,
                report: duplicatesReport
            };

        } catch (error: any) {
            console.error('Error checking for duplicate chapters:', error);
            return {
                message: 'Error checking for duplicate chapters',
                totalCoursesWithDuplicates: 0,
                totalDuplicatesFound: 0,
                report: [],
                error: error.message
            };
        }
    }
}
