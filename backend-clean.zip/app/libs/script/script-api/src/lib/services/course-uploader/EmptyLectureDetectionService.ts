import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { videoTempRepository } from '@edorer/video-uploader-data';
import { Types } from 'mongoose';

export class EmptyLectureDetectionService {
    private readonly universityId: string;

    constructor(universityId: string) {
        this.universityId = universityId;
    }

    async checkEmptyPages(): Promise<{ success: boolean; results: any[] }> {
        return this.runCheck((lecture: any) => {
            return !lecture.pages || lecture.pages.length === 0;
        });
    }

    async checkNoContent(): Promise<{ success: boolean; results: any[] }> {
        return this.runCheck((lecture: any) => {
            if (!lecture.pages || lecture.pages.length === 0) return false; // Handled by checkEmptyPages

            // Check if pages have content
            // Assuming "content" means having video or text properties, or specific types
            // If pages exist but are "empty shells"
            const hasContent = lecture.pages.some((p: any) => {
                if (p.contentType === 'video' || p.type === 'video') return true;
                if (p.contentType === 'text' && (p.content || (p.blocks && p.blocks.length > 0))) return true;
                // Add other content checks as needed
                return false;
            });

            return !hasContent;
        });
    }

    async checkAndFixEmptyLectures(): Promise<{ success: boolean; results: any[] }> {
        const report: any[] = [];
        const emptyResult = await this.checkNoContent();

        // We iterate specifically over the lectures we identified as "no content"
        // But the previous method 'checkNoContent' returns a flat list of results, not the actual objects to modify easily
        // unless we re-fetch or modify 'runCheck' to allow handling.
        // Better to implement a specialized loop here or modify runCheck to take a callback.
        // I will copy the loop structure to have full control for fixing.

        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length === 0) continue;

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    for (const lecture of lectures) {
                        // Check if empty/no content
                        const isEmpty = !lecture.pages || lecture.pages.length === 0 || !lecture.pages.some((p: any) =>
                            p.contentType === 'video' || p.type === 'video' || (p.contentType === 'text' && (p.content || (p.blocks && p.blocks.length > 0)))
                        );

                        if (isEmpty) {
                            // Try to fix
                            const cleanLecture = this.cleanTitle(lecture.title, 'Unit');
                            const cleanChapter = this.cleanTitle(chapter.title, 'Module');
                            // Course name might not have prefix, but handle if needed? Usually Course Name is cleaner.

                            // Clean course title: remove anything before the first " - "
                            const cleanCourse = course.title.replace(/^[^-]+-\s*/, '').trim();

                            // Find in VideoTemp
                            // We try to match reasonably loosely (case insensitive, trimmed)
                            const videoTemp = await videoTempRepository.findOne({
                                courseName: { $regex: new RegExp(this.escapeRegExp(cleanCourse), 'i') },
                                unitName: { $regex: new RegExp(this.escapeRegExp(cleanChapter), 'i') },
                                topicName: { $regex: new RegExp(this.escapeRegExp(cleanLecture), 'i') },
                                university: new Types.ObjectId(this.universityId)
                            });

                            // Re-try without course name constraint? No, that's dangerous.
                            // Maybe try course name contains?
                            // Let's stick to the cleanest possible matching first.

                            if (videoTemp && videoTemp.url) {
                                // FIX: Add page
                                const newPage = {
                                    title: 'Video',
                                    contentType: 'video',
                                    video: videoTemp.url,
                                    assetUrl: videoTemp.url,
                                    time: 0,
                                    _id: undefined // Mongoose will generate
                                };

                                lecture.pages = lecture.pages || [];
                                lecture.pages.push(newPage);
                                await lecture.save();

                                report.push({
                                    status: 'FIXED',
                                    course: course.title,
                                    chapter: chapter.title,
                                    lecture: lecture.title,
                                    details: `Mapped to VideoTemp: ${videoTemp.topicName} (URL: ${videoTemp.url})`
                                });
                            } else {
                                report.push({
                                    status: 'UNFIXED',
                                    course: course.title,
                                    chapter: chapter.title,
                                    lecture: lecture.title,
                                    details: `No matching video found in VideoTemp (Searched for: ${cleanLecture} in ${cleanChapter})`
                                });
                            }
                        }
                    }
                }
            }
            return { success: true, results: report };
        } catch (error: any) {
            return { success: false, results: [{ error: error.message }] };
        }
    }

    private cleanTitle(title: string, prefixType: 'Module' | 'Unit'): string {
        // Removes "Module 1 - " or "Unit 10 - "
        const regex = new RegExp(`^\\s*${prefixType}\\s*\\d+\\s*-\\s*`, 'i');
        return title.replace(regex, '').trim();
    }

    private escapeRegExp(string: string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    private async runCheck(predicate: (lecture: any) => boolean): Promise<{ success: boolean; results: any[] }> {
        const results: any[] = [];

        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length === 0) continue;

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    for (const lecture of lectures) {
                        if (predicate(lecture)) {
                            results.push({
                                course: course.title,
                                chapter: chapter.title,
                                lecture: lecture.title,
                                lectureId: lecture._id,
                                reason: 'Matched check criteria'
                            });
                        }
                    }
                }
            }

            return { success: true, results };

        } catch (error: any) {
            return { success: false, results: [{ error: error.message }] };
        }
    }
}
