import { Workbook } from 'exceljs';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { universityConfigurationRepository } from '@edorer/university-data';
import { videoTempRepository } from '@edorer/video-uploader-data';
import { Types } from 'mongoose';
import { v4 as uuidV4 } from 'uuid';
import { RemotionVideoProcessor } from './RemotionVideoProcessor';
import { parallelProcessor } from './ParallelProcessor';
import { GoogleDriveDownloader } from './GoogleDriveDownloader';
import { TaskStatusManager } from './TaskStatusManager';
const fs = require('fs');
const exec = require('child_process').exec;
const util = require('util');
const execPromise = util.promisify(exec);
const path = require('path');



interface ExcelRow {
  'Course Name': string;
  'Program Name'?: string;
  'Unit Name': string;
  'Topic Name': string;
  'Video Link': string;
  'Faculty Name for videos'?: string;
  'Semester'?: string;
}

interface GroupedData {
  courseName: string;
  programName?: string;
  unitName: string;
  topicName: string;
  videoLinks: string[];
  facultyName?: string;
  semester?: string;
}

export class VideoUploaderService {
  private readonly excelFile: any;
  private readonly universityId: string;
  private readonly maxConcurrentVideos: number;
  private universityConfig: any;
  private googleDriveDownloader: GoogleDriveDownloader | null = null;
  private readonly tokenPath?: string;
  private taskStatusManager: TaskStatusManager;

  constructor(excelFile: any, universityId: string, maxConcurrentVideos: number = 3, tokenPath?: string, statusFilePath?: string) {
    this.excelFile = excelFile;
    this.universityId = universityId;
    this.maxConcurrentVideos = maxConcurrentVideos;
    this.tokenPath = tokenPath;
    this.taskStatusManager = new TaskStatusManager(statusFilePath);
  }

  /**
   * Initialize Google Drive downloader with university config credentials
   */
  private initializeGoogleDriveDownloader(): void {
    if (this.googleDriveDownloader) {
      return; // Already initialized
    }

    const clientId = this.universityConfig?.advanced?.googleClientId;
    const clientSecret = this.universityConfig?.advanced?.googleClientSecret;

    this.googleDriveDownloader = new GoogleDriveDownloader(
      this.tokenPath,
      clientId,
      clientSecret
    );
  }

  async process(): Promise<{ success: number; errors: string[] }> {
    const errors: string[] = [];
    let successCount = 0;

    try {
      // Parse Excel file
      const rows = await this.parseExcel();

      // Group by Topic Name (same topic = append videos)
      const groupedData = this.groupByTopic(rows);

      // Get university config
      this.universityConfig = await universityConfigurationRepository.findOne({
        university: this.universityId
      }).lean();

      if (!this.universityConfig) {
        throw new Error('University configuration not found');
      }

      // Initialize Google Drive downloader with credentials
      this.initializeGoogleDriveDownloader();

      const s3 = new S3University(this.universityConfig, true);

      // Process all groups with parallel processing for downloads, FFmpeg, and uploads
      // Remotion processing will be queued automatically
      const processingTasks = groupedData.map(group => async () => {
        const taskId = this.taskStatusManager.generateTaskId(
          group.courseName,
          group.unitName,
          group.topicName
        );

        try {
          // First check if all videos already exist in videoTemps
          const allVideosExist = await this.checkAllVideosExist(group);
          if (allVideosExist) {
            console.log(`All videos already exist in videoTemps for ${taskId}, skipping`);
            return { success: true, group, skipped: true };
          }

          // Check if task is already being processed by another instance (JSON file coordination)
          const shouldSkip = await this.taskStatusManager.shouldSkipTask(taskId);
          if (shouldSkip) {
            const status = await this.taskStatusManager.getTaskStatus(taskId);
            console.log(`Skipping task ${taskId} (status: ${status} - another instance is processing)`);
            return { success: true, group, skipped: true };
          }

          // Reserve the task (mark as in_progress) - for coordinating multiple instances
          const reserved = await this.taskStatusManager.reserveTask(
            group.courseName,
            group.unitName,
            group.topicName,
            group.programName
          );

          if (!reserved) {
            console.log(`Could not reserve task ${taskId}, may already be in progress or done`);
            return { success: true, group, skipped: true };
          }

          console.log(`Processing group: ${group.courseName} - ${group.unitName} - ${group.topicName}`);
          await this.processGroup(group, s3);

          // Mark task as done in JSON file (for coordination)
          await this.taskStatusManager.markTaskDone(taskId);

          successCount++;
          console.log(`Successfully processed ${successCount} groups`);
          return { success: true, group };
        } catch (error: any) {
          // Remove task from status file on error so it can be retried by another instance
          await this.taskStatusManager.removeTask(taskId);

          const errorMsg = `Error processing ${group.courseName} - ${group.unitName} - ${group.topicName}: ${error.message}`;
          errors.push(errorMsg);
          console.error(errorMsg, error);
          return { success: false, group, error: errorMsg };
        }
      });

      // Process in parallel with limit of 6 concurrent operations
      await parallelProcessor.processInParallel(processingTasks);

      return { success: successCount, errors };
    } catch (error: any) {
      throw new Error(`Failed to process Excel file: ${error.message}`);
    }
  }

  private async parseExcel(): Promise<ExcelRow[]> {
    const workbook = new Workbook();
    await workbook.xlsx.load(this.excelFile.buffer);

    const worksheet = workbook.getWorksheet(1); // Get the first worksheet
    if (!worksheet) {
      throw new Error('Excel file is empty or invalid');
    }

    const rows: ExcelRow[] = [];
    let headers: { [key: string]: number } = {};
    let headerRowFound = false;

    // Process each row
    worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      // First row should be headers
      if (rowNumber === 1) {
        row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
          const headerValue = cell.value?.toString() || '';
          headers[headerValue] = colNumber;
        });
        headerRowFound = true;

        // Validate required columns
        const requiredColumns = ['Course Name', 'Unit Name', 'Topic Name', 'Video Link'];
        for (const col of requiredColumns) {
          if (!(col in headers)) {
            throw new Error(`Missing required column: ${col}`);
          }
        }
        return;
      }

      if (!headerRowFound) {
        return;
      }

      // Extract row data
      const rowData: ExcelRow = {
        'Course Name': '',
        'Program Name': undefined,
        'Unit Name': '',
        'Topic Name': '',
        'Video Link': '',
        'Faculty Name for videos': undefined,
        'Semester': undefined
      };

      // Get cell values by header name
      for (const [headerName, colNumber] of Object.entries(headers)) {
        const cell = row.getCell(colNumber);
        // console.log(cell);
        let cellValue = '';

        // Check if cell has a hyperlink (can be string or object with target property)
        const hyperlink = cell.hyperlink as any;
        console.log(hyperlink);
        console.log(cell.value);
        if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
          cellValue = hyperlink.target;
        } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
          const formula = (cell.value as any).formula;
          const urlMatch = formula?.match(/=HYPERLINK\("([^"]+)"/i);
          if (urlMatch && urlMatch[1]) {
            cellValue = urlMatch[1];
          } else {
            if (cell.value && (cell.value as any).hyperlink) {
              cellValue = (cell.value as any).hyperlink;
            } else {
              cellValue = cell.value?.toString() || '';
            }
          }
        } else {
          if (cell.value && (cell.value as any).hyperlink) {
            cellValue = (cell.value as any).hyperlink;
          } else {
            cellValue = cell.value?.toString() || '';
          }
        }

        if (headerName in rowData) {
          console.log(headerName);
          console.log(cellValue);
          (rowData as any)[headerName] = cellValue;
        }
      }

      // Only add row if it has required data
      if (rowData['Course Name'] || rowData['Unit Name'] || rowData['Topic Name']) {
        rows.push(rowData);
      }
      console.log(rowData);
    });
    if (rows.length === 0) {
      throw new Error('No data found in Excel file');
    }

    return rows;
  }

  private groupByTopic(rows: ExcelRow[]): GroupedData[] {
    const groupedMap = new Map<string, GroupedData>();

    for (const row of rows) {
      const key = `${row['Course Name']}|${row['Program Name'] || ''}|${row['Unit Name']}|${row['Topic Name']}`;

      if (!groupedMap.has(key)) {
        groupedMap.set(key, {
          courseName: row['Course Name'],
          programName: row['Program Name'],
          unitName: row['Unit Name'],
          topicName: row['Topic Name'],
          videoLinks: [],
          facultyName: row['Faculty Name for videos'],
          semester: row['Semester']
        });
      }

      const group = groupedMap.get(key)!;
      if (row['Video Link'] && row['Video Link'].trim()) {
        group.videoLinks.push(row['Video Link'].trim());
      }
    }

    return Array.from(groupedMap.values());
  }

  private async processGroup(group: GroupedData, s3: S3University): Promise<void> {
    const videoLinks = group.videoLinks;

    // If there's only one video, process it as before
    if (videoLinks.length === 1) {
      try {
        await this.downloadAndUploadVideo(videoLinks[0], s3, group);
      } catch (error: any) {
        throw new Error(`Error processing video for ${group.topicName}: ${error.message}`);
      }
      return;
    }

    // If there are multiple videos, concatenate them before processing with remotion
    let downloadedPaths: string[] = [];
    let concatenatedVideoPath: string | undefined;
    let unzippedDir: string | undefined;

    try {
      // Download all videos first - PARALLEL (6 at a time)
      console.log(`Downloading ${videoLinks.length} videos for topic: ${group.topicName} (parallel, max 6)`);
      const downloadTasks = videoLinks.map(videoLink => () => this.downloadVideo(videoLink));
      const downloadResults = await parallelProcessor.processInParallel(downloadTasks);

      for (const result of downloadResults) {
        if (result.success && result.result) {
          downloadedPaths.push(result.result.path);
        } else {
          console.error(`Failed to download video:`, result.error);
          throw new Error(`Failed to download one or more videos: ${result.error}`);
        }
      }

      if (downloadedPaths.length === 0) {
        throw new Error(`No videos were successfully downloaded for ${group.topicName}`);
      }

      // Concatenate videos using ffmpeg
      console.log(`Concatenating ${downloadedPaths.length} videos for topic: ${group.topicName}`);
      concatenatedVideoPath = await this.concatenateVideos(downloadedPaths);

      // Process the concatenated video with remotion processor
      const remotionDir = process.env.REMOTION_DIR || '/home/amine/test/remotion-video-app'; // Remotion directory path
      const processor = new RemotionVideoProcessor(remotionDir, this.universityConfig, s3, this.universityId);
      const uploadedUrl = await processor.processVideo(concatenatedVideoPath, group);

      console.log(`Successfully uploaded concatenated video: ${uploadedUrl}`);
    } catch (error: any) {
      console.error(`Error processing video group ${group.topicName}:`, error);
      throw error;
    } finally {
      // Cleanup downloaded files
      for (const path of downloadedPaths) {
        if (FileUtils.fileExists(path)) {
          try {
            FileUtils.removeFile(path);
          } catch (error) {
            console.error('Failed to cleanup downloaded file:', error);
          }
        }
      }

      // Cleanup concatenated video
      if (concatenatedVideoPath && FileUtils.fileExists(concatenatedVideoPath)) {
        try {
          FileUtils.removeFile(concatenatedVideoPath);
        } catch (error) {
          console.error('Failed to cleanup concatenated video:', error);
        }
      }
    }
  }

  private async downloadVideo(videoUrl: string): Promise<{ path: string }> {
    if (!this.googleDriveDownloader) {
      throw new Error('Google Drive downloader not initialized');
    }
    const downloadedPath = `/tmp/${uuidV4()}-${videoUrl.split('/').pop() || 'video'}.mp4`;
    try {
      await this.googleDriveDownloader.downloadFile(videoUrl, downloadedPath);
    } catch (error: any) {
      console.error(`Error downloading video ${videoUrl}:`, error);
      throw error;
    }
    return { path: downloadedPath };

  }

  /**
   * Refresh Google Drive token
   */
  async refreshGoogleDriveToken(): Promise<any> {
    if (!this.googleDriveDownloader) {
      // Initialize if not already done
      if (!this.universityConfig) {
        this.universityConfig = await universityConfigurationRepository.findOne({
          university: this.universityId
        }).lean();
        if (!this.universityConfig) {
          throw new Error('University configuration not found');
        }
      }
      this.initializeGoogleDriveDownloader();
    }
    return await this.googleDriveDownloader.refreshToken();
  }


  /**
   * Check if all videos for a group already exist in videoTemps
   * Returns true if all videos are already processed
   * Checks by courseName, unitName, topicName combination
   */
  private async checkAllVideosExist(group: GroupedData): Promise<boolean> {
    try {
      // Check if video exists by courseName, unitName, topicName combination
      // This is more reliable than just checking originalUrl
      const existing = await videoTempRepository.findOne({
        courseName: group.courseName,
        unitName: group.unitName,
        topicName: group.topicName,
        university: new Types.ObjectId(this.universityId)
      }).lean();

      if (existing && existing.url) {
        console.log(`Video already exists in videoTemp for ${group.courseName} - ${group.unitName} - ${group.topicName}`);
        return true;
      }

      return false;
    } catch (error: any) {
      console.error(`Error checking videoTemps for group ${group.courseName} - ${group.unitName} - ${group.topicName}:`, error);
      return false;
    }
  }

  private async downloadAndUploadVideo(videoUrl: string, s3: S3University, group: GroupedData) {
    let downloadedPath: string | undefined;

    try {
      // Check if video already exists in videoTemp by courseName, unitName, topicName
      const existing = await videoTempRepository.findOne({
        courseName: group.courseName,
        unitName: group.unitName,
        topicName: group.topicName,
        university: new Types.ObjectId(this.universityId)
      }).lean();

      if (existing && existing.url) {
        console.log(`Skipping download and processing for ${group.courseName} - ${group.unitName} - ${group.topicName}, using existing URL: ${existing.url}`);
        return existing.url;
      }

      // Download video
      const { path } = await this.downloadVideo(videoUrl);
      downloadedPath = path;

      // Process video with remotion processor
      const remotionDir = process.env.REMOTION_DIR || '/home/amine/test/remotion-video-app'; // Remotion directory path
      const processor = new RemotionVideoProcessor(remotionDir, this.universityConfig, s3, this.universityId);
      const uploadedUrl = await processor.processVideo(downloadedPath, {
        ...group,
        videoLinks: [videoUrl]
      });

      console.log(`Successfully uploaded and saved video: ${uploadedUrl}`);
      return uploadedUrl;
    } catch (error: any) {
      console.error(`Error processing video ${videoUrl}:`, error);
      throw error;
    } finally {
      if (downloadedPath && FileUtils.fileExists(downloadedPath)) {
        try {
          FileUtils.removeFile(downloadedPath);
        } catch (error) {
          console.error('Failed to cleanup temporary file:', error);
        }
      }
    }
  }

  private async concatenateVideos(videoPaths: string[]): Promise<string> {
    const outputPath = `/tmp/concatenated-${uuidV4()}.mp4`;

    try {
      // Validate all video files exist
      for (const path of videoPaths) {
        if (!FileUtils.fileExists(path)) {
          throw new Error(`Video file not found: ${path}`);
        }
      }

      const numVideos = videoPaths.length;
      console.log(`[CONCAT] Concatenating ${numVideos} videos...`);

      // Build input arguments
      const inputArgs = videoPaths.map(path => `-i "${path}"`).join(' ');

      // Build filter_complex: scale, pad, set SAR, fps, and format each video and audio stream
      const filterParts: string[] = [];

      // Process each video: scale to 1920x1080, pad, set SAR, and fps=30
      for (let i = 0; i < numVideos; i++) {
        filterParts.push(
          `[${i}:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[v${i}]`
        );
      }

      // Process each audio: format to 48kHz stereo
      for (let i = 0; i < numVideos; i++) {
        filterParts.push(
          `[${i}:a]aformat=sample_rates=48000:channel_layouts=stereo[a${i}]`
        );
      }

      // Concatenate all video and audio streams
      const concatInputs: string[] = [];
      for (let i = 0; i < numVideos; i++) {
        concatInputs.push(`[v${i}][a${i}]`);
      }
      filterParts.push(
        `${concatInputs.join('')}concat=n=${numVideos}:v=1:a=1[v][a]`
      );

      const filterComplex = filterParts.join(';');

      // Build FFmpeg command with filter_complex
      const command = `ffmpeg ${inputArgs} ` +
        `-filter_complex "${filterComplex}" ` +
        `-map "[v]" -map "[a]" ` +
        `-c:v libx264 -preset ultrafast -crf 23 ` +
        `-c:a aac -b:a 192k ` +
        `-movflags +faststart ` +
        `"${outputPath}"`;

      console.log(`[CONCAT] Running FFmpeg command (filter_complex with scaling and padding)...`);
      console.log(`[CONCAT] Command: ${command.substring(0, 300)}...`);

      const startTime = Date.now();
      const { stdout, stderr } = await execPromise(command, {
        maxBuffer: 1024 * 1024 * 100, // 100MB buffer
        timeout: 600000, // 10 minutes timeout
      });
      const duration = ((Date.now() - startTime) / 1000).toFixed(2);
      console.log(`[CONCAT] Concatenation completed in ${duration} seconds`);

      if (stdout) {
        console.log(`[CONCAT] Concatenation output: ${stdout}`);
      }
      if (stderr) {
        // FFmpeg outputs progress to stderr, so log it
        console.log(`[CONCAT] Concatenation stderr: ${stderr.substring(0, 500)}`);
      }

      // Small delay to ensure file is fully written
      await new Promise(resolve => setTimeout(resolve, 500));

      if (!FileUtils.fileExists(outputPath)) {
        throw new Error(`Concatenated video not found at ${outputPath}`);
      }

      // Check file size to ensure it's not empty
      const stats = fs.statSync(outputPath);
      if (stats.size === 0) {
        throw new Error(`Concatenated video is empty (0 bytes)`);
      }

      console.log(`[CONCAT] Successfully concatenated ${numVideos} videos`);
      console.log(`[CONCAT] Output path: ${outputPath}`);
      console.log(`[CONCAT] File size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);

      return outputPath;
    } catch (error: any) {
      console.error(`[CONCAT] Error occurred during concatenation:`, error);
      throw new Error(`Failed to concatenate videos: ${error.message}`);
    }
  }

}
