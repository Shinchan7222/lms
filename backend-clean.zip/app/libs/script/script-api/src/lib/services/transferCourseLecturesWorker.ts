import { createHash } from 'crypto';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { Lecture, lectureRepository } from '@edorer/lecture-data';
import { UniversityConfiguration } from '@edorer/university-data';
import * as mongoose from 'mongoose';

interface ProcessingStats {
  total: number;
  processed: number;
  successful: number;
  failed: number;
  skipped: number;
}

process.on('message', async (data: { lectures: Lecture[]; universityConfig: UniversityConfiguration }) => {
  try {
    // Ensure MongoDB connection
    if (!mongoose.connection.readyState) {
      await mongoose.connect(process.env.DATABASE || 'mongodb://localhost:27017/edorer');
    }

    const worker = new TransferCourseLecturesWorker(data.lectures, data.universityConfig);
    const stats = await worker.process();

    if (process.send) {
      process.send({ type: 'DONE', stats });
    }
  } catch (error) {
    if (process.send) {
      process.send({
        type: 'ERROR',
        error: error instanceof Error ? error.message : 'Unknown error',
        stats: {
          total: data.lectures.reduce((acc, lecture) => acc + (lecture.pages?.length || 0), 0),
          processed: 0,
          successful: 0,
          failed: data.lectures.reduce((acc, lecture) => acc + (lecture.pages?.length || 0), 0),
          skipped: 0
        }
      });
    }
    process.exit(1);
  }
});

process.on('uncaughtException', (error) => {
  if (process.send) {
    process.send({
      type: 'ERROR',
      error: error instanceof Error ? error.message : 'Uncaught exception',
      stats: {
        total: 0,
        processed: 0,
        successful: 0,
        failed: 0,
        skipped: 0
      }
    });
  }
  process.exit(1);
});

process.on('unhandledRejection', (error) => {
  if (process.send) {
    process.send({
      type: 'ERROR',
      error: error instanceof Error ? error.message : 'Unhandled rejection',
      stats: {
        total: 0,
        processed: 0,
        successful: 0,
        failed: 0,
        skipped: 0
      }
    });
  }
  process.exit(1);
});

class TransferCourseLecturesWorker {
  private readonly MAX_RETRIES = 3;
  private stats: ProcessingStats = {
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0,
    skipped: 0
  };

  constructor(private readonly lectures: Lecture[], private readonly universityConfig: UniversityConfiguration) {}

  private async updateLecture(filter: any, update: any): Promise<void> {
    await lectureRepository.update(filter, update);
  }

  private isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private generateSafeFileName(originalName: string): string {
    const ext = originalName.split('.').pop() || '';
    const hash = createHash('md5').update(originalName).digest('hex').slice(0, 8);
    const safeName = originalName.split('.')[0].slice(0, 32);
    return `${safeName}-${hash}.${ext}`;
  }

  private async downloadAndUploadUrl(url: string, bucketName: any): Promise<string | null> {
    let downloadedUrl: string | undefined;
    try {
      const downloader = new Downloader(url);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      const originalFileName = url.split('/').pop() || '';
      const safeFileName = this.generateSafeFileName(originalFileName);

      const s3 = new S3University(this.universityConfig, true);
      const uploadedUrl = await s3.uploadBuffer(fileContent, safeFileName, bucketName);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      return uploadedUrl;
    } catch (error) {
      return null;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch {}
      }
    }
  }

  private async processPageWithRetry(page: any, lecture: Lecture, retryCount = 0): Promise<void> {
    try {
      let url: string | undefined;
      let url2: string | undefined;

      if (page.contentType === 'document' && page.assetUrl) {
        url = page.assetUrl;
        url2 = page.storedURI;
      } else if (page.contentType === 'video' && page.video) {
        url = page.video;
      }

      if (!url || !this.isValidUrl(url)) {
        console.warn(`Invalid or missing URL for lecture ${url}`);
        if (page.contentType === 'document' && page.video) {
          page.video = null;
          await this.updateLecture({ _id: lecture._id }, { $set: { pages: lecture.pages, isShifted: true } });
        }

        await this.processImagesWithRetry(page, lecture);
        return;
      }

      const uploadedUrl = await this.downloadAndUploadUrl(url, this.universityConfig.buckets.LMS_COURSE_VIDEOS);
      if (!uploadedUrl) {
        throw new Error('Failed to process main asset');
      }

      page.assetUrl = uploadedUrl;
      page.previousUrl = url;

      if (url2) {
        const uploadedUrl2 = await this.downloadAndUploadUrl(url2, this.universityConfig.buckets.LMS_COURSE_VIDEOS);
        if (uploadedUrl2) {
          page.storedURI = uploadedUrl2;
        }
      }

      if (page.contentType === 'video') {
        page.video = uploadedUrl;
      }

      await this.processImagesWithRetry(page, lecture);
      await this.updateLecture({ _id: lecture._id }, { $set: { pages: lecture.pages, isShifted: true } });

      this.stats.successful++;
      this.stats.processed++;

      if (process.send) {
        process.send({ type: 'PROGRESS', stats: this.stats });
      }
    } catch (error) {
      console.error('Process page error:', error instanceof Error ? error.message : 'Unknown error');

      if (retryCount < this.MAX_RETRIES) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retryCount + 1)));
        return this.processPageWithRetry(page, lecture, retryCount + 1);
      }

      this.stats.failed++;
      this.stats.processed++;

      if (process.send) {
        process.send({ type: 'PROGRESS', stats: this.stats });
      }

      try {
        await this.processImagesWithRetry(page, lecture);
      } catch (imgError) {
        console.error('Failed to process images after main asset failure:', imgError);
      }
    }
  }

  private async processImagesWithRetry(page: any, lecture: Lecture, retryCount = 0): Promise<void> {
    try {
      if (!page.images || !Array.isArray(page.images) || page.images.length === 0) {
        return;
      }

      const uploadedImages: string[] = [];
      const originalImages: string[] = [...page.images];

      for (const imageUrl of originalImages) {
        if (this.isValidUrl(imageUrl)) {
          const uploadedUrl = await this.downloadAndUploadUrl(imageUrl, this.universityConfig.buckets.LMS_COURSE_VIDEOS);

          if (uploadedUrl) {
            uploadedImages.push(uploadedUrl);
          } else {
            uploadedImages.push(imageUrl);
          }
        } else {
          uploadedImages.push(imageUrl);
        }
      }

      if (JSON.stringify(originalImages) !== JSON.stringify(uploadedImages)) {
        page.images = uploadedImages;
        page.previousImages = originalImages;

        await this.updateLecture({ _id: lecture._id }, { $set: { pages: lecture.pages, isShifted: true } });
      }
    } catch (error) {
      console.error('Process images error:', error instanceof Error ? error.message : 'Unknown error');

      if (retryCount < this.MAX_RETRIES) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retryCount + 1)));
        return this.processImagesWithRetry(page, lecture, retryCount + 1);
      }
    }
  }

  async process(): Promise<ProcessingStats> {
    const pagePromises: Promise<void>[] = [];
    let totalPages = 0;

    for (const lecture of this.lectures) {
      if (!lecture?.pages?.length) {
        this.stats.skipped++;
        continue;
      }
      totalPages += lecture.pages.length;
    }

    this.stats.total = totalPages;

    for (const lecture of this.lectures) {
      if (!lecture?.pages?.length) continue;

      for (const page of lecture.pages) {
        pagePromises.push(this.processPageWithRetry(page, lecture));
      }
    }

    await Promise.all(pagePromises);
    return this.stats;
  }
}
