import { Workbook } from 'exceljs';
import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';
import { videoTempRepository } from '@edorer/video-uploader-data';
import { universityConfigurationRepository } from '@edorer/university-data';
import { Types } from 'mongoose';
import { GoogleDriveDownloader } from './GoogleDriveDownloader';
import { S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import * as path from 'path';
import * as os from 'os';

interface ExcelRow {
  'Course Name': string;
  'Program Name'?: string;
  'Unit Name': string;
  'Topic Name': string;
  'Video Link': string;
  'Faculty Name for videos'?: string;
  'Unit PDF Links'?: string;
}

interface GroupedData {
  courseName: string;
  programName?: string;
  unitName: string;
  topicName: string;
  videoLinks: string[];
  facultyName?: string;
}

interface CourseGroup {
  courseName: string;
  programName?: string;
  units: Map<string, UnitGroup>;
}

interface UnitGroup {
  unitName: string;
  topics: Map<string, TopicGroup>;
}

interface TopicGroup {
  topicName: string;
  videoUrls: string[];
}

interface SyllabusRow {
  'Course Name': string;
  'Syllabus-Link': string;
}

export class CourseCreator {
  private readonly excelFile: any;
  private readonly universityId: string;
  private readonly tabName: string;
  private readonly ownerId: string = '692ab73c5426270099610321'; // From example JSON
  private readonly domainId: string = '692aaf11c0d6c0620af3790a'; // From example JSON
  private universityConfig: any;
  private syllabusMap: Map<string, string> = new Map(); // courseName -> syllabusLink
  private unitPdfMap: Map<string, string> = new Map(); // courseName|unitName -> pdfLink
  private workbook: Workbook | null = null;

  constructor(excelFile: any, universityId: string, tabName: string) {
    this.excelFile = excelFile;
    this.universityId = universityId;
    this.tabName = tabName;
  }

  /**
   * Main process method to create course, chapters, and lectures
   */
  async process(): Promise<{ success: boolean; courseIds: string[]; errors: string[] }> {
    const errors: string[] = [];
    const courseIds: string[] = [];

    try {
      // Parse Excel file
      const rows = await this.parseExcel();
      

      // Parse syllabus from worksheet named "{tabName}_S"
      await this.parseSyllabusExcel();

      // Group data by Course -> Unit -> Topic
      const courseGroups = this.groupByCourseUnitTopic(rows);

      // Get university config
      this.universityConfig = await universityConfigurationRepository.findOne({
        university: this.universityId
      }).lean();

      if (!this.universityConfig) {
        throw new Error('University configuration not found');
      }

      // Process each course
      for (const [courseName, courseGroup] of courseGroups) {
        try {
          const courseId = await this.createCourseWithChaptersAndLectures(courseGroup);
          courseIds.push(courseId);
          console.log(`Successfully created course: ${courseName} (ID: ${courseId})`);
        } catch (error: any) {
          const errorMsg = `Error processing course ${courseName}: ${error.message}`;
          errors.push(errorMsg);
          console.error(errorMsg, error);
        }
      }

      if (courseIds.length === 0) {
        if (errors.length > 0) {
          return { success: false, courseIds: [], errors };
        }
        throw new Error('No courses were processed');
      }

      return { success: true, courseIds, errors };
    } catch (error: any) {
      errors.push(`Failed to process Excel file: ${error.message}`);
      return { success: false, courseIds: [], errors };
    }
  }

  /**
   * Parse Excel file and extract rows
   */
  private async parseExcel(): Promise<ExcelRow[]> {
    this.workbook = new Workbook();
    await this.workbook.xlsx.load(this.excelFile.buffer);

    // Log all worksheets in the Excel file
    const worksheetNames = this.workbook.worksheets.map(ws => ws.name);
    console.log('Available worksheets in Excel file:', worksheetNames);

    const worksheet = this.workbook.getWorksheet(1); // Get the first worksheet
    if (!worksheet) {
      throw new Error('Excel file is empty or invalid');
    }

    const rows: ExcelRow[] = [];
    let headers: { [key: string]: number } = {};
    let headerRowFound = false;

    // Process each row
    worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      // First row should be headers
      if (rowNumber === 1) {
        row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
          const headerValue = cell.value?.toString() || '';
          headers[headerValue] = colNumber;
        });
        headerRowFound = true;

        // Validate required columns
        const requiredColumns = ['Course Name', 'Unit Name', 'Topic Name', 'Video Link'];
        for (const col of requiredColumns) {
          if (!(col in headers)) {
            throw new Error(`Missing required column: ${col}`);
          }
        }
        return;
      }

      if (!headerRowFound) {
        return;
      }

      // Extract row data
      const rowData: ExcelRow = {
        'Course Name': '',
        'Program Name': undefined,
        'Unit Name': '',
        'Topic Name': '',
        'Video Link': '',
        'Faculty Name for videos': undefined,
        'Unit PDF Links': undefined
      };

      // Get cell values by header name
      for (const [headerName, colNumber] of Object.entries(headers)) {
        const cell = row.getCell(colNumber);
        let cellValue = '';

        // Check if cell has a hyperlink (can be string or object with target property)
        const hyperlink = cell.hyperlink as any;
        if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
          cellValue = hyperlink.target;
        } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
          const formula = (cell.value as any).formula;
          const urlMatch = formula?.match(/=HYPERLINK\("([^"]+)"/i);
          if (urlMatch && urlMatch[1]) {
            cellValue = urlMatch[1];
          } else {
            if (cell.value && (cell.value as any).hyperlink) {
              cellValue = (cell.value as any).hyperlink;
            } else {
              cellValue = cell.value?.toString() || '';
            }
          }
        } else {
          if (cell.value && (cell.value as any).hyperlink) {
            cellValue = (cell.value as any).hyperlink;
          } else {
            cellValue = cell.value?.toString() || '';
          }
        }

        if (headerName in rowData) {
          (rowData as any)[headerName] = cellValue;
        }
      }

      // Only add row if it has required data
      if (rowData['Course Name'] || rowData['Unit Name'] || rowData['Topic Name']) {
        rows.push(rowData);
        
        // Store unit PDF link if present
        if (rowData['Unit PDF Links'] && rowData['Unit PDF Links'].trim() && rowData['Course Name'] && rowData['Unit Name']) {
          const key = `${rowData['Course Name'].trim()}|${rowData['Unit Name'].trim()}`;
          this.unitPdfMap.set(key, rowData['Unit PDF Links'].trim());
        }
      }
    });

    if (rows.length === 0) {
      throw new Error('No data found in Excel file');
    }

    console.log(`Parsed ${this.unitPdfMap.size} unit PDF links from Excel file`);

    return rows;
  }

  /**
   * Group rows by Course -> Unit -> Topic
   */
  private groupByCourseUnitTopic(rows: ExcelRow[]): Map<string, CourseGroup> {
    const courseMap = new Map<string, CourseGroup>();

    for (const row of rows) {
      const courseName = row['Course Name'];
      const unitName = row['Unit Name'];
      const topicName = row['Topic Name'];

      if (!courseName || !unitName || !topicName) {
        continue;
      }

      // Get or create course group
      if (!courseMap.has(courseName)) {
        courseMap.set(courseName, {
          courseName,
          programName: row['Program Name'],
          units: new Map()
        });
      }

      const courseGroup = courseMap.get(courseName)!;

      // Get or create unit group
      if (!courseGroup.units.has(unitName)) {
        courseGroup.units.set(unitName, {
          unitName,
          topics: new Map()
        });
      }

      const unitGroup = courseGroup.units.get(unitName)!;

      // Get or create topic group
      if (!unitGroup.topics.has(topicName)) {
        unitGroup.topics.set(topicName, {
          topicName,
          videoUrls: []
        });
      }

      const topicGroup = unitGroup.topics.get(topicName)!;

      // Add video link if present
      if (row['Video Link'] && row['Video Link'].trim()) {
        topicGroup.videoUrls.push(row['Video Link'].trim());
      }
    }

    return courseMap;
  }

  /**
   * Create course with all chapters and lectures
   */
  private async createCourseWithChaptersAndLectures(courseGroup: CourseGroup): Promise<string> {
    // Fetch videos from videoTemp for all topics
    const videoMap = await this.fetchVideosFromVideoTemp(courseGroup);

    // Create course
    const course = await this.createCourse(courseGroup);

    // Create chapters and lectures
    const chapterIds: Types.ObjectId[] = [];
    let totalTime = 0;

    // Create Syllabus chapter and lecture as the first one if syllabus link exists
    const syllabusLink = this.syllabusMap.get(courseGroup.courseName);
    let syllabusPdfUrl: string | null = null;
    if (syllabusLink) {
      try {
        const syllabusChapter = await this.createChapter(course._id, 'Syllabus');
        chapterIds.push(syllabusChapter._id);

        syllabusPdfUrl = await this.downloadAndUploadSyllabus(syllabusLink, courseGroup.courseName);
        if (syllabusPdfUrl) {
          const syllabusLecture = await this.createSyllabusLecture(course._id, syllabusPdfUrl);
          
          // Add lecture to chapter using $addToSet to avoid duplicates
          await chapterRepository.findOneAndUpdate(
            { _id: syllabusChapter._id },
            { $addToSet: { lectures: syllabusLecture._id } },
            { multi: false }
          );
          
          // Calculate time for syllabus lecture
          if (syllabusLecture.pages && syllabusLecture.pages.length > 0) {
            const syllabusTime = syllabusLecture.pages.reduce((sum: number, page: any) => sum + (page.time || 0), 0);
            totalTime += syllabusTime;
          }
        }
      } catch (error: any) {
        console.error(`Error creating syllabus for ${courseGroup.courseName}:`, error);
      }
    }

    let unitIndex = 1;
    for (const [unitName, unitGroup] of courseGroup.units) {
      const chapterTitle = `UNIT ${unitIndex} - ${unitName}`;
      const chapter = await this.createChapter(course._id, chapterTitle);
      chapterIds.push(chapter._id);

      const lectureIds: Types.ObjectId[] = [];
      
      // Check if unit has PDF link and download/upload it
      const unitPdfKey = `${courseGroup.courseName}|${unitName}`;
      const unitPdfLink = this.unitPdfMap.get(unitPdfKey);
      let unitPdfUrl: string | null = null;
      if (unitPdfLink) {
        try {
          unitPdfUrl = await this.downloadAndUploadUnitPdf(unitPdfLink, courseGroup.courseName, unitName);
        } catch (error: any) {
          console.error(`Error downloading/uploading unit PDF for unit ${unitName} in course ${courseGroup.courseName}:`, error);
        }
      }
      
      let topicIndex = 1;
      let isFirstTopic = true;

      for (const [topicName, topicGroup] of unitGroup.topics) {
        const videoUrls = videoMap.get(`${courseGroup.courseName}|${unitName}|${topicName}`) || [];
        
        if (videoUrls.length === 0) {
          console.warn(`No videos found for ${courseGroup.courseName} - ${unitName} - ${topicName}`);
          continue;
        }

        const lectureTitle = `TOPIC ${topicIndex} - ${topicName}`;
        const lecture = await this.createLecture(course._id, lectureTitle, videoUrls, isFirstTopic && unitPdfUrl ? unitPdfUrl : null);
        lectureIds.push(lecture._id);
        topicIndex++;
        isFirstTopic = false;

        // Calculate total time from lecture pages
        if (lecture.pages && lecture.pages.length > 0) {
          const lectureTime = lecture.pages.reduce((sum: number, page: any) => sum + (page.time || 0), 0);
          totalTime += lectureTime;
        }
      }

      // Add lectures to chapter (merge with existing lectures, avoiding duplicates)
      if (lectureIds.length > 0) {
        // Use $addToSet to avoid duplicates, adding each lecture ID
        for (const lectureId of lectureIds) {
          await chapterRepository.findOneAndUpdate(
            { _id: chapter._id },
            { $addToSet: { lectures: lectureId } },
            { multi: false }
          );
        }
      }
      unitIndex++;
    }

    // Add chapters to course (merge with existing chapters, avoiding duplicates), update totalTime, and set intro to syllabus PDF URL if available
    for (const chapterId of chapterIds) {
      await courseRepository.findOneAndUpdate(
        { _id: course._id },
        { $addToSet: { chapters: chapterId } },
        { multi: false }
      );
    }
    
    // Update totalTime and intro if syllabus PDF URL is available
    const updateData: any = { totalTime };
    if (syllabusPdfUrl) {
      updateData.intro = syllabusPdfUrl;
    }
    
    if (Object.keys(updateData).length > 0) {
      await courseRepository.findOneAndUpdate(
        { _id: course._id },
        { $set: updateData },
        { multi: false }
      );
    }

    return course._id.toString();
  }

  /**
   * Fetch videos from videoTempRepository for all topics
   */
  private async fetchVideosFromVideoTemp(courseGroup: CourseGroup): Promise<Map<string, string[]>> {
    const videoMap = new Map<string, string[]>();

    for (const [unitName, unitGroup] of courseGroup.units) {
      for (const [topicName, topicGroup] of unitGroup.topics) {
        const key = `${courseGroup.courseName}|${unitName}|${topicName}`;
        
        // Find video in videoTemp by courseName, unitName, topicName
        const videoTemp = await videoTempRepository.findOne({
          courseName: courseGroup.courseName.trim(),
          unitName: unitName.trim(),
          topicName: topicName.trim()
        }).lean();

        if (videoTemp && videoTemp.url) {
          videoMap.set(key, [videoTemp.url]);
        } else {
          videoMap.set(key, []);
        }
      }
    }

    return videoMap;
  }

  /**
   * Create course with default fields
   */
  private async createCourse(courseGroup: CourseGroup): Promise<any> {
    const now = new Date();
    const defaultStartDate = new Date('2025-12-01T06:50:31.885Z');

    // Format course title based on program: MBA_{title} for MBA, else {programme} - {title}
    let courseTitle: string;
    if (courseGroup.programName && courseGroup.programName.toUpperCase() === 'MBA') {
      courseTitle = `MBA_${courseGroup.courseName}`;
    } else if (courseGroup.programName) {
      courseTitle = `${courseGroup.programName} - ${courseGroup.courseName}`;
    } else {
      courseTitle = courseGroup.courseName;
    }

    // Check if a course with the same title exists in the same university
    const existingCourse = await courseRepository.findOne({
      title: courseTitle,
      university: this.universityId,
      deleted: { $ne: true }
    }).lean();

    // If course exists, use it instead of creating a new one
    if (existingCourse) {
      console.log(`Using existing course "${courseTitle}" (ID: ${existingCourse._id})`);
      return existingCourse;
    }

    const courseData = {
      title: courseTitle,
      description: `Course: ${courseTitle}`,
      summary: `This course covers ${courseTitle}`,
      language: 'English',
      university: this.universityId,
      owner: this.ownerId,
      domain: this.domainId,
      type: 'Courses',
      price: 0,
      isActive: false,
      isApproved: false,
      isPublished: false,
      isCredX: false,
      isFavourite: false,
      isFeatured: false,
      isLocked: false,
      isLockedForTeachers: false,
      isRequested: false,
      deleted: false,
      skipEnrollPage: false,
      hasManualTime: false,
      haveCertificate: false,
      hasCompletionCertificate: false,
      splitPayment: false,
      initialPrice: null,
      secure: null,
      preRequisiteEnabled: false,
      progress: 0,
      timeLeft: 0,
      isAssetsShifted: false,
      minPoint: 0,
      paymentDueDay: 30,
      totalManualTime: null,
      certificate: null,
      certificateSerial: null,
      completionCertificate: null,
      credit: null,
      intro: null,
      meta: {
        title: null,
        description: null
      },
      program: null,
      semester: null,
      subjectCode: null,
      chapters: [],
      editors: [this.ownerId],
      students: [],
      classStudents: [],
      galleries: [],
      previousGalleries: [],
      objective: [
        "1. Gain a comprehensive understanding of databases and their importance in modern computing.",
        "2. Develop skills in database design, modelling, and normalization.",
        "3. Understand SQL and its role in querying, manipulating, and retrieving data from databases."
      ],
      learnings: [
        "CO1: Understand core concepts of DBMS, data abstraction, and database architectures.",
        "CO-2: Apply relational concepts and normalization techniques to design effective databases.",
        "CO-3: Analyze and implement methods for transaction management and concurrency control.",
        "CO-4: Use SQL to perform data definition, manipulation, and complex data retrieval operations."
      ],
      requirements: [
        "1. Basic understanding of computer systems and terminology.",
        "2. Familiarity with fundamental concepts of data storage and manipulation.",
        "3. Proficiency in using a computer and common software applications."
      ],
      skills: [
        "2. Normalization & Data Organization",
        "3. Transaction & Concurrency Management",
        "4.  ER Diagramming & Data Representation",
        "1. Database Design & Modelling",
        "5. SQL Querying & Data Manipulation"
      ],
      credX: {
        admissionProcess: [{
          description: null,
          title: null
        }],
        courseDuration: null,
        courseDurationUnit: 'days',
        courseType: 'masters',
        credits: null,
        eligibility: [{
          icon: null,
          description: null,
          link: null,
          title: null
        }],
        hasEligibility: false,
        hasAdmissionProcess: false,
        instructorLed: {
          actualFee: null,
          certificate: null,
          country: null,
          discountedFee: null,
          duration: null,
          durationUnit: 'days',
          livingCost: null,
          startDates: [{
            date: defaultStartDate
          }]
        },
        onCampus: {
          actualFee: null,
          certificate: null,
          country: null,
          discountedFee: null,
          duration: null,
          durationUnit: 'days',
          livingCost: null,
          startDates: [{
            date: defaultStartDate
          }]
        },
        selfPaced: {
          actualFee: null,
          certificate: null,
          country: null,
          discountedFee: null,
          duration: null,
          durationUnit: 'days',
          livingCost: null,
          startDates: [{
            date: defaultStartDate
          }]
        },
        tags: null,
        rating: 0,
        tabs: [{
          description: null,
          hasForm: false,
          horizontalForm: true,
          title: null
        }]
      },
      restricted: {
        enabled: false,
        mode: 'lesson'
      },
      reviews: {
        totalRatings: 0,
        averageRatings: 0,
        zeroPointFiveStar: 0,
        oneStar: 0,
        onePointFiveStar: 0,
        twoStar: 0,
        twoPointFiveStar: 0,
        threeStar: 0,
        threePointFiveStar: 0,
        fourStar: 0,
        fourPointFiveStar: 0,
        fiveStar: 0
      },
      grade: {
        aPlus: 95,
        a: 90,
        bPlus: 85,
        b: 80,
        cPlus: 65,
        c: 60,
        dPlus: 35,
        d: 30
      },
      rubric: {
        assignment: {
          weightageEnabled: false,
          globalWeightageEnabled: false,
          globalWeightage: 0,
          options: []
        },
        attendance: {
          globalWeightageEnabled: false,
          globalWeightage: 0
        },
        custom: {
          weightageEnabled: false,
          globalWeightageEnabled: false,
          globalWeightage: 0,
          options: []
        },
        exam: {
          weightageEnabled: false,
          globalWeightageEnabled: false,
          globalWeightage: 0,
          options: []
        },
        lecture: {
          weightageEnabled: false,
          globalWeightageEnabled: false,
          globalWeightage: 0,
          options: []
        },
        progress: {
          globalWeightageEnabled: false,
          weightage: 0,
          weightageCondition: 0,
          weightageEnabled: false
        }
      },
      createdAt: now,
      updatedAt: now
    };

    const course = await courseRepository.create(courseData);
    return course;
  }

  /**
   * Create chapter or use existing one
   */
  private async createChapter(courseId: Types.ObjectId, unitName: string): Promise<any> {
    // Check if chapter already exists for this course with the same title
    const existingChapter = await chapterRepository.findOne({
      course: courseId,
      title: unitName
    }).lean();

    if (existingChapter) {
      console.log(`Using existing chapter "${unitName}" (ID: ${existingChapter._id})`);
      return existingChapter;
    }

    // Create new chapter if not found
    const chapter = await chapterRepository.create({
      course: courseId,
      owner: this.ownerId,
      title: unitName,
      lectures: []
    });

    return chapter;
  }

  /**
   * Create lecture with video pages or use existing one
   * @param pdfUrl Optional PDF URL to add as content page (first page)
   */
  private async createLecture(courseId: Types.ObjectId, topicName: string, videoUrls: string[], pdfUrl: string | null = null): Promise<any> {
    // Check if lecture already exists for this course with the same title
    const existingLecture = await lectureRepository.findOne({
      course: courseId,
      title: topicName
    }).lean();

    if (existingLecture) {
      console.log(`Using existing lecture "${topicName}" (ID: ${existingLecture._id})`);
      return existingLecture;
    }

    // Create pages array with proper typing
    const pages: any[] = [];

    // Add content page as first page if PDF URL is provided
    if (pdfUrl) {
      pages.push({
        title: 'Content',
        contentType: 'document',
        assetUrl: pdfUrl,
        time: 300 // 5 minutes in seconds
      });
    }

    // Create pages from video URLs
    const videoPages = videoUrls.map((videoUrl, index) => ({
      title: index === 0 ? 'Video' : `Video ${index + 1}`,
      contentType: 'video',
      video: videoUrl,
      assetUrl: videoUrl,
      time: 1800 // 30 minutes in seconds
    }));

    pages.push(...videoPages);

    // Create new lecture if not found
    const lecture = await lectureRepository.create({
      course: courseId,
      owner: this.ownerId,
      title: topicName,
      pages: pages
    });

    return lecture;
  }

  /**
   * Parse syllabus Excel file to extract course names and syllabus links
   * Fetches syllabus from a worksheet named "{tabName}_S" where tabName is provided as parameter
   */
  private async parseSyllabusExcel(): Promise<void> {
    if (!this.workbook) {
      return;
    }

    if (!this.tabName) {
      console.warn('Tab name not provided, skipping syllabus parsing');
      return;
    }

    const syllabusWorksheetName = `${this.tabName}_S`;

    // Try to get the syllabus worksheet by name
    const worksheet = this.workbook.getWorksheet(syllabusWorksheetName);
    if (!worksheet) {
      console.warn(`Syllabus worksheet "${syllabusWorksheetName}" not found in Excel file`);
      return;
    }

    const rows: SyllabusRow[] = [];
    let headers: { [key: string]: number } = {};
    let headerRowFound = false;

    worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      if (rowNumber === 1) {
        row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
          const headerValue = cell.value?.toString() || '';
          headers[headerValue] = colNumber;
        });
        headerRowFound = true;
        return;
      }

      if (!headerRowFound) {
        return;
      }

      const rowData: SyllabusRow = {
        'Course Name': '',
        'Syllabus-Link': ''
      };

      for (const [headerName, colNumber] of Object.entries(headers)) {
        const cell = row.getCell(colNumber);
        let cellValue = '';

        // Check if cell has a hyperlink (can be string or object with target property)
        const hyperlink = cell.hyperlink as any;
        if (hyperlink && typeof hyperlink === 'object' && hyperlink.target) {
          cellValue = hyperlink.target;
        } else if (typeof cell.value === 'object' && cell.value !== null && 'formula' in cell.value) {
          const formula = (cell.value as any).formula;
          const urlMatch = formula?.match(/=HYPERLINK\("([^"]+)"/i);
          if (urlMatch && urlMatch[1]) {
            cellValue = urlMatch[1];
          } else {
            if (cell.value && (cell.value as any).hyperlink) {
              cellValue = (cell.value as any).hyperlink;
            } else {
              cellValue = cell.value?.toString() || '';
            }
          }
        } else {
          if (cell.value && (cell.value as any).hyperlink) {
            cellValue = (cell.value as any).hyperlink;
          } else {
            cellValue = cell.value?.toString() || '';
          }
        }

        if (headerName === 'Course Name' || headerName === 'Syllabus-Link') {
          (rowData as any)[headerName] = cellValue;
        }
      }

      if (rowData['Course Name'] && rowData['Syllabus-Link']) {
        rows.push(rowData);
      }
    });

    // Build syllabus map
    for (const row of rows) {
      if (row['Course Name'] && row['Syllabus-Link']) {
        this.syllabusMap.set(row['Course Name'].trim(), row['Syllabus-Link'].trim());
      }
    }

    console.log(`Parsed ${this.syllabusMap.size} syllabus links from Excel file`);
  }

  /**
   * Download PDF from Google Drive and upload to S3
   */
  private async downloadAndUploadSyllabus(syllabusLink: string, courseName: string): Promise<string | null> {
    let downloadedFilePath: string | undefined;
    
    try {
      // Create temporary file path
      const tempDir = os.tmpdir();
      const fileName = `syllabus-${courseName.replace(/[^a-zA-Z0-9]/g, '-')}-${Date.now()}.pdf`;
      downloadedFilePath = path.join(tempDir, fileName);

      // Download from Google Drive
      console.log(`Downloading syllabus PDF from Google Drive for course: ${courseName}`);
      const googleDriveDownloader = new GoogleDriveDownloader();
      await googleDriveDownloader.downloadFile(syllabusLink, downloadedFilePath);

      if (!FileUtils.fileExists(downloadedFilePath)) {
        throw new Error('Downloaded file does not exist');
      }

      const fileSize = FileUtils.getFileSize(downloadedFilePath);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      // Read file content
      const fileContent = FileUtils.readFile(downloadedFilePath);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      // Upload to S3
      const s3 = new S3University(this.universityConfig, true);
      const safeFileName = `syllabus-${courseName.replace(/[^a-zA-Z0-9]/g, '-')}-${Date.now()}.pdf`;
      const uploadedUrl = await s3.uploadBuffer(fileContent, safeFileName, this.universityConfig.buckets.LMS_COURSE_VIDEOS);

      if (!uploadedUrl) {
        throw new Error('Upload to S3 failed');
      }

      console.log(`Successfully uploaded syllabus PDF for course: ${courseName}`);
      return uploadedUrl;
    } catch (error: any) {
      console.error(`Error downloading/uploading syllabus for ${courseName}:`, error);
      return null;
    } finally {
      // Clean up temporary file
      if (downloadedFilePath && FileUtils.fileExists(downloadedFilePath)) {
        try {
          FileUtils.removeFile(downloadedFilePath);
        } catch (error) {
          console.warn(`Failed to remove temporary file: ${downloadedFilePath}`, error);
        }
      }
    }
  }

  /**
   * Create syllabus lecture with PDF page or use existing one
   */
  private async createSyllabusLecture(courseId: Types.ObjectId, pdfUrl: string): Promise<any> {
    // Check if syllabus lecture already exists for this course
    const existingLecture = await lectureRepository.findOne({
      course: courseId,
      title: 'Syllabus'
    }).lean();

    if (existingLecture) {
      console.log(`Using existing syllabus lecture (ID: ${existingLecture._id})`);
      return existingLecture;
    }

    // Create page with PDF document
    const page = {
      title: 'Syllabus',
      contentType: 'document',
      assetUrl: pdfUrl,
      time: 300 // 5 minutes in seconds
    };

    // Create new lecture if not found
    const lecture = await lectureRepository.create({
      course: courseId,
      owner: this.ownerId,
      title: 'Syllabus',
      pages: [page]
    });

    return lecture;
  }

  /**
   * Download PDF from Google Drive and upload to S3 for unit content
   */
  private async downloadAndUploadUnitPdf(pdfLink: string, courseName: string, unitName: string): Promise<string | null> {
    let downloadedFilePath: string | undefined;
    
    try {
      // Create temporary file path
      const tempDir = os.tmpdir();
      const safeUnitName = unitName.replace(/[^a-zA-Z0-9]/g, '-');
      const fileName = `content-${courseName.replace(/[^a-zA-Z0-9]/g, '-')}-${safeUnitName}-${Date.now()}.pdf`;
      downloadedFilePath = path.join(tempDir, fileName);

      // Download from Google Drive
      console.log(`Downloading unit PDF from Google Drive for course: ${courseName}, unit: ${unitName}`);
      const googleDriveDownloader = new GoogleDriveDownloader();
      await googleDriveDownloader.downloadFile(pdfLink, downloadedFilePath);

      if (!FileUtils.fileExists(downloadedFilePath)) {
        throw new Error('Downloaded file does not exist');
      }

      const fileSize = FileUtils.getFileSize(downloadedFilePath);
      if (fileSize === 0) {
        throw new Error('Downloaded file is empty');
      }

      // Read file content
      const fileContent = FileUtils.readFile(downloadedFilePath);
      if (!fileContent || fileContent.length === 0) {
        throw new Error('Failed to read file content');
      }

      // Upload to S3
      const s3 = new S3University(this.universityConfig, true);
      const safeFileName = `content-${courseName.replace(/[^a-zA-Z0-9]/g, '-')}-${safeUnitName}-${Date.now()}.pdf`;
      const uploadedUrl = await s3.uploadBuffer(fileContent, safeFileName, this.universityConfig.buckets.LMS_COURSE_VIDEOS);

      if (!uploadedUrl) {
        throw new Error('Upload to S3 failed');
      }

      console.log(`Successfully uploaded unit PDF for course: ${courseName}, unit: ${unitName}`);
      return uploadedUrl;
    } catch (error: any) {
      console.error(`Error downloading/uploading unit PDF for ${courseName} - ${unitName}:`, error);
      return null;
    } finally {
      // Clean up temporary file
      if (downloadedFilePath && FileUtils.fileExists(downloadedFilePath)) {
        try {
          FileUtils.removeFile(downloadedFilePath);
        } catch (error) {
          console.warn(`Failed to remove temporary file: ${downloadedFilePath}`, error);
        }
      }
    }
  }

}

