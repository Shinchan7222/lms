import { courseRepository } from '@edorer/course-data';
import { chapterRepository } from '@edorer/chapter-data';
import { lectureRepository } from '@edorer/lecture-data';

export class DuplicateLectureCheckerService {
    private readonly universityId: string;

    constructor(universityId: string) {
        this.universityId = universityId;
    }

    async process(): Promise<{
        message: string;
        totalDupLecturesFound: number;
        report: any[];
        error?: string;
    }> {
        try {
            const courses = await courseRepository.find({
                university: this.universityId,
                deleted: false
            });

            const duplicatesReport = [];
            let totalDupLecturesFound = 0;

            for (const course of courses) {
                if (!course.chapters || course.chapters.length === 0) continue;

                const chapters = await chapterRepository.find({
                    _id: { $in: course.chapters }
                });

                for (const chapter of chapters) {
                    if (!chapter.lectures || chapter.lectures.length === 0) continue;

                    const lectures = await lectureRepository.find({
                        _id: { $in: chapter.lectures }
                    });

                    const nameCounts = new Map<string, number>();

                    for (const lecture of lectures) {
                        let name = lecture.title || '';
                        // Normalize: Remove "* Unit {i} - " or "Unit {i} - " prefix
                        // Regex: optional *, optional space, Unit, space, digits, optional space, optional hyphen/colon, optional space
                        const normalized = name.replace(/^(\*?)\s*Unit\s+\d+\s*[-:]?\s*/i, '').trim();

                        if (nameCounts.has(normalized)) {
                            nameCounts.set(normalized, (nameCounts.get(normalized) || 0) + 1);
                        } else {
                            nameCounts.set(normalized, 1);
                        }
                    }

                    const chapterDuplicates = [];
                    for (const [name, count] of nameCounts.entries()) {
                        if (count > 1) {
                            chapterDuplicates.push({
                                name: name,
                                count: count
                            });
                            totalDupLecturesFound += (count - 1);
                        }
                    }

                    if (chapterDuplicates.length > 0) {
                        duplicatesReport.push({
                            courseId: course._id,
                            courseTitle: course.title,
                            chapterId: chapter._id,
                            chapterTitle: chapter.title,
                            duplicates: chapterDuplicates
                        });
                    }
                }
            }

            return {
                message: 'Duplicate lectures check completed',
                totalDupLecturesFound,
                report: duplicatesReport
            };

        } catch (error: any) {
            console.error('Error checking for duplicate lectures:', error);
            return {
                message: 'Error checking for duplicate lectures',
                totalDupLecturesFound: 0,
                report: [],
                error: error.message
            };
        }
    }
}
