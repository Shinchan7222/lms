import { Question, QuestionDifficulty, QuestionTypes } from '@edorer/question-data';
import { ReadableIdGenerator } from './ReadableIdGenerator';

export class ExportQuestionsForVec {

    private convertedQuestions = [];

    private readonly owner: string;

    private readonly questions: Question[] = [];

    constructor(owner: string, questions: Question[]) {
        this.owner = owner;
        this.questions = questions;
    }

    private static formatAnswers(type: QuestionTypes, options: any[]) {
        switch (type) {
            case QuestionTypes.PROGRAMMING: {
                return options.map(option => {
                    return {
                        ...option,
                        testCaseInput: option.input,
                        testCaseOutput: option.output,
                        isHugeTestCaseInput: option.isInputHuge,
                        isHugeTestCaseOutput: option.isOutputHuge,
                        isVisible: option.visible,
                    };
                });
            }

            default: {
                return options;
            }
        }
    }

    private static formatType(type: QuestionTypes) {
        switch (type) {
            case QuestionTypes.FILL_IN_THE_BLANKS: {
                return 'Fill in the Blank';
            }

            case QuestionTypes.FREE_ANSWER: {
                return 'Subjective';
            }

            case QuestionTypes.LIKERT_SCALE: {
                return 'Linear Scale';
            }

            case QuestionTypes.MATCHING: {
                return 'Match the Following';
            }

            case QuestionTypes.MULTIPLE_SELECT: {
                return 'Multiple Choice';
            }

            case QuestionTypes.ORDERING: {
                return 'Sorting';
            }

            case QuestionTypes.PROGRAMMING: {
                return 'Problem Solving';
            }

            case QuestionTypes.SINGLE_SELECT: {
                return 'Single Choice';
            }

            case QuestionTypes.VIDEO: {
                return 'Video Response';
            }

            case QuestionTypes.GROUP: {
                return 'Group Question';
            }
        }
    }

    private static formatDifficulty(difficulty: QuestionDifficulty) {
        switch (difficulty) {
            case QuestionDifficulty.EASY: {
                return 'Smart';
            }

            case QuestionDifficulty.MEDIUM: {
                return 'Brilliant';
            }

            case QuestionDifficulty.HARD: {
                return 'Genius';
            }
        }
    }

    convert() {
        this.convertQuestions();

        return this.convertedQuestions;
    }

    private convertQuestions() {
        for (let question of this.questions) {
            const convertedQuestion: { [key: string]: Array<any> | boolean | number | object | string } = { ...question };
            const options = question.options.map(option => ({ ...option, pointsType: '+ve' }));

            convertedQuestion.answers = ExportQuestionsForVec.formatAnswers(question.type as QuestionTypes, options);
            convertedQuestion.category = question.category._id;
            convertedQuestion.difficultyLevel = ExportQuestionsForVec.formatDifficulty(question.difficulty as QuestionDifficulty);
            convertedQuestion.owner = this.owner;
            convertedQuestion.pointType = 'question';
            convertedQuestion.points = question.points;
            convertedQuestion.readableId = ReadableIdGenerator.generate(question);
            convertedQuestion.subCategory = question.category._id;
            convertedQuestion.type = ExportQuestionsForVec.formatType(question.type as QuestionTypes);

            this.convertedQuestions.push(convertedQuestion);
        }
    }
}
