import { AwsDocumentsRestorer } from './AwsDocumentsRestorer';
import { ClassroomWork, classroomWorkRepository } from '@edorer/classroom-work-data';
import { createHash } from 'crypto';
import { Downloader, S3University } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { mailer } from '@edorer/mailer';
import { University, UniversityConfiguration } from '@edorer/university-data';

export class TransferClassroomWorks {
  private readonly restore: boolean = true;
  private readonly works: ClassroomWork[] = [];
  private readonly university: University;
  private readonly universityConfig: UniversityConfiguration;
  private readonly MAX_RETRIES = 3;
  private readonly MAX_CONCURRENT_TASKS = Math.max(4, Math.floor(require('os').cpus().length * 0.75));

  private activePromises = new Set<Promise<void>>();
  private stats = {
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0
  };
  private deniedUrls: { encodedUrl?: string; url: string; type: 'document' | 'video' | 'image'; workId: string }[] = [];

  constructor(works: ClassroomWork[] = [], university: University, universityConfig: UniversityConfiguration, restore = true) {
    this.restore = restore;
    this.university = university;
    this.universityConfig = universityConfig;
    this.works = works;
  }

  private async addToQueue(task: () => Promise<void>): Promise<void> {
    while (this.activePromises.size >= this.MAX_CONCURRENT_TASKS) {
      await Promise.race(this.activePromises);
    }

    const promise = task().finally(() => {
      this.activePromises.delete(promise);
    });

    this.activePromises.add(promise);
    return promise;
  }

  private isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return url.includes('amazonaws.com');
    } catch {
      return false;
    }
  }

  private generateSafeFileName(originalName: string): string {
    const ext = originalName.split('.').pop() || '';
    const hash = createHash('md5').update(originalName).digest('hex').slice(0, 8);
    // Take only first 12 chars of the name to keep it short
    const safeName = originalName
      .split('.')[0]
      .replace(/[^a-zA-Z0-9]/g, '-') // Replace non-alphanumeric chars with dash
      .replace(/-+/g, '-') // Replace multiple dashes with single dash
      .slice(0, 12)
      .trim();
    return `${safeName}-${hash}.${ext}`;
  }

  private async downloadAndUploadUrl(url: string, bucketName: any, workId: string, type: 'document' | 'video' | 'image'): Promise<string | null> {
    let downloadedUrl: string | undefined;
    try {
      const filename = url.split('/').pop();
      const encodedFilename = encodeURIComponent(filename);

      const encodedUrl = url.replace(filename, encodedFilename);

      const downloader = new Downloader(encodedUrl);
      downloadedUrl = await downloader.download();

      if (!downloadedUrl || !FileUtils.fileExists(downloadedUrl)) {
        this.deniedUrls.push({ encodedUrl, url, type, workId });
        throw new Error('Download failed');
      }

      const fileSize = FileUtils.getFileSize(downloadedUrl);
      if (fileSize === 0) {
        this.deniedUrls.push({ encodedUrl, url, type, workId });
        throw new Error('Downloaded file is empty');
      }

      const fileContent = FileUtils.readFile(downloadedUrl);
      if (!fileContent || fileContent.length === 0) {
        this.deniedUrls.push({ encodedUrl, url, type, workId });
        throw new Error('Failed to read file content');
      }

      const originalFileName = url.split('/').pop() || '';
      const safeFileName = this.generateSafeFileName(originalFileName);

      const s3 = new S3University(this.universityConfig, true);
      const uploadedUrl = await s3.uploadBuffer(fileContent, safeFileName, bucketName);

      if (!uploadedUrl) {
        throw new Error('Upload failed');
      }

      return uploadedUrl;
    } catch {
      this.deniedUrls.push({ url, type, workId });
      return null;
    } finally {
      if (downloadedUrl && FileUtils.fileExists(downloadedUrl)) {
        try {
          FileUtils.removeFile(downloadedUrl);
        } catch {}
      }
    }
  }

  private async processImagesWithRetry(work: ClassroomWork, retryCount = 0): Promise<void> {
    try {
      if (!work.images || !Array.isArray(work.images) || work.images.length === 0) {
        return;
      }

      const uploadedImages: string[] = [];
      const originalImages: string[] = [...work.images];

      for (const imageUrl of originalImages) {
        if (this.isValidUrl(imageUrl)) {
          const uploadedUrl = await this.downloadAndUploadUrl(
            imageUrl,
            this.universityConfig.buckets.LMS_COURSE_VIDEOS,
            work._id.toString(),
            'image'
          );

          if (uploadedUrl) {
            uploadedImages.push(uploadedUrl);
          } else {
            uploadedImages.push(imageUrl);
          }
        } else {
          uploadedImages.push(imageUrl);
        }
      }

      if (JSON.stringify(originalImages) !== JSON.stringify(uploadedImages)) {
        work.images = uploadedImages;
        work.previousImages = originalImages;

        await classroomWorkRepository.update(
          { _id: work._id },
          { $set: { images: work.images, previousImages: work.previousImages, isShifted: true } }
        );
      }
    } catch (error) {
      if (retryCount < this.MAX_RETRIES) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retryCount + 1)));
        return this.processImagesWithRetry(work, retryCount + 1);
      }
      this.stats.failed++;
    }
  }

  private async processWorkWithRetry(work: ClassroomWork, retryCount = 0): Promise<void> {
    let downloadedDocUrl: string | undefined;
    let downloadedVideoUrl: string | undefined;

    try {
      if (work.document && this.isValidUrl(work.document)) {
        const uploadedUrl = await this.downloadAndUploadUrl(
          work.document,
          this.universityConfig.buckets.LMS_COURSE_VIDEOS,
          work._id.toString(),
          'document'
        );

        if (uploadedUrl) {
          const originalDoc = work.document;
          work.document = uploadedUrl;

          await classroomWorkRepository.update(
            { _id: work._id },
            {
              $set: {
                document: uploadedUrl,
                previousDocument: originalDoc,
                isShifted: true
              }
            }
          );
          this.stats.successful++;
        }
      }

      if (work.video && this.isValidUrl(work.video)) {
        const uploadedUrl = await this.downloadAndUploadUrl(
          work.video,
          this.universityConfig.buckets.LMS_COURSE_VIDEOS,
          work._id.toString(),
          'video'
        );

        if (uploadedUrl) {
          const originalVideo = work.video;
          work.video = uploadedUrl;

          await classroomWorkRepository.update(
            { _id: work._id },
            {
              $set: {
                video: uploadedUrl,
                previousVideo: originalVideo,
                isShifted: true
              }
            }
          );
          this.stats.successful++;
        }
      }

      await this.processImagesWithRetry(work);
      this.stats.processed++;
    } catch (error) {
      if (retryCount < this.MAX_RETRIES) {
        await new Promise((resolve) => setTimeout(resolve, 1000 * (retryCount + 1)));
        return this.processWorkWithRetry(work, retryCount + 1);
      }
      this.stats.failed++;
      this.stats.processed++;

      try {
        await this.processImagesWithRetry(work);
      } catch {}
    } finally {
      if (downloadedDocUrl && FileUtils.fileExists(downloadedDocUrl)) {
        try {
          FileUtils.removeFile(downloadedDocUrl);
        } catch {}
      }
      if (downloadedVideoUrl && FileUtils.fileExists(downloadedVideoUrl)) {
        try {
          FileUtils.removeFile(downloadedVideoUrl);
        } catch {}
      }
    }
  }

  public async transfer() {
    if (this.works.length === 0) {
      return;
    }

    if (this.restore) {
      const documents = this.works.map((work) => work.document).filter((url) => this.isValidUrl(url));
      const videos = this.works.map((work) => work.video).filter((url) => this.isValidUrl(url));
      const images = this.works.flatMap((work) => work.images).filter((url) => this.isValidUrl(url));
      const allUrls = [...documents, ...videos, ...images];

      const restorer = new AwsDocumentsRestorer(20, 4, allUrls, this.university);
      await restorer.restore();
    }

    // Calculate total items to process
    this.stats.total = this.works.length;

    // Process all works maintaining max concurrent tasks
    for (const work of this.works) {
      await this.addToQueue(() => this.processWorkWithRetry(work));
    }

    // Wait for any remaining tasks to complete
    await Promise.all(this.activePromises);

    await this.sendMail();
  }

  private async sendMail() {
    try {
      const mailOptions: any = {};
      mailOptions.from = '"' + process.env.MAILER_NAME + ' " <' + process.env.MAILER_FROM + '>';

      // Group denied URLs by type
      const deniedDocuments = this.deniedUrls.filter((item) => item.type === 'document');
      const deniedVideos = this.deniedUrls.filter((item) => item.type === 'video');
      const deniedImages = this.deniedUrls.filter((item) => item.type === 'image');

      const deniedUrlsHtml = `
        <div style="margin: 20px 0;">
          <h5>Denied Access URLs:</h5>
          ${
            deniedDocuments.length > 0
              ? `
            <h6>Documents (${deniedDocuments.length}):</h6>
            <ul>
              ${deniedDocuments.map((item) => `<li>Work ID: ${item.workId} - URL: ${item.url}</li>`).join('')}
            </ul>
          `
              : ''
          }
          ${
            deniedVideos.length > 0
              ? `
            <h6>Videos (${deniedVideos.length}):</h6>
            <ul>
              ${deniedVideos.map((item) => `<li>Work ID: ${item.workId} - URL: ${item.url}</li>`).join('')}
            </ul>
          `
              : ''
          }
          ${
            deniedImages.length > 0
              ? `
            <h6>Images (${deniedImages.length}):</h6>
            <ul>
              ${deniedImages.map((item) => `<li>Work ID: ${item.workId} - URL: ${item.url}</li>`).join('')}
            </ul>
          `
              : ''
          }
        </div>
      `;

      mailOptions.html = `
          <h4>Classroom works assets transferred for ${this.university.url}!</h4>
          <div style="margin: 20px 0;">
            <h5>Transfer Statistics:</h5>
            <ul>
              <li>Total Works: ${this.stats.total}</li>
              <li>Successfully Processed: ${this.stats.successful}</li>
              <li>Failed: ${this.stats.failed}</li>
              <li>Success Rate: ${((this.stats.successful / this.stats.total) * 100).toFixed(2)}%</li>
            </ul>
          </div>
          ${this.deniedUrls.length > 0 ? deniedUrlsHtml : '<p>No access denied URLs found.</p>'}
          </br></br>
          <p>Best regards,</p>
          <p><em>This is an automated message, please do not reply directly to this email.</em></p>
        `;
      mailOptions.subject = `Classroom works transfer complete - Success Rate: ${((this.stats.successful / this.stats.total) * 100).toFixed(2)}% - ${
        this.deniedUrls.length
      } Denied URLs`;
      mailOptions.to = 'abdul@edorer.com';

      mailer.init();
      await mailer.send(mailOptions);
    } catch {}
  }
}
