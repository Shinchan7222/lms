import axios from 'axios';
import { chapterRepository } from '@edorer/chapter-data';

interface AssignmentGenerationResult {
  success: boolean;
  chapterId: string;
  courseId: string;
  error?: string;
}

interface GenerateAssignmentResponse {
  questions: Array<{
    question: string;
    difficulty: string;
    estimatedTime: number;
    reference: {
      lectureTitle: string;
      page: string;
      excerpt: string;
    };
  }>;
}

export class AssignmentGeneratorService {
  private readonly courseId: string;
  private readonly generateApiUrl: string = 'https://api-ai.edorer.com/api/assignments/generate';
  private readonly saveApiUrl: string = 'https://api-ai.edorer.com/api/assignment-generations';
  private readonly authToken: string = 'fda221uh3u2h313320-db34-11eb-89cb-c365057a3241';
  private results: AssignmentGenerationResult[] = [];

  constructor(courseId: string) {
    this.courseId = courseId;
  }

  async process(): Promise<{ success: number; errors: number; results: AssignmentGenerationResult[] }> {
    try {
      // Fetch all chapters for the course, excluding syllabus
      const chapters = await this.fetchChaptersExcludingSyllabus();
      
      if (chapters.length === 0) {
        return {
          success: 0,
          errors: 0,
          results: []
        };
      }

      // Process chapters in parallel batches of 7
      const batchSize = 7;
      for (let i = 0; i < chapters.length; i += batchSize) {
        const batch = chapters.slice(i, i + batchSize);
        await Promise.all(batch.map(chapter => this.processChapter(chapter)));
      }

      const successCount = this.results.filter(r => r.success).length;
      const errorCount = this.results.filter(r => !r.success).length;

      return {
        success: successCount,
        errors: errorCount,
        results: this.results
      };
    } catch (error: any) {
      console.error('Error processing assignment generation:', error);
      throw new Error(error.message || 'Failed to process assignment generation');
    }
  }

  private async fetchChaptersExcludingSyllabus() {
    // Get all chapters for the course that are NOT syllabus
    const chapters = await chapterRepository
      .find({
        course: this.courseId,
        title: { $ne: 'Syllabus' }
      })
      .select('_id')
      .lean();

    return chapters;
  }

  private async processChapter(chapter: any) {
    try {
      // Check if chapter has a lecture called "Assignment"
      const chapterWithLectures = await chapterRepository
        .findOne({ _id: chapter._id })
        .populate('lectures', 'title')
        .lean();

      if (chapterWithLectures?.lectures) {
        const hasAssignmentLecture = chapterWithLectures.lectures.some(
          (lecture: any) => lecture.title === 'Assignment'
        );

        if (hasAssignmentLecture) {
          // Skip processing if chapter has a lecture called "Assignment"
          this.results.push({
            success: false,
            chapterId: chapter._id.toString(),
            courseId: this.courseId,
            error: 'Chapter has a lecture called "Assignment", skipping'
          });
          return;
        }
      }

      // Step 1: Generate assignment
      const generateData = JSON.stringify({
        type: 'Chapter based',
        course: this.courseId,
        questionCount: 1,
        difficulty: 'Easy',
        chapter: chapter._id.toString()
      });

      const generateConfig = {
        method: 'post' as const,
        maxBodyLength: Infinity,
        url: this.generateApiUrl,
        headers: {
          'sec-ch-ua-platform': '"macOS"',
          'AuthorizationToken': this.authToken,
          'Referer': 'https://ai.edorer.com/',
          'sec-ch-ua': '"Brave";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
          'sec-ch-ua-mobile': '?0',
          'ContentType': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json'
        },
        data: generateData
      };

      const generateResponse = await axios.request<GenerateAssignmentResponse>(generateConfig);

      // Step 2: Save the assignment
      if (!generateResponse.data.questions || generateResponse.data.questions.length === 0) {
        this.results.push({
          success: false,
          chapterId: chapter._id.toString(),
          courseId: this.courseId,
          error: 'No questions generated'
        });
        return;
      }

      // Transform questions from API response to save format
      const questionsToSave = generateResponse.data.questions.map(q => ({
        question: q.question,
        difficulty: q.difficulty.charAt(0).toUpperCase() + q.difficulty.slice(1).toLowerCase(), // Capitalize first letter
        estimatedTime: `${q.estimatedTime} minutes`,
        isSelected: true,
        reference: q.reference
      }));

      const saveData = JSON.stringify({
        type: 'Chapter based',
        course: this.courseId,
        chapter: chapter._id.toString(),
        questions: questionsToSave
      });

      const saveConfig = {
        method: 'post' as const,
        maxBodyLength: Infinity,
        url: this.saveApiUrl,
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'Accept-Language': 'en-US,en;q=0.5',
          'AuthorizationToken': this.authToken,
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'Content-Type': 'application/json',
          'ContentType': 'application/json',
          'Origin': 'https://ai.edorer.com',
          'Pragma': 'no-cache',
          'Referer': 'https://ai.edorer.com/',
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'same-site',
          'Sec-GPC': '1',
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
          'sec-ch-ua': '"Brave";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"macOS"'
        },
        data: saveData
      };

      await axios.request(saveConfig);

      this.results.push({
        success: true,
        chapterId: chapter._id.toString(),
        courseId: this.courseId
      });
    } catch (error: any) {
      console.error(`Error processing chapter ${chapter._id}:`, error);
      this.results.push({
        success: false,
        chapterId: chapter._id.toString(),
        courseId: this.courseId,
        error: error.message || 'Failed to generate assignment'
      });
    }
  }
}

