import axios from 'axios';
import { lectureRepository } from '@edorer/lecture-data';
import { chapterRepository } from '@edorer/chapter-data';

interface VideoTextConversionResult {
  success: boolean;
  lectureId: string;
  chapterId: string;
  courseId: string;
  error?: string;
}

export class VideoTextConverterService {
  private readonly courseId: string;
  private readonly apiUrl: string = 'https://api-ai.edorer.com/api/video-text/convert';
  private readonly authToken: string = 'fda221uh3u2h313320-db34-11eb-89cb-c365057a3241';
  private results: VideoTextConversionResult[] = [];

  constructor(courseId: string) {
    this.courseId = courseId;
  }

  async process(): Promise<{ success: number; errors: number; results: VideoTextConversionResult[] }> {
    try {
      // Fetch all lectures with videos for the course
      const lectures = await this.fetchLecturesWithVideos();
      
      if (lectures.length === 0) {
        return {
          success: 0,
          errors: 0,
          results: []
        };
      }

      // Process each lecture
      for (const lecture of lectures) {
        await this.processLecture(lecture);
      }

      const successCount = this.results.filter(r => r.success).length;
      const errorCount = this.results.filter(r => !r.success).length;

      return {
        success: successCount,
        errors: errorCount,
        results: this.results
      };
    } catch (error: any) {
      console.error('Error processing video text conversion:', error);
      throw new Error(error.message || 'Failed to process video text conversion');
    }
  }

  private async fetchLecturesWithVideos() {
    // Find all lectures for the course that have at least one page with contentType 'video'
    const lectures = await lectureRepository
      .find({
        course: this.courseId,
        'pages.contentType': 'video'
      })
      .select('_id pages')
      .lean();

    return lectures;
  }

  private async processLecture(lecture: any) {
    try {
      // Find the chapter that contains this lecture
      const chapter = await chapterRepository
        .findOne({
          course: this.courseId,
          lectures: lecture._id
        })
        .select('_id')
        .lean();

      if (!chapter) {
        this.results.push({
          success: false,
          lectureId: lecture._id.toString(),
          chapterId: '',
          courseId: this.courseId,
          error: 'Chapter not found for lecture'
        });
        return;
      }

      // Call the video text conversion API
      const data = JSON.stringify({
        course: this.courseId,
        chapter: chapter._id.toString(),
        lecture: lecture._id.toString()
      });

      const config = {
        method: 'post' as const,
        maxBodyLength: Infinity,
        url: this.apiUrl,
        headers: {
          'sec-ch-ua-platform': '"macOS"',
          'AuthorizationToken': this.authToken,
          'Referer': 'http://localhost:3000/',
          'sec-ch-ua': '"Brave";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
          'sec-ch-ua-mobile': '?0',
          'ContentType': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json'
        },
        data: data
      };

      await axios.request(config);

      this.results.push({
        success: true,
        lectureId: lecture._id.toString(),
        chapterId: chapter._id.toString(),
        courseId: this.courseId
      });
    } catch (error: any) {
      console.error(`Error processing lecture ${lecture._id}:`, error);
      this.results.push({
        success: false,
        lectureId: lecture._id.toString(),
        chapterId: '',
        courseId: this.courseId,
        error: error.message || 'Failed to convert video text'
      });
    }
  }
}

