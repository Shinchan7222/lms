import { google } from 'googleapis';
const fs = require('fs');
const path = require('path');
const pLimit = require('p-limit');

/**
 * Google Drive Downloader using OAuth2 token
 * 
 * Configuration:
 * - Set GOOGLE_DRIVE_TOKEN_PATH environment variable to the path of your token.json file
 *   OR pass it as a parameter to the constructor
 * - The token.json should contain the OAuth2 token in the format:
 *   {
 *     "access_token": "...",
 *     "refresh_token": "...",
 *     "scope": "...",
 *     "token_type": "Bearer",
 *     "expiry_date": ...
 *   }
 * 
 * Example token.json location:
 *   - Absolute path: '/path/to/token.json'
 *   - Relative path: './token.json' (relative to process.cwd())
 *   - Environment variable: process.env.GOOGLE_DRIVE_TOKEN_PATH
 */
const CHUNK_SIZE = 50 * 1024 * 1024; // 50 MB chunks
const NUM_WORKERS = 2;

interface DownloadOptions {
  chunkSize?: number;
  numWorkers?: number;
  useChunks?: boolean; // Enable/disable chunked download
}

export class GoogleDriveDownloader {
  private oauth2Client: any;
  private readonly tokenPath: string;
  private readonly clientId?: string;
  private readonly clientSecret?: string;

  /**
   * @param tokenPath - Path to the token.json file containing OAuth2 credentials
   *                    If not provided, will use process.env.GOOGLE_DRIVE_TOKEN_PATH
   *                    If that's also not set, defaults to './token.json' (relative to process.cwd())
   * @param clientId - Google OAuth2 client ID (required for token refresh)
   * @param clientSecret - Google OAuth2 client secret (required for token refresh)
   */
  constructor(tokenPath?: string, clientId?: string, clientSecret?: string) {
    // Resolve token path: parameter > environment variable > default
    const resolvedTokenPath = tokenPath || process.env.GOOGLE_DRIVE_TOKEN_PATH || '/home/amine/test/token.json';
    // Resolve to absolute path
    this.tokenPath = path.isAbsolute(resolvedTokenPath)
      ? resolvedTokenPath
      : path.resolve(process.cwd(), resolvedTokenPath);

    // Store client credentials for token refresh
    this.clientId = `1018007228208-81jcr6g2gu044g5crgg9n70qh6g04b6r.apps.googleusercontent.com`;
    this.clientSecret = `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`;

    // Initialize OAuth2 client with credentials if available
    this.oauth2Client = new google.auth.OAuth2(
      this.clientId,
      this.clientSecret
    );

    // Set up automatic token refresh
    this.oauth2Client.on('tokens', (tokens: any) => {
      if (tokens.refresh_token) {
        // Store the refresh token if provided
        this.saveToken({ ...this.oauth2Client.credentials, ...tokens });
      } else if (tokens.access_token) {
        // Update access token
        this.saveToken({ ...this.oauth2Client.credentials, ...tokens });
      }
    });

    // Load token if it exists
    this.loadToken();
  }

  /**
   * Load saved token from file
   */
  private loadToken(): void {
    try {
      if (fs.existsSync(this.tokenPath)) {
        const token = JSON.parse(fs.readFileSync(this.tokenPath, 'utf8'));
        this.oauth2Client.setCredentials(token);
        console.log(`Token loaded from: ${this.tokenPath}`);
      } else {
        throw new Error(`Token file not found at: ${this.tokenPath}`);
      }
    } catch (err: any) {
      if (err.code === 'ENOENT') {
        throw new Error(`Token file not found at: ${this.tokenPath}. Please provide a valid token.json path.`);
      }
      throw new Error(`Failed to load token: ${err.message}`);
    }
  }

  /**
   * Save token to file
   */
  private saveToken(token: any): void {
    try {
      fs.writeFileSync(this.tokenPath, JSON.stringify(token, null, 2));
      console.log(`Token saved to: ${this.tokenPath}`);
    } catch (err: any) {
      console.error(`Failed to save token: ${err.message}`);
    }
  }

  /**
   * Refresh the access token using the refresh token
   * @returns Promise resolving to the new token
   */
  async refreshToken(): Promise<any> {
    try {
      if (!this.clientId || !this.clientSecret) {
        throw new Error('Client ID and Client Secret are required for token refresh. Please provide them in the constructor or set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables.');
      }

      const credentials = this.oauth2Client.credentials;
      if (!credentials || !credentials.refresh_token) {
        throw new Error('No refresh token available. Please re-authenticate.');
      }

      // Refresh the token
      const { credentials: newCredentials } = await this.oauth2Client.refreshAccessToken();

      // Update credentials
      this.oauth2Client.setCredentials(newCredentials);

      // Save the refreshed token
      this.saveToken(newCredentials);

      console.log('Token refreshed successfully');
      return newCredentials;
    } catch (error: any) {
      console.error('Error refreshing token:', error);
      throw new Error(`Failed to refresh token: ${error.message}`);
    }
  }

  /**
   * Extract file ID from Google Drive URL
   */
  extractFileId(url: string): string {
    // Handle various Google Drive URL formats
    const patterns = [
      /\/file\/d\/([a-zA-Z0-9_-]+)/,        // /file/d/FILE_ID/view
      /id=([a-zA-Z0-9_-]+)/,                 // ?id=FILE_ID
      /\/open\?id=([a-zA-Z0-9_-]+)/,         // /open?id=FILE_ID
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) return match[1];
    }

    throw new Error('Could not extract file ID from URL');
  }

  /**
   * Download a chunk of a file from Google Drive
   * @param drive - Google Drive API client
   * @param fileId - File ID to download
   * @param start - Start byte position
   * @param end - End byte position
   * @param chunkIndex - Index of the chunk
   * @returns Promise resolving to chunk data
   */
  private async downloadChunk(
    drive: any,
    fileId: string,
    start: number,
    end: number,
    chunkIndex: number
  ): Promise<{ index: number; data: Buffer }> {
    const response = await drive.files.get(
      {
        fileId: fileId,
        alt: 'media',
        supportsAllDrives: true
      },
      {
        headers: {
          Range: `bytes=${start}-${end}`,
        },
        responseType: 'arraybuffer',
      }
    );

    console.log(`Completed chunk ${chunkIndex + 1}`);
    return {
      index: chunkIndex,
      data: Buffer.from(response.data),
    };
  }

  /**
   * Download file using parallel chunks
   * @param drive - Google Drive API client
   * @param fileId - File ID to download
   * @param fileSize - Size of the file in bytes
   * @param outputPath - Path where the file should be saved
   * @param options - Download options
   * @returns Promise resolving to the output path
   */
  /**
   * Download file using parallel chunks with direct-to-disk writing
   * @param drive - Google Drive API client
   * @param fileId - File ID to download
   * @param fileSize - Size of the file in bytes
   * @param outputPath - Path where the file should be saved
   * @param options - Download options
   * @returns Promise resolving to the output path
   */
  private async parallelDownload(
    drive: any,
    fileId: string,
    fileSize: number,
    outputPath: string,
    options: DownloadOptions
  ): Promise<string> {
    const chunkSize = options.chunkSize || CHUNK_SIZE;
    const numWorkers = options.numWorkers || NUM_WORKERS;

    console.log(`\n📥 Downloading file in chunks (${(fileSize / (1024 ** 3)).toFixed(2)} GB)...`);

    // Ensure output directory exists
    const outputDir = path.dirname(outputPath);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    // Calculate chunks
    const chunks: Array<{ index: number; start: number; end: number }> = [];
    for (let i = 0, start = 0; start < fileSize; i++, start += chunkSize) {
      const end = Math.min(start + chunkSize - 1, fileSize - 1);
      chunks.push({ index: i, start, end });
    }

    console.log(`   Split into ${chunks.length} chunks, using ${numWorkers} workers`);

    // Open file handle for random access writing
    // We use 'w' flag to create/truncate the file
    const fileHandle = await fs.promises.open(outputPath, 'w');

    try {
      // Create concurrency limiter
      const limit = pLimit(numWorkers);
      let completedChunks = 0;
      const totalChunks = chunks.length;

      // Download and write chunks in parallel
      const downloadPromises = chunks.map((chunk) =>
        limit(async () => {
          try {
            // Download the chunk
            let { data } = await this.downloadChunk(drive, fileId, chunk.start, chunk.end, chunk.index);

            // Write directly to file at correct position
            await fileHandle.write(data, 0, data.length, chunk.start);

            completedChunks++;
            const percent = ((completedChunks / totalChunks) * 100).toFixed(1);
            process.stdout.write(`\rProgress: ${percent}% (${completedChunks}/${totalChunks} chunks)`);

            // Explicitly free the buffer (though GC should handle it as it goes out of scope)
            // @ts-ignore
            data = null;
          } catch (error) {
            console.error(`\nError processing chunk ${chunk.index}:`, error);
            throw error;
          }
        })
      );

      const results = await Promise.allSettled(downloadPromises);

      // Check for any failures
      const rejected = results.find(r => r.status === 'rejected');
      if (rejected) {
        throw (rejected as PromiseRejectedResult).reason;
      }

      console.log(`\n✅ File downloaded successfully to: ${outputPath}`);

      return outputPath;
    } finally {
      // Close file handle ensures data is flushed and file is closed
      await fileHandle.close();
    }
  }

  /**
   * Download file using sequential stream (for Google Workspace files or when chunks are disabled)
   * @param drive - Google Drive API client
   * @param fileId - File ID to download
   * @param outputPath - Path where the file should be saved
   * @param response - Response stream
   * @returns Promise resolving to the output path
   */
  private async sequentialDownload(
    drive: any,
    fileId: string,
    outputPath: string,
    response: any
  ): Promise<string> {
    const dest = fs.createWriteStream(outputPath);
    const totalSize = parseInt(response.headers['content-length'] || '0', 10);
    let downloaded = 0;

    return new Promise((resolve, reject) => {
      response.data
        .on('data', (chunk: Buffer) => {
          downloaded += chunk.length;
          if (totalSize) {
            const percent = ((downloaded / totalSize) * 100).toFixed(2);
            const downloadedMB = (downloaded / 1024 / 1024).toFixed(2);
            const totalMB = (totalSize / 1024 / 1024).toFixed(2);
            process.stdout.write(`\rDownloading: ${percent}% (${downloadedMB}MB / ${totalMB}MB)`);
          } else {
            const downloadedMB = (downloaded / 1024 / 1024).toFixed(2);
            process.stdout.write(`\rDownloaded: ${downloadedMB}MB`);
          }
        })
        .on('end', () => {
          console.log(`\n✅ File downloaded successfully to: ${outputPath}`);
          resolve(outputPath);
        })
        .on('error', (err: Error) => {
          console.error('Error downloading file:', err);
          reject(err);
        })
        .pipe(dest);
    });
  }

  /**
   * Download a file from Google Drive
   * @param fileIdOrUrl - Google Drive file ID or full URL
   * @param outputPath - Path where the file should be saved
   * @param options - Optional download options (chunkSize, numWorkers, useChunks)
   * @returns Promise resolving to the output path
   */
  async downloadFile(
    fileIdOrUrl: string,
    outputPath: string,
    options: DownloadOptions = {}
  ): Promise<string> {
    const drive = google.drive({ version: 'v3', auth: this.oauth2Client });

    // Extract file ID if URL is provided
    const fileId = fileIdOrUrl.includes('drive.google.com')
      ? this.extractFileId(fileIdOrUrl)
      : fileIdOrUrl;

    try {
      // First, get file metadata to know the filename and mimeType
      console.log('\n📄 Getting file info...');
      const fileInfo = await drive.files.get({
        fileId: fileId,
        fields: 'name, mimeType, size',
        supportsAllDrives: true
      });

      const fileName = fileInfo.data.name;
      const mimeType = fileInfo.data.mimeType;
      const fileSize = fileInfo.data.size ? parseInt(fileInfo.data.size, 10) : 0;

      console.log(`   Name: ${fileName}`);
      console.log(`   Type: ${mimeType}`);
      console.log(`   Size: ${fileSize ? this.formatBytes(fileSize) : 'Unknown'}`);

      // Determine output path
      let finalOutputPath = outputPath;
      if (!finalOutputPath || !path.extname(finalOutputPath)) {
        // Use original filename if outputPath has no extension
        const ext = fileName.match(/\.[^.]+$/);
        if (ext) {
          finalOutputPath = finalOutputPath || fileName;
          if (!finalOutputPath.endsWith(ext[0])) {
            finalOutputPath = finalOutputPath + ext[0];
          }
        } else {
          finalOutputPath = finalOutputPath || `./${fileName}`;
        }
      }

      // Check if it's a Google Workspace file (Docs, Sheets, etc.)
      const exportMimeTypes: { [key: string]: string } = {
        'application/vnd.google-apps.document': 'application/pdf',
        'application/vnd.google-apps.spreadsheet': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.google-apps.presentation': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.google-apps.drawing': 'image/png'
      };

      const isGoogleWorkspaceFile = mimeType && exportMimeTypes[mimeType];
      const useChunks = options.useChunks !== false && !isGoogleWorkspaceFile && fileSize > 0;

      if (isGoogleWorkspaceFile) {
        // Export Google Workspace files (doesn't support Range headers)
        console.log('\n📥 Exporting Google Workspace file...');
        const response = await drive.files.export(
          {
            fileId: fileId,
            mimeType: exportMimeTypes[mimeType]
          },
          { responseType: 'stream' }
        );
        return this.sequentialDownload(drive, fileId, finalOutputPath, response);
      } else if (useChunks) {
        // Use parallel chunked download for regular files
        return this.parallelDownload(drive, fileId, fileSize, finalOutputPath, options);
      } else {
        // Fallback to sequential download
        console.log('\n📥 Downloading file...');
        const response = await drive.files.get(
          {
            fileId: fileId,
            alt: 'media',
            supportsAllDrives: true
          },
          { responseType: 'stream' }
        );
        return this.sequentialDownload(drive, fileId, finalOutputPath, response);
      }
    } catch (error: any) {
      // Check if error is due to expired token
      if (error.code === 401 || error.message?.includes('invalid_request') || error.message?.includes('Could not determine client ID')) {
        console.log('Token expired or invalid, attempting to refresh...');
        try {
          await this.refreshToken();
          // Retry the download after refreshing token
          console.log('Retrying download after token refresh...');
          return this.downloadFile(fileIdOrUrl, outputPath, options);
        } catch (refreshError: any) {
          console.error('Failed to refresh token:', refreshError);
          throw new Error(`Authentication failed. Please refresh the token manually: ${refreshError.message}`);
        }
      }
      throw error;
    }
  }

  /**
   * Format bytes to human readable string
   */
  private formatBytes(bytes: number): string {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 Bytes';
    const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)).toString());
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  }
}

