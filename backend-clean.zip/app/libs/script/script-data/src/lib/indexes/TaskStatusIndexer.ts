import { taskStatusRepository } from '../repositories/TaskStatusRepository';

export class TaskStatusIndexer {
  static async index() {
    await taskStatusRepository.ensureIndex({ id: 1 });
    await taskStatusRepository.ensureIndex({ status: 1 });
    await taskStatusRepository.ensureIndex({ id: 1, status: 1 });
  }
}

