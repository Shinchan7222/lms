import { videoToUploadRepository } from '../repositories/VideoToUploadRepository';

export class VideoToUploadIndexer {
  static async index() {
    await videoToUploadRepository.ensureIndex({ status: 1 });
    await videoToUploadRepository.ensureIndex({ university: 1, status: 1 });
    await videoToUploadRepository.ensureIndex({ courseName: 1, unitName: 1, topicName: 1 });
    await videoToUploadRepository.ensureIndex({ startedAt: 1 });
  }
}

