import { ExpressMiddlewareInterface } from 'routing-controllers';

export class CanExecuteScript implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any): any {
    let token = req.query.token || req.body.token;
    if (token === '7f870b21bad041c91f1b5a2227a7fcb4') {
      next();
    } else {
      return res.status(400).send({ message: 'What do you want?' });
    }
  }
}
