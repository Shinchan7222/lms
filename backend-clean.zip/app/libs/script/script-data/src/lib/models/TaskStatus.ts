import { Model, MongooseModel, field } from '@edorer/nems';

export type TaskStatusType = 'in_progress' | 'done';

@Model('TaskStatus')
export class TaskStatus extends MongooseModel {
  @field({
    required: true,
    type: String,
    unique: true,
    index: true
  })
  id: string; // Format: "Course - Unit - Topic"

  @field({
    required: true,
    enum: ['in_progress', 'done'],
    type: String,
    default: 'in_progress'
  })
  status: TaskStatusType;

  @field({
    required: true,
    type: String
  })
  topicName: string;

  @field({
    required: true,
    type: String
  })
  unitName: string;

  @field({
    required: true,
    type: String
  })
  courseName: string;

  @field({
    type: String
  })
  programName?: string;

  @field({
    type: Date,
    default: Date.now
  })
  createdAt: Date;

  @field({
    type: Date,
    default: Date.now
  })
  updatedAt: Date;

  @field({
    type: Date
  })
  startedAt?: Date;

  @field({
    type: Date
  })
  completedAt?: Date;
}

