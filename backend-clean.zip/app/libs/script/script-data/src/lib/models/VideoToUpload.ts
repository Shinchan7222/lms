import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

export type VideoToUploadStatusType = 'pending' | 'in_progress' | 'done' | 'error';

@Model('VideoToUpload')
export class VideoToUpload extends MongooseModel {
  @field({
    required: true,
    type: String,
    index: true
  })
  courseName: string;

  @field({
    type: String,
    index: true
  })
  programName?: string;

  @field({
    required: true,
    type: String,
    index: true
  })
  unitName: string;

  @field({
    required: true,
    type: String,
    index: true
  })
  topicName: string;

  @field({
    required: true,
    type: [String]
  })
  videoLinks: string[];

  @field({
    type: String
  })
  facultyName?: string;

  @field({
    type: String
  })
  semester?: string;

  @field({
    required: true,
    enum: ['pending', 'in_progress', 'done', 'error'],
    type: String,
    default: 'pending',
    index: true
  })
  status: VideoToUploadStatusType;

  @field({
    ref: 'University',
    type: Types.ObjectId,
    index: true
  })
  university: any;

  @field({
    type: Date,
    default: Date.now
  })
  createdAt: Date;

  @field({
    type: Date,
    default: Date.now
  })
  updatedAt: Date;

  @field({
    type: Date
  })
  startedAt?: Date;

  @field({
    type: Date
  })
  completedAt?: Date;

  @field({
    type: String
  })
  errorMessage?: string;
}

