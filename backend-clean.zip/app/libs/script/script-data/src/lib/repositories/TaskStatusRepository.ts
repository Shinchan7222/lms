import { MongooseRepository } from '@edorer/nems';

class TaskStatusRepository extends MongooseRepository {
}

export let taskStatusRepository = new TaskStatusRepository();

