import { MongooseRepository } from '@edorer/nems';

class VideoToUploadRepository extends MongooseRepository {
}

export let videoToUploadRepository = new VideoToUploadRepository();

