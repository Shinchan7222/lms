import {
  CourseUploadScriptController,
  ScriptAllTransferController,
  ScriptApplicantController,
  ScriptAssetController,
  ScriptTrackBooksetController,
  ScriptCategoryController,
  ScriptClassController,
  ScriptClassroomController,
  ScriptController,
  ScriptCourseController,
  ScriptDebController,
  ScriptDebProfileController,
  ScriptDomainController,
  ScriptDynamicFormController,
  ScriptExamController,
  ScriptExamRegistrationController,
  ScriptFontsController,
  ScriptLiveClassRoomController,
  ScriptMigrationController,
  ScriptMigrationMMDUController,
  ScriptPageController,
  ScriptPaymentController,
  ScriptPaymentRequestController,
  ScriptProgramController,
  ScriptQuestionController,
  ScriptSupportController,
  ScriptTeacherController,
  ScriptTrackAssignmentController,
  ScriptTrackCourseController,
  ScriptTrackExamController,
  ScriptTrackInterviewController,
  ScriptTrackProgramController,
  ScriptTransferController,
  ScriptUserController,
  ScriptUserDynamicDataController,
  ScriptVideoController,
  ScriptWebinarController,
  ScriptCleanupController,
  videoToUploadCron
} from '@edorer/script-api';
import { TaskStatus, TaskStatusIndexer, VideoToUpload, VideoToUploadIndexer } from '@edorer/script-data';
import { Nems } from '@edorer/nems';
import { CronRegistry } from '@edorer/cron-data';
const schedule = require('node-schedule');

export class ScriptApp {
  controllers = [
    ScriptTrackBooksetController,
    CourseUploadScriptController,
    ScriptAllTransferController,
    ScriptApplicantController,
    ScriptAssetController,
    ScriptCategoryController,
    ScriptClassController,
    ScriptClassroomController,
    ScriptController,
    ScriptCourseController,
    ScriptDebController,
    ScriptDebProfileController,
    ScriptDomainController,
    ScriptDynamicFormController,
    ScriptExamController,
    ScriptExamRegistrationController,
    ScriptFontsController,
    ScriptLiveClassRoomController,
    ScriptMigrationController,
    ScriptMigrationMMDUController,
    ScriptPageController,
    ScriptPaymentController,
    ScriptPaymentRequestController,
    ScriptProgramController,
    ScriptQuestionController,
    ScriptSupportController,
    ScriptTeacherController,
    ScriptTrackAssignmentController,
    ScriptTrackCourseController,
    ScriptTrackExamController,
    ScriptTrackInterviewController,
    ScriptTrackProgramController,
    ScriptTransferController,
    ScriptUserController,
    ScriptUserDynamicDataController,
    ScriptVideoController,
    ScriptWebinarController,
    ScriptCleanupController
  ];

  constructor() {
    this.initDB();
    this.initCrons();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [
      { name: 'TaskStatus', model: TaskStatus },
      { name: 'VideoToUpload', model: VideoToUpload }
    ]);
    // await TaskStatusIndexer.index();
    // await VideoToUploadIndexer.index();
  }

  initCrons() {
    // console.log('videoToUploadCron.IS_RUNNING', videoToUploadCron.IS_RUNNING);
    // schedule.scheduleJob('* * * * *', async () => {
    //   console.log('videoToUploadCron.IS_RUNNING', videoToUploadCron.IS_RUNNING);
    //   setTimeout(async () => {
    //     if (videoToUploadCron.IS_RUNNING) {
    //       return;
    //     }
    //     await videoToUploadCron.init();
    //   }, 1000 * Math.floor(Math.random() * (55 + 1)));
    // });
  }
}
