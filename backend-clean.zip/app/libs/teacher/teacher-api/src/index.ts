export * from './lib/controllers/TeacherClassController';
export * from './lib/controllers/TeacherDomainController';
export * from './lib/controllers/TeacherCrudController';
export * from './lib/controllers/TeacherFeaturesController';

export * from './lib/facade/TeacherMultipleActionFacade';
