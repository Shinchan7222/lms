import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { IsAuthenticated, userRepository } from '@edorer/user-data';
import { Validate } from '@edorer/validator';
import { VerifyEmail } from '@edorer/user-api';

@JsonController()
export class TeacherFeaturesController {
  /**
   * @resendEmail
   * implements Authentication middleware for User is required.
   * @param: { email:string}  required field
   * send email to teacher
   */
  @Post('/teachers/resend/email')
  @Validate([
    {
      field: 'email',
      validation: [{ value: 'notEmpty', message: 'email is required' }]
    }
  ])
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async resendEmail(@Req() req: any, @Res() res: any) {
    try {
      const { email } = req.body;
      const user = await userRepository.findOne({ email: email });
      if (user) {
        const userFetch = await userRepository.findOne({ email }).populate({
          path: 'university',
          select:
            '-advanced.googleClientId -advanced.googleClientSecret -emailSender -smsSender -defaultPassword -driveAccessToken -driveRefreshToken -logRocket -logRocketEmail -logRocketPassword -plagiarism'
        });
        const mailer = new VerifyEmail(userFetch.university, userFetch);
        await mailer.send();
        return res.send({ message: 'ok' });
      } else {
        return res.status(401).send({ message: 'Not Authenticated' });
      }
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @markPhoneVerified
   * implements Authentication middleware for User is required.
   * @param: { phone:string , email:string}  required field
   * verify email to teacher and redirect him to to next step
   */
  @Post('/teachers/phone-verified')
  @Validate([
    {
      field: 'phone',
      validation: [{ value: 'notEmpty', message: 'phone is required' }]
    },
    {
      field: 'email',
      validation: [{ value: 'notEmpty', message: 'email is required' }]
    }
  ])
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async markPhoneVerified(@Req() req: any, @Res() res: any) {
    try {
      const user = await userRepository.findOne({ email: req.body.email });
      if (user) {
        await userRepository.update({ _id: user._id }, { $set: { phone: req.body.phone, isPhoneVerified: true } }, { multi: false });
        // res.status(200).send({ url: 'http://localhost:5000/auth/login-success?token=' + user.token });
        return res.status(200).send({ url: process.env.LMS_URL + '/auth/login-success?token=' + user.token });
      } else {
        return res.status(401).send({ message: 'Not Authenticated' });
      }
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @verifyEmail
   * implements Authentication middleware for User is required.
   * @param: { phone:string , email:string}  required field
   * verify email to teacher using token and redirect him to to next step
   */
  @Get('/teachers/verify-email/:token')
  @Validate([
    {
      field: 'token',
      validation: [{ value: 'notEmpty', message: 'token is required' }]
    }
  ])
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async verifyEmail(@Req() req: any, @Res() res: any) {
    try {
      const currentUser = await userRepository.findOne({ token: req.params.token }).populate({
        path: 'university',
        select:
          '-advanced.googleClientId -advanced.googleClientSecret -emailSender -smsSender -defaultPassword -driveAccessToken -driveRefreshToken -logRocket -logRocketEmail -logRocketPassword -plagiarism'
      });
      const verify = new VerifyEmail(currentUser.university, currentUser);
      await verify.verifyEmail();
      res.status(200);
      return res.redirect(process.env.LMS_URL + '/users/verify-phone');
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/teachers/suspend/:teacherId([0-9a-f]{24})')
  @Validate([
    {
      field: 'teacherId',
      validation: [{ value: 'notEmpty', message: 'Teacher ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async suspend(@Req() req: any, @Res() res: any, @Param('teacherId') teacherId: string) {
    try {
      await userRepository.update({ _id: teacherId }, { $set: { isSuspended: true } }, { multi: false });
      return res.status(201).send({ message: 'Teacher suspended successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
