const bcryptjs = require('bcryptjs');
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity, University } from '@edorer/university-data';
import { IsAuthenticated, UserTypes, userRepository } from '@edorer/user-data';
import { TeacherMultipleActionFacade } from '../facade/TeacherMultipleActionFacade';
import { Validate } from '@edorer/validator';
import { VerifyEmail } from '@edorer/user-api';

@JsonController()
export class TeacherCrudController {

    /**
     * @find
     * implements Authentication middleware for User is required.
     * @param: { keyword , skip , limit}  required fields and optional fields
     * fetch all teachers with the specific params
     */
    @Get('/teachers')
    @Validate([
        {
            field: 'limit',
            validation: [{ value: 'notEmpty', message: 'limit is required' }]
        },
        'action', 'classId', 'departmentId', 'domainId',
        'keyword', 'not_classId', 'not_departmentId',
        'skip'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async find(@Req() req: any, @Res() res: any) {
        try {
            if (req.user.type === UserTypes.STUDENT) {
                throw new Error('You are not allowed to access this route');
            }
            const facade = new TeacherMultipleActionFacade(req.user, req.query);
            const result = await facade.create();

            return res.status(200).send(result);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @create
     * implements Authentication middleware for User is required.
     * @param: { name , email , password}  required fields and optional fields
     * creates a teacher then send a mail to them with the giving credentials
     */
    @Post('/teachers')
    @Validate([
        {
            field: 'email',
            validation: [
                { value: 'notEmpty', message: 'email is required' },
                { value: 'isEmailAvailable', message: 'email is already used' }
            ]
        },
        {
            field: 'name', validation: [{ value: 'notEmpty', message: 'name is required' }]
        },
        {
            field: 'password', validation: [{ value: 'notEmpty', message: 'password is required' }]
        },
        'domains'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async create(@Req() req: any, @Res() res: any) {
        try {
            const university: University = req.university;
            let { domains = [], name, email, password } = req.body;
            password = await bcryptjs.hash(password, 10);

            const user = await userRepository.create({
                domains,
                email,
                isEdorer: true,
                isEmailVerified: !university.verifyEmail,
                isPhoneVerified: !university.verifyPhone,
                name,
                password,
                type: UserTypes.TEACHER,
                university: university._id
            });

            const mailer = new VerifyEmail(university, user);
            await mailer.send();

            const createdUser = await userRepository.findOne({ _id: user._id }).lean();

            return res.status(201).send(createdUser);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

}
