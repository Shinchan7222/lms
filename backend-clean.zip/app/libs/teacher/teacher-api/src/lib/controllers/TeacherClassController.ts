import { classRepository } from '@edorer/class-data';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated, userRepository } from '@edorer/user-data';
import { JsonController, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Types } from 'mongoose';
import { Validate } from '@edorer/validator';

@JsonController()
export class TeacherClassController {

    @Put('/teachers/add-to-class')
    @Validate([
        {
            field: 'classId',
            validation: [{ value: 'notEmpty', message: 'Class ID is required' }]
        },
        {
            field: 'teacherIds',
            validation: [{ value: 'notEmpty', message: 'Teacher IDs are required' }]
        },
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addToClass(@Req() req: any, @Res() res: any) {
        try {
            const { classId, teacherIds } = req.body;

            await userRepository.update(
                { _id: { $in: teacherIds } },
                { $addToSet: { classes: Types.ObjectId(classId) } },
                { multi: true }
            );

            await classRepository.update(
                { _id: classId },
                { $addToSet: { teachers: teacherIds.map((o) => Types.ObjectId(o)) } },
                { multi: false }
            );

            return res.status(201).send({ message: 'Teacher(s) added successfully to class.' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    @Put('/teachers/remove-from-class')
    @Validate([
        {
            field: 'classId',
            validation: [{ value: 'notEmpty', message: 'Class ID is required' }]
        },
        {
            field: 'teacherIds',
            validation: [{ value: 'notEmpty', message: 'Teacher IDs are required' }]
        },
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async removeFromClass(@Req() req: any, @Res() res: any) {
        try {
            const { classId, teacherIds } = req.body;

            await userRepository.update(
                { _id: { $in: teacherIds } },
                { $pull: { classes: Types.ObjectId(classId) } },
                { multi: true }
            );

            await classRepository.update(
                { _id: classId },
                { $pull: { teachers: teacherIds.map((o) => Types.ObjectId(o)) } },
                { multi: false }
            );

            return res.status(201).send({ message: 'Teacher(s) removed from class successfully.' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
