import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated, userRepository } from '@edorer/user-data';
import { JsonController, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Types } from 'mongoose';
import { Validate } from '@edorer/validator';
import { domainRepository } from '@edorer/domain-data';

@JsonController()
export class TeacherDomainController {

    /**
     * @addDomainToTeacher
     * implements Authentication middleware for User is required.
     * @param: { teacherIds:string[] , domainId:string }  required fields and optional fields
     * fetch all teachers and then add domain with the id
     */
    @Put('/teachers/add-to-domain')
    @Validate([
        {
            field: 'teacherIds',
            validation: [
                { value: 'notEmpty', message: 'teacherIds is required' }
            ]
        },
        {
            field: 'domainId',
            validation: [
                { value: 'notEmpty', message: 'domainId is required' }
            ]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async addDomainToTeacher(@Req() req: any, @Res() res: any) {
        try {
            const { teacherIds, domainId } = req.body;
            await userRepository.update(
                { _id: teacherIds },
                { $addToSet: { domains: Types.ObjectId(domainId) } },
                { multi: true }
            );
            await domainRepository.update(
                { _id: domainId },
                {
                    $addToSet: {
                        teachers: teacherIds.map((o) =>
                            Types.ObjectId(o)
                        )
                    }
                },
                { multi: false }
            );
            return res.status(201).send({ message: 'Teacher(s) added successfully to domain.' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }

    /**
     * @removeDomainFromTeacher
     * implements Authentication middleware for User is required.
     * @param: { teacherIds:string[] , domainId:string }  required fields and optional fields
     * fetch all teachers and then remove domain with the id
     */
    @Put('/teachers/remove-from-domain')
    @Validate([
        {
            field: 'teacherIds',
            validation: [
                { value: 'notEmpty', message: 'teacherIds is required' }
            ]
        },
        {
            field: 'domainId',
            validation: [
                { value: 'notEmpty', message: 'domainId is required' }
            ]
        }
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseAfter(FinishRequest)
    @UseBefore(StartRequest)
    async removeDomainFromTeacher(@Req() req: any, @Res() res: any) {
        try {
            const { teacherIds, domainId } = req.body;
            await userRepository.update(
                { _id: teacherIds },
                { $pull: { domains: Types.ObjectId(domainId) } },
                { multi: true }
            );
            await domainRepository.update(
                { _id: domainId },
                {
                    $pull: {
                        teachers: {
                            $in: teacherIds.map((o) =>
                                Types.ObjectId(o)
                            )
                        }
                    }
                },
                { multi: false }
            );
            return res.status(201).send({ message: 'Teacher(s) removed from domain successfully.' });
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
