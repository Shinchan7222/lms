import { ListFacade } from '@edorer/generic-facades';
import { Role } from '@edorer/role-data';
import { User, UserTypes, userRepository } from '@edorer/user-data';
import { domainRepository } from '@edorer/domain-data';
import { Types } from 'mongoose';

export class TeacherMultipleActionFacade {

    private facade: ListFacade;

    private readonly body: any;

    private readonly currentUser: User;

    constructor(currentUser: User, body: any) {
        this.currentUser = currentUser;
        this.body = body;
    }

    async create() {
        const { skip, limit, keyword } = this.body;
        this.facade = new ListFacade(
            this.currentUser, this.currentUser.university, +skip, +limit, keyword, ['name', 'email'], userRepository
        );
        await this.addConditions();

        if (this.body.action) {
            await this.runAction();
        }
        this.facade.deleteCondition('owner');

        this.facade.prepareQuery();
        return await this.facade.create();
    }

    private async addConditions() {
        this.facade.addConditions({ type: UserTypes.TEACHER });
        this.facade.addConditions({ isSuspended: false });

        if (this.body.classId && Types.ObjectId.isValid(this.body.classId)) {
            this.facade.addConditions({ classes: { $in: [this.body.classId] } });
        }

        if (this.body.not_classId) {
            this.facade.addConditions({ classes: { $nin: [this.body.not_classId] } });
        }

        if (this.body.domainId && !this.body.not_domainId) {
            this.facade.addConditions({ domains: { $in: [this.body.domainId] } });
        }

        if (this.body.not_domainId) {
            this.facade.addConditions({ domains: { $ne: this.body.not_domainId } });
        }

        await this.checkUserRole();
    }

    private async checkUserRole() {
        const { role, type, university } = this.currentUser;
        if (type === UserTypes.UNIVERSITY_MEMBER) {
            const conditions = [{ creator: this.currentUser._id }];

            const userRole = new Role(role);
            if (userRole.teachers && userRole.teachers.read) {
                const domainCondition = await userRole.createCondition(university);
                // const createdDomains = await domainRepository.distinct('_id', { creator: this.currentUser._id });

                if (Object.keys(domainCondition).length > 0) {
                    const condition: any = { domains: domainCondition };
                    // if (condition['domains']['$in']) {
                    //     condition['domains']['$in'].push(...createdDomains);
                    // } else if (!condition['domains']['$in'] && createdDomains.length > 0) {
                    //     condition['domains']['$in'] = createdDomains;
                    // }

                    conditions.push(condition);
                }
            }

            this.facade.addConditions({ $and: [{ $or: conditions }] });
        }
    }

    private async runAction() {
        if (this.body.action === 'DELETE') {
            await userRepository.destroy(this.facade.condition, this.currentUser._id);
        }
        if (this.body.action === 'ENROLL_TO_DOMAIN') {
            let query = userRepository.update(this.facade.condition, { $addToSet: { domains: this.body.domainId } }, { multi: true });
            this.facade.prepareFullQuery();
            let { items } = await this.facade.createOnlyItems();
            await query;
            await domainRepository.update({ _id: this.body.domaind }, { $addToSet: { teachers: items.map(o => o._id) } }, { multi: false });
        } else if (this.body.action === 'REMOVE_ENROLL_FROM_DOMAIN') {
            let query = userRepository.update(this.facade.condition, { $pull: { domains: this.body.domainId } }, { multi: true });
            this.facade.prepareFullQuery();
            let { items } = await this.facade.createOnlyItems();
            await query;
            // tslint:disable-next-line:max-line-length
            await domainRepository.update({ _id: this.body.domainId }, { $pull: { teachers: { $in: items.map(o => o._id) } } }, { multi: false });
        }
    }
}
