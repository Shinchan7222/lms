import { TeacherClassController, TeacherCrudController, TeacherDomainController, TeacherFeaturesController } from '@edorer/teacher-api';

export class TeacherApp {

    controllers = [TeacherClassController, TeacherCrudController, TeacherDomainController, TeacherFeaturesController];

    constructor() {
    }
}
