export * from './lib/TeacherApp';
