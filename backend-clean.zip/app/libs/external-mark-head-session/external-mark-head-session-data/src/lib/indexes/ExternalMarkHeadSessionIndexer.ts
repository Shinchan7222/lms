import { externalMarkHeadSessionRepository } from '@edorer/external-mark-head-session-data';

export class ExternalMarkHeadSessionIndexer {
  static async index() {
    await externalMarkHeadSessionRepository.ensureIndex({ _id: 1, deleted: 1 });
  }
}
