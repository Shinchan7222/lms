import { MongooseRepository } from '@edorer/nems';

class ExternalMarkHeadSessionRepository extends MongooseRepository {}

export let externalMarkHeadSessionRepository = new ExternalMarkHeadSessionRepository();
