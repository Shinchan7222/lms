import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanDownloadExternalMarkHeadSessions implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to download external mark head.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to download external mark head.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to download external mark head.' });

    const { externalMarkHeadSessionId } = params;
    if (externalMarkHeadSessionId === null) return res.status(401).send({ message: 'You do not have permission to download external mark head.' });
    if (externalMarkHeadSessionId === undefined)
      return res.status(401).send({ message: 'You do not have permission to download external mark head.' });
    if (Types.ObjectId.isValid(externalMarkHeadSessionId) === false)
      return res.status(401).send({ message: 'You do not have permission to download external mark head.' });

    const { type } = user;
    switch (type) {
      case UserTypes.ADMIN:
      case UserTypes.UNIVERSITY_MEMBER:
      case UserTypes.UNIVERSITY_OWNER: {
        break;
      }

      default:
        return res.status(401).send({ message: 'You do not have permission to download external mark head.' });
    }

    next();
  }
}
