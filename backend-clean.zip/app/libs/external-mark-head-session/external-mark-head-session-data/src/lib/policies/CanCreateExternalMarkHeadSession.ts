import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Role } from '@edorer/role-data';
import { UserTypes } from '@edorer/user-data';

export class CanCreateExternalMarkHeadSession implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to create external mark head.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to create external mark head.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to create external mark head.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to create external mark head.' });

        const { externalMarkHeadSessions } = role;
        if (externalMarkHeadSessions === null) return res.status(401).send({ message: 'You do not have permission to create external mark head.' });
        if (externalMarkHeadSessions === undefined)
          return res.status(401).send({ message: 'You do not have permission to create external mark head.' });
        if (Object.keys(externalMarkHeadSessions).length === 0)
          return res.status(401).send({ message: 'You do not have permission to create external mark head.' });

        const { write } = externalMarkHeadSessions;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to create external mark head.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to create external mark head.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to create external mark head.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
