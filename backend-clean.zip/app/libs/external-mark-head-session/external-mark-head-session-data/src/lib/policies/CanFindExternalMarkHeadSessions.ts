import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Role } from '@edorer/role-data';
import { UserTypes } from '@edorer/user-data';

export class CanFindExternalMarkHeadSessions implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });

        const { externalMarkHeadSessions } = role;
        if (externalMarkHeadSessions === null) return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });
        if (externalMarkHeadSessions === undefined)
          return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });
        if (Object.keys(externalMarkHeadSessions).length === 0)
          return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });

        const { read } = externalMarkHeadSessions;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view external mark heads.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
