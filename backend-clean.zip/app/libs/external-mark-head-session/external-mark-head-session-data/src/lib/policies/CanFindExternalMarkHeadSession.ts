import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Role } from '@edorer/role-data';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanFindExternalMarkHeadSession implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });

    const { externalMarkHeadSessionId } = params;
    if (externalMarkHeadSessionId === null) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
    if (externalMarkHeadSessionId === undefined) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
    if (Types.ObjectId.isValid(externalMarkHeadSessionId) === false)
      return res.status(401).send({ message: 'You do not have permission to view external mark head.' });

    const role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        if (String(externalMarkHeadSessionId) !== String(user._id))
          return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
        break;
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });

        const { externalMarkHeadSessions } = role;
        if (externalMarkHeadSessions === null) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
        if (externalMarkHeadSessions === undefined)
          return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
        if (Object.keys(externalMarkHeadSessions).length === 0)
          return res.status(401).send({ message: 'You do not have permission to view external mark head.' });

        const { read } = externalMarkHeadSessions;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view external mark head.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
