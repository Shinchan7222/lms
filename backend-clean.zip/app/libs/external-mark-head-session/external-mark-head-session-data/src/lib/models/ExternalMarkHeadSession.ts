import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('ExternalMarkHeadSession')
export class ExternalMarkHeadSession extends MongooseModel {
  @field({
    required: true,
    type: String
  })
  name: string;

  @field({
    ref: 'User',
    type: Types.ObjectId
  })
  owner: any;

  @field({
    ref: 'Program',
    required: true,
    type: Types.ObjectId
  })
  program: any;

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  @post('save')
  async notifyCreate() {
    dbOperationsNotifier.notify(
      'ExternalMarkHeadSession',
      {
        id: this._id,
        name: this.name,
        university: this.university
      },
      'create'
    );
  }
}
