import { ExternalMarkHeadSessionCrudController } from '@edorer/external-mark-head-session-api';
import { ExternalMarkHeadSession, ExternalMarkHeadSessionIndexer } from '@edorer/external-mark-head-session-data';
import { Nems } from '@edorer/nems';

export class ExternalMarkHeadSessionApp {
  controllers = [ExternalMarkHeadSessionCrudController];

  constructor() {
    this.initDB();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'ExternalMarkHeadSession', model: ExternalMarkHeadSession }]);
    await ExternalMarkHeadSessionIndexer.index();
  }
}
