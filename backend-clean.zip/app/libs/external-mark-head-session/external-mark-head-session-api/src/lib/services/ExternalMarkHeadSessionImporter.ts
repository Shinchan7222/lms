import { Class, classRepository } from '@edorer/class-data';
import { Course, courseRepository } from '@edorer/course-data';
import { ListFacade } from '@edorer/generic-facades';
import { ExternalMarkHeadSession, externalMarkHeadSessionRepository } from '@edorer/external-mark-head-session-data';
import { externalMarkEntryRepository } from '@edorer/external-mark-entry-data';
import { Program, programRepository } from '@edorer/program-data';
import { University } from '@edorer/university-data';
import { User, userRepository } from '@edorer/user-data';
import * as exportToJson from 'convert-excel-to-json';

export class ExternalMarkHeadSessionImporter {
  private readonly currentUser: User;
  private readonly university: University;
  private readonly uploadedFile: any;

  private classes: Map<string, Class> = new Map();
  private courses: Map<string, Course> = new Map();
  private createdMarkHeads: ExternalMarkHeadSession[] = [];
  private programs: Map<string, Program> = new Map();
  private results: Array<Record<string, any>> = [];
  private teachers: Map<string, User> = new Map();
  private totalEntriesCreated: number = 0;

  constructor(uploadedFile: any, currentUser: User, university: University) {
    this.uploadedFile = uploadedFile;
    this.currentUser = currentUser;
    this.university = university;
  }

  async import() {
    // Step 1: Extract data from Excel
    this.extractExcelData();

    // Step 2: Fetch related entities
    await Promise.all([this.fetchPrograms(), this.fetchClasses(), this.fetchCourses(), this.fetchTeachers()]);

    // Step 3: Create mark heads and their entries
    await this.createMarkHeadsWithEntries();

    return {
      message: 'Mark heads imported successfully',
      total: this.results.length,
      markHeadsCreated: this.createdMarkHeads.length,
      markEntriesCreated: this.totalEntriesCreated
    };
  }

  /**
   * Extract data from uploaded Excel file
   */
  private extractExcelData() {
    try {
      const result = exportToJson({
        columnToKey: {
          A: 'Name',
          B: 'Class',
          C: 'Course',
          D: 'Program',
          E: 'Inam Session',
          F: 'Mark Type',
          G: 'Max Mark',
          H: 'Passing Mark',
          I: 'Semester',
          J: 'Sequence',
          K: 'Remarks',
          L: 'Teachers'
        },
        header: { rows: 1 },
        source: this.uploadedFile.buffer
      });

      this.results = result['MarkHeads'];

      if (this.results.length === 0) {
        throw new Error('No data found in Incel file');
      }
    } catch (error) {
      console.error('Error intracting Incel data:', error);
      throw new Error('Could not read Incel file. Please check the format.');
    }
  }

  /**
   * Fetch programs based on ID or programCode from Excel
   */
  private async fetchPrograms() {
    try {
      const programIds = [...new Set(this.results.map((r) => r.Program).filter(Boolean))];

      const query: any = { university: this.university._id };

      if (programIds.length > 0) {
        query.$or = [];
        if (programIds.length > 0) query.$or.push({ id: { $in: programIds } });
      }

      const programs = await programRepository.find(query).lean();

      programs.forEach((program) => {
        if (program.id) this.programs.set(program.id, program);
      });
    } catch (error) {
      console.error('Error fetching programs:', error);
      throw new Error('Could not fetch programs');
    }
  }

  /**
   * Fetch classes based on name from Excel
   */
  private async fetchClasses() {
    try {
      const classNames = [...new Set(this.results.map((r) => r.Class).filter(Boolean))];

      if (classNames.length === 0) return;

      const classes = await classRepository
        .find({
          id: { $in: classNames },
          university: this.university._id
        })
        .lean();

      classes.forEach((classItem) => {
        this.classes.set(classItem.id, classItem);
      });
    } catch (error) {
      console.error('Error fetching classes:', error);
      throw new Error('Could not fetch classes');
    }
  }

  /**
   * Fetch courses based on subject code from Excel
   */
  private async fetchCourses() {
    try {
      const courseCodes = [...new Set(this.results.map((r) => r.Course).filter(Boolean))];

      if (courseCodes.length === 0) return;

      const courses = await courseRepository
        .find({
          id: { $in: courseCodes },
          university: this.university._id
        })
        .lean();

      courses.forEach((course) => {
        this.courses.set(course.id, course);
      });
    } catch (error) {
      console.error('Error fetching courses:', error);
      throw new Error('Could not fetch courses');
    }
  }

  /**
   * Fetch teachers based on emails from Excel
   */
  private async fetchTeachers() {
    try {
      // Extract all teacher emails (comma-separated in each row)
      const allTeacherEmails = new Set<string>();

      this.results.forEach((row) => {
        if (row.Teachers) {
          const emails = String(row.Teachers)
            .split(',')
            .map((email) => email.trim().toLowerCase())
            .filter(Boolean);
          emails.forEach((email) => allTeacherEmails.add(email));
        }
      });

      if (allTeacherEmails.size === 0) return;

      const teachers = await userRepository
        .find({
          email: { $in: Array.from(allTeacherEmails) },
          university: this.university._id
        })
        .select('email')
        .lean();

      teachers.forEach((teacher) => {
        this.teachers.set(teacher.email.toLowerCase(), teacher);
      });
    } catch (error) {
      console.error('Error fetching teachers:', error);
      throw new Error('Could not fetch teachers');
    }
  }

  /**
   * Create mark heads and automatically create entries for students
   */
  private async createMarkHeadsWithEntries() {
    for (const row of this.results) {
      console.log(row);
      try {
        // Get related entities
        const program = this.programs.get(row.Program);
        const classItem = this.classes.get(row.Class);
        const course = this.courses.get(row.Course);

        // Validate required fields
        if (!program) {
          console.warn(`Program not found for: ${row.Program}`);
          continue;
        }

        if (!classItem) {
          console.warn(`Class not found for: ${row.Class}`);
          continue;
        }

        if (!course) {
          console.warn(`Course not found for: ${row.Course}`);
          continue;
        }

        if (!row.Name) {
          console.warn(`Name is required for mark head`);
          continue;
        }

        // Parse teacher emails
        const teacherIds: string[] = [];
        if (row.Teachers) {
          const emails = String(row.Teachers)
            .split(',')
            .map((email) => email.trim().toLowerCase())
            .filter(Boolean);

          emails.forEach((email) => {
            const teacher = this.teachers.get(email);
            if (teacher) {
              teacherIds.push(teacher._id);
            } else {
              console.warn(`Teacher not found: ${email}`);
            }
          });
        }

        // Create External Mark Head
        const markHeadData: any = {
          classes: classItem._id,
          course: course._id,
          inamSession: row['Inam Session'] || '',
          markType: row['Mark Type'] || 'Theory',
          maxMark: Number(row['Max Mark']) || 100,
          name: row.Name,
          owner: this.currentUser._id,
          passingMark: Number(row['Passing Mark']) || 40,
          program: program._id,
          remarks: row['Remarks'] || '',
          semester: Number(row['Semester']) || 1,
          sequence: String(row['Sequence']) || '001',
          teachers: teacherIds,
          university: this.university._id
        };

        const markHead = await externalMarkHeadSessionRepository.create(markHeadData);
        this.createdMarkHeads.push(markHead);

        // Create mark entries for all students in the program/class
        const entriesCreated = await this.createEntriesForMarkHead(markHead, program, classItem, course);
        this.totalEntriesCreated += entriesCreated;

        console.log(`Created mark head "${markHead.name}" with ${entriesCreated} student entries`);
      } catch (error) {
        console.error('Error creating mark head:', error);
      }
    }
  }

  /**
   * Create mark entries for all students in the program/class combination
   * Similar to CreateExternalMarkHeadSession.createEntries()
   */
  private async createEntriesForMarkHead(markHead: any, program: Program, classItem: Class, course: Course): Promise<number> {
    try {
      // Get students who are in both the program and the class
      const facade = new ListFacade(null, this.university, 0, 0, null, [], userRepository);
      facade.addConditions({ programs: { $in: [program._id] } });
      facade.addConditions({ classes: { $in: [classItem._id] } });
      facade.addSelect('_id');

      const { items: users } = await facade.create();

      if (users.length === 0) {
        console.warn(`No students found for program ${program.title} and class ${classItem.name}`);
        return 0;
      }

      // Prepare entries for all students
      const items = [];

      for (const user of users) {
        items.push({
          classes: classItem._id,
          course: course._id,
          markHead: markHead._id,
          markType: markHead.markType,
          mark: 0, // Default mark is 0
          owner: this.currentUser._id,
          program: program._id,
          university: this.university._id,
          user: user._id || user,
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }

      if (items.length === 0) return 0;

      // Insert all entries at once
      await externalMarkEntryRepository.insertMany(items);

      return items.length;
    } catch (error) {
      console.error('Error creating entries for mark head:', error);
      return 0;
    }
  }
}
