import { externalMarkHeadSessionRepository } from '@edorer/external-mark-head-session-data';
import { ListFacade } from '@edorer/generic-facades';
import { Types } from 'mongoose';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';
import * as moment from 'moment';

export class ExternalMarkHeadSessionListFacade {
  private readonly currentUser: User;

  private readonly endDate: Date;

  private readonly facade: ListFacade;

  private readonly keyword: string;

  private readonly limit: number;

  private readonly owner: string;

  private readonly program: string;

  private readonly skip: number;

  private readonly startDate: Date;

  private readonly university: University;

  constructor(
    endDate: number,
    keyword: string,
    limit: number,
    owner: string,
    program: string,
    skip: number,
    startDate: number,
    currentUser: User,
    university: University
  ) {
    this.currentUser = currentUser;
    this.keyword = keyword;
    this.limit = +limit;
    this.owner = owner;
    this.program = program;
    this.skip = +skip;
    this.university = university;

    if (endDate) {
      this.endDate = moment(new Date(+endDate)).endOf('day').toDate();
    }

    if (startDate) {
      this.startDate = moment(new Date(+startDate)).startOf('day').toDate();
    }

    this.facade = new ListFacade(null, this.university, this.skip, this.limit, this.keyword, ['name'], externalMarkHeadSessionRepository);
  }

  async create() {
    await this.addConditions();

    this.addPopulates();

    this.facade.prepareQuery();

    return await this.facade.create();
  }

  private async addConditions() {
    this.checkOwner();
    this.checkProgram();
    this.checkRole();
    this.checkCreationDate();
  }

  private checkRole() {
    if (this.currentUser.role && this.currentUser.role.externalMarkHeadSessions && this.currentUser.role.externalMarkHeadSessions.read) {
      this.facade.addConditions({ owner: this.currentUser._id });
    }

    const { type } = this.currentUser;

    if (type === UserTypes.TEACHER) {
      this.facade.addConditions({ teachers: { $in: [this.currentUser._id] } });
    }
  }

  private checkCreationDate() {
    if (this.startDate && this.endDate) {
      this.facade.addConditions({ createdAt: { $gte: this.startDate, $lte: this.endDate } });
    }
  }

  private checkProgram() {
    if (this.program) {
      this.facade.addConditions({ program: this.program });
    }
  }

  private checkOwner() {
    if (this.owner && Types.ObjectId.isValid(this.owner)) {
      this.facade.addConditions({ owner: this.owner });
    }
  }

  private addPopulates() {
    this.facade.addPopulates([
      { path: 'owner', select: 'email name' },
      { path: 'program', select: 'title' }
    ]);
  }
}
