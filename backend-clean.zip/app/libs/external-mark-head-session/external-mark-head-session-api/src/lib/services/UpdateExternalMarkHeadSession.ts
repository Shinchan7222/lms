import { ExternalMarkHeadSession, externalMarkHeadSessionRepository } from '@edorer/external-mark-head-session-data';
import { UpdateFacade } from '@edorer/generic-facades';

export class UpdateExternalMarkHeadSession {
  private readonly markHead: ExternalMarkHeadSession;

  private readonly headId: string;

  constructor(markHead: ExternalMarkHeadSession, headId: string) {
    this.markHead = markHead;
    this.headId = headId;
  }

  async update() {
    await this.updateHead();
  }

  private async updateHead() {
    const facade = new UpdateFacade(this.headId, this.markHead, ['name', 'program'], externalMarkHeadSessionRepository);
    await facade.create();
  }
}
