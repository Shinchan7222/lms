import { externalMarkHeadSessionRepository } from '@edorer/external-mark-head-session-data';
import { Program } from '@edorer/program-data';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class CreateExternalMarkHeadSession {
  private readonly currentUser: User;

  private readonly name: number;

  private readonly programId: string;

  private readonly university: University;

  constructor(name: number, programId: string, currentUser: User, university: University) {
    this.name = name;
    this.programId = programId;
    this.currentUser = currentUser;
    this.university = university;
  }

  async create() {
    await this.createHead();
  }

  private async createHead() {
    await externalMarkHeadSessionRepository.create({
      name: this.name,
      owner: this.currentUser._id,
      program: this.programId,
      university: this.university._id
    });
  }
}
