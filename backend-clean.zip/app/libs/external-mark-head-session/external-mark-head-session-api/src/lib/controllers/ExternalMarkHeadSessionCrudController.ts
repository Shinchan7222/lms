import { CanFindExternalMarkHeadSessions } from '@edorer/external-mark-head-session-data';
import { CreateExternalMarkHeadSession } from '../services/CreateExternalMarkHeadSession';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { HasUser, IsAuthenticated } from '@edorer/user-data';
import { ExternalMarkHeadSessionListFacade } from '../services/ExternalMarkHeadSessionListFacade';
import { externalMarkHeadSessionRepository } from '@edorer/external-mark-head-session-data';
import { UpdateExternalMarkHeadSession } from '../services/UpdateExternalMarkHeadSession';
import { Validate } from '@edorer/validator';

/**
 * @description CRUD controller for ExternalMarkHeadSession
 */
@JsonController()
export class ExternalMarkHeadSessionCrudController {
  /**
   * @param req
   * @param res
   * @description Create a new ExternalMarkHeadSession
   */
  @Post('/external-mark-head-sessions')
  @Validate(['name', 'program'])
  @UseBefore(GetUniversity)
  @UseBefore(HasUser)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async create(@Req() req: any, @Res() res: any) {
    try {
      const { name, program } = req.body;

      const externalMarkHeadSession = new CreateExternalMarkHeadSession(name, program, req.user, req.university);

      await externalMarkHeadSession.create();

      return res.status(201).send({ message: 'ExternalMarkHeadSession created successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Finds ExternalMarkHeadSession with the given queries
   */
  @Get('/external-mark-head-sessions')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    'endDate',
    'keyword',
    'owner',
    'program',
    'startDate'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated, CanFindExternalMarkHeadSessions)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { endDate, keyword, limit, owner, program, skip, startDate } = req.query;

      const externalMarkHeadSessionListFacade = new ExternalMarkHeadSessionListFacade(
        endDate,
        keyword,
        limit,
        owner,
        program,
        skip,
        startDate,
        req.user,
        req.university
      );
      const result = await externalMarkHeadSessionListFacade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param headId
   * @description Finds One ExternalMarkHeadSession with the given ID
   */
  @Get('/external-mark-head-sessions/:headId([0-9a-f]{24})')
  @Validate([
    {
      field: 'headId',
      validation: [{ value: 'notEmpty', message: 'External Mark Head ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('headId') headId: string) {
    try {
      const externalMarkHeadSession = await externalMarkHeadSessionRepository.findOne({ _id: headId });

      return res.status(200).send(externalMarkHeadSession);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param headId
   * @description Updates one ExternalMarkHeadSession with the given changes
   */
  @Put('/external-mark-head-sessions/:headId([0-9a-f]{24})')
  @Validate([
    {
      field: 'headId',
      validation: [{ value: 'notEmpty', message: 'External Mark Head ID is required' }]
    },
    {
      field: 'name',
      validation: [{ value: 'notEmpty', message: 'Title is required' }]
    },

    'program'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async update(@Req() req: any, @Res() res: any, @Param('headId') headId: string) {
    try {
      const facade = new UpdateExternalMarkHeadSession(req.body, headId);
      await facade.update();

      return res.status(201).send({ message: 'External MarkHead updated successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Delete ExternalMarkHeadSession by ID
   */
  @Put('/external-mark-head-sessions/delete')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'External Mark Head IDs are required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async delete(@Req() req: any, @Res() res: any) {
    const { ids } = req.body;

    try {
      await externalMarkHeadSessionRepository.destroy({ _id: { $in: ids } }, req.user);

      return res.send({ message: 'ExternalMarkHeadSession deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
