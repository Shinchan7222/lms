export * from './lib/controllers/ClassroomPeopleAllowController';
export * from './lib/controllers/ClassroomPeopleCrudController';
export * from './lib/controllers/ClassroomPeopleUploadController';
