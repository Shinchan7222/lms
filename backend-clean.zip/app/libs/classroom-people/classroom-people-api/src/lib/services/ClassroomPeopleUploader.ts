import { DistinctFacade } from '@edorer/generic-facades';
import { Downloader } from '@edorer/s3';
import { FileUtils } from '@edorer/utils';
import { Types } from 'mongoose';
import { University } from '@edorer/university-data';
import { userRepository, UserTypes } from '@edorer/user-data';
import * as excelToJson from 'convert-excel-to-json';

export class ClassroomPeopleUploader {
  private excelFile: Buffer;

  private readonly document: string;

  private readonly isAllowed: boolean;

  private readonly subject: string;

  private readonly university: University;

  private results: Array<Record<string, string>> = [];

  constructor(document: string, isAllowed: boolean, subject: string, university: University) {
    this.document = document;
    this.isAllowed = isAllowed;
    this.subject = subject;
    this.university = university;
  }

  async upload() {
    await this.downloadFile();

    this.readExcelFile();
    await this.allowOrDisallowStudents();
  }

  private async downloadFile() {
    try {
      const downloader = new Downloader(this.document);
      const downloadedFile = await downloader.download();

      if (downloadedFile) {
        this.excelFile = FileUtils.readFile(downloadedFile);
      }

      if (!this.excelFile) {
        throw new Error('Could not download file. Please try again.');
      }
    } catch (error) {
      console.error(error);
      throw new Error('Could not download file. Please try again.');
    }
  }

  private readExcelFile() {
    const result = excelToJson({
      source: this.excelFile,
      header: {
        rows: 1
      },
      columnToKey: {
        A: 'Email'
      }
    });

    if (result['Students']) {
      this.results = result['Students'];
    } else {
      throw new Error('Could not upload results. Please try again.');
    }
  }

  private async allowOrDisallowStudents() {
    try {
      const facade = new DistinctFacade(null, this.university, '_id', null, [], userRepository);
      facade.addConditions({ type: UserTypes.STUDENT, email: { $in: this.results.map((entry) => entry['Email']).filter(Boolean) } });

      const students = await facade.create();

      if (Types.ObjectId.isValid(this.subject) === false) return;

      const update = {};

      if (this.isAllowed) {
        update['$pull'] = { disallowedSubjects: { $in: [this.subject] } };
      } else {
        update['$addToSet'] = { disallowedSubjects: this.subject };
      }

      await userRepository.update({ _id: { $in: students } }, update, { multi: true });
    } catch (error) {
      console.error(error);
      throw new Error('Error while allowing students');
    }
  }
}
