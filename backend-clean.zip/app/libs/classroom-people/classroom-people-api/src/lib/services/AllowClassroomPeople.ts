import { DistinctFacade } from '@edorer/generic-facades';
import { Types } from 'mongoose';
import { University } from '@edorer/university-data';
import { userRepository, UserTypes } from '@edorer/user-data';

export class AllowClassroomPeople {
  private readonly action: string;

  private readonly classroom: string;

  private readonly facade: DistinctFacade;

  private readonly students: string[];

  private readonly subject: string;

  private readonly university: University;

  private studentsList: string[] = [];

  constructor(action: string, classroom: string, students: string[], subject: string, university: University) {
    this.action = action;
    this.classroom = classroom;
    this.students = students;
    this.subject = subject;
    this.university = university;

    this.facade = new DistinctFacade(null, this.university, '_id', null, [], userRepository);
  }

  public async allow(): Promise<void> {
    this.addConditions();

    await this.fetchStudents();
    await this.allowStudents();
  }

  private addConditions() {
    this.checkAction();
    this.checkStudentIds();

    this.facade.addConditions({ type: UserTypes.STUDENT });
  }

  private checkAction() {
    if (!this.action) return;
    if (this.action !== 'ALLOW_ALL') return;
    if (this.students.length !== 0) return;

    this.facade.addConditions({ classes: { $in: [this.classroom] } });
  }

  private checkStudentIds() {
    if (this.students.length === 0) return;

    this.facade.addConditions({ _id: { $in: this.students } });
  }

  private async fetchStudents() {
    try {
      this.studentsList = await this.facade.create();
    } catch (error) {
      console.error(error);
      throw new Error('Error while allowing students');
    }
  }

  private async allowStudents() {
    if (this.studentsList.length === 0) return;
    if (Types.ObjectId.isValid(this.subject) === false) return;

    try {
      await userRepository.update({ _id: { $in: this.studentsList } }, { $pull: { disallowedSubjects: { $in: [this.subject] } } }, { multi: true });
    } catch (error) {
      console.error(error);
      throw new Error('Error while allowing students');
    }
  }
}
