import { DataUtils, Json2Excel } from '@edorer/utils';
import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { User, userRepository, UserTypes } from '@edorer/user-data';

export class DownloadDisallowedClassroomPeople {
  private readonly classroom: string;

  private readonly facade: ListFacade;

  private readonly subject: string;

  private readonly university: University;

  private students: User[] = [];

  constructor(classroom: string, subject: string, university: University) {
    this.classroom = classroom;
    this.subject = subject;
    this.university = university;

    this.facade = new ListFacade(null, this.university, 0, 0, null, [], userRepository);
  }

  public async download() {
    this.addConditions();
    await this.fetchStudents();

    return await this.generateReport();
  }

  private addConditions() {
    this.facade.addConditions({ classes: { $in: [this.classroom] } });
    this.facade.addConditions({ disallowedSubjects: { $in: [this.subject] } });
    this.facade.addConditions({ type: UserTypes.STUDENT });
  }

  private async fetchStudents() {
    try {
      const { items } = await this.facade.createOnlyItems();
      this.students = items;
    } catch (error) {
      console.error(error);
      throw new Error('Error while allowing students');
    }
  }

  private async generateReport(): Promise<string> {
    const reports = [];

    for (let student of this.students) {
      const { email, extraFields, name } = student;

      const reportBody = {
        Name: name,
        Email: email,
        'Roll Number': DataUtils.getUserField(extraFields, 'Roll Number')
      };

      reports.push(reportBody);
    }

    const converter = new Json2Excel(reports, null, 'DisallowedPeople');
    converter.sheet = 'DisallowedPeople';

    return await converter.convert();
  }
}
