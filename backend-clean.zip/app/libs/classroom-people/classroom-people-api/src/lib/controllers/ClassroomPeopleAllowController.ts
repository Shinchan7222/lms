import { AllowClassroomPeople } from '../services/AllowClassroomPeople';
import { DisallowClassroomPeople } from '../services/DisallowClassroomPeople';
import { DownloadAllowedClassroomPeople } from '../services/DownloadAllowedClassroomPeople';
import { DownloadDisallowedClassroomPeople } from '../services/DownloadDisallowedClassroomPeople';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { readFileSync } from 'fs';
import { Validate } from '@edorer/validator';

@JsonController()
export class ClassroomPeopleAllowController {
  @Post('/classroom-people/allow/:classroom([0-9a-f]{24})')
  @Validate([
    {
      field: 'classroom',
      validation: [{ value: 'notEmpty', message: 'Classroom is required' }]
    },
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    },
    'action',
    'students'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async allow(@Req() req: any, @Res() res: any, @Param('classroom') classroom: string) {
    try {
      const { action, students, subject } = req.body;

      const facade = new AllowClassroomPeople(action, classroom, students, subject, req.university);
      await facade.allow();

      return res.status(201).send({ message: 'Students allowed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Post('/classroom-people/disallow/:classroom([0-9a-f]{24})')
  @Validate([
    {
      field: 'classroom',
      validation: [{ value: 'notEmpty', message: 'Classroom is required' }]
    },
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    },
    'action',
    'students'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async disallow(@Req() req: any, @Res() res: any, @Param('classroom') classroom: string) {
    try {
      const { action, students, subject } = req.body;

      const facade = new DisallowClassroomPeople(action, classroom, students, subject, req.university);
      await facade.disallow();

      return res.status(201).send({ message: 'Students disallowed' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/classroom-people/download-allowed/:classroom([0-9a-f]{24})')
  @Validate([
    {
      field: 'classroom',
      validation: [{ value: 'notEmpty', message: 'Classroom is required' }]
    },
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async downloadAllowed(@Req() req: any, @Res() res: any, @Param('classroom') classroom: string) {
    try {
      const { subject } = req.query;

      const downloader = new DownloadAllowedClassroomPeople(classroom, subject, req.university);
      const path = await downloader.download();

      const buffer = readFileSync(path);

      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=AllowedPeople.xlsx');

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; AllowedPeople.xlsx`,
        'Content-Length': buffer.length
      });
      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/classroom-people/download-disallowed/:classroom([0-9a-f]{24})')
  @Validate([
    {
      field: 'classroom',
      validation: [{ value: 'notEmpty', message: 'Classroom is required' }]
    },
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async downloadDisallowed(@Req() req: any, @Res() res: any, @Param('classroom') classroom: string) {
    try {
      const { subject } = req.query;

      const downloader = new DownloadDisallowedClassroomPeople(classroom, subject, req.university);
      const path = await downloader.download();

      const buffer = readFileSync(path);

      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=DisallowedPeople.xlsx');

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; DisallowedPeople.xlsx`,
        'Content-Length': buffer.length
      });
      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
