import { ClassroomPeopleUploader } from '../services/ClassroomPeopleUploader';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { Validate } from '@edorer/validator';

@JsonController()
export class ClassroomPeopleUploadController {
  @Post('/classroom-people/upload/:subject([0-9a-f]{24})')
  @Validate([
    {
      field: 'document',
      validation: [{ value: 'notEmpty', message: 'Document is required' }]
    },
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    },
    'isAllowed'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async upload(@Req() req: any, @Res() res: any, @Param('subject') subject: string) {
    const { document, isAllowed } = req.body;

    try {
      const uploader = new ClassroomPeopleUploader(document, isAllowed, subject, req.university);
      await uploader.upload();

      return res.status(200).send({ message: 'Uploaded successfully.' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
