import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated, UserTypes, userRepository } from '@edorer/user-data';
import { ListFacade } from '@edorer/generic-facades';
import { Validate } from '@edorer/validator';

@JsonController()
export class ClassroomPeopleCrudController {
  @Get('/classroom-people/:classroom([0-9a-f]{24})')
  @Validate([
    {
      field: 'classroom',
      validation: [{ value: 'notEmpty', message: 'Classroom is required' }]
    },
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    'keyword'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async find(@Req() req: any, @Res() res: any, @Param('classroom') classroom: string) {
    try {
      const { keyword, limit, skip } = req.query;

      const facade = new ListFacade(null, req.university, +skip, +limit, keyword, ['email', 'name'], userRepository, false);

      facade.addConditions({ classes: { $in: [classroom] } });
      facade.addConditions({ type: { $in: [UserTypes.STUDENT] } });
      facade.addSelect('disallowedSubjects email extraFields name');

      facade.prepareQuery();

      const response = await facade.create();

      return res.status(200).send(response);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
