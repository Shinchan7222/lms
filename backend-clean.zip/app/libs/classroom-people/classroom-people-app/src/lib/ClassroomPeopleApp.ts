import { ClassroomPeopleAllowController, ClassroomPeopleCrudController, ClassroomPeopleUploadController } from '@edorer/classroom-people-api';

export class ClassroomPeopleApp {
  controllers = [ClassroomPeopleAllowController, ClassroomPeopleCrudController, ClassroomPeopleUploadController];

  constructor() {}
}
