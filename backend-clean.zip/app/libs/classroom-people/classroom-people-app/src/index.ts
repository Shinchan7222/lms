export * from './lib/ClassroomPeopleApp';
