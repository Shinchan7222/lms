import { CanCreateCategory, CanDeleteCategory, CanFindCategories, CanUpdateCategory, categoryRepository } from '@edorer/category-data';
import { Delete, Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { ListFacade, QueryActions, UpdateFacade } from '@edorer/generic-facades';
import { StringUtils } from '@edorer/utils';
import { Validate } from '@edorer/validator';

/**
 * @description CRUD controller for Categories
 */
@JsonController()
export class CategoryCrudController {
	/**
	 * @param req
	 * @param res
	 * @description Creates one Category with the given properties
	 */
	@Post('/categories')
	@Validate([
		{
			field: 'name',
			validation: [{ value: 'notEmpty', message: 'name is required' }],
		},
	])
	@UseBefore(GetUniversity)
	@UseBefore(IsAuthenticated, CanCreateCategory)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async create(@Req() req: any, @Res() res: any) {
		try {
			const { name } = req.body;
			const categoryExists = await categoryRepository.count({ name: StringUtils.titleCase(name), university: req.university._id });
			if (categoryExists > 0) {
				return res.status(400).send({ error: 'Category exists already' });
			}

			const category = await categoryRepository.create({
				name: StringUtils.titleCase(name),
				owner: req.user._id,
				university: req.university._id,
			});

			return res.status(201).send(category);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}

	/**
	 * @param req
	 * @param res
	 * @description Finds Categories with the given queries
	 */
	@Get('/categories')
	@Validate([
		{
			field: 'skip',
			validation: [{ value: 'notEmpty', message: 'skip is required' }],
		},
		{
			field: 'limit',
			validation: [{ value: 'notEmpty', message: 'limit is required' }],
		},
		'keyword',
		'action',
	])
	@UseBefore(GetUniversity)
	@UseBefore(IsAuthenticated, CanFindCategories)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async find(@Req() req: any, @Res() res: any) {
		try {
			const { keyword, skip, limit } = req.query;

			const facade = new ListFacade(null, req.university, +skip, +limit, keyword, ['name'], categoryRepository);
			if (req.query.action && req.query.action === QueryActions.DELETE) {
				facade.query = categoryRepository.destroy(facade.condition, req.user._id);
				await facade.create();
			}
			facade.prepareQuery();

			const result = await facade.create();

			return res.status(200).send(result);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param categoryId
	 * @description Finds one Category with the given ID
	 */
	@Get('/categories/:categoryId([0-9a-f]{24})')
	@Validate([
		{
			field: 'categoryId',
			validation: [{ value: 'notEmpty', message: 'Category ID is required' }],
		},
	])
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async findOne(@Req() req: any, @Res() res: any, @Param('categoryId') categoryId: string) {
		try {
			const category = await categoryRepository.findOne({ _id: categoryId }).lean();

			return res.status(200).send(category);
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param categoryId
	 * @description Updates one Category with the given changes
	 */
	@Put('/categories/:categoryId([0-9a-f]{24})')
	@Validate([
		{
			field: 'categoryId',
			validation: [{ value: 'notEmpty', message: 'Category ID is required' }],
		},
		{
			field: 'name',
			validation: [{ value: 'notEmpty', message: 'Category Name is required' }],
		},
	])
	@UseBefore(IsAuthenticated, CanUpdateCategory)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async update(@Req() req: any, @Res() res: any, @Param('categoryId') categoryId: string) {
		try {
			const facade = new UpdateFacade(categoryId, req.body, ['name'], categoryRepository);
			await facade.create();

			return res.status(201).send({ message: 'Category updated successfully' });
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param categoryId
	 * @description Deletes Category with the given ID
	 */
	@Delete('/categories/:categoryId([0-9a-f]{24})')
	@Validate([
		{
			field: 'categoryId',
			validation: [{ value: 'notEmpty', message: 'Category ID is required' }],
		},
	])
	@UseBefore(IsAuthenticated, CanDeleteCategory)
	@UseBefore(StartRequest)
	@UseAfter(FinishRequest)
	async delete(@Req() req: any, @Res() res: any, @Param('categoryId') categoryId: string) {
		try {
			await categoryRepository.destroy({ _id: categoryId }, req.user._id);
			return res.status(200).send({ message: 'Category deleted successfully' });
		} catch (error: any) {
			console.error(error);
			return res.status(400).send({ error: error.message });
		}
	}
}
