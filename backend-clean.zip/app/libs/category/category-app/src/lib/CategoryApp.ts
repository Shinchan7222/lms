import { Category, CategoryIndexer } from '@edorer/category-data';
import { CategoryCrudController } from '@edorer/category-api';
import { Nems } from '@edorer/nems';

export class CategoryApp {

    controllers = [
        CategoryCrudController
    ];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'Category', model: Category }]);
        await CategoryIndexer.index();
    }
}
