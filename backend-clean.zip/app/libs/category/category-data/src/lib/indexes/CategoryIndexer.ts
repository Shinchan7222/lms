import { categoryRepository } from '@edorer/category-data';

export class CategoryIndexer {

    static async index() {
        await categoryRepository.ensureIndex({ _id: 1, deleted: 1 });
        await categoryRepository.ensureIndex({ name: 1, deleted: 1 });
        await categoryRepository.ensureIndex({ name: 1, university: 1, deleted: 1 });
        await categoryRepository.ensureIndex({ university: 1, name: 1, deleted: 1 });
    }
}
