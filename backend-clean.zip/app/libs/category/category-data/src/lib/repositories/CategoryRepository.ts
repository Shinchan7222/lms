import { MongooseRepository } from '@edorer/nems';

class CategoryRepository extends MongooseRepository {
}

export let categoryRepository = new CategoryRepository();
