import { ExpressMiddlewareInterface } from 'routing-controllers';
import { UserTypes } from '@edorer/user-data';
import { Types } from 'mongoose';
import { categoryRepository } from '../repositories/CategoryRepository';
import { Role } from '@edorer/role-data';

export class CanDuplicateCategory implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { body, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (body === null) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
    if (body === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
    if (Object.keys(body).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });

    const { categoryId } = body;
    if (categoryId === null) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
    if (categoryId === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
    if (Types.ObjectId.isValid(categoryId) === false) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });

    const role: Role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });

        const { categories } = role;
        if (categories === null) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
        if (categories === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
        if (Object.keys(categories).length === 0) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });

        const { write } = categories;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await categoryRepository.count({
          _id: categoryId,
          $or: [{ owner: user._id }, { editors: { $in: user._id } }]
        });

        if (count === 0) return res.status(401).send({ message: 'You do not have permission to duplicate category.' });
        break;
      }

      default:
        break;
    }

    next();
  }
}
