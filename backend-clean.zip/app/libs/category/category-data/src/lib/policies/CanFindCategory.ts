import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Role } from '@edorer/role-data';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';

export class CanFindCategory implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to view category.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to view category.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to view category.' });

    const { categoryId } = params;
    if (categoryId === null) return res.status(401).send({ message: 'You do not have permission to view category.' });
    if (categoryId === undefined) return res.status(401).send({ message: 'You do not have permission to view category.' });
    if (Types.ObjectId.isValid(categoryId) === false) return res.status(401).send({ message: 'You do not have permission to view category.' });

    const role: Role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        if (String(categoryId) !== String(user._id)) return res.status(401).send({ message: 'You do not have permission to view category.' });
        break;
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to view category.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view category.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view category.' });

        const { categories } = role;
        if (categories === null) return res.status(401).send({ message: 'You do not have permission to view category.' });
        if (categories === undefined) return res.status(401).send({ message: 'You do not have permission to view category.' });
        if (Object.keys(categories).length === 0) return res.status(401).send({ message: 'You do not have permission to view category.' });

        const { read } = categories;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view category.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view category.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view category.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
