import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Role } from '@edorer/role-data';
import { UserTypes } from '@edorer/user-data';

export class CanFindCategories implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    //   return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const role: Role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to view categories.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to view categories.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to view categories.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to view categories.' });

        const { categories } = role;
        if (categories === null) return res.status(401).send({ message: 'You do not have permission to view categories.' });
        if (categories === undefined) return res.status(401).send({ message: 'You do not have permission to view categories.' });
        if (Object.keys(categories).length === 0) return res.status(401).send({ message: 'You do not have permission to view categories.' });

        const { read } = categories;
        if (read === null) return res.status(401).send({ message: 'You do not have permission to view categories.' });
        if (read === undefined) return res.status(401).send({ message: 'You do not have permission to view categories.' });
        if (read === false) return res.status(401).send({ message: 'You do not have permission to view categories.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
