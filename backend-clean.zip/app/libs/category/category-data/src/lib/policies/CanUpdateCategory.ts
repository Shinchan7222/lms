import { ExpressMiddlewareInterface } from 'routing-controllers';
import { categoryRepository } from '../repositories/CategoryRepository';
import { Types } from 'mongoose';
import { UserTypes } from '@edorer/user-data';
import { Role } from '@edorer/role-data';

export class CanUpdateCategory implements ExpressMiddlewareInterface {
  async use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { params, user } = req;

    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    if (params === null) return res.status(401).send({ message: 'You do not have permission to update category.' });
    if (params === undefined) return res.status(401).send({ message: 'You do not have permission to update category.' });
    if (Object.keys(params).length === 0) return res.status(401).send({ message: 'You do not have permission to update category.' });

    const { categoryId } = params;
    if (categoryId === null) return res.status(401).send({ message: 'You do not have permission to update category.' });
    if (categoryId === undefined) return res.status(401).send({ message: 'You do not have permission to update category.' });
    if (Types.ObjectId.isValid(categoryId) === false) return res.status(401).send({ message: 'You do not have permission to update category.' });

    const role: Role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to update category.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to update category.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to update category.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to update category.' });

        const { categories } = role;
        if (categories === null) return res.status(401).send({ message: 'You do not have permission to update category.' });
        if (categories === undefined) return res.status(401).send({ message: 'You do not have permission to update category.' });
        if (Object.keys(categories).length === 0) return res.status(401).send({ message: 'You do not have permission to update category.' });

        const { write } = categories;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to update category.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to update category.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to update category.' });

        break;
      }

      case UserTypes.TEACHER: {
        const count = await categoryRepository.count({ _id: categoryId, owner: user._id });
        if (count === 0) return res.status(401).send({ message: 'You do not have permission to update category.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
