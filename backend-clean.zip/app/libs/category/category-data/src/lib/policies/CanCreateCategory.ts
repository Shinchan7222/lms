import { ExpressMiddlewareInterface } from 'routing-controllers';
import { Role } from '@edorer/role-data';
import { UserTypes } from '@edorer/user-data';

export class CanCreateCategory implements ExpressMiddlewareInterface {
  use(req: any, res: any, next?: (err?: any) => any) {
    // return true;

    const { user } = req;
    if (user === null) return res.status(401).send({ message: 'You are not authenticated.' });
    if (user === undefined) return res.status(401).send({ message: 'You are not authenticated.' });

    const role: Role = user.role;

    const { type } = user;
    switch (type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        return res.status(401).send({ message: 'You do not have permission to create category.' });
      }

      case UserTypes.UNIVERSITY_MEMBER: {
        if (role === null) return res.status(401).send({ message: 'You do not have permission to create category.' });
        if (role === undefined) return res.status(401).send({ message: 'You do not have permission to create category.' });
        if (Object.keys(role).length === 0) return res.status(401).send({ message: 'You do not have permission to create category.' });

        const { categories } = role;
        if (categories === null) return res.status(401).send({ message: 'You do not have permission to create category.' });
        if (categories === undefined) return res.status(401).send({ message: 'You do not have permission to create category.' });
        if (Object.keys(categories).length === 0) return res.status(401).send({ message: 'You do not have permission to create category.' });

        const { write } = categories;
        if (write === null) return res.status(401).send({ message: 'You do not have permission to create category.' });
        if (write === undefined) return res.status(401).send({ message: 'You do not have permission to create category.' });
        if (write === false) return res.status(401).send({ message: 'You do not have permission to create category.' });

        break;
      }

      default:
        break;
    }

    next();
  }
}
