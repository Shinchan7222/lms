import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('Category')
export class Category extends MongooseModel {
  @field({
    required: true,
    trim: true,
    type: String
  })
  name: string;

  @field({
    type: Types.ObjectId,
    ref: 'User',
    required: true
  })
  owner: any;

  @field({
    type: Types.ObjectId,
    ref: 'University',
    required: true
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;
}
