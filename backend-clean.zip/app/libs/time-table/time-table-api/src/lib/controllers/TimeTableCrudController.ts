import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { TimeTableListFacade } from '../services/TimeTableListFacade';
import { Validate } from '@edorer/validator';

/**
 * @description CRUD controller for Notices
 */
@JsonController()
export class TimeTableCrudController {

    /**
     * @param req
     * @param res
     * @description Finds TimeTables with the given queries
     */
    @Get('/time-tables')
    @Validate([
        {
            field: 'date',
            validation: [{ value: 'notEmpty', message: 'Date is required' }]
        },
        {
            field: 'fields',
            validation: [{ value: 'notEmpty', message: 'Fields are required' }]
        },
        'fields', 'keyword'
    ])
    @UseBefore(GetUniversity)
    @UseBefore(IsAuthenticated)
    @UseBefore(StartRequest)
    @UseAfter(FinishRequest)
    async find(@Req() req: any, @Res() res: any) {
        try {
            const { date, fields, keyword } = req.query;

            const facade = new TimeTableListFacade(+date, fields, keyword, req.user, req.university);
            const response = await facade.create();

            return res.status(200).send(response);
        } catch (error: any) {
            console.error(error);
            return res.status(400).send({ error: error.message });
        }
    }
}
