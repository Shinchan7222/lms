import { Assignment, assignmentRepository } from '@edorer/assignment-data';
import { Chapter } from '@edorer/chapter-data';
import { classRepository } from '@edorer/class-data';
import { Course, courseRepository } from '@edorer/course-data';
import { DateUtils } from '@edorer/utils';
import { DistinctFacade, ListFacade } from '@edorer/generic-facades';
import { DomainDepartments, domainRepository } from '@edorer/domain-data';
import { examEnrollmentRepository } from '@edorer/exam-enrollment-data';
import { examRepository } from '@edorer/exam-data';
import { Lecture } from '@edorer/lecture-data';
import { liveClassRoomRepository } from '@edorer/live-class-room-data';
import { subjectRepository } from '@edorer/subject-data';
import { TimeTable, TimeTableTypes } from '@edorer/time-table-data';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';
import { videoSessionRepository } from '@edorer/video-session-data';
import * as moment from 'moment-timezone';

export class TimeTableListFacade {
  private timeTables: TimeTable[] = [];

  private readonly dateCondition: object;

  private readonly endDate: Date;

  private readonly fields: string[];

  private readonly keyword: string;

  private readonly startDate: Date;

  private readonly university: University;

  private readonly user: User;

  constructor(date: number, fields: string[], keyword: string = null, user: User, university: University) {
    this.endDate = moment(date).add(1, 'day').endOf('month').toDate();
    this.fields = fields;
    this.keyword = keyword;
    this.startDate = moment(date).add(1, 'day').startOf('month').toDate();
    this.university = university;
    this.user = user;

    this.dateCondition = { $gte: this.startDate, $lte: this.endDate };
  }

  async create() {
    if ([UserTypes.ADMIN, UserTypes.UNIVERSITY_MEMBER, UserTypes.UNIVERSITY_OWNER].includes(this.user.type)) {
      throw new Error('Time table is available for Applicants, Students or Teachers only');
    }

    if (this.fields.includes(TimeTableTypes.ASSIGNMENT)) {
      await this.fetchAssignments();
    }

    if (this.fields.includes(TimeTableTypes.EXAM_ENROLLMENT)) {
      await this.fetchExams();
    }

    if (this.fields.includes(TimeTableTypes.LIVE_CLASS_ROOM)) {
      await this.fetchLiveClassRooms();
    }

    this.timeTables = this.timeTables.sort((timeTable1, timeTable2) => {
      return new Date(timeTable1.date).valueOf() - new Date(timeTable2.date).valueOf();
    });

    return this.timeTables;
  }

  private async fetchAssignments() {
    const condition: object = { hasDueDate: true, dueDateTime: this.dateCondition };

    switch (this.user.type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        const courses: Course[] = await courseRepository
          .find({ students: { $in: [this.user._id] } })
          .populate({
            path: 'chapters',
            select: 'lectures',
            populate: { path: 'lectures', select: 'pages.assignment' }
          })
          .select('chapters')
          .lean();
        const chapters: Chapter[] = courses.flatMap((course) => course.chapters);
        const lectures: Lecture[] = chapters.flatMap((chapter) => chapter.lectures);
        const pages = lectures.flatMap((lecture) => lecture.pages);

        const assignmentIds = pages.filter((page) => page.assignment).map((page) => page.assignment);
        condition['_id'] = { $in: assignmentIds };
        break;
      }

      case UserTypes.TEACHER: {
        condition['owner'] = this.user._id;
        break;
      }
    }

    const assignments: Assignment[] = await assignmentRepository.find(condition).select('title dueDateTime').lean();

    for (let assignment of assignments) {
      const timeTableIndex = this.timeTables.findIndex((timetable) => {
        return timetable.date === moment(assignment.dueDateTime).format(DateUtils.DATE_FORMATS.SHORT_DATE);
      });

      if (timeTableIndex !== -1) {
        this.timeTables[timeTableIndex].modules.push({ module: assignment, type: TimeTableTypes.ASSIGNMENT });
      } else {
        this.timeTables.push({
          date: moment(assignment.dueDateTime).format(DateUtils.DATE_FORMATS.SHORT_DATE),
          modules: [{ module: assignment, type: TimeTableTypes.ASSIGNMENT }]
        });
      }
    }
  }

  private async fetchExams() {
    const condition: object = { startDateTime: this.dateCondition };

    switch (this.user.type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        condition['$or'] = [{ applicants: { $in: [this.user._id] } }, { students: { $in: [this.user._id] } }];
        break;
      }

      case UserTypes.TEACHER: {
        const exams = await examRepository.find({ $or: [{ owner: this.user._id }, { editors: { $in: [this.user._id] } }] }).lean();
        condition['exam'] = { $in: exams.map((exam) => exam._id) };
        break;
      }
    }

    const facade = new ListFacade(null, null, 0, 0, this.keyword, ['title'], examEnrollmentRepository);
    facade.addConditions(condition);
    facade.addPopulates({ path: 'exam', select: 'title' });
    const { items: enrollments } = await facade.create();

    for (let enrollment of enrollments) {
      const timeTableIndex = this.timeTables.findIndex((timetable) => {
        return timetable.date === moment(enrollment.startDateTime).format(DateUtils.DATE_FORMATS.SHORT_DATE);
      });

      if (timeTableIndex !== -1) {
        this.timeTables[timeTableIndex].modules.push({ module: enrollment, type: TimeTableTypes.EXAM_ENROLLMENT });
      } else {
        this.timeTables.push({
          date: moment(enrollment.startDateTime).format(DateUtils.DATE_FORMATS.SHORT_DATE),
          modules: [{ module: enrollment, type: TimeTableTypes.EXAM_ENROLLMENT }]
        });
      }
    }
  }

  private async fetchLiveClassRooms() {
    const videoSessions = await videoSessionRepository.find({ startDateTime: this.dateCondition }).lean();
    const videoSessionIds = videoSessions.map((videoSession) => videoSession._id);

    const condition: any = { $or: [], videoSession: { $in: videoSessionIds } };

    switch (this.user.type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT: {
        const courses: Course[] = await courseRepository
          .find({ students: { $in: [this.user._id] } })
          .select('_id')
          .lean();

        condition.$or.push({ classes: { $in: this.user.classes } });
        condition.$or.push({ course: { $in: courses.map((course) => course._id) } });

        const { disallowedSubjects = [] } = this.user;

        if (this.university.isParul) {
          const domains = await domainRepository.distinct('_id', {
            department: DomainDepartments.LMS,
            university: this.university._id
          });

          const classesFacade = new ListFacade(null, this.university, 0, 0, null, [], classRepository);
          classesFacade.addConditions({ isHidden: false }).addConditions({ _id: { $in: this.user.classes } });
          if (domains.length > 0) classesFacade.addConditions({ domain: { $in: domains } });

          const { items } = await classesFacade.addSelect('_id').createOnlyItems();
          const classes = items.map((o) => o._id);

          const subjectsFacade = new DistinctFacade(null, this.university, '_id', null, [], subjectRepository);
          subjectsFacade.addConditions({ _id: { $nin: disallowedSubjects } });
          subjectsFacade.addConditions({ classroom: { $exists: true, $in: classes } });

          const subjects = await subjectsFacade.create();

          condition.classes = { $in: classes };
          condition.subjects = { $in: subjects };
        }

        break;
      }

      case UserTypes.TEACHER: {
        delete condition.$or;
        condition['teacher'] = this.user._id;
        break;
      }

      default: {
        delete condition.$or;
      }
    }

    const facade = new ListFacade(null, null, 0, 0, this.keyword, ['title'], liveClassRoomRepository);
    facade.addConditions(condition);

    facade.addPopulates([
      { path: 'class', select: 'name' },
      { path: 'course', select: 'title' },
      { path: 'videoSession', select: 'startDateTime' }
    ]);

    const { items: liveClassRooms } = await facade.create();

    for (let liveClassRoom of liveClassRooms) {
      const timeTableIndex = this.timeTables.findIndex((timetable) => {
        return timetable.date === moment(liveClassRoom.videoSession.startDateTime).format(DateUtils.DATE_FORMATS.SHORT_DATE);
      });

      if (timeTableIndex !== -1) {
        this.timeTables[timeTableIndex].modules.push({ module: liveClassRoom, type: TimeTableTypes.LIVE_CLASS_ROOM });
      } else {
        this.timeTables.push({
          date: moment(liveClassRoom.videoSession.startDateTime).format(DateUtils.DATE_FORMATS.SHORT_DATE),
          modules: [{ module: liveClassRoom, type: TimeTableTypes.LIVE_CLASS_ROOM }]
        });
      }
    }
  }
}
