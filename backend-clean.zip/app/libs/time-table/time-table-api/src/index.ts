export * from './lib/controllers/TimeTableCrudController';
