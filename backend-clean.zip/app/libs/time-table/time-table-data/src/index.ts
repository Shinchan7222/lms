export * from './lib/enums/TimeTableEnum';
export * from './lib/interfaces/TimeTable';

