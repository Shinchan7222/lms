import { Assignment } from '@edorer/assignment-data';
import { ExamEnrollment } from '@edorer/exam-enrollment-data';
import { Interview } from '@edorer/interview-data';
import { LiveClassRoom } from '@edorer/live-class-room-data';
import { TimeTableTypes } from '../enums/TimeTableEnum';

export interface TimeTable {
    date: string;
    modules: Array<{ module: Assignment | ExamEnrollment | Interview | LiveClassRoom, type: TimeTableTypes }>;
}
