export enum TimeTableTypes {
    ASSIGNMENT = 'assignment',
    EXAM_ENROLLMENT = 'examEnrollment',
    INTERVIEW = 'interview',
    LIVE_CLASS_ROOM = 'liveClassRoom',
}
