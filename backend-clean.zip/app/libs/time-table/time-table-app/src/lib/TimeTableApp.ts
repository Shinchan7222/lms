import { TimeTableCrudController } from '@edorer/time-table-api';

export class TimeTableApp {

    controllers = [TimeTableCrudController];

    constructor() {
        this.initDB();
    }

    async initDB() {
    }
}
