import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { NotificationListFacade } from '../services/NotificationListFacade';
import { notificationRepository } from '@edorer/notification-data';
import { Validate } from '@edorer/validator';

/**
 * @description Crud Controller for Notification
 */
@JsonController()
export class NotificationCrudController {
  /**
   * @description Get Notification List
   */
  @Get('/notifications/:notificationId([0-9a-f]{24})')
  @Validate([
    {
      field: 'notificationId',
      validation: [{ value: 'notEmpty', message: 'Notification ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('notificationId') notificationId: string) {
    try {
      const notification = await notificationRepository.findOne({ _id: notificationId }).lean();

      return res.status(200).send(notification);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @description Get Notification List
   */
  @Get('/notifications')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    'keyword'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      const { keyword, limit, skip } = req.query;

      const facade = new NotificationListFacade(keyword, limit, skip, req.user, req.university);
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/notifications/delete')
  @Validate([
    {
      field: 'ids',
      validation: [{ value: 'notEmpty', message: 'IDs are required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async delete(@Req() req: any, @Res() res: any) {
    try {
      const { ids } = req.body;

      await notificationRepository.destroy({ _id: { $in: ids } }, req.user._id);

      return res.send({ message: 'Notice(s) deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
