import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { HasUser, IsAuthenticated } from '@edorer/user-data';
import { notificationRepository } from '@edorer/notification-data';
import { Validate } from '@edorer/validator';

/**
 * @description Read Operation Controller Notification
 */
@JsonController()
export class NotificationReadController {
  /**
   * @description Count Notification not read
   */
  @Get('/notifications/count-not-read')
  @UseBefore(HasUser)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async countNotRead(@Req() req: any, @Res() res: any) {
    try {
      let count = 0;

      if (req.user) {
        count = await notificationRepository.count({ isRead: false, receiver: req.user._id });
      }

      return res.status(200).send({ count });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param examId
   * @description Reads One Notification with the given ID
   */
  @Put('/notifications/read/:notificationId([0-9a-f]{24})')
  @Validate([
    {
      field: 'notificationId',
      validation: [{ value: 'notEmpty', message: 'Notification ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async readOne(@Req() req: any, @Res() res: any, @Param('notificationId') notificationId: string) {
    try {
      await notificationRepository.update({ _id: notificationId }, { $set: { isRead: true } }, { multi: false });

      return res.status(201).send({ message: 'Notification read successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param examId
   * @description Reads All Notifications
   */
  @Put('/notifications/read')
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async read(@Req() req: any, @Res() res: any) {
    try {
      await notificationRepository.update({ receiver: req.user._id }, { $set: { isRead: true } }, { multi: true });

      return res.status(201).send({ message: 'Notifications read successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
