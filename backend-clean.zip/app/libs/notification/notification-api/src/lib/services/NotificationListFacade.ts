import { ListFacade } from '@edorer/generic-facades';
import { notificationRepository } from '@edorer/notification-data';
import { University } from '@edorer/university-data';
import { User, UserTypes } from '@edorer/user-data';

export class NotificationListFacade {
  private readonly facade: ListFacade;

  private readonly currentUser: User;

  constructor(keyword: string, limit: number, skip: number, currentUser: User, university: University) {
    this.currentUser = currentUser;

    this.facade = new ListFacade(null, university, +skip, +limit, keyword, ['message', 'subject'], notificationRepository);
  }

  public async create() {
    this.addConditions();

    this.facade.prepareQuery();

    return await this.facade.create();
  }

  private addConditions() {
    this.checkUserType();
  }

  private checkUserType() {
    switch (this.currentUser.type) {
      case UserTypes.APPLICANT:
      case UserTypes.APPLICANT_V2:
      case UserTypes.STUDENT:
        this.facade.addConditions({ dueDate: { $exists: true, $gte: new Date() } });
        this.facade.addConditions({ receiver: this.currentUser._id });

        break;

      case UserTypes.TEACHER:
      case UserTypes.UNIVERSITY_MEMBER:
        this.facade.addConditions({ receiver: this.currentUser._id });
        break;

      case UserTypes.ADMIN:
        this.facade.deleteCondition('university');
        break;
    }
  }
}
