import { Nems } from '@edorer/nems';
import { Notification, NotificationIndexer } from '@edorer/notification-data';
import { NotificationCrudController, NotificationReadController } from '@edorer/notification-api';

export class NotificationApp {

    controllers = [NotificationCrudController, NotificationReadController];

    constructor() {
        this.initDB();
    }

    async initDB() {
        Nems.getInstance().connect(process.env.DATABASE, [{ name: 'Notification', model: Notification }]);
        await NotificationIndexer.index();
    }
}
