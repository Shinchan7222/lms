import { notificationRepository } from '@edorer/notification-data';

export class NotificationIndexer {
  static async index() {
    await notificationRepository.ensureIndex({ _id: 1, deleted: 1 });
    await notificationRepository.ensureIndex({ isRead: 1, receiver: 1, deleted: 1 });
  }
}
