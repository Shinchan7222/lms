import { Model, MongooseModel, dbOperationsNotifier, field, post, pre } from '@edorer/nems';
import { Schema, Types } from 'mongoose';

@Model('Notification')
export class Notification extends MongooseModel {
  @field({
    type: String
  })
  attachment: string;

  @field({
    default: new Date(),
    type: Date
  })
  dueDate: Date;

  @field({
    type: Boolean,
    default: false
  })
  isRead: boolean;

  @field({
    trim: true,
    type: String
  })
  message: string;

  @field({
    ref: 'User',
    type: Types.ObjectId
  })
  receiver: any;

  @field({
    ref: 'User',
    type: Types.ObjectId
  })
  sender: any;

  @field({
    trim: true,
    type: String
  })
  subject: string;

  @field({
    type: Schema.Types.Mixed
  })
  target: any;

  @field({
    trim: true,
    type: String
  })
  type: string;

  @field({
    type: String
  })
  url: string;

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    type: Date
  })
  updatedAt: Date;

  @pre('save')
  checkDifferentReceiverThanSender(next: Function) {
    if (this.receiver.equals(this.sender)) {
      throw new Error('receiver should not be the same as the sender');
    } else {
      next();
    }
  }

  @post('save')
  async notifyCreate() {
    dbOperationsNotifier.notify(
      'notification',
      {
        id: this._id,
        sender: this.sender,
        receiver: this.receiver,
        type: this.type
      },
      'create'
    );
  }

  // @post('save')
  // sendNotification(notification: any) {
  //     PushNotification.create(notification).then(() => {
  //         console.info('Notification sent');
  //     });
  //     application.io.emit('notifications_' + this.receiver, {notification});
  // }
}
