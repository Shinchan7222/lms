import { MongooseRepository } from '@edorer/nems';


class NotificationRepository extends MongooseRepository {
}

export let notificationRepository = new NotificationRepository();
