export enum ClassroomWorkTypes {
  ASSIGNMENT = 'assignment',
  CLASSROOM_WORK = 'classroomWork',
  DOCUMENT = 'document',
  DOWNLOADABLE = 'downloadable',
  EXAM = 'exam',
  POLL = 'poll',
  POWERPOINT = 'powerpoint',
  SESSION_RECORDING = 'sessionRecording',
  YOUTUBE = 'youtube'
}

export enum ClassroomWorkStatus {
  PUBLISHED = 'published',
  SCHEDULED = 'scheduled'
}
