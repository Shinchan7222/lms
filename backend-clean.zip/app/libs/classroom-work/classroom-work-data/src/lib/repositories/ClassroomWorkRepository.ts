import { MongooseRepository } from '@edorer/nems';

class ClassroomWorkRepository extends MongooseRepository {
}

export const classroomWorkRepository = new ClassroomWorkRepository();
