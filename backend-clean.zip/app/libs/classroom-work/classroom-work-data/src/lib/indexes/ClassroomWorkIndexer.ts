import { classroomWorkRepository } from '@edorer/classroom-work-data';

export class ClassroomWorkIndexer {

    static async index() {
        await classroomWorkRepository.ensureIndex({ _id: 1, deleted: 1 });
        await classroomWorkRepository.ensureIndex({ _id: 1, owner: 1 });
        await classroomWorkRepository.ensureIndex({ _id: 1, owner: 1, deleted: 1 });
        await classroomWorkRepository.ensureIndex({ _id: 1, owner: 1, university: 1 });
        await classroomWorkRepository.ensureIndex({ _id: 1, owner: 1, university: 1, deleted: 1 });
        await classroomWorkRepository.ensureIndex({ _id: 1, university: 1 });
        await classroomWorkRepository.ensureIndex({ _id: 1, university: 1, deleted: 1 });
        await classroomWorkRepository.ensureIndex({ deleted: 1 });
        await classroomWorkRepository.ensureIndex({ owner: 1 });
        await classroomWorkRepository.ensureIndex({ owner: 1, deleted: 1 });
        await classroomWorkRepository.ensureIndex({ owner: 1, university: 1 });
        await classroomWorkRepository.ensureIndex({ owner: 1, university: 1, deleted: 1 });
        await classroomWorkRepository.ensureIndex({ university: 1 });
        await classroomWorkRepository.ensureIndex({ university: 1, deleted: 1 });
    }

}
