export interface ClassroomWorkAnswer {
    content: string;
    count: number;
}