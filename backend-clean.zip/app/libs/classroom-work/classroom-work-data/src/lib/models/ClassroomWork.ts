import { ClassroomWorkStatus, ClassroomWorkTypes } from '../enums/ClassroomWorksEnum';
import { Model, MongooseModel, dbOperationsNotifier, field, post } from '@edorer/nems';
import { Types } from 'mongoose';

@Model('ClassroomWork')
export class ClassroomWork extends MongooseModel {
  @field([
    {
      content: { type: String },
      isAnswerd: { default: false, type: Boolean },
      count: { default: 0, type: Number }
    }
  ])
  answers: Array<{ _id: Types.ObjectId; content: string; count: number; isAnswerd: boolean }>;

  @field({
    ref: 'Assignment',
    type: Types.ObjectId
  })
  assignment: any;

  @field({
    type: String
  })
  document: string;

  @field({
    type: String
  })
  previousDocument: string;

  @field({
    ref: 'Exam',
    type: Types.ObjectId
  })
  exam: any;

  @field([
    {
      type: String
    }
  ])
  images: string[];

  @field([
    {
      type: String
    }
  ])
  previousImages: string[];

  @field({
    type: Boolean
  })
  isDownloadable: boolean;

  @field({
    ref: 'User',
    required: true,
    type: Types.ObjectId
  })
  owner: any;

  @field({
    default: new Date(),
    type: Date
  })
  publishAt: Date;

  @field({
    default: ClassroomWorkStatus.PUBLISHED,
    enum: [ClassroomWorkStatus.PUBLISHED, ClassroomWorkStatus.SCHEDULED],
    type: String
  })
  status: string;

  @field({
    ref: 'Subject',
    required: true,
    type: Types.ObjectId
  })
  subject: any;

  @field({
    default: 0,
    type: Number
  })
  taken: number;

  @field({
    required: true,
    type: String
  })
  title: string;

  @field({
    ref: 'ClassroomTopic',
    type: Types.ObjectId
  })
  topic: any;

  @field({
    ref: 'TrackAssignment',
    type: Types.ObjectId
  })
  trackAssignment: any;

  @field({
    enum: [
      ClassroomWorkTypes.ASSIGNMENT,
      ClassroomWorkTypes.CLASSROOM_WORK,
      ClassroomWorkTypes.DOCUMENT,
      ClassroomWorkTypes.DOWNLOADABLE,
      ClassroomWorkTypes.EXAM,
      ClassroomWorkTypes.POLL,
      ClassroomWorkTypes.POWERPOINT,
      ClassroomWorkTypes.SESSION_RECORDING,
      ClassroomWorkTypes.YOUTUBE
    ],
    required: true,
    type: String
  })
  type: ClassroomWorkTypes;

  @field({
    type: String
  })
  video: string;

  @field({
    type: String
  })
  previousVideo: string;

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  @post('save')
  async notifyCreate() {
    dbOperationsNotifier.notify(
      'ClassroomWork',
      {
        id: this._id,
        university: this.university,
        owner: this.owner
      },
      'create'
    );
  }
}
