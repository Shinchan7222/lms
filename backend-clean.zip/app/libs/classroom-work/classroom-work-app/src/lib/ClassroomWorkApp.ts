import { ClassroomWork, ClassroomWorkIndexer } from '@edorer/classroom-work-data';
import {
  ClassroomWorkCrudController,
  ClassroomWorkFetchController,
  ClassroomWorkLogsController,
  ClassroomWorkMaterialsController
} from '@edorer/classroom-work-api';
import { CronRegistry } from '@edorer/cron-data';
import { Nems } from '@edorer/nems';
import { publishClassroomWorks } from '@edorer/classroom-work-cron';

export class ClassroomWorkApp {
  controllers = [ClassroomWorkCrudController, ClassroomWorkFetchController, ClassroomWorkLogsController, ClassroomWorkMaterialsController];

  constructor() {
    this.initDB();
    this.initCrons();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'ClassroomWork', model: ClassroomWork }]);

    await ClassroomWorkIndexer.index();
  }

  async initCrons() {
    CronRegistry.getInstance().register('publishClassroomWorks', publishClassroomWorks.init, publishClassroomWorks);
  }
}
