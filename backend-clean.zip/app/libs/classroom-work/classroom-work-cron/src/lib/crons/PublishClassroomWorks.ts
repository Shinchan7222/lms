import { ClassroomWork, ClassroomWorkStatus, classroomWorkRepository } from '@edorer/classroom-work-data';

class PublishClassroomWorks {

    private classroomWorks: ClassroomWork[] = [];

    async init() {
        await this.fetchData();
        await this.work();
    }

    private async fetchData() {
        this.classroomWorks = await classroomWorkRepository
            .find({
                status: { $exists: true, $eq: ClassroomWorkStatus.SCHEDULED },
                publishAt: { $exists: true, $lte: new Date() }
            })
            .limit(200)
            .lean();
    }

    private async work() {
        const workIds = this.classroomWorks.map(entry => entry._id);
        if (workIds.length > 0) {
            await classroomWorkRepository.update(
                { _id: { $in: workIds } },
                { $set: { status: ClassroomWorkStatus.PUBLISHED } },
                { multi: true }
            );
        }
    }
}

export const publishClassroomWorks = new PublishClassroomWorks();
