import { ClassroomWorkCreator } from '../services/ClassroomWorkCreator';
import { classroomWorkRepository } from '@edorer/classroom-work-data';
import { ClassroomWorkUpdater } from '../services/ClassroomWorkUpdater';
import { Delete, Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { FindClassroomWorkFacade } from '../facades/FindClassroomWorkFacade';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity, GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ClassroomWorkCrudController {
  @Post('/classroom-works/:subject([0-9a-f]{24})')
  @Validate([
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    },
    {
      field: 'title',
      validation: [{ value: 'notEmpty', message: 'Title is required' }]
    },
    {
      field: 'type',
      validation: [{ value: 'notEmpty', message: 'Type is required' }]
    },
    'answers',
    'assignment',
    'attachedSubjects',
    'document',
    'exam',
    'isDownloadable',
    'publishAt',
    'status',
    'topic',
    'video'
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async create(@Req() req: any, @Res() res: any, @Param('subject') subject: string) {
    try {
      const {
        answers,
        assignment,
        attachedSubjects,
        document,
        exam,
        isDownloadable = false,
        publishAt,
        status,
        title,
        topic,
        type,
        video
      } = req.body;

      const classroomCreator = new ClassroomWorkCreator(
        answers,
        assignment,
        attachedSubjects,
        document,
        exam,
        isDownloadable,
        publishAt,
        status,
        subject,
        title,
        topic,
        type,
        video,
        req.user,
        req.university,
        req.universityConfig
      );
      await classroomCreator.create();

      return res.status(201).send({ message: 'Classroom work created successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/classroom-works/:subject([0-9a-f]{24})')
  @Validate([
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    },
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async find(@Req() req: any, @Res() res: any, @Param('subject') subject: string) {
    try {
      const { limit, skip } = req.query;

      const facade = new FindClassroomWorkFacade(limit, skip, subject, req.user, req.university);
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Put('/classroom-works/:classroomWork([0-9a-f]{24})')
  @Validate([
    {
      field: 'classroomWork',
      validation: [{ value: 'notEmpty', message: 'Classroom Work ID is required' }]
    },
    'answers',
    'document',
    'isDownloadable',
    'title',
    'topic',
    'video'
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async update(@Req() req: any, @Res() res: any, @Param('classroomWork') classroomWork: string) {
    try {
      const updateFacade = new ClassroomWorkUpdater(req.body, classroomWork, req.universityConfig);
      const work = await updateFacade.update();

      return res.status(201).send(work);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Delete('/classroom-works/:classroomWork([0-9a-f]{24})')
  @Validate([
    {
      field: 'classroomWork',
      validation: [{ value: 'notEmpty', message: 'Classroom Work ID is required' }]
    }
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async delete(@Req() req: any, @Res() res: any, @Param('classroomWork') classroomWork: string) {
    try {
      await classroomWorkRepository.destroy({ _id: classroomWork }, req.user);

      return res.status(200).send({ message: 'Work deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
