import { ClassroomWorkFetcher } from '../services/ClassroomWorkFetcher';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { Validate } from '@edorer/validator';

@JsonController()
export class ClassroomWorkFetchController {
  @Get('/classroom-works/fetch/:subject([0-9a-f]{24})')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'Limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'Skip is required' }]
    },
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    },
    'keyword'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async fetch(@Req() req: any, @Res() res: any, @Param('subject') subject: string) {
    const { keyword, limit, skip } = req.query;

    try {
      const facade = new ClassroomWorkFetcher(keyword, limit, skip, subject, req.user, req.university);
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
