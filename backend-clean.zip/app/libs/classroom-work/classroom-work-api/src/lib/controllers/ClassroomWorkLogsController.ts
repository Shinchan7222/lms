import { ClassroomWorkLogsDownloader } from '../services/ClassroomWorkLogsDownloader';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Post, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity, GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { logRepository } from '@edorer/log-data';
import { readFileSync } from 'fs';
import { Validate } from '@edorer/validator';

@JsonController()
export class ClassroomWorkLogsController {
  @Post('/classroom-works/log/:subject([0-9a-f]{24})')
  @Validate([
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    },
    {
      field: 'content',
      validation: [{ value: 'notEmpty', message: 'Content is required' }]
    }
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async create(@Req() req: any, @Res() res: any, @Param('subject') subject: string) {
    try {
      const { content } = req.body;

      await logRepository.create({ targetType: 'ClassroomWork', action: 'create', user: req.user, content, subject, university: req.university._id });

      return res.status(201).send({ message: 'Logged successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  @Get('/classroom-works/logs/download/:subject([0-9a-f]{24})')
  @Validate([
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    }
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async download(@Req() req: any, @Res() res: any, @Param('subject') subject: string) {
    try {
      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=ExamReports.xlsx');

      const excel = new ClassroomWorkLogsDownloader(subject);
      const path = await excel.download();
      const buffer = readFileSync(path);

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; ExamReports.xlsx`,
        'Content-Length': buffer.length
      });

      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
