import { ClassroomWorkMaterialsDownloader } from '../services/ClassroomWorkMaterialsDownloader';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { Get, JsonController, Param, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { GetUniversity, GetUniversityConfig } from '@edorer/university-data';
import { IsAuthenticated } from '@edorer/user-data';
import { readFileSync } from 'fs';
import { Validate } from '@edorer/validator';

@JsonController()
export class ClassroomWorkMaterialsController {
  @Get('/classroom-works/materials/download/:subject([0-9a-f]{24})')
  @Validate([
    {
      field: 'subject',
      validation: [{ value: 'notEmpty', message: 'Subject is required' }]
    }
  ])
  @UseBefore(GetUniversityConfig)
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseAfter(FinishRequest)
  @UseBefore(StartRequest)
  async download(@Req() req: any, @Res() res: any, @Param('subject') subject: string) {
    try {
      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', 'attachment; filename=ClassroomMaterials.xlsx');

      const excel = new ClassroomWorkMaterialsDownloader(subject, req.user, req.university);
      const path = await excel.download();
      const buffer = readFileSync(path);

      res.writeHead(200, {
        'Content-Type': 'application/vnd.ms-excel',
        'Content-disposition': `attachment;attachment; ClassroomMaterials.xlsx`,
        'Content-Length': buffer.length
      });

      return res.end(buffer);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
