import { ClassroomPollAnswer, classroomPollAnswerRepository } from '@edorer/classroom-poll-answer-data';
import { ClassroomWork, ClassroomWorkTypes, classroomWorkRepository, ClassroomWorkStatus } from '@edorer/classroom-work-data';
import { ListFacade } from '@edorer/generic-facades';
import { TrackAssignment, trackAssignmentRepository } from '@edorer/track-assignment-data';
import { TrackExam } from '@edorer/track-exam-data';
import { Types } from 'mongoose';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class FindClassroomWorkFacade {

    private readonly currentUser: User;

    private readonly facade: ListFacade;

    private readonly subject: string;

    private readonly university: University;

    private total: number;

    private trackAssignments: TrackAssignment[] = [];

    private pollAnswers: ClassroomPollAnswer[] = [];

    private trackExams: TrackExam[] = [];

    private works: ClassroomWork[] = [];

    constructor(limit: number, skip: number, subject: string, currentUser: User, university: University) {
        this.currentUser = currentUser;
        this.subject = subject;
        this.university = university;

        this.facade = new ListFacade(null, this.university, +skip, +limit, null, [], classroomWorkRepository, false);
    }

    async create() {
        this.addConditions();
        this.addPopulates();

        await this.fetchWorks();

        await this.fetchPollAnswers();
        await this.fetchTrackAssignments();
        await this.fetchTrackExams();

        this.prepareClassroomWorks();

        return { items: this.works, total: this.total };
    }

    private addConditions() {
        this.facade.addConditions({ status: ClassroomWorkStatus.PUBLISHED });
        this.facade.addConditions({ subject: Types.ObjectId(this.subject) });
        this.facade.addConditions({ $or: [{ topic: { $exists: false } }, { topic: { $eq: null } }] });
    }

    private addPopulates() {
        this.facade.addPopulates([
            {
                path: 'assignment',
                select: 'domain dueDateTime hasDueDate point submissions title',
                populate: { path: 'domain', select: 'name' }
            },
            {
                path: 'exam',
                select: 'domain questions title totalMarks',
                populate: { path: 'domain', select: 'name' }
            }
        ]);
    }

    private async fetchWorks() {
        this.facade.prepareQuery();

        const { items } = await this.facade.create();

        this.works = JSON.parse(JSON.stringify(items)).filter(item => item.owner);
        this.total = this.works.length;
    }

    private async fetchPollAnswers() {
        if (this.works.length > 0) {
            const polls = this.works.filter(work => work.type === ClassroomWorkTypes.POLL).map(work => work._id);
            this.pollAnswers = await classroomPollAnswerRepository.find({ classroomWork: { $in: polls } }).lean();
        }
    }

    private async fetchTrackAssignments() {
        if (this.works.length > 0) {
            const assignments = this.works.filter(work => work.assignment && work.assignment._id).map(work => work.assignment._id);
            this.trackAssignments = await trackAssignmentRepository.find({ assignment: { $in: assignments } }).lean();
        }
    }

    private async fetchTrackExams() {
        if (this.works.length > 0) {
            const exams = this.works.filter(work => work.exam && work.exam._id).map(work => work.exam._id);
            this.trackExams = await trackAssignmentRepository.find({ exam: { $in: exams } }).lean();
        }
    }

    private prepareClassroomWorks() {
        for (let work of this.works) {
            switch (work.type) {
                case ClassroomWorkTypes.ASSIGNMENT: {
                    const tracks = this.trackAssignments.filter(track => work.assignment && track.assignment.toString() === work.assignment._id.toString());
                    work.taken = tracks.length;
                    work.trackAssignment = this.trackAssignments.find(track => work.assignment && track.assignment.toString() === work.assignment._id.toString() && track.user.toString() === this.currentUser._id.toString());

                    break;
                }

                case ClassroomWorkTypes.EXAM: {
                    const tracks = this.trackExams.filter(track => work.exam && track.exam.toString() === work.exam._id.toString());
                    work.taken = tracks.length;

                    break;
                }

                case ClassroomWorkTypes.POLL: {
                    const answers = this.pollAnswers.filter(answer => answer.classroomWork.toString() === work._id.toString());
                    for (let answer of work.answers) {
                        answer.count = answers.filter(entry => entry.answer.toString() === answer._id.toString()).length;
                        answer.isAnswerd = answers.findIndex(entry => {
                            return entry.answer.toString() === answer._id.toString() &&
                                entry.owner.toString() === this.currentUser._id.toString()
                        }) > -1;
                    }

                    break;
                }
            }
        }
    }
}
