import { classroomWorkRepository, ClassroomWork, ClassroomWorkStatus } from '@edorer/classroom-work-data';
import { DateUtils, Json2Excel, StringUtils } from '@edorer/utils';
import { ListFacade } from '@edorer/generic-facades';
import { Subject, subjectRepository } from '@edorer/subject-data';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import * as moment from 'moment-timezone';

export class ClassroomWorkMaterialsDownloader {
  private readonly currentUser: User;

  private readonly subjectId: string;

  private readonly university: University;

  private classroomWorks: ClassroomWork[] = [];

  private items = [];

  private subject: Subject;

  constructor(subjectId: string, currentUser: User, university: University) {
    this.subjectId = subjectId;
    this.currentUser = currentUser;
    this.university = university;
  }

  public async download() {
    await this.fetchSubject();
    await this.fetchWorks();
    this.prepareItems();

    const converter = new Json2Excel(this.items, [], StringUtils.titleCase(this.subject.name));
    converter.sheet = StringUtils.titleCase(this.subject.name);

    return converter.convert();
  }

  private async fetchSubject() {
    try {
      this.subject = await subjectRepository.findOne({ _id: this.subjectId }).lean();
      if (!this.subject) throw new Error('Subject was not found.');
    } catch (error) {
      throw new Error('Could not generate logs for this subject.');
    }
  }

  private async fetchWorks() {
    try {
      const facade = new ListFacade(this.currentUser, this.university, 0, 0, null, [], classroomWorkRepository);
      facade.addSelect('document owner title video');
      facade.addPopulates({ path: 'owner', select: 'email' });

      const { items } = await facade
        .addConditions({
          $or: [{ video: { $exists: true, $ne: null } }, { document: { $exists: true, $ne: null } }],
          status: ClassroomWorkStatus.PUBLISHED,
          subject: this.subjectId
        })
        .createOnlyItems();

      this.classroomWorks = items;
    } catch (error) {
      throw new Error('Could not generate report for this subject.');
    }
  }

  private prepareItems() {
    for (let { createdAt, document, title, owner, video } of this.classroomWorks) {
      this.items.push({
        Work: title,
        Attachment: document || video,
        Uploader: owner.email,
        Uploaded: moment(createdAt).tz('Asia/Kolkata').format(DateUtils.DATE_FORMATS.FULL_DATE)
      });
    }
  }
}
