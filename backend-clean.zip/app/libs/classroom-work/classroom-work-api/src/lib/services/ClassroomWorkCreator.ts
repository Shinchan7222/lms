import { classroomRepository } from '@edorer/classroom-data';
import { classroomTopicRepository } from '@edorer/classroom-topic-data';
import { ClassroomWorkTypes, classroomWorkRepository, ClassroomWorkStatus, ClassroomWorkAnswer } from '@edorer/classroom-work-data';
import { ConvertDocToPDF, ConvertPPTToImages, FileUtils } from '@edorer/utils';
import { Types } from 'mongoose';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';
import { v4 as uuidV4 } from 'uuid';

export class ClassroomWorkCreator {
  private readonly answers: ClassroomWorkAnswer[] = [];

  private readonly assignment: string;

  private readonly attachedSubjects: string[];

  private readonly currentUser: User;

  private document: string | null;

  private readonly exam: string | null;

  private readonly isDownloadable: boolean;

  private readonly publishAt: Date;

  private readonly status: ClassroomWorkStatus;

  private readonly subject: string;

  private readonly title: string;

  private readonly topic: string;

  private readonly type: ClassroomWorkTypes;

  private readonly university: University;

  private readonly video: string | null;

  private images: string[] = [];

  private subjects: string[] = [];

  private topics: string[] = [];

  private readonly universityConfig: any;

  constructor(
    answers: ClassroomWorkAnswer[] = [],
    assignment: string,
    attachedSubjects: string[],
    document: string | null,
    exam: string | null,
    isDownloadable: boolean,
    publishAt: number,
    status: ClassroomWorkStatus,
    subject: string,
    title: string,
    topic: string,
    type: ClassroomWorkTypes,
    video: string | null,
    currentUser: User,
    university: University,
    universityConfig: any
  ) {
    this.answers = answers;
    this.assignment = assignment;
    this.attachedSubjects = attachedSubjects;
    this.currentUser = currentUser;
    this.document = document;
    this.exam = exam;
    this.isDownloadable = isDownloadable;
    this.status = status;
    this.subject = subject;
    this.title = title;
    this.topic = topic;
    this.type = type;
    this.university = university;
    this.video = video;
    this.universityConfig = universityConfig;
    if (publishAt) {
      this.publishAt = new Date(+publishAt);
    }
  }

  async create() {
    this.prepareSubjects();
    await this.prepareImages();
    await this.prepareTopics();
    await this.addTopics();
    await this.createWorks();
  }

  private prepareSubjects() {
    if (this.subject && Types.ObjectId.isValid(this.subject)) {
      this.subjects.push(this.subject);
    }

    if (this.attachedSubjects && this.attachedSubjects.length > 0) {
      for (let attachedSubject of this.attachedSubjects) {
        if (Types.ObjectId.isValid(attachedSubject)) {
          this.subjects.push(attachedSubject);
        }
      }
    }

    this.subjects = [...new Set(this.subjects)];
  }

  private async prepareImages() {
    if (this.type === ClassroomWorkTypes.POWERPOINT && this.document) {
      const url = await FileUtils.download(this.document);

      const file = {
        buffer: FileUtils.readFile(url),
        originalname: uuidV4() + '.pptx'
      };

      const converter = new ConvertPPTToImages(file, this.universityConfig);
      this.images = await converter.convert();
    } else if (this.type === ClassroomWorkTypes.DOCUMENT && this.document && this.document.indexOf('.docx') > -1) {
      const url = await FileUtils.download(this.document);

      const file = {
        buffer: FileUtils.readFile(url),
        originalname: uuidV4() + '.docx'
      };

      let converter = new ConvertDocToPDF(file, this.universityConfig);
      this.document = await converter.convert();
    }
  }

  private async prepareTopics() {
    if (this.topic) {
      for (let subject of this.subjects) {
        const topic = await classroomTopicRepository.findOneAndUpdate(
          { subject, title: this.topic },
          { $set: { owner: this.currentUser._id, university: this.university._id } },
          { multi: false, new: true, upsert: true }
        );

        this.topics.push(topic._id);
      }
    }
  }

  private async addTopics() {
    if (this.topics.length > 0) {
      for (let index = 0; index < this.topics.length; index++) {
        const subject = this.subjects[index];
        const topic = this.topics[index];

        await classroomRepository.update({ subject }, { $addToSet: { topics: [topic] } }, { multi: false });
      }
    }
  }

  private async createWorks() {
    const workPromises = [];
    for (let index = 0; index < this.subjects.length; index++) {
      const subject = this.subjects[index];
      const topic = this.topics[index];

      const classroomWork = classroomWorkRepository.create({
        answers: this.answers,
        assignment: this.assignment,
        document: this.document,
        exam: this.exam,
        images: this.images,
        isDownloadable: this.isDownloadable,
        owner: this.currentUser._id,
        publishAt: this.publishAt,
        status: this.status,
        subject,
        title: this.title,
        topic,
        type: this.type,
        university: this.university._id,
        video: this.video
      });

      workPromises.push(classroomWork);
    }

    await Promise.all(workPromises);
  }
}
