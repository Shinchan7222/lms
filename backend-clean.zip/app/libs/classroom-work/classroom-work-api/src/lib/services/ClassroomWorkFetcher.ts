import { classroomWorkRepository, ClassroomWorkTypes } from '@edorer/classroom-work-data';
import { ListFacade } from '@edorer/generic-facades';
import { University } from '@edorer/university-data';
import { User } from '@edorer/user-data';

export class ClassroomWorkFetcher {
  private readonly currentUser: User;

  protected readonly keyword: string;

  protected readonly limit: number;

  protected readonly skip: number;

  private readonly subject: string;

  private readonly facade: ListFacade;

  private readonly university: University;

  constructor(keyword: string, limit: number, skip: number, subject: string, currentUser: User, university: University) {
    this.currentUser = currentUser;
    this.keyword = keyword;
    this.limit = +limit;
    this.skip = +skip;
    this.subject = subject;
    this.university = university;

    this.facade = new ListFacade(this.currentUser, this.university, this.skip, this.limit, this.keyword, ['title'], classroomWorkRepository, false);
  }

  async create() {
    this.addConditions();

    this.facade.prepareQuery();

    return await this.facade.create();
  }

  private addConditions() {
    this.checkSubject();
    this.checkType();
  }

  private checkSubject() {
    if (this.subject) {
      this.facade.addConditions({ subject: { $eq: this.subject } });
    }
  }

  private checkType() {
    this.facade.addConditions({ type: ClassroomWorkTypes.DOCUMENT, document: new RegExp('.mp4', 'i') });
  }
}
