import { ClassroomWorkTypes, classroomWorkRepository, ClassroomWork } from '@edorer/classroom-work-data';
import { DateUtils, Json2Excel, StringUtils } from '@edorer/utils';
import { Log, logRepository } from '@edorer/log-data';
import { Subject, subjectRepository } from '@edorer/subject-data';
import { User, userRepository } from '@edorer/user-data';
import * as moment from 'moment-timezone';

export class ClassroomWorkLogsDownloader {
  private readonly subjectId: string;

  private classroomWorks: ClassroomWork[] = [];

  private items = [];

  private logs: Log[] = [];

  private subject: Subject;

  private users: User[] = [];

  constructor(subjectId: string) {
    this.subjectId = subjectId;
  }

  public async download() {
    await this.fetchSubject();
    await this.fetchUsers();
    await this.fetchWorks();
    await this.fetchLogs();

    this.prepareItems();

    const converter = new Json2Excel(this.items, [], StringUtils.titleCase(this.subject.name));
    converter.sheet = StringUtils.titleCase(this.subject.name);

    return converter.convert();
  }

  private async fetchSubject() {
    try {
      this.subject = await subjectRepository.findOne({ _id: this.subjectId }).lean();
      if (!this.subject) throw new Error('Subject was not found.');
    } catch (error) {
      throw new Error('Could not generate logs for this subject.');
    }
  }

  private async fetchWorks() {
    try {
      this.classroomWorks = await classroomWorkRepository.find({ subject: this.subjectId }).lean();
    } catch (error) {
      throw new Error('Could not generate logs for this subject.');
    }
  }

  private async fetchUsers() {
    try {
      this.users = await userRepository
        .find({ classes: { $in: [this.subject.classroom] } })
        .select('email name')
        .lean();
    } catch (error) {
      throw new Error('Could not generate logs for this subject.');
    }
  }

  private async fetchLogs() {
    try {
      const assignments = this.classroomWorks.filter((c) => c.type === ClassroomWorkTypes.ASSIGNMENT).map((o) => o.assignment);
      const exams = this.classroomWorks.filter((c) => c.type === ClassroomWorkTypes.EXAM).map((o) => o.exam);

      this.logs = await logRepository
        .find({ $or: [{ subject: this.subjectId }, { assignment: { $in: assignments } }, { exam: { $in: exams } }] })
        .lean();
    } catch (error) {
      throw new Error('Could not generate logs for this subject.');
    }
  }

  private prepareItems() {
    for (let user of this.users) {
      const userLogs = this.logs.filter((o) => o.user && String(o.user) === String(user._id));
      let percentage = this.classroomWorks.length === 0 ? 0 : (userLogs.length / this.classroomWorks.length) * 100;
      percentage = Math.min(percentage, 100);

      this.items.push({
        Name: user.name,
        Email: user.email,
        Progress: percentage.toFixed(2),
        'First Log': userLogs.length > 0 ? moment(userLogs[0].createdAt).tz('Asia/Kolkata').format(DateUtils.DATE_FORMATS.FULL_DATE) : '--',
        'Last Log':
          userLogs.length > 0
            ? moment(userLogs[userLogs.length - 1].createdAt)
                .tz('Asia/Kolkata')
                .format(DateUtils.DATE_FORMATS.FULL_DATE)
            : '--'
      });
    }
  }
}
