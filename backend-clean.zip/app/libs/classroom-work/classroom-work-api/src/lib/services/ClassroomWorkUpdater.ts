import { ClassroomWorkTypes, classroomWorkRepository, ClassroomWork } from '@edorer/classroom-work-data';
import { ConvertPPTToImages, FileUtils } from '@edorer/utils';
import { UpdateFacade } from '@edorer/generic-facades';
import { v4 as uuidV4 } from 'uuid';

export class ClassroomWorkUpdater {
  private readonly updatedData: Record<string, string>;

  private readonly workId: string;

  private work: ClassroomWork;

  private updatedWork: ClassroomWork;

  private readonly universityConfig: any;

  constructor(updatedData: Record<string, string>, workId: string, universityConfig: any) {
    this.updatedData = updatedData;
    this.workId = workId;
    this.universityConfig = universityConfig;
  }

  public async update() {
    await this.fetchWork();
    await this.updateWork();
    await this.updateImages();

    return this.updatedWork;
  }

  private async fetchWork() {
    this.work = await classroomWorkRepository.findOne({ _id: this.workId }).lean();
    if (!this.work) {
      throw new Error('Classroom work not found');
    }
  }

  private async updateWork() {
    const updateFacade = new UpdateFacade(
      this.workId,
      this.updatedData,
      ['answers', 'document', 'isDownloadable', 'title', 'topic', 'video'],
      classroomWorkRepository
    );
    this.updatedWork = await updateFacade.create();
  }

  private async updateImages() {
    if (this.work.type === ClassroomWorkTypes.POWERPOINT) {
      const url = await FileUtils.download(this.updatedWork.document);

      const file = {
        buffer: FileUtils.readFile(url),
        originalname: uuidV4() + '.pptx'
      };

      const converter = new ConvertPPTToImages(file, this.universityConfig);
      const images = await converter.convert();

      this.updatedWork = await classroomWorkRepository.findOneAndUpdate({ _id: this.workId }, { $set: { images } }, { multi: false, new: true });
    }
  }
}
