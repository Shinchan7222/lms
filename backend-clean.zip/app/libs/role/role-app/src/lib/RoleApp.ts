import { RoleCrudController } from '@edorer/role-api';
import { Role, RoleIndexer } from '@edorer/role-data';
import { Nems } from '@edorer/nems';

export class RoleApp {
  controllers = [RoleCrudController];

  constructor() {
    this.initDB();
  }

  async initDB() {
    Nems.getInstance().connect(process.env.DATABASE, [{ name: 'Role', model: Role }]);
    await RoleIndexer.index();
  }
}
