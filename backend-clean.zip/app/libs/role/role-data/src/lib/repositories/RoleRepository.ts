import { MongooseRepository } from '@edorer/nems';

class RoleRepository extends MongooseRepository {
}

export let roleRepository = new RoleRepository();
