import { roleRepository } from '@edorer/role-data';

export class RoleIndexer {

    static async index() {
        await roleRepository.ensureIndex({ _id: 1, deleted: 1 });
        await roleRepository.ensureIndex({ allDomains: 1, 'domains.allSelected': 1, deleted: 1 });
        await roleRepository.ensureIndex({ owner: 1, university: 1, deleted: 1 });
        await roleRepository.ensureIndex({ owner: 1, university: 1, title: 1, deleted: 1 });
        await roleRepository.ensureIndex({ university: 1, deleted: 1 });
        await roleRepository.ensureIndex({ university: 1, title: 1, deleted: 1 });
    }
}
