import { domainRepository } from '@edorer/domain-data';
import { Model, MongooseModel, field } from '@edorer/nems';
import { Types } from 'mongoose';

const roleFields = {
  delete: {
    default: false,
    type: Boolean
  },
  read: {
    default: false,
    type: Boolean
  },
  write: {
    default: false,
    type: Boolean
  },
  download: {
    default: false,
    type: Boolean
  }
};

@Model('Role')
export class Role extends MongooseModel {
  @field(roleFields)
  admins: { delete: boolean; read: boolean; write: boolean };

  @field({
    read: {
      default: false,
      type: Boolean
    }
  })
  analytics: { read: boolean };

  @field(roleFields)
  admissions: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  booksets: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  booksetTracks: { delete: boolean; read: boolean; write: boolean; download: boolean };

  @field(roleFields)
  feeCategories: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  ticketCategories: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, change: { default: false, type: Boolean } })
  feePlans: { delete: boolean; read: boolean; write: boolean; change: boolean };

  @field(roleFields)
  crmToLms: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  studentViews: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  studentEnrollments: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  studentPayments: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  admissionCategories: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  admissionQuotas: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  feeHeads: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  debAdmissions: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  debToLms: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  approvedDebToLms: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  debStudentProfiles: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  admissionToLms: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  paymentTransactions: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  feeManagement: { delete: boolean; read: boolean; write: boolean };

  externalMarks: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  externalMarkEntries: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  externalMarkGrades: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  externalMarkHeads: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  externalMarkHeadNames: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  externalMarkHeadSessions: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  externalMarkMatrices: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalMarks: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalAdmitCards: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalMarkEntries: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  vivaMarkEntries: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalMarkGrades: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalMarkHeads: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  vivaMarkHeads: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalMarkHeadNames: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  vivaMarks: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  vivaMarkHeadNames: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalMarkHeadSessions: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  vivaMarkHeadSessions: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  internalMarkMatrices: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  applicantGroups: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, selfCreated: { default: false, type: Boolean } })
  applicants: { delete: boolean; read: boolean; selfCreated: boolean; write: boolean };

  @field(roleFields)
  assignments: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  bannedStudents: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  broadCasts: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  categories: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, duplicate: { default: false, type: Boolean } })
  classes: { delete: boolean; read: boolean; write: boolean; duplicate: boolean };

  @field(roleFields)
  classroomAnalytics: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  contentBuilders: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, selfCreated: { default: false, type: Boolean } })
  coupons: { delete: boolean; read: boolean; selfCreated: boolean; write: boolean };

  @field({ ...roleFields, selfCreated: { default: false, type: Boolean } })
  courses: { delete: boolean; read: boolean; selfCreated: boolean; write: boolean };

  @field(roleFields)
  courseAnalytics: { delete: boolean; read: boolean; write: boolean };

  @field({
    ...roleFields,
    allSelected: {
      default: false,
      type: Boolean
    },
    exceptions: [
      {
        ref: 'Domain',
        type: Types.ObjectId
      }
    ],
    exceptionDepartments: [
      {
        type: String
      }
    ],
    hasException: {
      default: false,
      type: Boolean
    },
    selected: [
      {
        ref: 'Domain',
        type: Types.ObjectId
      }
    ]
  })
  domains: {
    allSelected: boolean;
    delete: boolean;
    exceptionDepartments: string[];
    exceptions: any[];
    hasException: boolean;
    read: boolean;
    selected: any[];
    write: boolean;
  };

  @field({ ...roleFields, selfCreated: { default: false, type: Boolean } })
  dynamicForms: { delete: boolean; read: boolean; write: boolean; selfCreated: boolean };

  @field(roleFields)
  events: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, selfCreated: { default: false, type: Boolean } })
  exams: { delete: boolean; read: boolean; write: boolean; selfCreated: boolean };

  @field(roleFields)
  flows: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  forums: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  htmlTemplates: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, interviewerOnly: { default: true, type: Boolean } })
  interviews: { interviewerOnly: boolean; delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, selfCreated: { default: false, type: Boolean } })
  leads: { delete: boolean; read: boolean; selfCreated: boolean; write: boolean };

  @field({ ...roleFields, lock: { default: false, type: Boolean }, selfCreated: { default: false, type: Boolean } })
  lmsExam: { delete: boolean; lock: boolean; read: boolean; selfCreated: boolean; write: boolean };

  @field(roleFields)
  logs: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  openBooks: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  pages: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  paymentGateways: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  paymentRequests: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, selfCreated: { default: false, type: Boolean }, canRefund: { default: false, type: Boolean } })
  payments: { delete: boolean; read: boolean; write: boolean; selfCreated: boolean; canRefund: boolean };

  @field(roleFields)
  pendingStudents: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  plugins: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  programResults: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  programs: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  reassesments: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  referrals: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  requests: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  roles: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  sales: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  schedules: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  sessions: { delete: boolean; read: boolean; write: boolean };

  @field({
    ...roleFields,
    canRevoke: { default: false, type: Boolean },
    canSuspend: { default: false, type: Boolean },
    selfCreated: { default: false, type: Boolean }
  })
  students: { delete: boolean; read: boolean; write: boolean; selfCreated: boolean; canRevoke: boolean; canSuspend: boolean };

  @field({ ...roleFields, canApprove: { default: false, type: Boolean } })
  studentsViews: { delete: boolean; read: boolean; write: boolean; canApprove: boolean };

  @field(roleFields)
  subCategories: { delete: boolean; read: boolean; write: boolean };

  @field({
    ...roleFields,
    allSelected: {
      default: false,
      type: Boolean
    },
    exceptions: [
      {
        ref: 'SubDomain',
        type: Types.ObjectId
      }
    ],
    exceptionDepartments: [
      {
        type: String
      }
    ],
    hasException: {
      default: false,
      type: Boolean
    },
    selected: [
      {
        ref: 'SubDomain',
        type: Types.ObjectId
      }
    ]
  })
  subDomains: {
    allSelected: boolean;
    exceptions: any[];
    exceptionDepartments: string[];
    hasException: boolean;
    read: boolean;
    selected: any[];
    write: boolean;
  };

  @field(roleFields)
  subjects: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  supports: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  teachers: { delete: boolean; read: boolean; write: boolean };

  @field(roleFields)
  templates: { delete: boolean; read: boolean; write: boolean };

  @field({ required: true, type: String })
  title: string;

  @field(roleFields)
  trivias: { delete: boolean; read: boolean; write: boolean };

  @field({ ...roleFields, lock: { default: false, type: Boolean }, selfCreated: { default: false, type: Boolean } })
  universityExam: { delete: boolean; lock: boolean; read: boolean; selfCreated: boolean; write: boolean };

  @field(roleFields)
  webinars: { delete: boolean; read: boolean; write: boolean };

  @field({
    ref: 'University',
    required: true,
    type: Types.ObjectId
  })
  university: any;

  @field({
    default: new Date(),
    type: Date
  })
  createdAt: Date;

  @field({
    default: new Date(),
    type: Date
  })
  updatedAt: Date;

  public async createCondition(university: any) {
    const condition: any = {};

    if (!this.domains.read) {
      return condition;
    }

    if (this.domains.selected && this.domains.selected.length > 0) {
      condition.$in = this.domains.selected;
    }

    if (this.domains.allSelected) {
      if (condition.$in) {
        delete condition.$in;
      }

      condition.$exists = true;
    }

    if (this.domains.hasException && this.domains.exceptions.length > 0) {
      condition.$nin = this.domains.exceptions;
    }

    if (
      university.hasDomainDepartment &&
      this.domains.hasException &&
      this.domains.exceptionDepartments &&
      this.domains.exceptionDepartments.length > 0
    ) {
      condition.$nin = await domainRepository
        .distinct('_id', {
          department: { $in: this.domains.exceptionDepartments },
          university
        })
        .lean();

      if (this.domains.exceptionDepartments.map((entry) => entry.toLowerCase()).indexOf('exam') === -1) {
        if (!condition.$in) {
          condition.$in = [];
        }

        condition.$in.push(
          ...(await domainRepository
            .distinct('_id', {
              department: 'Exam',
              university
            })
            .lean())
        );
      }

      if (this.domains.exceptionDepartments.map((entry) => entry.toLowerCase()).indexOf('lms') === -1) {
        if (!condition.$in) {
          condition.$in = [];
        }

        condition.$in.push(...(await domainRepository.distinct('_id', { department: 'LMS', university }).lean()));
      }
    }
    return condition;
  }

  public async createSubDomainCondition() {
    const condition: any = {};

    if (!this.subDomains) {
      return condition;
    }

    if (!this.subDomains.read) {
      return condition;
    }

    if (this.subDomains.selected && this.subDomains.selected.length > 0) {
      condition.$in = this.subDomains.selected;
    }

    if (this.subDomains.allSelected) {
      if (condition.$in) {
        delete condition.$in;
      }
    }

    if (this.subDomains.hasException && this.subDomains.exceptions.length > 0) {
      condition.$nin = this.subDomains.exceptions;
    }

    return condition;
  }
}
