export const RoleMatching = {
    'ApplicantRepository': 'applicants',
    'AssignmentRepository': 'assignments',
    'DomainRepository': 'domains',
    'ClassRepository': 'classes',
    'CourseRepository': 'courses',
    'EventRepository': 'events',
    'ExamRepository': 'exams',
    'PaymentGatewayRepository': 'gateways',
    'PaymentRepository': 'payments',
    'LiveClassRoomRepository': 'sessions',
    'SubjectRepository': 'subjects',
    'TriviaRepository': 'trivias',
    'ProgramRepository': 'programs',
    'UniversityRepository': 'university'
};
