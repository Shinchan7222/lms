import { Delete, Get, JsonController, Param, Post, Put, Req, Res, UseAfter, UseBefore } from 'routing-controllers';
import { FinishRequest, StartRequest } from '@edorer/performance-tools';
import { GetUniversity } from '@edorer/university-data';
import { IsAuthenticated, UserTypes } from '@edorer/user-data';
import { ListFacade, UpdateFacade } from '@edorer/generic-facades';
import { roleRepository } from '@edorer/role-data';
import { Validate } from '@edorer/validator';

/**
 * @description CRUD controller for Roles
 */
@JsonController()
export class RoleCrudController {
  /**
   * @param req
   * @param res
   * @description Creates a role with the given inputs
   */
  @Post('/roles')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async create(@Req() req: any, @Res() res: any) {
    try {
      const role = await roleRepository.create({ ...req.body, university: req.university });

      return res.status(201).send(role);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @description Finds roles with the given queries
   */
  @Get('/roles')
  @Validate([
    {
      field: 'limit',
      validation: [{ value: 'notEmpty', message: 'limit is required' }]
    },
    {
      field: 'skip',
      validation: [{ value: 'notEmpty', message: 'skip is required' }]
    },
    'action',
    'keyword'
  ])
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async find(@Req() req: any, @Res() res: any) {
    try {
      if (req.user.type === UserTypes.STUDENT) {
        throw new Error('You are not allowed to access this route');
      }
      const { keyword, limit, skip } = req.query;

      const facade = new ListFacade(req.user, req.university, +skip, +limit, keyword, ['title'], roleRepository);
      if (req.query.action && req.query.action === 'DELETE') {
        facade.query = roleRepository.destroy(facade.condition, req.user._id);
        await facade.create();
      }

      facade.prepareQuery();
      const result = await facade.create();

      return res.status(200).send(result);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param roleId
   * @description Finds a role with the given ID
   */
  @Get('/roles/:roleId([0-9a-f]{24})')
  @Validate([
    {
      field: 'roleId',
      validation: [{ value: 'notEmpty', message: 'Role ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async findOne(@Req() req: any, @Res() res: any, @Param('roleId') roleId: string) {
    try {
      const domain = await roleRepository.findOne({ _id: roleId }).populate({ path: 'university', select: 'examTypes' }).lean();

      return res.status(200).send(domain);
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param roleId
   * @description Updates a role with the given changes
   */
  @Put('/roles/:roleId([0-9a-f]{24})')
  @UseBefore(GetUniversity)
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async update(@Req() req: any, @Res() res: any, @Param('roleId') roleId: string) {
    try {
      const fields = [
        'admins',
        'admissionCategories',
        'admissionQuotas',
        'admissions',
        'admissionToLms',
        'analytics',
        'applicantGroups',
        'applicants',
        'approvedDebToLms',
        'assignments',
        'bannedStudents',
        'booksets',
        'booksetTracks',
        'categories',
        'classes',
        'contentBuilders',
        'courses',
        'crmToLms',
        'debAdmissions',
        'debStudentProfiles',
        'debToLms',
        'domains',
        'dynamicForms',
        'events',
        'exams',
        'externalMarkEntries',
        'externalMarkGrades',
        'externalMarkHeads',
        'externalMarkMatrices',
        'externalMarks',
        'feeCategories',
        'feeHeads',
        'feeManagement',
        'feePlans',
        'flows',
        'forums',
        'internalAdmitCards',
        'internalMarkEntries',
        'internalMarkGrades',
        'internalMarkHeads',
        'internalMarkHeadNames',
        'internalMarkHeadSessions',
        'internalMarkMatrices',
        'internalMarks',
        'interviews',
        'leads',
        'logs',
        'openBooks',
        'pages',
        'paymentGateways',
        'paymentRequests',
        'payments',
        'paymentTransactions',
        'plugins',
        'programResults',
        'programs',
        'reassesments',
        'referrals',
        'requests',
        'roles',
        'sales',
        'schedules',
        'sessions',
        'studentEnrollments',
        'studentPayments',
        'students',
        'studentsViews',
        'studentViews',
        'subCategories',
        'subDomains',
        'subjects',
        'supports',
        'teachers',
        'templates',
        'title',
        'trivias',
        'vivaMarks',
        'vivaMarkEntries',
        'vivaMarkHeadNames',
        'vivaMarkHeads',
        'vivaMarkHeadSessions',
        'webinars'
      ];

      for (let examType of req.university.examTypes) {
        fields.push(`${examType.toLowerCase()}Exam`);
      }

      const facade = new UpdateFacade(roleId, req.body, fields, roleRepository);
      await facade.create();

      return res.status(201).send({ message: 'ok' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }

  /**
   * @param req
   * @param res
   * @param roleId
   * @description Deletes roles with the given IDs
   */
  @Delete('/roles/:roleId([0-9a-f]{24})')
  @Validate([
    {
      field: 'roleId',
      validation: [{ value: 'notEmpty', message: 'Role ID is required' }]
    }
  ])
  @UseBefore(IsAuthenticated)
  @UseBefore(StartRequest)
  @UseAfter(FinishRequest)
  async delete(@Req() req: any, @Res() res: any, @Param('roleId') roleId: string) {
    try {
      await roleRepository.destroy({ _id: roleId }, req.user._id);
      return res.status(200).send({ message: 'Role deleted successfully' });
    } catch (error: any) {
      console.error(error);
      return res.status(400).send({ error: error.message });
    }
  }
}
