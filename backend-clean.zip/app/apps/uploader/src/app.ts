import { PoolApplication } from '@edorer/pool-app';
import { CronApp } from '@edorer/cron-app';
import { VideoUploaderApp } from '@edorer/video-uploader-app';
import { LectureApp } from "@edorer/lecture-app";
import { UniversityApp } from "@edorer/university-app";
import { UserApp } from "@edorer/user-app";
import { ScriptApp } from "@edorer/script-app";
import { ChapterApp } from "@edorer/chapter-app";
import { CourseApp } from "@edorer/course-app";
import { RoleApp } from "@edorer/role-app";
import { TrackExamApp } from "@edorer/track-exam-app";

require('moment-timezone').tz.setDefault('Etc/UTC');

class Application extends PoolApplication {

    port = parseInt(process.env.UPLOADER_PORT || '5050', 10);

    constructor() {
        super();
        this.libs.push(...[
            new ScriptApp(),
            new UserApp(),
            new LectureApp(),
            new ChapterApp(),
            new CourseApp(),
            new UniversityApp(),
            new CronApp(),
            new VideoUploaderApp(),
            new RoleApp(),
            new TrackExamApp()
        ]);
        setTimeout(async () => {
            await this.init();
        }, 500);
    }
}

export let application = new Application();
