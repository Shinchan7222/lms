# edorer

This application was generated with [Nx](https://nx.dev).

## Building

Run `nx build edorer` to build the application.

## Starting

Run `nx start edorer` to start/run the application.



## Running unit tests

Run `nx test edorer` to execute the unit tests via [Jest](https://jestjs.io).


