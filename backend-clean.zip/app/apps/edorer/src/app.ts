import 'reflect-metadata';

import { ActivityApp } from '@edorer/activity-app';
import { AdmissionCategoryApp } from '@edorer/admission-category-app';
import { AdmissionQuotaApp } from '@edorer/admission-quota-app';
import { AdmissionToLmsApp } from '@edorer/admission-to-lms-app';
import { AnalyticsApp } from '@edorer/analytics-app';
import { ApplicantApp } from '@edorer/applicant-app';
import { ApplicantGroupApp } from '@edorer/applicant-group-app';
import { AssetsApp } from '@edorer/assets-app';
import { AssignmentApp } from '@edorer/assignment-app';
import { AssignmentReportApp } from '@edorer/assignment-report-app';
import { AssignmentSubmissionApp } from '@edorer/assignment-submission-app';
import { AttendanceApp } from '@edorer/attendance-app';
import { BannedUserApp } from '@edorer/banned-user-app';
import { BooksetApp } from '@edorer/bookset-app';
import { BooksetTrackApp } from '@edorer/bookset-track-app';
import { BroadCastApp } from '@edorer/broadcast-app';
import { CategoryApp } from '@edorer/category-app';
import { ChapterApp } from '@edorer/chapter-app';
import { ChatApp } from '@edorer/chat-app';
import { ClassApp } from '@edorer/class-app';
import { ClassroomApp } from '@edorer/classroom-app';
import { ClassroomPeopleApp } from '@edorer/classroom-people-app';
import { ClassroomPollAnswerApp } from '@edorer/classroom-poll-answer-app';
import { ClassroomStreamApp } from '@edorer/classroom-stream-app';
import { ClassroomStreamCommentApp } from '@edorer/classroom-stream-comment-app';
import { ClassroomTopicApp } from '@edorer/classroom-topic-app';
import { ClassroomTopicTemplateApp } from '@edorer/classroom-topic-template-app';
import { ClassroomWorkApp } from '@edorer/classroom-work-app';
import { ContentBuilderApp } from '@edorer/content-builder-app';
import { CouponApp } from '@edorer/coupon-app';
import { CouponTrackApp } from '@edorer/coupon-track-app';
import { CourseApp } from '@edorer/course-app';
import { CourseProgramApp } from '@edorer/course-program-app';
import { CourseReportApp } from '@edorer/course-report-app';
import { CourseReviewApp } from '@edorer/course-review-app';
import { CredXCourseApp } from '@edorer/credx-course-app';
import { CredXCourseRequestApp } from '@edorer/credx-course-request-app';
import { CrmToLmsApp } from '@edorer/crm-to-lms-app';
import { CronApp } from '@edorer/cron-app';
import { DebStudentProfileApp } from '@edorer/deb-student-profile-app';
import { DebToLmsApp } from '@edorer/deb-to-lms-app';
import { DomainApp } from '@edorer/domain-app';
import { DynamicFormApp } from '@edorer/dynamic-form-app';
import { DynamicFormReportApp } from '@edorer/dynamic-form-report-app';
import { ExamApp } from '@edorer/exam-app';
import { ExamCommonAccessApp } from '@edorer/exam-common-access-app';
import { ExamEnrollmentApp } from '@edorer/exam-enrollment-app';
import { ExamFaqApp } from '@edorer/exam-faq-app';
import { ExamGuideApp } from '@edorer/exam-guide-app';
import { ExamIssueApp } from '@edorer/exam-issue-app';
import { ExamRegistrationApp } from '@edorer/exam-registration-app';
import { ExamRegistrationEnrollmentApp } from '@edorer/exam-registration-enrollment-app';
import { ExamRegistrationSubmissionApp } from '@edorer/exam-registration-submission-app';
import { ExamReportApp } from '@edorer/exam-report-app';
import { ExamScheduleApp } from '@edorer/exam-schedule-app';
import { ExternalMarkEntryApp } from '@edorer/external-mark-entry-app';
import { ExternalMarkGradeApp } from '@edorer/external-mark-grade-app';
import { ExternalMarkHeadApp } from '@edorer/external-mark-head-app';
import { ExternalMarkHeadNameApp } from '@edorer/external-mark-head-name-app';
import { ExternalMarkHeadSessionApp } from '@edorer/external-mark-head-session-app';
import { ExternalMarkMatrixApp } from '@edorer/external-mark-matrix-app';
import { FavouriteCourseApp } from '@edorer/favourite-course-app';
import { FeeCategoryApp } from '@edorer/fee-category-app';
import { FeeHeadApp } from '@edorer/fee-head-app';
import { FeePlanApp } from '@edorer/fee-plan-app';
import { FlowApp } from '@edorer/flow-app';
import { FlowReportApp } from '@edorer/flow-report-app';
import { GroupQuestionApp } from '@edorer/group-question-app';
import { HtmlTemplateApp } from '@edorer/html-template-app';
import { InquiryApp } from '@edorer/inquiry-app';
import { InternalAdmitCardApp } from '@edorer/internal-admit-card-app';
import { InternalMarkEntryApp } from '@edorer/internal-mark-entry-app';
import { InternalMarkGradeApp } from '@edorer/internal-mark-grade-app';
import { InternalMarkHeadApp } from '@edorer/internal-mark-head-app';
import { VivaMarkHeadApp } from '@edorer/viva-mark-head-app';
import { VivaMarkHeadNameApp } from '@edorer/viva-mark-head-name-app';
import { VivaMarkHeadSessionApp } from '@edorer/viva-mark-head-session-app';
import { InternalMarkHeadNameApp } from '@edorer/internal-mark-head-name-app';
import { InternalMarkHeadSessionApp } from '@edorer/internal-mark-head-session-app';
import { InternalMarkMatrixApp } from '@edorer/internal-mark-matrix-app';
import { InterviewApp } from '@edorer/interview-app';
import { LeadApp } from '@edorer/lead-app';
import { LectureApp } from '@edorer/lecture-app';
import { LiveClassRoomApp } from '@edorer/live-class-room-app';
import { LocationApp } from '@edorer/location-app';
import { LogApp } from '@edorer/log-app';
import { MediaApp } from '@edorer/media-app';
import { MeetingApp } from '@edorer/meeting-app';
import { MessageApp } from '@edorer/message-app';
import { ModifiedAnswerApp } from '@edorer/modified-answer-app';
import { NoteApp } from '@edorer/note-app';
import { NoticeApp } from '@edorer/notice-app';
import { NotificationApp } from '@edorer/notification-app';
import { NotificationConfigurationApp } from '@edorer/notification-configuration-app';
import { OnBoardingApp } from '@edorer/on-boarding-app';
import { OnBoardingTrackApp } from '@edorer/on-boarding-track-app';
import { OpenBookApp } from '@edorer/open-book-app';
import { OtpApp } from '@edorer/otp-app';
import { PageBuilderApp } from '@edorer/page-builder-app';
import { PageNoticeApp } from '@edorer/page-notice-app';
import { PaymentAnalyticsApp } from '@edorer/payment-analytics-app';
import { PaymentApp } from '@edorer/payment-app';
import { PaymentFeeApp } from '@edorer/payment-fee-app';
import { PaymentFeeHeadApp } from '@edorer/payment-fee-head-app';
import { PaymentFeePlanApp } from '@edorer/payment-fee-plan-app';
import { PaymentGatewayApp } from '@edorer/payment-gateway-app';
import { PaymentInvoiceApp } from '@edorer/payment-invoice-app';
import { PaymentReceiptApp } from '@edorer/payment-receipt-app';
import { PaymentRefundApp } from '@edorer/payment-refund-app';
import { PaymentRequestApp } from '@edorer/payment-request-app';
import { PaymentTransactionApp } from '@edorer/payment-transaction-app';
import { PendingStudentApp } from '@edorer/pending-student-app';
import { PluginApp } from '@edorer/plugin-app';
import { PoolApplication } from '@edorer/pool-app';
import { ProctorRequestApp } from '@edorer/proctor-request-app';
import { ProgramApp } from '@edorer/program-app';
import { ProgramCurriculumApp } from '@edorer/program-curriculum-app';
import { ProgramFeesApp } from '@edorer/program-fees-app';
import { ProgramReportApp } from '@edorer/program-report-app';
import { ProgramResultApp } from '@edorer/program-result-app';
import { ProvisionalResultApp } from '@edorer/provisional-result-app';
import { QuestionApp } from '@edorer/question-app';
import { ReferralApp } from '@edorer/referral-app';
import { ReviewRequestApp } from '@edorer/review-request-app';
import { RoleApp } from '@edorer/role-app';
import { ScheduleApp } from '@edorer/schedule-app';
import { ScheduleTrackApp } from '@edorer/schedule-track-app';
import { ScriptApp } from '@edorer/script-app';
import { SessionApp } from '@edorer/session-app';
import { StreamApp } from '@edorer/stream-app';
import { StudentApp } from '@edorer/student-app';
import { StudentEnrollmentApp } from '@edorer/student-enrollment-app';
import { StudentFeeApp } from '@edorer/student-fee-app';
import { SubCategoryApp } from '@edorer/sub-category-app';
import { SubDomainApp } from '@edorer/sub-domain-app';
import { SubjectApp } from '@edorer/subject-app';
import { SubmissionApp } from '@edorer/submission-app';
import { SupportApp } from '@edorer/support-app';
import { TeacherApp } from '@edorer/teacher-app';
import { TemplateApp } from '@edorer/template-app';
import { TicketCategoryApp } from '@edorer/ticket-category-app';
import { TicketSubCategoryApp } from '@edorer/ticket-sub-category-app';
import { TimeTableApp } from '@edorer/time-table-app';
import { TmpUploadsApp } from '@edorer/tmp-uploads-app';
import { TokenApp } from '@edorer/token-app';
import { TrackAssignmentApp } from '@edorer/track-assignment-app';
import { TrackCourseApp } from '@edorer/track-course-app';
import { TrackCourseLogApp } from '@edorer/track-course-log-app';
import { TrackExamApp } from '@edorer/track-exam-app';
import { TrackProctorApp } from '@edorer/track-proctor-app';
import { TrackFlowApp } from '@edorer/track-flow-app';
import { TrackFormApp } from '@edorer/track-form-app';
import { TrackInterviewApp } from '@edorer/track-interview-app';
import { TrackLiveClassRoomApp } from '@edorer/track-live-class-room-app';
import { TrackProgramApp } from '@edorer/track-program-app';
import { TrackVideoSessionApp } from '@edorer/track-video-session-app';
import { TrackWebinarApp } from '@edorer/track-webinar-app';
import { TriviaAnswerApp } from '@edorer/trivia-answer-app';
import { TriviaApp } from '@edorer/trivia-app';
import { TriviaReportApp } from '@edorer/trivia-report-app';
import { UniversityApp } from '@edorer/university-app';
import { UserApp } from '@edorer/user-app';
import { UserDynamicApp } from '@edorer/user-dynamic-app';
import { VivaMarkEntryApp } from '@edorer/viva-mark-entry-app';
import { VideoSessionApp } from '@edorer/video-session-app';
import { VideoUploaderApp } from '@edorer/video-uploader-app';
import { WebinarApp } from '@edorer/webinar-app';
import { Nems } from '@edorer/nems';

require('moment-timezone').tz.setDefault('Etc/UTC');

class Application extends PoolApplication {
  port = parseInt(process.env.PORT || '5000', 10);

  constructor() {
    super();
    this.libs.push(
      ...[
        // new ExamPermissionApp(),
        new ActivityApp(),
        new AdmissionCategoryApp(),
        new AdmissionQuotaApp(),
        new AdmissionToLmsApp(),
        new AnalyticsApp(),
        new ApplicantApp(),
        new ApplicantGroupApp(),
        new AssetsApp(),
        new AssignmentApp(),
        new AssignmentReportApp(),
        new AssignmentSubmissionApp(),
        new AttendanceApp(),
        new BannedUserApp(),
        new BooksetApp(),
        new BooksetTrackApp(),
        new BroadCastApp(),
        new CategoryApp(),
        new ChapterApp(),
        new ChatApp(),
        new ClassApp(),
        new ClassroomApp(),
        new ClassroomPeopleApp(),
        new ClassroomPollAnswerApp(),
        new ClassroomStreamApp(),
        new ClassroomStreamCommentApp(),
        new ClassroomTopicApp(),
        new ClassroomTopicTemplateApp(),
        new ClassroomWorkApp(),
        new ContentBuilderApp(),
        new CouponApp(),
        new CouponTrackApp(),
        new CourseApp(),
        new CourseProgramApp(),
        new CourseReportApp(),
        new CourseReviewApp(),
        new CredXCourseApp(),
        new CredXCourseRequestApp(),
        new CrmToLmsApp(),
        new CronApp(),
        new DebStudentProfileApp(),
        new DebToLmsApp(),
        new DomainApp(),
        new DynamicFormApp(),
        new DynamicFormReportApp(),
        new ExamApp(),
        new ExamCommonAccessApp(),
        new ExamEnrollmentApp(),
        new ExamFaqApp(),
        new ExamGuideApp(),
        new ExamIssueApp(),
        new ExamRegistrationApp(),
        new ExamRegistrationEnrollmentApp(),
        new ExamRegistrationSubmissionApp(),
        new ExamReportApp(),
        new ExamScheduleApp(),
        new ExternalMarkEntryApp(),
        new ExternalMarkGradeApp(),
        new ExternalMarkHeadApp(),
        new ExternalMarkHeadNameApp(),
        new ExternalMarkHeadSessionApp(),
        new ExternalMarkMatrixApp(),
        new FavouriteCourseApp(),
        new FeeCategoryApp(),
        new FeeHeadApp(),
        new FeePlanApp(),
        new FlowApp(),
        new FlowReportApp(),
        new GroupQuestionApp(),
        new HtmlTemplateApp(),
        new InquiryApp(),
        new InternalAdmitCardApp(),
        new InternalMarkEntryApp(),
        new InternalMarkGradeApp(),
        new InternalMarkHeadApp(),
        new VivaMarkHeadApp(),
        new VivaMarkHeadNameApp(),
        new VivaMarkHeadSessionApp(),
        new InternalMarkHeadNameApp(),
        new InternalMarkHeadSessionApp(),
        new InternalMarkMatrixApp(),
        new InterviewApp(),
        new LeadApp(),
        new LectureApp(),
        new LiveClassRoomApp(),
        new LocationApp(),
        new LogApp(),
        new MediaApp(),
        new MeetingApp(),
        new MessageApp(),
        new ModifiedAnswerApp(),
        new NoteApp(),
        new NoticeApp(),
        new NotificationApp(),
        new NotificationConfigurationApp(),
        new OnBoardingApp(),
        new OnBoardingTrackApp(),
        new OpenBookApp(),
        new OtpApp(),
        new PageBuilderApp(),
        new PageBuilderApp(),
        new PageNoticeApp(),
        new PaymentAnalyticsApp(),
        new PaymentApp(),
        new PaymentFeeApp(),
        new PaymentFeeHeadApp(),
        new PaymentFeePlanApp(),
        new PaymentGatewayApp(),
        new PaymentInvoiceApp(),
        new PaymentReceiptApp(),
        new PaymentRefundApp(),
        new PaymentRequestApp(),
        new PaymentTransactionApp(),
        new PendingStudentApp(),
        new PluginApp(),
        new ProctorRequestApp(),
        new ProgramApp(),
        new ProgramCurriculumApp(),
        new ProgramFeesApp(),
        new ProgramReportApp(),
        new ProgramResultApp(),
        new ProvisionalResultApp(),
        new QuestionApp(),
        new ReferralApp(),
        new ReviewRequestApp(),
        new RoleApp(),
        new ScheduleApp(),
        new ScheduleTrackApp(),
        new ScriptApp(),
        new SessionApp(),
        new StreamApp(),
        new StudentApp(),
        new StudentEnrollmentApp(),
        new StudentFeeApp(),
        new SubCategoryApp(),
        new SubDomainApp(),
        new SubjectApp(),
        new SubmissionApp(),
        new SupportApp(),
        new SupportApp(),
        new TeacherApp(),
        new TemplateApp(),
        new TicketCategoryApp(),
        new TicketSubCategoryApp(),
        new TimeTableApp(),
        new TmpUploadsApp(),
        new TokenApp(),
        new TrackAssignmentApp(),
        new TrackCourseApp(),
        new TrackCourseLogApp(),
        new TrackExamApp(),
        new TrackProctorApp(),
        new TrackFlowApp(),
        new TrackFormApp(),
        new TrackInterviewApp(),
        new TrackLiveClassRoomApp(),
        new TrackProgramApp(),
        new TrackVideoSessionApp(),
        new TrackWebinarApp(),
        new TriviaAnswerApp(),
        new TriviaApp(),
        new TriviaReportApp(),
        new UniversityApp(),
        new UserApp(),
        new UserDynamicApp(),
        new VivaMarkEntryApp(),
        new VideoSessionApp(),
        new VideoUploaderApp(true),
        new WebinarApp()
      ]
    );
    setTimeout(async () => {
      await this.init();
    }, 500);

    process.on('SIGTERM', async () => {
      console.log('SIGTERM received...');
      process.exit(0);
    });

    process.on('SIGINT', async () => {
      console.log('SIGINT received...');
      process.exit(0);
    });
  }
}

export let application = new Application();
