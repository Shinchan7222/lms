#!/usr/bin/env node
/*
 * Asset inventory per university.
 *
 * Usage:
 *   DATABASE="mongodb://user:pass@host:27017/edorer" node tools/audit-assets.js
 *
 * Flags:
 *   --json=<path>        Also write the full report as JSON
 *   --skip=coll1,coll2   Additional collections to skip
 *   --only=coll1,coll2   Only scan these collections (debug)
 *   --limit=N            Cap docs scanned per collection (debug)
 *   --university=<id>    Restrict to one university ObjectId
 *
 * What it counts, per university:
 *   - For every collection in the DB, number of docs that reference any
 *     GCS storage URL (http(s)://storage.googleapis.com/<bucket>/... or
 *     <bucket>.storage.googleapis.com/...), plus baseUrl+bucket prefixes
 *     inferred from UniversityConfiguration.
 *   - Breakdown by bucket.
 *   - Proctoring (TrackProctorAsset) is scanned separately and never merged
 *     into the regular totals.
 *
 * Definition of "functioning" used here: document exists in the DB (we don't
 * check whether the GCS object is reachable — that's a separate pass).
 */

const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;
const fs = require('fs');
const path = require('path');

// ---------- args ----------
const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, v] = a.replace(/^--/, '').split('=');
    return [k, v ?? true];
  })
);

const URI = process.env.DATABASE;
if (!URI) {
  console.error('DATABASE env var is required, e.g.:');
  console.error('  DATABASE="mongodb://user:pass@host:27017/edorer" node tools/audit-assets.js');
  process.exit(1);
}

const LIMIT = args.limit ? Number(args.limit) : Infinity;
const ONLY = args.only ? new Set(args.only.split(',')) : null;
const ONE_UNI = args.university ? String(args.university) : null;

// System / noise collections we don't need to scan.
const DEFAULT_SKIP = new Set([
  'sessions',
  'tokens',
  'logs',
  'auditlogs',
  'notifications',
  'notificationlogs',
  'activities',
  'activitylogs',
  'migrations',
  'changelogs',
  'crons',
  'queues',
  'jobs',
  'events',
  'chatmessages', // URLs here are possible but mostly user chat noise; re-enable if you want
  'performancelogs', // confirmed noise: 1.5M+ rows, 0 URLs
  'performancetools',
  'errorlogs',
  'accesslogs',
  'examtimelogs',
  'trackcourselogs', // confirmed noise: 1M+ rows, 0 URLs
  'trackanalyticslogs',
  'tracksubmissionlogs',
  'useractivitylogs',
  'logins',
  'loginhistories',
]);
// Regex-based skip for any name matching a log/history/audit suffix.
function isNoiseCollection(name) {
  return /(logs?|histor(y|ies)|audits?|telemetry|metrics)$/i.test(name);
}
if (args.skip) {
  for (const s of String(args.skip).split(',')) DEFAULT_SKIP.add(s);
}

// ---------- URL / bucket detection ----------
// Matches:
//   https://storage.googleapis.com/<bucket>/...
//   https://storage.cloud.google.com/<bucket>/...
//   https://<bucket>.storage.googleapis.com/...
//   gs://<bucket>/...
const GCS_REGEX =
  /\b(?:https?:\/\/storage\.(?:googleapis|cloud\.google)\.com\/([a-z0-9][-a-z0-9._]{1,61}[a-z0-9])|https?:\/\/([a-z0-9][-a-z0-9._]{1,61}[a-z0-9])\.storage\.googleapis\.com|gs:\/\/([a-z0-9][-a-z0-9._]{1,61}[a-z0-9]))\b/gi;

// baseUrl + bucketName prefixes loaded from UniversityConfiguration (handles
// tenants that serve through a custom CDN domain).
let CUSTOM_PREFIXES = []; // [{prefix, bucket}]

function extractBuckets(value, out) {
  if (value == null) return;
  const t = typeof value;
  if (t === 'string') {
    if (value.length < 12) return;
    let m;
    GCS_REGEX.lastIndex = 0;
    while ((m = GCS_REGEX.exec(value)) !== null) {
      const b = m[1] || m[2] || m[3];
      if (b) out.add(b);
    }
    for (const { prefix, bucket } of CUSTOM_PREFIXES) {
      if (value.includes(prefix)) out.add(bucket);
    }
    return;
  }
  if (t !== 'object') return;
  if (Array.isArray(value)) {
    for (const v of value) extractBuckets(v, out);
    return;
  }
  // Mongo ObjectId / Date / Buffer: skip
  if (value._bsontype || value instanceof Date || Buffer.isBuffer(value)) return;
  for (const k of Object.keys(value)) extractBuckets(value[k], out);
}

function bucketsIn(doc) {
  const set = new Set();
  extractBuckets(doc, set);
  return set;
}

// ---------- main ----------
async function main() {
  await mongoose.connect(URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    maxPoolSize: 10,
    socketTimeoutMS: 0, // disable socket timeout so long cursors survive
    serverSelectionTimeoutMS: 30000,
    heartbeatFrequencyMS: 10000,
  });
  const db = mongoose.connection.db;
  const dbName = db.databaseName;

  console.error(`[info] Connected to ${dbName}`);

  // Discover "university" collection name (case varies by Mongoose pluralization).
  const allColls = (await db.listCollections({}, { nameOnly: true }).toArray()).map((c) => c.name).sort();
  const uniCollName = allColls.find((n) => /^universities?$/i.test(n)) || 'universities';
  const configCollName =
    allColls.find((n) => /^universityconfigurations?$/i.test(n)) || 'universityconfigurations';
  const examCollName = allColls.find((n) => /^exams?$/i.test(n)) || 'exams';
  const tpCollName = allColls.find((n) => /^trackproctors?$/i.test(n));
  const tpAssetCollName = allColls.find((n) => /^trackproctorassets?$/i.test(n));

  // Load universities.
  const universities = await db
    .collection(uniCollName)
    .find({}, { projection: { name: 1, url: 1, isParul: 1, isParulLMS: 1 } })
    .toArray();
  const uniMap = new Map(universities.map((u) => [String(u._id), u]));
  console.error(`[info] Universities: ${universities.length}`);

  // Load bucket configs.
  const configs = await db.collection(configCollName).find({}).toArray();
  const uniBuckets = new Map(); // uniId -> Set(bucketNames)
  const prefixSet = new Map();
  for (const c of configs) {
    const uid = String(c.university || '');
    if (!uid) continue;
    if (!uniBuckets.has(uid)) uniBuckets.set(uid, new Set());
    for (const k of ['LMS_COURSE_VIDEOS', 'ASSETS', 'BACKUP_BUCKET']) {
      const b = c?.buckets?.[k];
      if (b?.name) {
        uniBuckets.get(uid).add(b.name);
        if (b.baseUrl) {
          // Matches how S3University.upload() builds URLs: baseUrl + name + '/' + file.
          const prefix = b.baseUrl + b.name + '/';
          prefixSet.set(prefix, b.name);
        }
      }
    }
  }
  CUSTOM_PREFIXES = Array.from(prefixSet.entries()).map(([prefix, bucket]) => ({ prefix, bucket }));
  console.error(`[info] Configs: ${configs.length}, custom baseUrl prefixes: ${CUSTOM_PREFIXES.length}`);

  // Pick which collections to scan.
  const scanColls = allColls
    .filter((n) => !n.startsWith('system.'))
    .filter((n) => !DEFAULT_SKIP.has(n))
    .filter((n) => !isNoiseCollection(n))
    .filter((n) => n !== tpAssetCollName) // handle proctoring separately
    .filter((n) => !ONLY || ONLY.has(n));
  const skipped = allColls.filter((n) => !scanColls.includes(n) && n !== tpAssetCollName && !n.startsWith('system.'));
  if (skipped.length) console.error(`[info] Skipping ${skipped.length} noise collections: ${skipped.join(', ')}`);

  // counters: uniId -> { collName -> { docsWithAssets, bucketCounts } }
  const counters = new Map();
  function bump(uniId, coll, buckets) {
    if (!counters.has(uniId)) counters.set(uniId, {});
    const c = counters.get(uniId);
    if (!c[coll]) c[coll] = { docsWithAssets: 0, bucketCounts: {} };
    c[coll].docsWithAssets++;
    for (const b of buckets) c[coll].bucketCounts[b] = (c[coll].bucketCounts[b] || 0) + 1;
  }

  const started = Date.now();
  // ---- scan regular collections ----
  for (const coll of scanColls) {
    const filter = ONE_UNI ? { university: safeOid(ONE_UNI) } : {};
    // If the collection has no 'university' field the filter won't match. Probe first.
    let effectiveFilter = filter;
    if (ONE_UNI) {
      const probe = await db.collection(coll).findOne({ university: { $exists: true } }, { projection: { _id: 1 } });
      if (!probe) effectiveFilter = {}; // scan all; tag as unknown
    }
    const cursor = db.collection(coll).find(effectiveFilter, { batchSize: 500 });
    let n = 0, matched = 0;
    const t0 = Date.now();
    for await (const doc of cursor) {
      n++;
      if (n > LIMIT) break;
      const buckets = bucketsIn(doc);
      if (buckets.size > 0) {
        matched++;
        const uniId = doc.university ? String(doc.university) : 'unknown';
        bump(uniId, coll, buckets);
      }
      if (n % 50000 === 0) {
        process.stderr.write(`  [${coll}] ${n} scanned, ${matched} with assets\n`);
      }
    }
    const secs = ((Date.now() - t0) / 1000).toFixed(1);
    console.error(`[scan] ${coll.padEnd(40)} ${String(n).padStart(9)} docs  ${String(matched).padStart(8)} with assets  (${secs}s)`);
  }

  // ---- scan proctoring separately ----
  let proctoring = null;
  if (tpAssetCollName && tpCollName) {
    console.error(`[scan] ${tpAssetCollName} (via ${tpCollName} join)...`);
    const examUni = new Map();
    for (const e of await db
      .collection(examCollName)
      .find({}, { projection: { _id: 1, university: 1 } })
      .toArray()) {
      examUni.set(String(e._id), e.university ? String(e.university) : 'unknown');
    }
    const tpMap = new Map();
    {
      const cursor = db.collection(tpCollName).find({}, { projection: { _id: 1, university: 1, exam: 1 } });
      for await (const tp of cursor) {
        let uid = tp.university ? String(tp.university) : null;
        if (!uid && tp.exam) uid = examUni.get(String(tp.exam)) || null;
        tpMap.set(String(tp._id), uid || 'unknown');
      }
    }
    console.error(`  [proctor] loaded ${tpMap.size} TrackProctor rows`);

    proctoring = new Map(); // uniId -> { rows, withUrl, bucketCounts }
    const cursor = db.collection(tpAssetCollName).find({}, { batchSize: 1000 });
    let n = 0, matched = 0;
    for await (const doc of cursor) {
      n++;
      if (n > LIMIT) break;
      const uniId = tpMap.get(String(doc.trackProctor)) || 'unknown';
      if (!proctoring.has(uniId)) proctoring.set(uniId, { rows: 0, withUrl: 0, bucketCounts: {} });
      const p = proctoring.get(uniId);
      p.rows++;
      const buckets = bucketsIn(doc.assetUrl);
      if (buckets.size > 0) {
        matched++;
        p.withUrl++;
        for (const b of buckets) p.bucketCounts[b] = (p.bucketCounts[b] || 0) + 1;
      }
      if (n % 100000 === 0) process.stderr.write(`  [proctor] ${n} scanned, ${matched} with URL\n`);
    }
    console.error(`[scan] ${tpAssetCollName.padEnd(40)} ${String(n).padStart(9)} rows   ${String(matched).padStart(8)} with URL`);
  }

  const totalSecs = ((Date.now() - started) / 1000).toFixed(1);
  console.error(`[done] total scan time: ${totalSecs}s\n`);

  // ---------- emit report ----------
  const report = { database: dbName, scannedAt: new Date().toISOString(), universities: [] };

  const rows = Array.from(counters.entries())
    .map(([uniId, coll]) => {
      const docsTotal = Object.values(coll).reduce((s, v) => s + v.docsWithAssets, 0);
      return { uniId, coll, docsTotal };
    })
    .sort((a, b) => b.docsTotal - a.docsTotal);

  const unseenUniIds = new Set(uniMap.keys());
  for (const row of rows) unseenUniIds.delete(row.uniId);
  if (proctoring) for (const k of proctoring.keys()) unseenUniIds.delete(k);

  console.log(`# Asset inventory — ${dbName}`);
  console.log(`Scanned: ${new Date().toISOString()}`);
  console.log('');

  for (const row of rows) {
    const uni = uniMap.get(row.uniId);
    const name = uni ? `${uni.name}${uni.url ? ` [${uni.url}]` : ''}` : `(unknown uni)`;
    console.log(`\n## ${name}`);
    console.log(`id: ${row.uniId}`);
    const expected = Array.from(uniBuckets.get(row.uniId) || []);
    if (expected.length) console.log(`expected buckets: ${expected.join(', ')}`);

    const collRows = Object.entries(row.coll)
      .map(([coll, v]) => ({
        coll,
        docs: v.docsWithAssets,
        buckets: Object.entries(v.bucketCounts).sort((a, b) => b[1] - a[1]),
      }))
      .sort((a, b) => b.docs - a.docs);

    console.log('\n  regular assets:');
    console.log('  collection                                   docs       bucket breakdown');
    console.log('  ' + '-'.repeat(90));
    for (const r of collRows) {
      const bk = r.buckets.map(([b, c]) => `${b}:${c}`).join(' | ');
      console.log(`  ${r.coll.padEnd(40)} ${String(r.docs).padStart(8)}   ${bk}`);
    }

    const uniReport = {
      id: row.uniId,
      name: uni?.name,
      url: uni?.url,
      expectedBuckets: expected,
      collections: row.coll,
    };

    if (proctoring && proctoring.has(row.uniId)) {
      const p = proctoring.get(row.uniId);
      console.log('\n  proctoring (TrackProctorAsset, SEPARATE):');
      console.log(`    rows: ${p.rows}   with URL: ${p.withUrl}`);
      const bk = Object.entries(p.bucketCounts)
        .sort((a, b) => b[1] - a[1])
        .map(([b, c]) => `${b}:${c}`)
        .join(' | ');
      if (bk) console.log(`    by bucket: ${bk}`);
      uniReport.proctoring = p;
      proctoring.delete(row.uniId);
    }

    report.universities.push(uniReport);
  }

  // Proctoring-only universities (no other assets).
  if (proctoring && proctoring.size > 0) {
    for (const [uniId, p] of proctoring) {
      const uni = uniMap.get(uniId);
      const name = uni ? `${uni.name}${uni.url ? ` [${uni.url}]` : ''}` : '(unknown uni)';
      console.log(`\n## ${name}  (proctoring only)`);
      console.log(`id: ${uniId}`);
      console.log(`  proctoring (TrackProctorAsset, SEPARATE):`);
      console.log(`    rows: ${p.rows}   with URL: ${p.withUrl}`);
      const bk = Object.entries(p.bucketCounts)
        .sort((a, b) => b[1] - a[1])
        .map(([b, c]) => `${b}:${c}`)
        .join(' | ');
      if (bk) console.log(`    by bucket: ${bk}`);
      report.universities.push({ id: uniId, name: uni?.name, url: uni?.url, proctoring: p });
    }
  }

  if (unseenUniIds.size > 0) {
    console.log(`\n## universities with 0 assets found (${unseenUniIds.size}):`);
    for (const id of unseenUniIds) {
      const u = uniMap.get(id);
      console.log(`  - ${u?.name || id} ${u?.url ? `[${u.url}]` : ''}`);
    }
  }

  if (args.json) {
    fs.writeFileSync(path.resolve(String(args.json)), JSON.stringify(report, null, 2));
    console.error(`[info] JSON written to ${args.json}`);
  }

  await mongoose.disconnect();
}

function safeOid(s) {
  try {
    return new ObjectId(s);
  } catch {
    return s;
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
