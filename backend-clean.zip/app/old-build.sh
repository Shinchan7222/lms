rm -rdf node_modules
rm -rdf build
npm i
npm run bprod
rm -rdf node_modules
npm install --only=prod
aws ecr get-login-password --region ap-south-1 | sudo docker login --username AWS --password-stdin 086614993254.dkr.ecr.ap-south-1.amazonaws.com
sudo docker build -t lms .
sudo docker tag lms:latest 086614993254.dkr.ecr.ap-south-1.amazonaws.com/talentgood/lms:latest
sudo docker push 086614993254.dkr.ecr.ap-south-1.amazonaws.com/talentgood/lms:latest
aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin 086614993254.dkr.ecr.ap-south-1.amazonaws.com
docker build -t lms .
docker tag lms:latest 086614993254.dkr.ecr.ap-south-1.amazonaws.com/talentgood/lms:latest
docker push 086614993254.dkr.ecr.ap-south-1.amazonaws.com/talentgood/lms:latest
