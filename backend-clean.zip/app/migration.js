const mongoose = require('mongoose');
const { Storage } = require('@google-cloud/storage');
const axios = require('axios');
const fs = require('fs').promises;
const path = require('path');
const util = require('util');
const stream = require('stream');
const pipeline = util.promisify(stream.pipeline);

// Configure Google Cloud Storage
const storage = new Storage({
  keyFilename: 'path/to/your/google-credentials.json',
  projectId: 'your-project-id'
});

const bucketName = 'your-gcs-bucket-name';
const bucket = storage.bucket(bucketName);

// MongoDB connection
mongoose.connect('mongodb://your-mongodb-connection-string', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Function to check if URL is from S3
function isS3Url(url) {
  return url && url.includes('amazonaws.com');
}

// Function to download file from S3
async function downloadFile(url, localPath) {
  const response = await axios({
    method: 'GET',
    url: url,
    responseType: 'stream'
  });

  await pipeline(response.data, await fs.open(localPath, 'w'));
}

// Function to upload file to Google Cloud Storage
async function uploadToGCS(localPath, destination) {
  await bucket.upload(localPath, {
    destination: destination,
    metadata: {
      cacheControl: 'public, max-age=31536000',
    },
  });

  return `https://storage.googleapis.com/${bucketName}/${destination}`;
}

// Main migration function
async function migrateS3ToGCS() {
  // Get all mongoose models
  const models = mongoose.modelNames();
  
  for (const modelName of models) {
    const Model = mongoose.model(modelName);
    console.log(`Processing model: ${modelName}`);

    // Find all documents
    const documents = await Model.find({});

    for (const doc of documents) {
      try {
        // Convert document to JSON to easily traverse all fields
        const docObj = doc.toObject();
        let modified = false;

        // Recursive function to process nested objects and arrays
        async function processObject(obj) {
          for (const key in obj) {
            if (typeof obj[key] === 'string' && isS3Url(obj[key])) {
              // Found S3 URL
              console.log(`Found S3 URL in ${modelName}/${doc._id}: ${obj[key]}`);
              
              // Generate local and GCS file paths
              const fileName = path.basename(obj[key]);
              const localPath = `/tmp/${fileName}`;
              
              try {
                // Download from S3
                await downloadFile(obj[key], localPath);
                
                // Upload to GCS
                const gcsUrl = await uploadToGCS(localPath, `${modelName}/${doc._id}/${fileName}`);
                
                // Update URL
                obj[key] = gcsUrl;
                modified = true;

                // Clean up local file
                await fs.unlink(localPath);
                
                console.log(`Migrated to: ${gcsUrl}`);
              } catch (error) {
                console.error(`Error processing file ${fileName}:`, error);
              }
            } else if (typeof obj[key] === 'object' && obj[key] !== null) {
              // Recursively process nested objects and arrays
              await processObject(obj[key]);
            }
          }
        }

        await processObject(docObj);

        // Save document if modified
        if (modified) {
          Object.assign(doc, docObj);
          await doc.save();
          console.log(`Saved updated document ${modelName}/${doc._id}`);
        }
      } catch (error) {
        console.error(`Error processing document ${modelName}/${doc._id}:`, error);
      }
    }
  }
}

// Run migration
migrateS3ToGCS()
  .then(() => {
    console.log('Migration completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration failed:', error);
    process.exit(1);
  });