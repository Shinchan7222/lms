#!/usr/bin/env bash
set -euo pipefail
cd ~/lms
BRANCH="master"
DEPLOY_CMD="./build-parul.sh"
# 1. Fetch latest from remote
git fetch origin "$BRANCH"
# 2. Get latest commit hashes
LOCAL_HASH=$(git rev-parse "$BRANCH")
REMOTE_HASH=$(git rev-parse "origin/$BRANCH")

# 3. Check if there are new commits
if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]; then
  echo "🔁 New commit detected on $BRANCH at $(date)"
  git checkout "$BRANCH"
  git pull origin "$BRANCH"

  # 4. Check if commit message contains "parul-staging"
  COMMIT_MSG=$(git log -1 --pretty=%B)
  if echo "$COMMIT_MSG" | grep -q "parul-release"; then
    echo "🚀 parul-release found in commit message, deploying..."
    eval "$DEPLOY_CMD"
  else
    echo "⏭ Commit does not match parul-release tag, skipping deploy."
  fi
else
  echo "✅ No new commit on $BRANCH at $(date)"
fi