#!/bin/bash

# Build and push edorer-with-remotion Docker image to DigitalOcean Container Registry
# Builds for Linux Intel x86-64 architecture (not ARM/Apple Silicon)

set -e  # Exit on error

# Configuration
REGISTRY_NAME="backend"
IMAGE_NAME="edorer-with-remotion"
DOCKERFILE_PATH="./docker/default/edorer-with-remotion/Dockerfile"
DIGITALOCEAN_API_KEY="dop_v1_423b57613729222cc295e6fb3cba663575f9a6b1ab265b4bc7bc9558434eaa34"
REGISTRY_URL="registry.digitalocean.com/silver-oak"

# Generate version tag (date-based)
VERSION=$(date +%Y%m%d-%H%M%S)

# Full image tag
FULL_IMAGE_TAG="${REGISTRY_URL}/${REGISTRY_NAME}/${IMAGE_NAME}:${VERSION}"
LATEST_TAG="${REGISTRY_URL}/${REGISTRY_NAME}/${IMAGE_NAME}:latest"

echo "Building Docker image for Linux Intel x86-64 architecture..."
docker build --platform linux/amd64 -t ${IMAGE_NAME}:${VERSION} -f ${DOCKERFILE_PATH} .

echo "Tagging image..."
docker tag ${IMAGE_NAME}:${VERSION} ${FULL_IMAGE_TAG}
docker tag ${IMAGE_NAME}:${VERSION} ${LATEST_TAG}

echo "Logging into DigitalOcean Container Registry..."
# Verify API key format
if [[ ! ${DIGITALOCEAN_API_KEY} =~ ^dop_v1_ ]]; then
    echo "ERROR: Invalid DigitalOcean API key format. Should start with 'dop_v1_'"
    exit 1
fi

# Login to DigitalOcean Container Registry
# Use API token as both username and password
if ! echo ${DIGITALOCEAN_API_KEY} | docker login ${REGISTRY_URL} -u ${DIGITALOCEAN_API_KEY} --password-stdin; then
    echo "ERROR: Failed to authenticate with DigitalOcean Container Registry"
    echo "Please verify:"
    echo "  1. The API token is valid and not expired"
    echo "  2. The API token has 'read' and 'write' permissions for Container Registry"
    echo "  3. The registry '${REGISTRY_NAME}' exists in your DigitalOcean account"
    echo ""
    echo "You can create/verify a token at: https://cloud.digitalocean.com/account/api/tokens"
    exit 1
fi

echo "Pushing image to DigitalOcean Container Registry..."
docker push ${LATEST_TAG}
docker push ${FULL_IMAGE_TAG}

echo "Successfully pushed image:"
echo "  - ${FULL_IMAGE_TAG}"
echo "  - ${LATEST_TAG}"
