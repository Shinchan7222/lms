# Remotion Video Composer

A Node.js application using Remotion to compose educational videos with animated intros, logo overlays, and outros.

## Features

- **Intro Section (5 seconds)**: Displays logo with 3 animated text lines (pop-in animation)
  - Main title
  - Subtitle with orange background
  - Semester info with golden background
  
- **Main Video**: Your lecture/content video with:
  - Logo overlay in top-left corner
  - Teacher name in bottom-right corner
  
- **Outro Section (5 seconds)**: Your outro/credits video

## Installation

```bash
npm install
```

## Requirements

- Node.js 18+
- FFmpeg (for video processing)
- Chromium (installed automatically by Remotion)

## Usage

```bash
node render.mjs [options]
```

### Options

| Flag | Description | Required |
|------|-------------|----------|
| `--main <path>` | Path to main lecture video | ✅ Yes |
| `--intro <path>` | Path to intro background video | No |
| `--outro <path>` | Path to outro video | No |
| `--logo <path>` | Path to logo image (PNG/JPG) | No |
| `--output <path>` | Output video path (default: ./output.mp4) | No |
| `--title <text>` | Main title text | No |
| `--subtitle <text>` | Subtitle text | No |
| `--semester <text>` | Semester text | No |
| `--teacher <text>` | Teacher name | No |
| `--fps <number>` | Frames per second (default: 30) | No |
| `--width <number>` | Video width (default: 1920) | No |
| `--height <number>` | Video height (default: 1080) | No |

### Example

```bash
node render.mjs \
  --intro ./videos/intro.mp4 \
  --main ./videos/lecture.mp4 \
  --outro ./videos/outro.mp4 \
  --logo ./assets/logo.png \
  --title "MEANING AND CHARACTERISTICS OF RESEARCH" \
  --subtitle "Research Design and Techniques" \
  --semester "SEM - 1" \
  --teacher "Prof. John Smith" \
  --output ./final_video.mp4
```

## Output

The tool will:
1. Show a 5-second intro with animated text
2. Play your main video with logo and teacher name overlay
3. Show a 5-second outro
4. Export as a single MP4 file

## Video Structure

```
[5 sec Intro] + [Main Video] + [5 sec Outro] = Final Output
```

### Intro Layout

```
┌─────────────────────────────────────┐
│            [LOGO]                   │
│                                     │
│     MAIN TITLE (white, bold)        │
│                                     │
│   ┌───────────────────────────┐     │
│   │ Subtitle (orange bg)      │     │
│   └───────────────────────────┘     │
│                                     │
│   ┌───────────────────────────┐     │
│   │ Semester (gold bg)        │     │
│   └───────────────────────────┘     │
└─────────────────────────────────────┘
```

### Main Video Layout

```
┌─────────────────────────────────────┐
│ [LOGO]                              │
│                                     │
│                                     │
│         [VIDEO CONTENT]             │
│                                     │
│                                     │
│                    [Teacher Name]   │
└─────────────────────────────────────┘
```

## License

MIT
