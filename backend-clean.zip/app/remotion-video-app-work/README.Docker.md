# Docker Setup for Remotion Video App

This project includes Dockerfiles for rendering videos and consuming the output.

## Dockerfile (Video Renderer)

The main Dockerfile builds and runs the Remotion video rendering process, outputting the video to a mounted volume on the host machine.

### Building the Image

```bash
docker build -t remotion-video-renderer .
```

### Running with Docker Compose (Recommended)

```bash
docker-compose up --build
```

This will:
1. Build the Docker image
2. Run the renderer
3. Save the output video to `./output/rendered_video.mp4` on your host machine

### Running with Docker Run

```bash
# Create output directory on host
mkdir -p ./output

# Run the container with volume mount
docker run --rm \
  -v $(pwd)/output:/app/output \
  -v $(pwd)/assets:/app/assets:ro \
  remotion-video-renderer
```

The rendered video will be available at `./output/rendered_video.mp4` on your host machine.

### Custom Parameters

You can override the default command to customize the rendering:

```bash
docker run --rm \
  -v $(pwd)/output:/app/output \
  -v $(pwd)/assets:/app/assets:ro \
  remotion-video-renderer \
  node render.mjs \
    --intro ./assets/intro.mp4 \
    --logo ./assets/logo.png \
    --title "Custom Title" \
    --subtitle "Custom Subtitle" \
    --semester "SEM - 2" \
    --output /app/output/custom_video.mp4
```

## Dockerfile.consumer (Example Consumer)

This is an example Dockerfile that consumes the rendered video file created by the first Dockerfile.

### Building the Consumer Image

First, ensure the video file exists in `./output/rendered_video.mp4`:

```bash
# Build the consumer image
docker build -f Dockerfile.consumer -t video-consumer .
```

### Running the Consumer

```bash
docker run --rm video-consumer
```

## Complete Workflow

1. **Render the video:**
   ```bash
   docker-compose up --build
   ```

2. **Verify output exists:**
   ```bash
   ls -lh ./output/rendered_video.mp4
   ```

3. **Build consumer image:**
   ```bash
   docker build -f Dockerfile.consumer -t video-consumer .
   ```

4. **Run consumer:**
   ```bash
   docker run --rm video-consumer
   ```

## Notes

- The output directory (`./output`) is mounted as a volume, so the video file is accessible on the host machine
- The assets directory is mounted as read-only to allow using different input files
- Adjust the consumer Dockerfile (`Dockerfile.consumer`) based on your specific needs for processing the video



