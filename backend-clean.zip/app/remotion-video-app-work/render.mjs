#!/usr/bin/env node

import { bundle } from '@remotion/bundler';
import { renderMedia, getCompositions } from '@remotion/renderer';
import { execSync } from 'child_process';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Copy file to public folder for Remotion to access
function copyToPublic(filePath, publicDir) {
  if (!filePath || !fs.existsSync(filePath)) {
    return '';
  }
  
  const fileName = path.basename(filePath);
  const destPath = path.join(publicDir, fileName);
  
  fs.copyFileSync(filePath, destPath);
  console.log(`Copied ${filePath} to ${destPath}`);
  
  return fileName; // Return just the filename for staticFile()
}

async function renderVideo(config) {
  const fps = config.fps || 30;
  const width = config.width || 1920;
  const height = config.height || 1080;

  console.log('🎬 Starting video composition...\n');

  // Create public directory for assets
  const publicDir = path.join(__dirname, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // Copy assets to public folder
  console.log('📁 Copying assets...');
  const introFileName = copyToPublic(config.introVideoPath, publicDir);
  const logoFileName = copyToPublic(config.logoPath, publicDir);

  // Calculate durations
  console.log('\n⏱️  Calculating video durations...');
  
  const introDurationSec = 5; // Fixed 5 seconds for intro

  console.log(`  Intro: ${introDurationSec}s`);

  const introDuration = Math.round(introDurationSec * fps);
  const totalDuration = introDuration;

  console.log(`  Total duration: ${totalDuration / fps}s (${totalDuration} frames)\n`);

  // Bundle the Remotion project
  console.log('📦 Bundling Remotion project...');
  const bundleLocation = await bundle({
    entryPoint: path.join(__dirname, 'src', 'index.tsx'),
    publicDir,
  });
  console.log('  Bundle created at:', bundleLocation);

  // Get compositions
  console.log('\n🎭 Loading compositions...');
  const compositions = await getCompositions(bundleLocation, {
    inputProps: {
      introVideoPath: introFileName || '',
      logoPath: logoFileName || '',
      title: config.title,
      subtitle: config.subtitle,
      topic: config.topic,
      semester: config.semester,
      introDuration,
    },
  });

  const composition = compositions.find((c) => c.id === 'VideoComposition');
  if (!composition) {
    throw new Error('Composition "VideoComposition" not found');
  }

  console.log('  Found composition:', composition.id);

  // Render the video
  console.log('\n🎥 Rendering video...');
  console.log('  This may take a while depending on video length...\n');

  await renderMedia({
    composition: {
      ...composition,
      durationInFrames: totalDuration,
      width,
      height,
    },
    serveUrl: bundleLocation,
    codec: 'h264',
    outputLocation: config.outputPath,
    timeoutInMilliseconds: 300000, // 5 minutes timeout (increased from default)
    inputProps: {
      introVideoPath: introFileName || '',
      logoPath: logoFileName || '',
      title: config.title,
      subtitle: config.subtitle,
      topic: config.topic,
      semester: config.semester,
      introDuration,
    },
    onProgress: ({ progress }) => {
      const percent = Math.round(progress * 100);
      process.stdout.write(`\r  Progress: ${percent}%`);
    },
  });

  console.log('\n\n✅ Video rendered successfully!');
  console.log(`📍 Output: ${config.outputPath}`);
}

// Parse command line arguments
function parseArgs() {
  const args = process.argv.slice(2);
  
  const config = {
    introVideoPath: '',
    logoPath: '',
    outputPath: './output.mp4',
    title: 'MEANING AND CHARACTERISTICS OF RESEARCH',
    subtitle: 'Research Design and Techniques',
    topic: '',
    semester: 'SEM - 1',
  };

  for (let i = 0; i < args.length; i += 2) {
    const flag = args[i];
    const value = args[i + 1];

    switch (flag) {
      case '--intro':
        config.introVideoPath = value;
        break;
      case '--logo':
        config.logoPath = value;
        break;
      case '--output':
        config.outputPath = value;
        break;
      case '--title':
        config.title = value;
        break;
      case '--subtitle':
        config.subtitle = value;
        break;
      case '--topic':
        config.topic = value;
        break;
      case '--semester':
        config.semester = value;
        break;
      case '--fps':
        config.fps = parseInt(value, 10);
        break;
      case '--width':
        config.width = parseInt(value, 10);
        break;
      case '--height':
        config.height = parseInt(value, 10);
        break;
    }
  }

  return config;
}

// Main execution
const config = parseArgs();

if (!config.introVideoPath) {
  console.log(`
╔════════════════════════════════════════════════════════════════════════════╗
║                    REMOTION INTRO VIDEO GENERATOR                          ║
╚════════════════════════════════════════════════════════════════════════════╝

Usage: node render.mjs [options]

Required:
  --intro <path>      Path to intro background video (5 sec will be shown)

Optional:
  --logo <path>       Path to logo image
  --output <path>     Output video path (default: ./output.mp4)
  --title <text>      Main title text
  --subtitle <text>   Subtitle text
  --topic <text>      Topic text (displayed as main title)
  --semester <text>   Semester text (displayed as subtitle)
  --fps <number>      Frames per second (default: 30)
  --width <number>    Video width (default: 1920)
  --height <number>   Video height (default: 1080)

Example:
  node render.mjs \\
    --intro ./intro.mp4 \\
    --logo ./logo.png \\
    --title "MEANING AND CHARACTERISTICS OF RESEARCH" \\
    --subtitle "Research Design and Techniques" \\
    --topic "Topic Name" \\
    --semester "SEM - 1" \\
    --output ./intro_video.mp4
`);
  process.exit(1);
}

renderVideo(config).catch((err) => {
  console.error('Error rendering video:', err);
  process.exit(1);
});
