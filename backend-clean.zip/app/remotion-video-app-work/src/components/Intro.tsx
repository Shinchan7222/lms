import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
  staticFile,
  OffthreadVideo,
} from 'remotion';

interface IntroProps {
  introVideoPath: string;
  logoPath: string;
  title: string;
  subtitle: string;
  topic: string;
  semester: string;
  durationInFrames: number;
}

export const Intro: React.FC<IntroProps> = ({
  introVideoPath,
  logoPath,
  title,
  subtitle,
  topic,
  semester,
  durationInFrames,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Helper to normalize path for staticFile
  const getStaticPath = (path: string) => {
    if (!path) return '';
    // Remove leading slash and any 'public/' prefix if present
    let normalized = path.startsWith('/') ? path.slice(1) : path;
    normalized = normalized.startsWith('public/') ? normalized.slice(7) : normalized;
    return staticFile(normalized);
  };

  // Pop-in animation for each text line with staggered delays
  const getPopInStyle = (delay: number) => {
    const progress = spring({
      frame: frame - delay,
      fps,
      config: {
        damping: 12,
        stiffness: 200,
        mass: 0.5,
      },
    });

    const scale = interpolate(progress, [0, 1], [0, 1]);
    const opacity = interpolate(progress, [0, 1], [0, 1]);

    return {
      transform: `scale(${scale})`,
      opacity,
    };
  };

  // Logo animation
  const logoProgress = spring({
    frame,
    fps,
    config: {
      damping: 15,
      stiffness: 100,
    },
  });

  const logoOpacity = interpolate(logoProgress, [0, 1], [0, 1]);
  const logoY = interpolate(logoProgress, [0, 1], [-50, 0]);

  // Fade out at the end (last 1 second)
  const fadeOutDuration = fps; // 1 second
  const fadeOutStart = durationInFrames - fadeOutDuration;
  const fadeOutOpacity = interpolate(
    frame,
    [fadeOutStart, durationInFrames],
    [1, 0],
    {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    }
  );

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#2d3748',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'Arial, sans-serif',
        opacity: fadeOutOpacity,
      }}
    >
      {/* Background video if provided */}
      {introVideoPath && (
        <AbsoluteFill>
          <OffthreadVideo src={getStaticPath(introVideoPath)} style={{ objectFit: 'cover', width: '100%', height: '100%' }} />
        </AbsoluteFill>
      )}

      {/* Decorative elements */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: 150,
          height: 150,
          borderRadius: '50%',
          backgroundColor: '#48bb78',
          transform: 'translate(-30%, -30%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: 50,
          right: 50,
          width: 80,
          height: 80,
          borderRadius: '50%',
          backgroundColor: '#9f7aea',
          opacity: 0.7,
        }}
      />
      <div
        style={{
          position: 'absolute',
          bottom: 0,
          left: 100,
          width: 120,
          height: 120,
          borderRadius: '50%',
          backgroundColor: '#ecc94b',
          transform: 'translateY(30%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          bottom: 50,
          right: 0,
          width: 200,
          height: 200,
          borderRadius: '50%',
          backgroundColor: '#ed8936',
          transform: 'translateX(30%)',
        }}
      />

      {/* Main content container */}
      <div
        style={{
          backgroundColor: '#4a5568',
          padding: 60,
          borderRadius: 30,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 30,
          maxWidth: '80%',
        }}
      >
        
        {/* Title - First text with pop-in */}
        <div
          style={{
            ...getPopInStyle(15),
            color: 'white',
            fontSize: 48,
            fontWeight: 'bold',
            textAlign: 'center',
            textTransform: 'uppercase',
            letterSpacing: 2,
          }}
        >
          {title}
        </div>

        {/* Subtitle - Second text with pop-in */}
        <div
          style={{
            ...getPopInStyle(30),
            backgroundColor: '#ed8936',
            color: 'white',
            fontSize: 32,
            fontWeight: 'bold',
            fontStyle: 'italic',
            padding: '12px 40px',
            borderRadius: 30,
            textAlign: 'center',
          }}
        >
          {subtitle}
        </div>

        {/* Topic - Third text with pop-in */}
        <div
          style={{
            ...getPopInStyle(45),
            backgroundColor: '#d69e2e',
            color: 'white',
            fontSize: 36,
            fontWeight: 'bold',
            padding: '15px 50px',
            borderRadius: 30,
            textAlign: 'center',
          }}
        >
          {topic}
        </div>

        {/* Semester - Fourth text with pop-in */}
        <div
          style={{
            ...getPopInStyle(60),
            backgroundColor: '#9f7aea',
            color: 'white',
            fontSize: 28,
            fontWeight: 'bold',
            padding: '12px 40px',
            borderRadius: 30,
            textAlign: 'center',
          }}
        >
          Semester {semester}
        </div>
      </div>
    </AbsoluteFill>
  );
};
