import React from 'react';
import { Intro } from './Intro';

export interface VideoCompositionProps {
  introVideoPath: string;
  logoPath: string;
  title: string;
  subtitle: string;
  topic: string;
  semester: string;
  introDuration: number; // in frames
}

export const VideoComposition: React.FC<VideoCompositionProps> = ({
  introVideoPath,
  logoPath,
  title,
  subtitle,
  topic,
  semester,
  introDuration,
}) => {
  return (
    <Intro
      introVideoPath={introVideoPath}
      logoPath={logoPath}
      title={title}
      subtitle={subtitle}
      topic={topic}
      semester={semester}
      durationInFrames={introDuration}
    />
  );
};
