import React from 'react';
import {
  AbsoluteFill,
  OffthreadVideo,
  staticFile,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';

interface OutroProps {
  outroVideoPath: string;
  durationInFrames: number;
}

export const Outro: React.FC<OutroProps> = ({ outroVideoPath, durationInFrames }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Helper to normalize path for staticFile
  const getStaticPath = (path: string) => {
    if (!path) return '';
    // Remove leading slash and any 'public/' prefix if present
    let normalized = path.startsWith('/') ? path.slice(1) : path;
    normalized = normalized.startsWith('public/') ? normalized.slice(7) : normalized;
    return staticFile(normalized);
  };

  // Fade in at the start (first 1 second)
  const fadeInDuration = fps; // 1 second
  const fadeInOpacity = interpolate(
    frame,
    [0, fadeInDuration],
    [0, 1],
    {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    }
  );

  return (
    <AbsoluteFill style={{ backgroundColor: 'black', opacity: fadeInOpacity }}>
      <OffthreadVideo
        src={getStaticPath(outroVideoPath)}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'contain',
        }}
      />
    </AbsoluteFill>
  );
};
