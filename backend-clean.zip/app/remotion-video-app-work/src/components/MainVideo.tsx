import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
  OffthreadVideo,
  staticFile,
} from 'remotion';

interface MainVideoProps {
  videoPath: string;
  logoPath: string;
  teacherName: string;
  durationInFrames: number;
}

export const MainVideo: React.FC<MainVideoProps> = ({
  videoPath,
  logoPath,
  teacherName,
  durationInFrames,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Helper to normalize path for staticFile
  const getStaticPath = (path: string) => {
    if (!path) return '';
    // Remove leading slash and any 'public/' prefix if present
    let normalized = path.startsWith('/') ? path.slice(1) : path;
    normalized = normalized.startsWith('public/') ? normalized.slice(7) : normalized;
    return staticFile(normalized);
  };

  // Fade in at the start (first 1 second)
  const fadeInDuration = fps; // 1 second
  const fadeInOpacity = interpolate(
    frame,
    [0, fadeInDuration],
    [0, 1],
    {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    }
  );

  // Fade out at the end (last 1 second)
  const fadeOutDuration = fps; // 1 second
  const fadeOutStart = durationInFrames - fadeOutDuration;
  const fadeOutOpacity = interpolate(
    frame,
    [fadeOutStart, durationInFrames],
    [1, 0],
    {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    }
  );

  // Combined opacity (fade in at start, fade out at end)
  const overallOpacity = Math.min(fadeInOpacity, fadeOutOpacity);

  // Fade in animation for overlays
  const fadeIn = spring({
    frame,
    fps,
    config: {
      damping: 20,
      stiffness: 100,
    },
  });

  const opacity = interpolate(fadeIn, [0, 1], [0, 1]);

  return (
    <AbsoluteFill style={{ backgroundColor: 'black', opacity: overallOpacity }}>
      {/* Main video - plays full duration from start */}
      {videoPath && (
        <OffthreadVideo
          src={getStaticPath(videoPath)}
          startFrom={0}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'contain',
          }}
        />
      )}

      {/* Logo overlay - top left */}
      {logoPath && (
        <div
          style={{
            position: 'absolute',
            top: 30,
            left: 30,
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            padding: '10px 20px',
            borderRadius: 8,
            opacity,
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.3)',
          }}
        >
          <Img
            src={getStaticPath(logoPath)}
            style={{
              height: 60,
              objectFit: 'contain',
            }}
          />
        </div>
      )}

      {/* Teacher name - bottom right */}
      <div
        style={{
          position: 'absolute',
          bottom: 40,
          right: 40,
          backgroundColor: 'rgba(0, 0, 0, 0.75)',
          color: 'white',
          padding: '12px 24px',
          borderRadius: 8,
          fontSize: 28,
          fontWeight: 'bold',
          fontFamily: 'Arial, sans-serif',
          opacity,
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.3)',
          borderLeft: '4px solid #ed8936',
        }}
      >
        {teacherName}
      </div>
    </AbsoluteFill>
  );
};
