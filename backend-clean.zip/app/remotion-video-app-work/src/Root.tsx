import React from 'react';
import { Composition } from 'remotion';
import { VideoComposition, VideoCompositionProps } from './components/VideoComposition';

// These will be overridden by inputProps during rendering
// Note: staticFile should be called inside components, not at module level
const defaultProps: VideoCompositionProps = {
  introVideoPath: 'intro.mp4',
  logoPath: 'logo.png',
  title: 'MEANING AND CHARACTERISTICS OF RESEARCH',
  subtitle: 'Research Design and Techniques',
  topic: '',
  semester: 'SEM - 1',
  introDuration: 150, // 5 seconds at 30fps
};

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="VideoComposition"
        component={VideoComposition as any}
        durationInFrames={150} // 5 seconds at 30fps
        fps={30}
        width={1920}
        height={1080}
        defaultProps={defaultProps}
      />
    </>
  );
};
