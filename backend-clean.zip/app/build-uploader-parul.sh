#!/bin/bash
npm install
npm run full-build
npm run buploaderprod
aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin 086614993254.dkr.ecr.ap-south-1.amazonaws.com
docker build . -t parul/uploader -f docker/parul/uploader/Dockerfile
REGION=ap-south-1
LAST_TAG=$(aws ecr describe-images --output json --repository-name parul/uploader --query 'sort_by(imageDetails,& imagePushedAt)[-1].imageTags[0]' | jq . --raw-output)
NEW_TAG=$(( LAST_TAG + 1 ))
IMAGE_URI=086614993254.dkr.ecr.ap-south-1.amazonaws.com/parul/uploader:$NEW_TAG
docker tag parul/uploader:latest $IMAGE_URI
docker push $IMAGE_URI
