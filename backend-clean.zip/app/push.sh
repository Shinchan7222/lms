aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin 086614993254.dkr.ecr.ap-south-1.amazonaws.com
docker build -t talentgood/lms .
REGION=ap-south-1
TASK_FAMILY=lms
LAST_TAG=$(aws ecr describe-images --output json --repository-name talentgood/lms --query 'sort_by(imageDetails,& imagePushedAt)[-1].imageTags[0]' | jq . --raw-output)
NEW_TAG=$(( LAST_TAG + 1 ))
IMAGE_URI=086614993254.dkr.ecr.ap-south-1.amazonaws.com/talentgood/lms:$NEW_TAG
docker tag talentgood/lms:latest $IMAGE_URI
docker push $IMAGE_URI
TASK_DEFINITION=$(aws ecs describe-task-definition --task-definition "$TASK_FAMILY" --region "$REGION")
NEW_TASK_DEFINITION=$(echo $TASK_DEFINITION | jq --arg IMAGE $IMAGE_URI '.taskDefinition | .containerDefinitions[0].image = $IMAGE | del(.taskDefinitionArn) | del(.revision) | del(.status) | del(.requiresAttributes) | del(.compatibilities) | del(.registeredAt) | del(.registeredBy) ')
NEW_TASK=$(aws ecs register-task-definition --region "$REGION" --cli-input-json "$NEW_TASK_DEFINITION")
NEW_REVISION=$(echo $NEW_TASK | jq '.taskDefinition.revision')
aws ecs update-service --cluster LMS --service lms --task-definition ${TASK_FAMILY}:${NEW_REVISION}
